package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetStreamList
 */
@WebServlet("/GetStreamList")
public class GetStreamList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetStreamList() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		// 設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			System.out.println(json);

			URL = json.get("conn_url").textValue();
			USER = json.get("conn_user").textValue();
			PASS = json.get("conn_pass").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		StreamListDto dto = new StreamListDto();
		
		String  publisher_type = request.getParameter("publisher_type"); 

		try {
			
			int type = Integer.parseInt(publisher_type);

			if (ReadDB(type,out, dto) == 0) {
				dto.setResult("OK");
			} else {
				dto.setResult("NG");
			}
		}catch(Exception ex){
			dto.setResult("NG");
			dto.setMessage(ex.toString());
		}

		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();
		log("End");

	}

	public int ReadDB(int type,PrintWriter out, StreamListDto dto) {

		int ret = -1;

		String SQL = "";

		SQL = "select * from TBWG0011 WHERE publisher_type="+type;
		dto.setSql(SQL);

		log(SQL);

		List<StreamListBean> jsonList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;
					String publisher_id = rs.getNString("publisher_id");
					int publisher_type = rs.getInt("publisher_type");
					String publisher_src_name = rs.getNString("publisher_src_name");
					String termId = rs.getNString("termId");
					String team = rs.getNString("team");
					Date update = rs.getDate("UPDATE_DATE");

					StreamListBean jsonBean = new StreamListBean();

					jsonBean.setPublisher_id(publisher_id);
					;
					jsonBean.setPublisher_type(publisher_type);
					jsonBean.setPublisher_src_name(publisher_src_name);
					jsonBean.setTermId(termId);
					jsonBean.setTeam(team);
					if (update != null) {
						String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(update);
						jsonBean.setUpdate_date(str);
					}

					jsonList.add(jsonBean);
				}
				dto.setData(jsonList);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

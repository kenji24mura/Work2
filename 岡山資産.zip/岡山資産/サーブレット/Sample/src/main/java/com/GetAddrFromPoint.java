package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetAddrFromPoint
 */
@WebServlet("/GetAddrFromPoint")
public class GetAddrFromPoint extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";

//	final String URL = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";
//	final String URL = "jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	final String USER = "WEBGIS";
//	final String PASS = "WEBGIS";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAddrFromPoint() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin","*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();

		ObjectMapper mapper = new ObjectMapper();
		PointDto dto = new PointDto();
		
		String strX = request.getParameter("lx");
		String strY = request.getParameter("ly");
		String strLen = request.getParameter("len");
		
		if(strX != null & strY != null & strLen != null) {

			int lx=0;
			int ly=0;
			int len = 10;//(10m)
			
			lx = (int)Double.parseDouble(strX);
			ly = (int)Double.parseDouble(strY);
			len = Integer.parseInt(strLen)*1000;

			//if(ReadDB(lx,ly,len,out)<0) {
				//len = 100000;//(100m)
			ReadDB(lx,ly,len,out,dto);
			//};
			dto.setResult("OK");
		}else {
			dto.setResult("NG");
			dto.setMessage("request parameter is null.");
		}

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			System.out.println(e.toString());
		}
		
		out.flush();
		
	}

	public int  ReadDB(int lx,int ly,int len,PrintWriter out,PointDto dto) {
		
		int ret=-1;
		
		
		String SQL="";
		SQL += "select * from TBWG0024 WHERE ( zx BETWEEN ? AND ? ) AND (zy BETWEEN ? AND ?) ";
		System.out.println(SQL);
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {
			
			
			ps.setInt(1, lx-len);
			ps.setInt(2, lx+len);
			ps.setInt(3, ly-len);
			ps.setInt(4, ly+len);
			
			
			String log = "select * from TBWG0024 WHERE ( zx BETWEEN "+(lx-len)+ "AND"+(lx+len)+" ) AND (zy BETWEEN " +(ly-len)+" AND "+(ly+len)+") ";
			
			System.out.println(log);

			try (ResultSet rs = ps.executeQuery()) {

				List<JsonPointBean> jsonList = new ArrayList<>();

				//if (rs.next()) {
				while (rs.next()) {
					
					JsonPointBean jsonBean = new JsonPointBean();

					int prifval = rs.getInt("prif");
					int cityval = rs.getInt("city");
					int town1val = rs.getInt("town1");
					int town2val = rs.getInt("town2");
					int zxval = rs.getInt("zx");
					int zyval = rs.getInt("zy");
					double lonval= rs.getDouble("lon");
					double latval= rs.getDouble("lat");
					String nameval = rs.getString("name");
					String kanaval = rs.getString("kana");

					jsonBean.setPrif(prifval);
					jsonBean.setCity(cityval);
					jsonBean.setTown1(town1val);
					jsonBean.setTown2(town2val);
					jsonBean.setZx(zxval);
					jsonBean.setZy(zyval);
					jsonBean.setLon(lonval);
					jsonBean.setLat(latval);
					jsonBean.setName(nameval);
					jsonBean.setKana(kanaval);

					jsonList.add(jsonBean);

					ret = 0;
					
					//out.println(prifval+","+cityval+","+town1val+","+town2val+","+nameval);
				}
				dto.setData(jsonList);
				dto.setResult("OK");
			}
		} catch (SQLException e) {
			ret =-1;
			System.out.println(e.toString());
		} catch (Exception e) {
			ret =-1;
			System.out.println(e.toString());
		} finally {

		}
		
	//	ObjectMapper mapper = new ObjectMapper();
		//try {
			//String jsonData = mapper.writeValueAsString(dto);
			//out.write(jsonData);
			//ret = 0;
		//} catch (JsonProcessingException e) {
			//ret = -1;
		//}
		
		return ret;
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

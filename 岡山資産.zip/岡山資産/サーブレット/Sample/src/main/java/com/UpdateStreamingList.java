package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class UpdateStreaminList
 */
@WebServlet("/UpdateStreamingList")
public class UpdateStreamingList extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateStreamingList() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			System.out.println(json);

			URL = json.get("conn_url").textValue();
			USER = json.get("conn_user").textValue();
			PASS = json.get("conn_pass").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();

		String publisher_id = request.getParameter("publisher_id");
		String publisher_name = request.getParameter("publisher_name");
		String broadcast_name = request.getParameter("broadcast_name");
		String publish_status = request.getParameter("publish_status");
		String registered = request.getParameter("registered");
		String devices = request.getParameter("devices");
		String start_date = request.getParameter("start_date");
		String end_date = request.getParameter("end_date");

		String SQL;

		SQL = "select * from TBWG0010 where publisher_id ='" + publisher_id + "'";

		System.out.println(SQL);

		Boolean isExit = false;

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				String item_no = rs.toString();

				if (rs.next()) {
					isExit = true;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("処理が完了しました");
		}

		if (isExit == true) {
			ModRec(publisher_id, publisher_name, broadcast_name, publish_status, registered, devices, start_date,
					end_date);
		} else {
			AddRec(publisher_id, publisher_name, broadcast_name, publish_status, registered, devices, start_date,
					end_date);
		}

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public int AddRec(String publisher_id, String publisher_name, String broadcast_name, String publish_status,
			String registered, String devices, String start_date, String end_date) {

		int ret = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "insert into  TBWG0010(publisher_id,publisher_name,broadcast_name,publish_status,registered,devices,start_date,end_date) ";
			sql += "values (?,?,?,?,?,?,TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'),TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'))";

			System.out.println(sql);

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, publisher_id);
			pstmt.setString(2, publisher_name);
			pstmt.setString(3, broadcast_name);
			pstmt.setString(4, publish_status);
			pstmt.setString(5, registered);
			pstmt.setString(6, devices);
			pstmt.setString(7, start_date);
			pstmt.setString(8, end_date);

			pstmt.executeUpdate();
			conn.commit();

		} catch (

		SQLException e) {
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}
		return ret;

	}

	public int ModRec(String publisher_id, String publisher_name, String broadcast_name, String publish_status,
			String registered, String devices, String start_date, String end_date) {
		int ret = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "update TBWG0010 set publisher_id=?,publisher_name=?,broadcast_name=?,publish_status=?,registered=?,devices=?,start_date=TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'),end_date=TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS')";
			sql += " where  publisher_id=? ";

			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, publisher_id);
			pstmt.setString(2, publisher_name);
			pstmt.setString(3, broadcast_name);
			pstmt.setString(4, publish_status);
			pstmt.setString(5, registered);
			pstmt.setString(6, devices);
			pstmt.setString(7, start_date);
			pstmt.setString(8, end_date);
			pstmt.setString(9, publisher_id);

			pstmt.executeUpdate();
			conn.commit();

		} catch (

		SQLException e) {
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}

		return ret;

	}
}

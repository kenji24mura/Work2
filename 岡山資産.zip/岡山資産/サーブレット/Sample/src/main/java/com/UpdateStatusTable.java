package com;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class UpdateStatusTable
 */
@WebServlet("/UpdateStatusTable")
public class UpdateStatusTable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateStatusTable() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setHeader("Access-Control-Allow-Methods", "POST, PUT, PATCH, GET, DELETE, OPTIONS"); // CROS対策
		response.setHeader("Access-Control-Allow-Headers",
				"Origin, X-Api-Key, X-Requested-With, Content-Type, Accept, Authorization"); // CROS対策
		response.setCharacterEncoding("utf-8");
		
		/*
		String reqBuf=" {\"jiancode\":\"aaaaaa\",\"suiriinfo\":[{\"suiriCode\":\"11135 H 553 \",\"hasMyCar\":1,\"suiriKahi\":0,\"suiriStatusCode\":0,\"busyoCarNum\":0,\"hasSitei\":1,\"busyoMax\":0,\"jointCarCode1\":\"0101\",\"jointCarCode2\":\"0202\",\"carcode\":[\"0301\",\"0401\",\"0501\",\"0601\",\"0701\"]}]}";
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode json = objectMapper.readTree(reqBuf);

		JsonNode jn = json.get("jiancode");
		
		String jiancode = json.get("jiancode").textValue();

		//int carcd = json.get("carcd").intValue();

		int len = json.get("suiriinfo").size();
		
		int i=0;
		
		String suiriCode = json.get("suiriinfo").get(i).get("suiriCode").textValue();
		int hasMyCar = json.get("suiriinfo").get(i).get("hasMyCar").intValue();
		int suiriKahi = json.get("suiriinfo").get(i).get("suiriKahi").intValue();
		int suiriStatusCode = json.get("suiriinfo").get(i).get("suiriStatusCode").intValue();
		int busyoCarNum = json.get("suiriinfo").get(i).get("busyoCarNum").intValue();
		int hasSitei = json.get("suiriinfo").get(i).get("hasSitei").intValue();
		int busyoMax = json.get("suiriinfo").get(i).get("busyoMax").intValue();
		String jointCarCode1 = json.get("suiriinfo").get(i).get("jointCarCode1").textValue();
		String jointCarCode2 = json.get("suiriinfo").get(i).get("jointCarCode2").textValue();
//		String carcode = json.get("suiriinfo").get(i).get("carcode").textValue();
		
		JsonNode jcar = json.get("suiriinfo").get(i).get("carcode");
		
		List<String> lists =
				  StreamSupport.stream(jcar.spliterator(), false)
				    .map(
				      e -> {
				        return e.asText(); // Stringに変換
				    })
				    .collect(Collectors.toList());
		
		System.out.println(jiancode);
		//System.out.println(carcd);
		System.out.println(hasMyCar);
		System.out.println(suiriStatusCode);
		System.out.println(jointCarCode1);
		System.out.println(jointCarCode2);
		//System.out.println(carcode);
		
		System.out.println(lists.size());
		
		for(int j=0;j<lists.size();j++) {
			System.out.println(lists.get(j));
		}
*/
		//PrintWriter out = response.getWriter();
		//out.write("0000");
		//out.flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		
		log("START");
		
		request.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();

		// 送信されたJSONの取得
		try {
			BufferedReader buffer = new BufferedReader(request.getReader());
			String reqBuf = buffer.readLine();
			
			//int buflen = reqBuf.length();
			//System.out.println(buflen);
			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode json = objectMapper.readTree(reqBuf);
			
			log(reqBuf);
			
			JsonNode jn = json.get("jiancode");
			
			System.out.println(jn);
			
			if(jn==null) {
				
				log("事案番号 null");
				
				System.out.println("jsonは空");
				int carcd = json.get("carcd").intValue();
				System.out.println(carcd);
				
				
				//202030731 いったんDBは残す
				//
				//DelRec(carcd);
				
			}else {
				String jiancode = json.get("jiancode").textValue();
				System.out.println(jiancode);

				log("事案番号="+jiancode);

				int carcd = json.get("carcd").intValue();
				System.out.println(carcd);

				log("carcd="+carcd);

				int len = json.get("suiriinfo").size();
				System.out.println(len);
				log("suiriinfo len="+len);

				for (int i = 0; i < len; i++) {
					String suiriCode = json.get("suiriinfo").get(i).get("suiriCode").textValue();

					log("suiriCode="+suiriCode);
					
					int hasMyCar = json.get("suiriinfo").get(i).get("hasMyCar").intValue();
					log("hasMyCar="+hasMyCar);
					int suiriKahi = json.get("suiriinfo").get(i).get("suiriKahi").intValue();
					log("suiriKahi="+suiriKahi);
					int suiriStatusCode = json.get("suiriinfo").get(i).get("suiriStatusCode").intValue();
					log("suiriStatusCode="+suiriStatusCode);
					int busyoCarNum = json.get("suiriinfo").get(i).get("busyoCarNum").intValue();
					log("busyoCarNum="+busyoCarNum);
					int hasSitei = json.get("suiriinfo").get(i).get("hasSitei").intValue();
					log("hasSitei="+hasSitei);
					int busyoMax = json.get("suiriinfo").get(i).get("busyoMax").intValue();
					log("busyoMax="+busyoMax);
					String jointCarCode1 = json.get("suiriinfo").get(i).get("jointCarCode1").textValue();
					log("jointCarCode1="+jointCarCode1);
					String jointCarCode2 = json.get("suiriinfo").get(i).get("jointCarCode2").textValue();
					log("jointCarCode2="+jointCarCode2);
					
					JsonNode jcar = json.get("suiriinfo").get(i).get("carCode");
					log("jcar="+jcar);
					
					List<String> listcarcode =
							  StreamSupport.stream(jcar.spliterator(), false)
							    .map(
							      e -> {
							        return e.asText(); // Stringに変換
							    })
							    .collect(Collectors.toList());


					UpdateData(jiancode, carcd, suiriCode, suiriKahi, suiriStatusCode, jointCarCode1, jointCarCode2,
							busyoMax, busyoCarNum, hasMyCar, hasSitei, listcarcode);

				}
				out.write("0000");
			}
		} catch (Exception e) {
			out.write("9999");
			e.printStackTrace();
			out.write(e.toString());
			log(e.toString());

		}

		doGet(request, response);
		
		out.flush();
		
		log("END");

	}

	private void UpdateData(String jiancode, int carcd, String suiriCode, int suiriKahi, int suiriStatusCode,
			String jointCarCode1, String jointCarCode2, int busyoMax, int busyoCarNum,
			int hasMyCar, int hasSitei, List<String> listcarcode) {

		String SQL = "";
		ObjectMapper objectMapper = new ObjectMapper();

		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			System.out.println(json);

			URL = json.get("conn_url").textValue();
			USER = json.get("conn_user").textValue();
			PASS = json.get("conn_pass").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		SQL = "select * from TBWG0009_N where termId =" + carcd + "  and jisiki = '" + jiancode + "'  and suiricode = '"
				+ suiriCode + "'";

		System.out.println(SQL);

		Boolean isExit = false;

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				String item_no = rs.toString();

				if (rs.next()) {
					isExit = true;
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("処理が完了しました");
		}

		if (isExit == true) {
			ModRec(jiancode, carcd, suiriCode, suiriKahi, suiriStatusCode, jointCarCode1, jointCarCode2, busyoMax,
					busyoCarNum, hasMyCar, hasSitei, listcarcode);
		} else {
			AddRec(jiancode, carcd, suiriCode, suiriKahi, suiriStatusCode, jointCarCode1, jointCarCode2, busyoMax,
					busyoCarNum, hasMyCar, hasSitei, listcarcode);
		}
	}

	public int AddRec(String jiancode, int carcd, String suiriCode, int suiriKahi, int suiriStatusCode,
			String jointCarCode1, String jointCarCode2, int busyoMax, int busyoCarNum,
			int hasMyCar, int hasSitei, List<String> listcarcode) {

		int ret = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "insert into  TBWG0009_N(termId,jisiki,suiriCode,suiriKahi,suiriStatusCode,jointCarCode1,jointCarCode2,busyoMax,busyoCarNum,hasMyCar,hasSitei,carCode,update_date) ";
			sql += "values (?,?,?,?,?,?,?,?,?,?,?,?,TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'))";

			System.out.println(sql);

			//		termId,jisiki,suiriCode,suiriKahi,suiriStatusCode,jointCarCode1,jointCarCode2,busyoMax,busyoCarNum,hasMyCar,hasSite,underBusho,			

			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, carcd);
			pstmt.setString(2, jiancode);
			pstmt.setString(3, suiriCode);
			pstmt.setInt(4, suiriKahi);
			pstmt.setInt(5, suiriStatusCode);
			pstmt.setString(6, jointCarCode1);
			pstmt.setString(7, jointCarCode2);
			pstmt.setInt(8, busyoMax);
			pstmt.setInt(9, busyoCarNum);
			pstmt.setInt(10, hasMyCar);
			pstmt.setInt(11, hasSitei);
			
			String carCode ="";
			
			for(int j=0;j<listcarcode.size();j++) {
				if(j>0) {
					carCode += ",";
				}
				carCode += listcarcode.get(j);
			}
			
			pstmt.setString(12, carCode);
			pstmt.setString(13, update_date);

			pstmt.executeUpdate();
			conn.commit();

		} catch (

		SQLException e) {
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}
		return ret;

	}

	public int ModRec(String jiancode, int carcd, String suiriCode, int suiriKahi, int suiriStatusCode,
			String jointCarCode1, String jointCarCode2, int busyoMax, int busyoCarNum,
			int hasMyCar, int hasSitei, List<String> listcarcode) {
		int ret = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "update  TBWG0009_N set termId=?,jisiki=?,suiriCode=?,suiriKahi=?,suiriStatusCode=?,jointCarCode1=?,jointCarCode2=?,busyoMax=?,busyoCarNum=?,hasMyCar=?,hasSitei=?,carCode=? ,update_date=TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS')";
			sql += "where   termId=? and jisiki=? and suiriCode=?";

			//			sql += "update  TBWG0008 set suiriCode=? ";
			//			sql += "where termId=? and jisiki=? and suiriCode=? ";
			//			sql += "where termId=?";

			System.out.println(sql);
			pstmt = conn.prepareStatement(sql);

			pstmt.setInt(1, carcd);
			pstmt.setString(2, jiancode);
			pstmt.setString(3, suiriCode);

			pstmt.setInt(4, suiriKahi);
			pstmt.setInt(5, suiriStatusCode);
			pstmt.setString(6, jointCarCode1);
			pstmt.setString(7, jointCarCode2);
			pstmt.setInt(8, busyoMax);
			pstmt.setInt(9, busyoCarNum);
			pstmt.setInt(10, hasMyCar);
			pstmt.setInt(11, hasSitei);
			
			String carCode ="";
			
			for(int j=0;j<listcarcode.size();j++) {
				if(j>0) {
					carCode += ",";
				}
				carCode += listcarcode.get(j);
			}

			
			pstmt.setString(12, carCode);
			pstmt.setString(13, update_date);

			pstmt.setInt(14, carcd);
			pstmt.setString(15, jiancode);
			pstmt.setString(16, suiriCode);

			pstmt.executeUpdate();
			conn.commit();

		} catch (

		SQLException e) {
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}

		return ret;

	}
	public int DelRec(int carcd) {
		int ret = 0;
		try {

			//設定ファイル読み込み処理
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				JsonNode json = objectMapper
						.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
				System.out.println(json);

				URL = json.get("conn_url").textValue();
				USER = json.get("conn_user").textValue();
				PASS = json.get("conn_pass").textValue();
			} catch (Exception e) {
				e.printStackTrace();
			}

			Connection conn = null;
			PreparedStatement pstmt = null;


			String sql = "";

			sql += "delete from TBWG0009_N";
			sql += " Where termId=? ";

			try {

				conn = DriverManager.getConnection(URL, USER, PASS);
				conn.setAutoCommit(false); // オートコミットはオフ

				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, carcd);

				pstmt.executeUpdate();
				conn.commit();

			} catch (SQLException e) {
				e.printStackTrace();
				ret = -1;
			} finally {
			}
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
					ret = -1;
				}
			} catch (SQLException ex) {
			}
			try {
				if (conn != null) {
					conn.close();
					conn = null;
					ret = -1;
				}
			} catch (SQLException ex) {
				ret = -1;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			ret = -1;
		}
		
		return ret;
	}
}

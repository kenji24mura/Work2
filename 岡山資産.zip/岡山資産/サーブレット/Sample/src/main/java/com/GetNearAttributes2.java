package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetNearAttributes2
 */
@WebServlet("/GetNearAttributes2")
public class GetNearAttributes2 extends HttpServlet {
  private static final long serialVersionUID = 1L;

  String URL = "";
  String USER = "";
  String PASS = "";
  // 20240130 start
  int kijyunkei = 6;
  // 20240130 end

  /**
   * @see HttpServlet#HttpServlet()
   */
  public GetNearAttributes2() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html");
    response.setHeader("Cache-Control", "nocache");
    response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
    response.setCharacterEncoding("utf-8");

    // 20240130 start
    String coordinate = request.getParameter("coordinate");
    if (coordinate == null) {
    } else {
      kijyunkei = Integer.parseInt(coordinate);
    }
    // 20240130 end

    // 設定ファイル読み込み処理
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      JsonNode json = objectMapper.readTree(
          Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
      System.out.println(json);
      
      kijyunkei= Integer.parseInt(json.get("coordinate").textValue());

      URL = json.get("conn_url").textValue();
      USER = json.get("conn_user").textValue();
      PASS = json.get("conn_pass").textValue();
    } catch (Exception e) {
      e.printStackTrace();
    }

    PrintWriter out = response.getWriter();
    MiddleDto dto = new MiddleDto();

    try {

      // 中心座標x(lon)
      // 中心座標y(lat)
      // 検索範囲(m)
      // 対象レイヤ

      String s_lon = request.getParameter("lon");
      String s_lat = request.getParameter("lat");
      String s_radius = request.getParameter("radius");
      String lay_no_tbl[] = request.getParameterValues("lay_no");

      System.out.println(lay_no_tbl);

      System.out.println(s_lon);
      System.out.println(s_lat);
      System.out.println(s_radius);


      double lon = 0.0;
      double lat = 0.0;
      int radius = 0;

      if (s_lon != null) {
        lon = Double.parseDouble(s_lon);
      }
      if (s_lat != null) {
        lat = Double.parseDouble(s_lat);
      }
      if (s_radius != null) {
        radius = Integer.parseInt(s_radius);
      }

      MapConvert mc = new MapConvert();

      // 20240130 コメント
      // int kijyunkei = 6;

      int xy[] = new int[2];

      mc.ConvertPos2(lon, lat, kijyunkei, xy);

      System.out.println(xy[0] + "," + xy[1]);

      int minx = xy[0] - radius * 1000;
      int miny = xy[1] - radius * 1000;
      int maxx = xy[0] + radius * 1000;
      int maxy = xy[1] + radius * 1000;

      double min_lonlat[] = new double[2];
      mc.ConvertPos(minx, miny, kijyunkei, min_lonlat);

      double max_lonlat[] = new double[2];
      mc.ConvertPos(maxx, maxy, kijyunkei, max_lonlat);

      System.out.println("min:" + min_lonlat[0] + "," + min_lonlat[1]);
      System.out.println("max:" + max_lonlat[0] + "," + max_lonlat[1]);

      ReadDB(lay_no_tbl, min_lonlat[0], min_lonlat[1], max_lonlat[0], max_lonlat[1], dto);

    } catch (Exception e) {
      e.printStackTrace();
      dto.setMessage(e.toString());
      dto.setResult("NG");
    } finally {
    }

    ObjectMapper mapper = new ObjectMapper();

    try {
      String jsonData = mapper.writeValueAsString(dto);
      out.write(jsonData);
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    out.flush();

  }

  public int ReadDB(String[] lay_no_tbl, double min_lon, double min_lat, double max_lon,
      double max_lat, MiddleDto dto) {

    int ret = -1;
    String SQL = "";
    int info_value = 0;

    SQL +=
        "select lay_no,item_no,item_no2,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y  from TBWG0001 WHERE ( zahyo_x BETWEEN "
            + min_lon + " AND " + max_lon + " ) AND ( zahyo_y BETWEEN " + min_lat + " AND "
            + max_lat + " ) ";

    if (lay_no_tbl.length > 0) {
      SQL += " AND (";

      for (int i = 0; i < lay_no_tbl.length; i++) {
        if (i > 0) {
          SQL += " OR ";
        }
        // SQL += "lay_type='"+ lay_no_tbl[i]+"'";

        info_value = GetInfoValue(lay_no_tbl[i]);
        SQL += " info_type=" + info_value;

      }
      SQL += " )";
    }

    SQL += " UNION ALL ";
    SQL +=
        "select  lay_no,item_no,item_no2,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y   from TBWG0002 WHERE ( zahyo_x BETWEEN "
            + min_lon + " AND " + max_lon + " ) AND ( zahyo_y BETWEEN " + min_lat + " AND "
            + max_lat + " ) ";
    if (lay_no_tbl.length > 0) {
      SQL += " AND (";

      for (int i = 0; i < lay_no_tbl.length; i++) {
        if (i > 0) {
          SQL += " OR ";
        }
        // SQL += " lay_type='"+ lay_no_tbl[i]+"'";
        info_value = GetInfoValue(lay_no_tbl[i]);
        SQL += " info_type=" + info_value;
      }
      SQL += " )";
    }

    dto.setSql(SQL);

    List<MiddleBean> jsonList = new ArrayList<>();


    try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

          ret = 0;

          MiddleBean bean = new MiddleBean();

          String lay_no = rs.getString("LAY_NO");
          String item_no = rs.getString("ITEM_NO");
          String item_no2 = rs.getString("ITEM_NO2");
          int info_type = rs.getInt("INFO_TYPE");
          String info_summery = rs.getString("INFO_SUMMERY");
          int lay_type = rs.getInt("LAY_TYPE");
          int symbol_no = rs.getInt("SYMBOL_NO");
          Double zahyo_x = rs.getDouble("ZAHYO_X");
          Double zahyo_y = rs.getDouble("ZAHYO_Y");
          bean.setLay_no(lay_no);


          // 2023.08.05 start

          String w_item_no = item_no;
          if (info_type == 16 && lay_type == 1) {
            w_item_no = item_no2;
          }

          boolean IsHit = false;

          for (int i = 0; i < jsonList.size(); i++) {
            if (lay_no.indexOf(jsonList.get(i).getLay_no()) == 0
                && w_item_no.indexOf(jsonList.get(i).getItem_no()) == 0) {
              IsHit = true;
              break;
            }
          }

          if (IsHit == false) {
            bean.setItem_no(w_item_no);
            bean.setItem_no2(item_no2);
            bean.setInfo_type(info_type);
            bean.setInfo_summery(info_summery);
            bean.setLay_type(lay_type);
            bean.setSymbol_no(symbol_no);
            bean.setZahyo_x(zahyo_x);
            bean.setZahyo_y(zahyo_y);

            jsonList.add(bean);
          }
          // 2023.08.05 end
        }
        dto.setData(jsonList);
        dto.setMessage("検索処理が完了しました");
      }
    } catch (SQLException e) {
      e.printStackTrace();
      dto.setMessage(e.toString());
      System.out.println(e.toString());
      ret = 1;
    } catch (Exception e) {
      e.printStackTrace();
      dto.setMessage(e.toString());
      System.out.println(e.toString());
      ret = 1;
    } finally {
      System.out.println("処理が完了しました");
    }

    return ret;
  }

  private int GetInfoValue(String lay_no) {
    int ret = -1;

    String[] lay_no_tbl = {"n@1-1", "n@2-1", "n@3-1", "n@4-1", "n@5-1", "n@6-1", "n@7-1", "n@8-1",
        "n@9-1", "n@10-1", "n@11-1", "n@12-1", "n@13-1", "n@14-1", "n@15-1", "n@16-1", "n@17-1",
        "n@18-1", "n@19-1"};

    for (int i = 0; i < lay_no_tbl.length; i++) {
      if (lay_no_tbl[i].indexOf(lay_no) >= 0) {
        ret = i + 1;
        break;
      }
    }
    return ret;
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}

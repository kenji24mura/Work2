package com;

import java.util.List;

public class CarDto {
	 private String result;
	 private String message;
	private List<JsonCarBean> data;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<JsonCarBean> getData() {
		return data;
	}
	public void setData(List<JsonCarBean> data) {
		this.data = data;
	}

}

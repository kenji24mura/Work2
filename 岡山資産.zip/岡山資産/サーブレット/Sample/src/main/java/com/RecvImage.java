package com;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class RecvImage
 */
@WebServlet("/RecvImage")
public class RecvImage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String IMG_PATH="";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecvImage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  envobjectMapper = new ObjectMapper();
		try {
	        JsonNode json = envobjectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        IMG_PATH = json.get("image_path").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		// 送信されたJSONの取得
		BufferedReader buffer = new BufferedReader(request.getReader());
		String reqBuf = buffer.readLine();

		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode json = objectMapper.readTree(reqBuf);

		String method = json.get("method").textValue(); 
		String filename = json.get("filename").textValue();
		String headers = json.get("headers").textValue();
		String body = json.get("body").textValue();

		System.out.println(method);
		System.out.println(filename);
		System.out.println(headers);
		System.out.println(body);

		String[] values = body.split(",");

		String imgString = values[1].replace("\"}", "");
		System.out.println(imgString);

		//デコード処理
		byte[] bytes = Base64.getDecoder().decode(imgString.getBytes());
		
		try {
			FileOutputStream file = new FileOutputStream(IMG_PATH + filename);
			file.write(bytes);
			file.close();
			response.getWriter().append(file.toString());
		} catch (Exception ex) {
			response.getWriter().append(ex.toString());
		}
		doGet(request, response);
	}

}

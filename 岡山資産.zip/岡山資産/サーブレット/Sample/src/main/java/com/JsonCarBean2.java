package com;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonCarBean2 {
	@JsonProperty("car_cd")
	 private String car_cd;
	@JsonProperty("houko")
	 private String houko;
	@JsonProperty("dotai")
	 private int dotai;
	@JsonProperty("symbolid")
	 private int symbolid;
	@JsonProperty("zx")
	 private double zx;
	@JsonProperty("zy")
	 private double zy;
	private String car_nm;
	private String doutai_nm;
	private String cartype_nm;
	private String update_date;
	
	public String getCar_cd() {
		return car_cd;
	}
	public void setCar_cd(String car_cd) {
		this.car_cd = car_cd;
	}
	public String getHouko() {
		return houko;
	}
	public void setHouko(String houko) {
		this.houko = houko;
	}
	public double getZx() {
		return zx;
	}
	public void setZx(double zx) {
		this.zx = zx;
	}
	public double getZy() {
		return zy;
	}
	public void setZy(double zy) {
		this.zy = zy;
	}
	public void setDotai(int dotai) {
		// TODO 自動生成されたメソッド・スタブ
		this.dotai = dotai;
	}
	public int getSymbolid() {
		return symbolid;
	}
	public void setSymbolid(int symbolid) {
		this.symbolid = symbolid;
	}
	public String getCar_nm() {
		return car_nm;
	}
	public void setCar_nm(String car_nm) {
		this.car_nm = car_nm;
	}
	public String getDoutai_nm() {
		return doutai_nm;
	}
	public void setDoutai_nm(String doutai_nm) {
		this.doutai_nm = doutai_nm;
	}
	public String getCartype_nm() {
		return cartype_nm;
	}
	public void setCartype_nm(String cartype_nm) {
		this.cartype_nm = cartype_nm;
	}
	public String getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}
}

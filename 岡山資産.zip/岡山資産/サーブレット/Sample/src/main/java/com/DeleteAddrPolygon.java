package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class DeleteAddrPolygon
 */
@WebServlet("/DeleteAddrPolygon")
public class DeleteAddrPolygon extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";

//	private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";
//	private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	private String conn_user = "WEBGIS";
//	private String conn_pass = "WEBGIS";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteAddrPolygon() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		
		try {
			int prif = Integer.parseInt(request.getParameter("prif"));
			int city = Integer.parseInt(request.getParameter("city"));
			int town1 = Integer.parseInt(request.getParameter("town1"));
			int town2 = Integer.parseInt(request.getParameter("town2"));
			DeletePolygon(prif, city, town1, town2, out);

		} catch (Exception e) {
			e.printStackTrace();
			out.println(e.toString());
		} finally {
//		out.println("処理が完了しました<br>");
		}

		out.println("処理が完了しました<br>");
		out.flush();
			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	public int DeletePolygon(int m_prif, int m_city, int m_town1, int m_town2,PrintWriter out) {

		int ret = 0;

//		final String URL = conn_str;
//		final String USER = conn_user;
//		final String PASS = conn_pass;

		String SQL = "";
		
		SQL = "delete from TBWG0007 WHERE ";
		SQL += "prif=" + m_prif;
		SQL += "AND city=" + m_city;
		SQL += "AND town1=" + m_town1;
		SQL += "AND town2=" + m_town2;

		try {

			out.println(SQL);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);

			Statement stmt = conn.createStatement();

			int num = stmt.executeUpdate(SQL);
			out.println(num);
			
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			//out.println("処理が完了しました<br>");
		}
		return ret;

	}
}

package com;
import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonPointBean {
    @JsonProperty("prif")
    private int prif;
    @JsonProperty("city")
    private int city;
    @JsonProperty("town1")
    private int town1;
    @JsonProperty("town2")
    private int town2;
    @JsonProperty("zx")
    private int zx;
    @JsonProperty("zy")
    private int zy;

    private double lon;
    private double lat;

    @JsonProperty("name")
    private String name;

    @JsonProperty("kana")
    private String kana;

    
    public void setPrif(int prif) {
		this.prif = prif;
	}
    public void setCity(int city) {
		this.city = city;
	}
    public void setTown1(int town1) {
		this.town1 = town1;
	}
    public void setTown2(int town2) {
		this.town2 = town2;
	}
    public void setZx(int zx) {
		this.zx = zx;
	}
    public void setZy(int zy) {
		this.zy = zy;
	}

	public void setName(String name) {
        this.name = name;
    }

	public void setKana(String kana) {
        this.kana = kana;
    }
	public double getLon() {
		return lon;
	}
	public void setLon(double lon) {
		this.lon = lon;
	}
	public double getLat() {
		return lat;
	}
	public void setLat(double lat) {
		this.lat = lat;
	}


}

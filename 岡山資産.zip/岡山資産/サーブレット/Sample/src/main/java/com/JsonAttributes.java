package com;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonAttributes {
    @JsonProperty("key")
    private String key;
    @JsonProperty("value")
    private String value;
    public void setKey(String key) {
 		this.key = key;
 	}
    public void setValue(String value) {
 		this.value = value;
 	}
}

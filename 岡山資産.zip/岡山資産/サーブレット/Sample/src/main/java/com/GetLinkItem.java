package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetLinkItem
 */
@WebServlet("/GetLinkItem")
public class GetLinkItem extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetLinkItem() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		//設定ファイル読み込み処理
		
		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin","*"); //CROS対策
		response.setCharacterEncoding("utf-8");
		
		
		PrintWriter out = response.getWriter();
		
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
	        
	        
			String lay_no = request.getParameter("lay_no");
			String item_no = request.getParameter("item_no");
			
			String result = ReadDB(lay_no,item_no);
			
			out.write(result);
			out.flush();

	        
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String ReadDB(String lay_no,String item_no) {

		String ret ="";
		String SQL = "";
		
			SQL += "select * from TBWG0001";
			SQL += " where lay_no='" + lay_no + "'";
			SQL += " AND item_no='" + item_no + "'";
			
			System.out.println(SQL);

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					String item_no2 = rs.getString("ITEM_NO2");

					ret = item_no2;
					
					System.out.println(ret);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

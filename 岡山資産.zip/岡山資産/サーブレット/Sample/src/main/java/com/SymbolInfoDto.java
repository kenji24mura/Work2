package com;

import java.util.List;

public class SymbolInfoDto {

	private String result;
	private String message;
	private String lay_no;
	private String item_no;
	private int info_type;
	private String info_summery;
	private int lay_type;
	private int symbol_no;
	private double zahyo_x;
	private double zahyo_y;
	private String strinfo1;
	private String strinfo2;
	private String strinfo3;
	private double str_zahyo_x;
	private double str_zahyo_y;
	private int zahyo_cnt;
	
	private List<ZPointBean> data;

	public String getLay_no() {
		return lay_no;
	}

	public void setLay_no(String lay_no) {
		this.lay_no = lay_no;
	}

	public String getItem_no() {
		return item_no;
	}

	public void setItem_no(String item_no) {
		this.item_no = item_no;
	}

	public int getInfo_type() {
		return info_type;
	}

	public void setInfo_type(int info_type) {
		this.info_type = info_type;
	}

	public String getInfo_summery() {
		return info_summery;
	}

	public void setInfo_summery(String info_summery) {
		this.info_summery = info_summery;
	}

	public int getLay_type() {
		return lay_type;
	}

	public void setLay_type(int lay_type) {
		this.lay_type = lay_type;
	}

	public int getSymbol_no() {
		return symbol_no;
	}

	public void setSymbol_no(int symbol_no) {
		this.symbol_no = symbol_no;
	}

	public double getZahyo_x() {
		return zahyo_x;
	}

	public void setZahyo_x(double zahyo_x) {
		this.zahyo_x = zahyo_x;
	}

	public double getZahyo_y() {
		return zahyo_y;
	}

	public void setZahyo_y(double zahyo_y) {
		this.zahyo_y = zahyo_y;
	}

	public String getStrinfo1() {
		return strinfo1;
	}

	public void setStrinfo1(String strinfo1) {
		this.strinfo1 = strinfo1;
	}

	public String getStrinfo2() {
		return strinfo2;
	}

	public void setStrinfo2(String strinfo2) {
		this.strinfo2 = strinfo2;
	}

	public String getStrinfo3() {
		return strinfo3;
	}

	public void setStrinfo3(String strinfo3) {
		this.strinfo3 = strinfo3;
	}

	public double getStr_zahyo_x() {
		return str_zahyo_x;
	}

	public void setStr_zahyo_x(double str_zahyo_x) {
		this.str_zahyo_x = str_zahyo_x;
	}

	public double getStr_zahyo_y() {
		return str_zahyo_y;
	}

	public void setStr_zahyo_y(double str_zahyo_y) {
		this.str_zahyo_y = str_zahyo_y;
	}

	public int getZahyo_cnt() {
		return zahyo_cnt;
	}

	public void setZahyo_cnt(int zahyo_cnt) {
		this.zahyo_cnt = zahyo_cnt;
	}

	public List<ZPointBean> getData() {
		return data;
	}

	public void setData(List<ZPointBean> data) {
		this.data = data;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}

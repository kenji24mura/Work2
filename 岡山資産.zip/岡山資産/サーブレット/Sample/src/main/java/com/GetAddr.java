package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetAddr
 */
@WebServlet("/GetAddr")
public class GetAddr extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAddr() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin","*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		AddrDto dto = new AddrDto();
		PrintWriter out = response.getWriter();
		
		
		String strPrif = request.getParameter("prif");
		String strCity = request.getParameter("city");
		String strTown1 = request.getParameter("town1");
		String strTown2 = request.getParameter("town2");
		
	
		int prif=0;
		int city=0;
		int town1=0;
		int town2=0;
		
		try {
			prif = Integer.parseInt(strPrif);
			city = Integer.parseInt(strCity);
			town1 = Integer.parseInt(strTown1);
			town2 = Integer.parseInt(strTown2);
			
			if(ReadDB(prif,city,town1,town2,out,dto)==0) {
				dto.setResult("OK");
			}else {
				dto.setResult("NG");
			}

		}catch(Exception ex) {
			dto.setMessage(ex.toString());
			dto.setResult("NG");
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();
		log("End");

	}
	
	public int  ReadDB(int prif,int city,int town1,int town2,PrintWriter out,AddrDto dto) {
		
		int ret=-1;
		
		String SQL="";

		if(prif==0) {
			SQL = "select * from TBWG0023 WHERE prif > 0  AND city=0 AND town1=0 AND town2 = 0";
		}else {
			if(prif>0 && city == 0) {
				SQL = "select * from TBWG0023 WHERE prif=" + prif + " AND city > 0 AND town1=0 AND town2 = 0";
			}else {
				if(prif>0 && city > 0 && town1==0) {
					SQL = "select * from TBWG0023 WHERE prif=" + prif + " AND city="+city+" AND town1 > 0 AND town2 = 0";
				}else {
					if(prif>0 && city > 0 && town1 >0 && town2 == 0) {
						SQL = "select * from TBWG0023 WHERE prif=" + prif + " AND city="+city+" AND town1="+town1 +" AND town2 > 0 ";
					}else {
						SQL = "select * from TBWG0023 WHERE prif=" + prif + " AND city="+city+" AND town1="+town1 +" AND town2 = "+town2;
					}
				}
			}
		}
		
		//2022.12.12 order by 句追加
		SQL += " order by prif,city,town1,town2";
		
		
		System.out.println(SQL);
		log(SQL);
		
		List<JsonAddrBean> jsonList = new ArrayList<>();

		System.out.println("URL="+URL);
		
		
		try ( Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret =0;

					int prifval = rs.getInt("prif");
					int cityval = rs.getInt("city");
					int town1val = rs.getInt("town1");
					int town2val = rs.getInt("town2");
					int zxval = rs.getInt("zx");
					int zyval = rs.getInt("zy");
					double lonval= rs.getDouble("lon");
					double latval= rs.getDouble("lat");
					String nameval = rs.getString("name");
					String kanaval = rs.getString("kana");

					//除外条件

					boolean skip = false;
					
					if(prifval==27 && cityval==100 && town1==0 ) {
					skip = true;	
					System.out.println("skip"+nameval);
					
					}
					if(prifval==27 && cityval==140 && town1 ==0) {
						skip = true;	
						System.out.println("skip"+nameval);
					}
					//付加条件
					if(prifval==27 && cityval>100 && cityval<=129 && town1val==0 ) {
						
						nameval = "大阪市　"+nameval;
					}
					if(prifval==27 && cityval>140 && cityval<=149 && town1val  == 0) {
						nameval = "堺市　"+nameval;
					}
					
					if(skip == false) {
						JsonAddrBean jsonBean = new JsonAddrBean();

						jsonBean.setPrif(prifval);
						jsonBean.setCity(cityval);
						jsonBean.setTown1(town1val);
						jsonBean.setTown2(town2val);
						jsonBean.setZx(zxval);
						jsonBean.setZy(zyval);
						jsonBean.setLon(lonval);
						jsonBean.setLat(latval);
						jsonBean.setName(nameval);
						jsonBean.setKana(kanaval);

						jsonList.add(jsonBean);
					}
				}
				dto.setData(jsonList);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			ret =-1;
			dto.setMessage(e.toString());
//			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret =-1;
			dto.setMessage(e.toString());
//			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

//		ObjectMapper mapper = new ObjectMapper();
//		dto.setResult(ret);

	//	try {
		//	String jsonData = mapper.writeValueAsString(dto);
			//out.write(jsonData);
		//} catch (JsonProcessingException e) {
			//e.printStackTrace();
			//ret ="NG";
		//}
		return ret;
		
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

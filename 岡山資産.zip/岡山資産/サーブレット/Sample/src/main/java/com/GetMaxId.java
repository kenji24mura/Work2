package com;

import java.io.IOException;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetMaxId
 */
@WebServlet("/GetMaxId")
public class GetMaxId extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	String URL = "";
	String USER = "";
	String PASS = "";

//	private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

	//private String conn_user = "WEBGIS";
	//private String conn_pass = "WEBGIS";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetMaxId() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String SQL="";
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}
		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;

		
		//itemidは重複しないように自動採番する
		//レイヤグループ番号(2桁)+シンボル一覧No.(4桁)+通しID(6桁)
		
		int symbol_no = 9999;
		int info_type = 2;
		int number = 1;
		
		
		SQL = "select max(item_no) from TBWG0001 where info_type =" + info_type +"  and symbol_no = "+symbol_no;
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {
				
				String item_no = rs.toString();
				
				if (rs.next()) {
					item_no = rs.getString(1);
					
					if(item_no == null) {
						System.out.println("no record");
					}else {
						System.out.println(item_no);
						if(item_no.length()==12) {
							String str = item_no.substring(6, 12);
							System.out.println("str="+str);
							number = Integer.parseInt(str)+1;
						}else {
							number = 1;
						}
					}

				}
				//while (rs.next()) {
					//String item_no=rs.getString("item_no");
				//}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("処理が完了しました");
		}
		String result = String.format("%02d",info_type) + String.format("%04d",symbol_no)+String.format("%06d",number);
		

		System.out.println(result);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

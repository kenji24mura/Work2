package com;

public class DBDto {
	private String result;
	private String message;
	private String item_no;
	private String sql;
		//2023.07.02
	private double  zahyo_x;
	private double  zahyo_y;

	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getItem_no() {
		return item_no;
	}
	public void setItem_no(String item_no) {
		this.item_no = item_no;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}
		public double getZahyo_x() {
		return zahyo_x;
	}
	public void setZahyo_x(double zahyo_x) {
		this.zahyo_x = zahyo_x;
	}
	public double getZahyo_y() {
		return zahyo_y;
	}
	public void setZahyo_y(double zahyo_y) {
		this.zahyo_y = zahyo_y;
	}

}

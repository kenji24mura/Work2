package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetWaterInfo
 */
@WebServlet("/GetWaterInfo")
public class GetWaterInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";
	String URL2 = "";
	String USER2 = "";
	String PASS2 = "";
	String URL3 = "";
	String USER3 = "";
	String PASS3 = "";
	String MODE="";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetWaterInfo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		// 設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			System.out.println(json);

			URL = json.get("conn_url").textValue();
			USER = json.get("conn_user").textValue();
			PASS = json.get("conn_pass").textValue();
			URL2 = json.get("conn_url2").textValue();
			USER2 = json.get("conn_user2").textValue();
			PASS2 = json.get("conn_pass2").textValue();
//			URL3 = json.get("conn_url3").textValue();
//			USER3 = json.get("conn_user3").textValue();
//			PASS3 = json.get("conn_pass3").textValue();
			
			MODE = json.get("mode").textValue();
			if(MODE.indexOf("debug")==0) {
				URL3 = json.get("conn_url").textValue();
				USER3 = json.get("conn_user").textValue();
				PASS3 = json.get("conn_pass").textValue();
				
			}else{
				URL3 = json.get("conn_url3").textValue();
				USER3 = json.get("conn_user3").textValue();
				PASS3 = json.get("conn_pass3").textValue();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		WaterInfo dto = new WaterInfo();

		try {

			// 水利番号(number)

			String number = request.getParameter("number");

			int ret = ReadDB(number, dto);
			
			if(ret == 0) {
				dto.setResult("OK");
			}else {
				AddMessage(dto,"該当レコードなし");
				dto.setResult("NG");
			}

		} catch (Exception e) {
			e.printStackTrace();
			AddMessage(dto,e.toString());
			dto.setResult("NG");
		} finally {
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		out.flush();
	}
	private void AddMessage(WaterInfo dto,String msg) {
		String oldmsg = dto.getMessage();
		if(oldmsg == null) {
			dto.setMessage(msg);
		}else {
			dto.setMessage(oldmsg+","+msg);
		}
	}

	public int ReadDB(String number, WaterInfo dto) {

		int ret = -1;
		String SQL = "";

		SQL += "select *  from TBDMT340A WHERE SUIRI_CD='"+number+"'";

		System.out.println(SQL);
		
		dto.setSql(SQL);
		
		try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;

					String SUIRI_CD = rs.getString("SUIRI_CD");
					int SUIRI_SBT = rs.getInt("SUIRI_SBT");
					int SYMBOL_SBT = rs.getInt("SYMBOL_SBT");
					int SHIYO_KAHI = rs.getInt("SHIYO_KAHI");
					int HAIKAN_KOKEI = rs.getInt("HAIKAN_KOKEI");
					String MOJI = rs.getString("MOJI");
					int IZAHYO_X = rs.getInt("IZAHYO_X");
					int IZAHYO_Y = rs.getInt("IZAHYO_Y");
					int KOZO_B = rs.getInt("KOZO_B");// 1:単口 2:双口
					String MAKE_KBN = rs.getString("MAKE_KBN");
					
					dto.setSuiri_cd(SUIRI_CD);
					dto.setSuiri_sbt(SUIRI_SBT);
					dto.setSymbol_sbt(SYMBOL_SBT);
					dto.setShiyo_kahi(SHIYO_KAHI);
					dto.setHaikan_kokei(HAIKAN_KOKEI);
					dto.setMoji(MOJI);
					dto.setIzahyo_x(IZAHYO_X);
					dto.setIzahyo_y(IZAHYO_Y);
					dto.setKozo_b(KOZO_B);
					dto.setMake_kbn(MAKE_KBN);
					
					AddMessage(dto,SUIRI_CD);

				}
				AddMessage(dto,"検索処理が完了しました");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			AddMessage(dto,e.toString());
			System.out.println(e.toString());
			ret = 1;
		} catch (Exception e) {
			e.printStackTrace();
			AddMessage(dto,e.toString());
			System.out.println(e.toString());
			ret = 1;
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

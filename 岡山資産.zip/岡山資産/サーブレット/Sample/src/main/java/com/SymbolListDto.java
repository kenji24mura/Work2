package com;

import java.util.List;

public class SymbolListDto {
	 private String result;
	 private String message;
	private List<JsonSymbolList> data;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<JsonSymbolList> getData() {
		return data;
	}
	public void setData(List<JsonSymbolList> data) {
		this.data = data;
	}

}

package com;

import java.util.List;

public class AddrDto {
	 private String result;
	 private String message;
	 private List<JsonAddrBean> data;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<JsonAddrBean> getData() {
		return data;
	}
	public void setData(List<JsonAddrBean> data) {
		this.data = data;
	}
}

package com;

public class WaterInfo {
	 private String result;
	 private String message;
	 private String sql;
		private String suiri_cd;
		private int suiri_sbt;
		private int symbol_sbt;
		private int shiyo_kahi;
		private int haikan_kokei;
		private String moji;
		private int izahyo_x;
		private int izahyo_y;
		private int kozo_b;
		private String make_kbn;

	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}
	public String getSuiri_cd() {
		return suiri_cd;
	}
	public void setSuiri_cd(String suiri_cd) {
		this.suiri_cd = suiri_cd;
	}
	public int getSuiri_sbt() {
		return suiri_sbt;
	}
	public void setSuiri_sbt(int suiri_sbt) {
		this.suiri_sbt = suiri_sbt;
	}
	public int getSymbol_sbt() {
		return symbol_sbt;
	}
	public void setSymbol_sbt(int symbol_sbt) {
		this.symbol_sbt = symbol_sbt;
	}
	public int getShiyo_kahi() {
		return shiyo_kahi;
	}
	public void setShiyo_kahi(int shiyo_kahi) {
		this.shiyo_kahi = shiyo_kahi;
	}
	public int getHaikan_kokei() {
		return haikan_kokei;
	}
	public void setHaikan_kokei(int haikan_kokei) {
		this.haikan_kokei = haikan_kokei;
	}
	public String getMoji() {
		return moji;
	}
	public void setMoji(String moji) {
		this.moji = moji;
	}
	public int getIzahyo_x() {
		return izahyo_x;
	}
	public void setIzahyo_x(int izahyo_x) {
		this.izahyo_x = izahyo_x;
	}
	public int getIzahyo_y() {
		return izahyo_y;
	}
	public void setIzahyo_y(int izahyo_y) {
		this.izahyo_y = izahyo_y;
	}
	public int getKozo_b() {
		return kozo_b;
	}
	public void setKozo_b(int kozo_b) {
		this.kozo_b = kozo_b;
	}
	public String getMake_kbn() {
		return make_kbn;
	}
	public void setMake_kbn(String make_kbn) {
		this.make_kbn = make_kbn;
	}

}

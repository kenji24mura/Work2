package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetItemnoFromUkedateNumber
 */
@WebServlet("/GetItemnoFromUkedateNumber")
public class GetItemnoFromUkedateNumber extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String URL = "";
	String USER = "";
	String PASS = "";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetItemnoFromUkedateNumber() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			//System.out.println(json); 

			URL = json.get("conn_url2").textValue();
			USER = json.get("conn_user2").textValue();
			PASS = json.get("conn_pass2").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		TBSK0020Dto dto = new TBSK0020Dto();
		PrintWriter out = response.getWriter();

		String ukedate ="";
		int number=0;
		
		try {
			ukedate = request.getParameter("ukedate");
			number = Integer.parseInt(request.getParameter("number"));

			if (ReadDB(ukedate, number, out, dto) == 0) {
				dto.setResult("OK");
			} else {
				dto.setResult("NG");
			}
		}catch(Exception ex) {
			dto.setResult("NG");
			dto.setMessage(ex.toString());
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();

		log("End");

	}
	public int ReadDB(String ukedate, int number, PrintWriter out,TBSK0020Dto dto) {

		int ret = 0;

		String SQL = "";
		SQL = "select * from TBSK0020 WHERE UKE_DATE=TO_DATE('"+ukedate+"', 'YYYY-MM-DD HH24:MI:SS')" + " AND REMBAN="+number ;

		System.out.println(SQL);
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				if (rs.next()) {

					String OBJECT_ID = rs.getString("OBJECT_ID");
					int SHORI_KBN= rs.getInt("SHORI_KBN");
					
					dto.setItem_no(OBJECT_ID);
					dto.setSyori_kbn(SHORI_KBN);
					
					dto.setMessage(SQL);
					ret = 0;
				}else {
					ret = -2;
					dto.setMessage("no record");
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

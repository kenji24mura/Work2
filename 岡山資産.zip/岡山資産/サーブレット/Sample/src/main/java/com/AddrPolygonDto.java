package com;

import java.util.List;

public class AddrPolygonDto {
	private String result;
	 private String message;
	private int prif;
	private int city;
	private int town1;
	private int town2;
	private int zahyo_cnt;
	private List<ZPointBean> data;

	public int getZahyo_cnt() {
		return zahyo_cnt;
	}

	public void setZahyo_cnt(int zahyo_cnt) {
		this.zahyo_cnt = zahyo_cnt;
	}

	public List<ZPointBean> getData() {
		return data;
	}

	public void setData(List<ZPointBean> data) {
		this.data = data;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public int getPrif() {
		return prif;
	}

	public void setPrif(int prif) {
		this.prif = prif;
	}

	public int getCity() {
		return city;
	}

	public void setCity(int city) {
		this.city = city;
	}

	public int getTown1() {
		return town1;
	}

	public void setTown1(int town1) {
		this.town1 = town1;
	}

	public int getTown2() {
		return town2;
	}

	public void setTown2(int town2) {
		this.town2 = town2;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}

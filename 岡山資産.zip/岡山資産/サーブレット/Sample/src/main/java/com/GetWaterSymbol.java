package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetWaterSymbol
 */
@WebServlet("/GetWaterSymbol")
public class GetWaterSymbol extends HttpServlet {
  private static final long serialVersionUID = 1L;

  String URL = "";
  String USER = "";
  String PASS = "";
  String URL2 = "";
  String USER2 = "";
  String PASS2 = "";
  String URL3 = "";
  String USER3 = "";
  String PASS3 = "";
  String MODE = "";
  // 20240130 start
  int kijyunkei = 6;
  // 20240130 end

  /**
   * @see HttpServlet#HttpServlet()
   */
  public GetWaterSymbol() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub


    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html");
    response.setHeader("Cache-Control", "nocache");
    response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
    response.setCharacterEncoding("utf-8");

    // 20240130 start
    String coordinate = request.getParameter("coordinate");
    if (coordinate == null) {
    } else {
      kijyunkei = Integer.parseInt(coordinate);
    }
    // 20240130 end

    // 運用モード
    int OPE_MODE = 0;
    String ope_mode = request.getParameter("ope_mode");
    if (ope_mode == null) {
    } else {
      OPE_MODE = Integer.parseInt(ope_mode);
    }
    if (OPE_MODE == 0) {
      System.out.println("運用モードは[通常]");
    } else {
      System.out.println("運用モードは[訓練]");
    }

    // 設定ファイル読み込み処理
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      JsonNode json = objectMapper.readTree(
          Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
      System.out.println(json);
      
      kijyunkei= Integer.parseInt(json.get("coordinate").textValue());

      if (OPE_MODE == 0) {
        URL = json.get("conn_url").textValue();
        USER = json.get("conn_user").textValue();
        PASS = json.get("conn_pass").textValue();
        URL2 = json.get("conn_url2").textValue();
        USER2 = json.get("conn_user2").textValue();
        PASS2 = json.get("conn_pass2").textValue();

        MODE = json.get("mode").textValue();
        if (MODE.indexOf("debug") == 0) {
          URL3 = json.get("conn_url").textValue();
          USER3 = json.get("conn_user").textValue();
          PASS3 = json.get("conn_pass").textValue();

        } else {
          URL3 = json.get("conn_url3").textValue();
          USER3 = json.get("conn_user3").textValue();
          PASS3 = json.get("conn_pass3").textValue();
        }

      } else {
        URL = json.get("conn_url_t").textValue();
        USER = json.get("conn_user_t").textValue();
        PASS = json.get("conn_pass_t").textValue();
        URL2 = json.get("conn_url2_t").textValue();
        USER2 = json.get("conn_user2_t").textValue();
        PASS2 = json.get("conn_pass2_t").textValue();

        MODE = json.get("mode").textValue();
        if (MODE.indexOf("debug") == 0) {
          URL3 = json.get("conn_url_t").textValue();
          USER3 = json.get("conn_user_t").textValue();
          PASS3 = json.get("conn_pass_t").textValue();

        } else {
          URL3 = json.get("conn_url3_t").textValue();
          USER3 = json.get("conn_user3_t").textValue();
          PASS3 = json.get("conn_pass3_t").textValue();
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
    }

    PrintWriter out = response.getWriter();
    WaterDto dto = new WaterDto();

    try {

      // 中心座標x(lon)
      // 中心座標y(lat)
      // 検索範囲(m)
      // 対象レイヤ

      String s_lon = request.getParameter("lon");
      String s_lat = request.getParameter("lat");
      String s_radius = request.getParameter("radius");
      String jisiki = request.getParameter("jisiki");
      String carcd = request.getParameter("carcd");

      log(s_lon);
      log(s_lat);
      log(s_radius);

      double lon = 0.0;
      double lat = 0.0;
      int radius = 0;

      if (s_lon != null) {
        lon = Double.parseDouble(s_lon);
      }
      if (s_lat != null) {
        lat = Double.parseDouble(s_lat);
      }
      if (s_radius != null) {
        radius = Integer.parseInt(s_radius);
      }

      MapConvert mc = new MapConvert();

      // 20240130 コメント
      // int kijyunkei = 6;

      int xy[] = new int[2];

      System.out.println(lon + "," +lat);
      mc.ConvertPos2(lon, lat, kijyunkei, xy);

      System.out.println(xy[0] + "," + xy[1]);


      int minx = xy[0] - radius * 1000;
      int miny = xy[1] - radius * 1000;
      int maxx = xy[0] + radius * 1000;
      int maxy = xy[1] + radius * 1000;

      double min_lonlat[] = new double[2];
      mc.ConvertPos(minx, miny, kijyunkei, min_lonlat);

      double max_lonlat[] = new double[2];
      mc.ConvertPos(maxx, maxy, kijyunkei, max_lonlat);

      System.out.println("min:" + min_lonlat[0] + "," + min_lonlat[1]);
      System.out.println("max:" + max_lonlat[0] + "," + max_lonlat[1]);

      // 範囲内の水利テーブルを読み込む
      ReadDB2(minx, miny, maxx, maxy, jisiki, carcd, dto);

      
      /*
      int ret = -1;

      int CARCD = 0;
      if (carcd == null || carcd.length() == 0) {
        System.out.println("carcdはnull");
      } else {
        // ReadStatus
        // シンボル状態DBを検索する
        CARCD = Integer.parseInt(carcd);
        // 水利状態テーブルを読み込む
        ret = ReadStatus_2(jisiki, CARCD, dto);
      }
      // 水利部署テーブルを読み込む
      ReadTBCK0001_2(jisiki, carcd, dto);
*/
      dto.setResult("OK");

    } catch (Exception e) {
      e.printStackTrace();
      AddMessage(dto, e.toString());
      dto.setResult("NG");
    } finally {
    }

    ObjectMapper mapper = new ObjectMapper();

    try {
      String jsonData = mapper.writeValueAsString(dto);
      out.write(jsonData);
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    out.flush();

  }

  private void AddMessage(WaterDto dto, String msg) {
    String oldmsg = dto.getMessage();
    if (oldmsg == null) {
      dto.setMessage(msg);
    } else {
      dto.setMessage(oldmsg + "," + msg);
    }
  }

  public int ReadDB2(int MINX, int MINY, int MAXX, int MAXY, String jisiki, String carcd,
      WaterDto dto) {

    String disp_name[] = {"部署水利", "指定水利\r\n自車両", "不能水利", "他事案部署中", "他車両部署中\r\n相掛否", "他事案部署中\r\n部署可",
        "他車両部署中\r\n相掛可", "他車両部署中\r\n部署可/相掛可", "他車両部署中\r\n相掛可/部署可", "他車両部署中\r\n部署可/相掛否",
        "他車両部署中\r\n相掛否/部署可", "他車両部署中\r\n相掛可/相掛可", "他車両部署中\r\n相掛可/相掛否", "他車両部署中\r\n相掛否/相掛可",
        "指定水利\r\n他車両", "使用可能水利", "通常"};

    int cnt = 0;
    int ret = -1;
    String SQL = "";

    // 2023/07/02
    SQL += "select *  from TBDSC340B WHERE  ";
    SQL += "  ( ZAHYO_X BETWEEN " + MINX + " AND " + MAXX + " ) AND ( ZAHYO_Y BETWEEN " + MINY
        + " AND " + MAXY + " ) ";
    //SQL += " AND MAKE_KBN <>'D' ";

    System.out.println(SQL);

    log("jiski=" + jisiki + ",carcd=" + carcd);

    dto.setSql(SQL);

    if (carcd == null || carcd.length() == 0) {
      AddMessage(dto, "CARCD無効");
    }

    List<WaterBean> jsonList = new ArrayList<>();


    System.out.println("URL2=" + URL2);
    System.out.println("USER2=" + USER2);
    System.out.println("PASS2=" + PASS2);


    try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

          ret = 0;
          cnt++;

          WaterBean bean = new WaterBean();

          String SUIRI_CD = rs.getString("SUIRI_CD");
          //int SUIRI_SBT = rs.getInt("SUIRI_CD");
          int SYMBOL_SBT = rs.getInt("SYMBOL_CD");
          //int SHIYO_KAHI = rs.getInt("SHIYO_KAHI");
          //int HAIKAN_KOKEI = rs.getInt("HAIKAN_KOKEI");
          // 20230903
          String MOJI = rs.getString("SUIRI_CD").trim();
          int IZAHYO_X = rs.getInt("ZAHYO_X");
          int IZAHYO_Y = rs.getInt("ZAHYO_Y");
          // 2023.07.02
          //int KOZO_B = rs.getInt("KOZO_B");// 1:単口 2:双口

          AddMessage(dto, SUIRI_CD);

          log("SUIRI_CD=" + SUIRI_CD);


          int ptn = 17;


          /*
           * if (carcd == null || carcd.length() == 0) { System.out.println("carcdはnull"); } else {
           * // ReadStatus // シンボル状態DBを検索する int CARCD = Integer.parseInt(carcd); // ptn =
           * ReadStaus(jisiki,CARCD,SUIRI_CD); ptn = ReadStaus(jisiki, CARCD, SUIRI_CD, KOZO_B,
           * bean);
           * 
           * } // ReadTBCK0001
           * 
           * if (ptn < 0) { log("シンボル状態テーブルに該当なし"); ptn = ReadTBCK0001(SUIRI_CD, jisiki, carcd,
           * KOZO_B, bean);
           * 
           * if(ptn<0) { log("水利部署テーブルに該当なし");
           * 
           * ptn = 17; } }
           * 
           * if (SHIYO_KAHI == 1) { //水利マスタは[1]が使用不可 log("水利使用不可"); ptn = 3; }
           */

          //SYMBOL_SBT = switchSymbolId(SYMBOL_SBT, ptn);
          // log("ptn="+ptn + ",SYMBOL_SBT="+SYMBOL_SBT);

          // System.out.println("2:SYMBOL_SBT=" + SYMBOL_SBT);

          bean.setSuiri_cd(SUIRI_CD);
          //bean.setSuiri_sbt(SUIRI_SBT);
          bean.setSymbol_sbt(SYMBOL_SBT);
          //bean.setShiyo_kahi(SHIYO_KAHI);
          //bean.setHaikan_kokei(HAIKAN_KOKEI);
          bean.setMoji(MOJI.substring(MOJI.length()-4));
          bean.setIzahyo_x(IZAHYO_X);
          bean.setIzahyo_y(IZAHYO_Y);
          //bean.setKozo_b(KOZO_B);// 2023.07.02

          // 表示名を編集する

          if (ptn > 0) {
            bean.setDisp_name(disp_name[ptn - 1]);
          } else {
            bean.setDisp_name("通常");
          }

          jsonList.add(bean);

          log("add list");
        }
        dto.setData(jsonList);
        AddMessage(dto, "検索処理が完了しました。件数=[" + cnt + "]件");
      }
    } catch (SQLException e) {
      e.printStackTrace();
      AddMessage(dto, e.toString());
      System.out.println(e.toString());
      ret = 1;
    } catch (Exception e) {
      e.printStackTrace();
      AddMessage(dto, e.toString());
      System.out.println(e.toString());
      ret = 1;
    } finally {
      // System.out.println("処理が完了しました");
    }

    return ret;
  }


  private int ReadStatus_2(String jiancode, int carcd, WaterDto dto) {

    String disp_name[] = {"部署水利", "指定水利\r\n自車両", "不能水利", "他事案部署中", "他車両部署中\r\n相掛否", "他事案部署中\r\n部署可",
        "他車両部署中\r\n相掛可", "他車両部署中\r\n部署可/相掛可", "他車両部署中\r\n相掛可/部署可", "他車両部署中\r\n部署可/相掛否",
        "他車両部署中\r\n相掛否/部署可", "他車両部署中\r\n相掛可/相掛可", "他車両部署中\r\n相掛可/相掛否", "他車両部署中\r\n相掛否/相掛可",
        "指定水利\r\n他車両", "使用可能水利", "通常"};


    List<WaterBean> jsonList = dto.getData();


    int ret = -1;

    String SQL = "";
    ObjectMapper objectMapper = new ObjectMapper();

    try {
      JsonNode json = objectMapper.readTree(
          Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
      System.out.println(json);

      URL = json.get("conn_url").textValue();
      USER = json.get("conn_user").textValue();
      PASS = json.get("conn_pass").textValue();
    } catch (Exception e) {
      e.printStackTrace();
    }

    SQL = "select * from TBWG0009_N where termId =" + carcd + "  and jisiki = '" + jiancode + "'";

    System.out.println(SQL);

    try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

          String SUIRI_CD = rs.getString("SUIRICODE");
          log("★SUIRI_CD=" + SUIRI_CD);

          // System.out.println("★"+SUIRI_CD);

          for (int i = 0; i < jsonList.size(); i++) {
            // System.out.println("'"+jsonList.get(i).getSuiri_cd()+"','"+SUIRI_CD+"'");

            if (jsonList.get(i).getSuiri_cd().indexOf(SUIRI_CD) == 0) {
              // System.out.println(jsonList.get(i).getSuiri_cd());
              System.out.println("★hit SUIRI_CD=　" + SUIRI_CD);


              int KOZO_B = jsonList.get(i).getKozo_b();

              // jsonList.get(i).setSuiri_cd("****");

              // String suiriCode;
              int suiriStatusCode = rs.getInt("suiriStatusCode");
              int suiriKahi = rs.getInt("suiriKahi");
              String jointCarCode1 = rs.getString("jointCarCode1");
              String jointCarCode2 = rs.getString("jointCarCode2");
              int busyoMax = rs.getInt("busyoMax");
              int busyoCarNum = rs.getInt("busyoCarNum");
              int hasMyCar = rs.getInt("hasMyCar");
              int hasSitei = rs.getInt("hasSitei");
              // Boolean underBusho = rs.getBoolean("underBusho");

              jsonList.get(i).setSuiriStatusCode(suiriStatusCode);
              jsonList.get(i).setJointCarCode1(jointCarCode1);
              jsonList.get(i).setJointCarCode2(jointCarCode2);

              if (suiriKahi == 0) {
                // 水利状態テーブルは[0]が使用不可
                log("使用不可");
                ret = 3;
              } else {
                if (hasMyCar == 1) {
                  // 自車両
                  log("自車両");
                  ret = 1;
                } else {
                  if (busyoCarNum == 0) {
                    log("部署車両数が0");

                    if (hasSitei == 0) {
                      log("水利指定が0");
                      ret = 16;
                    }
                    if (hasSitei == 2) {
                      log("水利指定が2");
                      ret = 15;
                    }
                    if (hasSitei == 1) {
                      log("水利指定が1");
                      ret = 2;
                    }
                  } else {
                    if (KOZO_B == 2) {
                      log("双口");
                      // 双口
                      if (busyoCarNum == 1 && suiriStatusCode == 2) {
                        ret = 8;
                      }
                      if (busyoCarNum == 1 && suiriStatusCode == 1) {
                        ret = 9;
                      }
                      if (busyoCarNum == 1 && suiriStatusCode == 0
                          && jointCarCode1.indexOf("0000") == 0
                          && jointCarCode2.indexOf("0000") != 0) {
                        ret = 10;

                      }
                      if (busyoCarNum == 1 && suiriStatusCode == 0
                          && jointCarCode1.indexOf("0000") != 0
                          && jointCarCode2.indexOf("0000") == 0) {
                        ret = 11;
                      }
                      if (busyoCarNum >= 2 && suiriStatusCode == 3) {
                        ret = 12;
                      }
                      if (busyoCarNum >= 2 && suiriStatusCode == 1) {
                        ret = 13;
                      }
                      if (busyoCarNum >= 2 && suiriStatusCode == 2) {
                        ret = 14;
                      }
                      if (busyoCarNum >= 2 && suiriStatusCode == 0) {
                        ret = 5;
                      }

                    } else {
                      log("単口");
                      // 単口
                      if (suiriStatusCode == 0) {
                        ret = 7;
                      }
                      if (suiriStatusCode == 1) {
                        if (busyoMax <= busyoCarNum) {
                          ret = 5;
                        } else {
                          ret = 7;
                        }
                      }

                    }
                  }
                }
              }

              int SYMBOL_SBT = jsonList.get(i).getSymbol_sbt();
              SYMBOL_SBT = switchSymbolId(SYMBOL_SBT, ret);

              // 表示名を編集する

              if (ret > 0) {
                jsonList.get(i).setDisp_name(disp_name[ret - 1]);
              }

              jsonList.get(i).setSymbol_sbt(SYMBOL_SBT);
              log("ret=" + ret);
              log("★SYMBOL_SBT=" + SYMBOL_SBT);
              break;
            }
          }
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      // System.out.println("処理が完了しました");
    }

    return ret;
  }

  private void ReadTBCK0001_2(String jiancode, String carcd, WaterDto dto) {

    String disp_name[] = {"部署水利", "指定水利\r\n自車両", "不能水利", "他事案部署中", "他車両部署中\r\n相掛否", "他事案部署中\r\n部署可",
        "他車両部署中\r\n相掛可", "他車両部署中\r\n部署可/相掛可", "他車両部署中\r\n相掛可/部署可", "他車両部署中\r\n部署可/相掛否",
        "他車両部署中\r\n相掛否/部署可", "他車両部署中\r\n相掛可/相掛可", "他車両部署中\r\n相掛可/相掛否", "他車両部署中\r\n相掛否/相掛可",
        "指定水利\r\n他車両", "使用可能水利", "通常"};

    List<WaterBean> jsonList = dto.getData();


    int ptn = -1;
    String SQL = "";

    if (MODE.indexOf("debug") == 0) {
      SQL = "select * from TBCK0001 WHERE JISIKI='" + jiancode + "'";
    } else {
      SQL = "select * from SHASAI.TBCK0001 WHERE JISIKI='" + jiancode + "'";
    }

    System.out.println(SQL);

    // int reccnt = 0;
    // Boolean IsJian = false;

    // 水利部署テーブルに該当レコードがあるか？

    int CAR_CD = 0;

    // 2023.08.16
    int term_type = 0;



    try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

          String SUI_CD = rs.getString("SUI_CD");
          log("★SUIRI_CD=" + SUI_CD);

          for (int i = 0; i < jsonList.size(); i++) {
            if (jsonList.get(i).getSuiri_cd().indexOf(SUI_CD) == 0) {
              System.out.println("★hit");

              if (carcd == null || carcd.length() == 0) {
                // DAMS処理 2023.08.16

                log("DAMS 処理");
                term_type = 0;


                String JISIKI = rs.getString("JISIKI");
                int RENBAN = rs.getInt("RENBAN");
                // String SUI_CD = rs.getString("SUI_CD");
                int BUSHO_MAX = rs.getInt("BUSHO_MAX");
                int BUSHO_CARNUM = rs.getInt("BUSHO_CARNUM");
                int SITUATION_CD = rs.getInt("SITUATION_CD");
                int USE_KAHI = rs.getInt("USE_KAHI");
                int AI_CARCD1 = rs.getInt("AI_CARCD1");
                int AI_CARCD2 = rs.getInt("AI_CARCD2");

                String jointCarCode1 = Integer.valueOf(AI_CARCD1).toString();
                String jointCarCode2 = Integer.valueOf(AI_CARCD2).toString();;

                // bean.setSuiriStatusCode(SITUATION_CD);
                // bean.setJointCarCode1(jointCarCode1);
                // bean.setJointCarCode2(jointCarCode2);
                jsonList.get(i).setSuiriStatusCode(SITUATION_CD);
                jsonList.get(i).setJointCarCode1(jointCarCode1);
                jsonList.get(i).setJointCarCode2(jointCarCode2);

                // 水利使用可否が[0]なら[不能水利]
                if (USE_KAHI == 0) {
                  ptn = 3;
                } else {
                  // 部署済み車両数が1以上か？
                  if (BUSHO_CARNUM >= 1) {
                    log("部署済み車両数が1以上");
                    ptn = 1;
                  } else {
                    log("部署済み車両数が0");
                    ptn = 17;
                  }
                }
                int SYMBOL_SBT = jsonList.get(i).getSymbol_sbt();
                SYMBOL_SBT = switchSymbolId(SYMBOL_SBT, ptn);

                jsonList.get(i).setSymbol_sbt(SYMBOL_SBT);



              } else {
                // 受令端末処理
                log("受令端末処理");
                term_type = 1;
                CAR_CD = Integer.parseInt(carcd);

                int KOZO_B = jsonList.get(i).getKozo_b();

                // 電文で設定されていたら処理しない

                log("★" + jsonList.get(i).getDisp_name());

                if (jsonList.get(i).getDisp_name().indexOf("通常") == 0) {

                  String JISIKI = rs.getString("JISIKI");
                  int RENBAN = rs.getInt("RENBAN");
                  // String SUI_CD = rs.getString("SUI_CD");
                  int BUSHO_MAX = rs.getInt("BUSHO_MAX");
                  int BUSHO_CARNUM = rs.getInt("BUSHO_CARNUM");
                  int SITUATION_CD = rs.getInt("SITUATION_CD");
                  int USE_KAHI = rs.getInt("USE_KAHI");
                  int AI_CARCD1 = rs.getInt("AI_CARCD1");
                  int AI_CARCD2 = rs.getInt("AI_CARCD2");

                  String jointCarCode1 = Integer.valueOf(AI_CARCD1).toString();
                  String jointCarCode2 = Integer.valueOf(AI_CARCD2).toString();;

                  // bean.setSuiriStatusCode(SITUATION_CD);
                  // bean.setJointCarCode1(jointCarCode1);
                  // bean.setJointCarCode2(jointCarCode2);
                  jsonList.get(i).setSuiriStatusCode(SITUATION_CD);
                  jsonList.get(i).setJointCarCode1(jointCarCode1);
                  jsonList.get(i).setJointCarCode2(jointCarCode2);


                  // 部署車両テーブル(TBCK0002)の
                  // 自車両レコードの水利コードの部署区分が1(部署)
                  int kbn = CheckTBCK0002_01(SUI_CD, CAR_CD);

                  log("部署車両テーブル(TBCK0002)の自車両レコードの水利コードの部署区分" + kbn);
                  // 2023.07.18 修正
                  if (kbn == 1) {
                    ptn = 1;
                  } else {
                    if (JISIKI.indexOf(jiancode) == 0) {
                      log("事案識別子が一致");
                      // 事案識別子が一致
                      if (BUSHO_CARNUM > 0) {
                        log("部署車両数が0以上");
                        if (KOZO_B == 2) {
                          // 双口
                          log("双口");
                          if (BUSHO_CARNUM == 1 && SITUATION_CD == 2) {
                            ptn = 8;
                          }
                          if (BUSHO_CARNUM == 1 && SITUATION_CD == 1) {
                            ptn = 9;
                          }
                          if (BUSHO_CARNUM == 1 && SITUATION_CD == 0 && AI_CARCD1 == 0
                              && AI_CARCD2 != 0) {
                            ptn = 10;
                          }
                          if (BUSHO_CARNUM == 1 && SITUATION_CD == 0 && AI_CARCD1 != 0
                              && AI_CARCD2 == 0) {
                            ptn = 11;
                          }
                          if (BUSHO_CARNUM >= 2 && SITUATION_CD == 3) {
                            ptn = 12;
                          }
                          if (BUSHO_CARNUM >= 2 && SITUATION_CD == 1) {
                            ptn = 13;
                          }
                          if (BUSHO_CARNUM >= 2 && SITUATION_CD == 2) {
                            ptn = 14;
                          }
                          if (BUSHO_CARNUM >= 2 && SITUATION_CD == 0) {
                            ptn = 5;
                          }

                        } else {
                          // 単口
                          log("単口");
                          if (SITUATION_CD == 0) {
                            log("水利状況コードが0");
                            ptn = 7;
                          }
                          if (SITUATION_CD == 1) {
                            /// TBCK0001 最大部署数<=部署済車両数 ret =5
                            if (BUSHO_MAX <= BUSHO_CARNUM) {
                              log("最大部署数<=部署済車両数");
                              ptn = 5;
                            } else {
                              ptn = 7;
                            }
                          }
                        }
                      } else {
                        log("部署車両数が0");
                        // 部署車両テーブ(TBCK0002)の自車両レコードで
                        // 部署区分が0(部署解除)＆割当区分が0以外 ret =16

                        if (CheckTBCK0002_03(jiancode, SUI_CD, CAR_CD) != 0) {
                          ptn = 16;
                        } else {
                          log("部署車両テーブル(TBCK0002)で対象事案が存在し、割り当て区分が0以外");
                          if (CheckTBCK0002_02(SUI_CD, CAR_CD) == 0) {
                            log("部署車両テーブル(TBCK0002)の自車両レコードで部署区分が０");
                            ptn = 2;
                          } else {
                            ptn = 15;
                          }
                        }
                      }

                    } else {
                      log("事案識別子が一致しない");
                      // (TBCK0001)最大部署数<＝(TBCK0001)部署済車両数。
                      if (BUSHO_MAX <= BUSHO_CARNUM) {
                        log("(TBCK0001)最大部署数<＝(TBCK0001)部署済車両数");
                        ptn = 4;
                      } else {
                        if (BUSHO_CARNUM > 0) {
                          log("(TBCK0001)部署済車両数が0以上");
                          ptn = 6;
                        } else {
                          ptn = 16;
                        }
                      }
                    }

                  }
                  int SYMBOL_SBT = jsonList.get(i).getSymbol_sbt();
                  SYMBOL_SBT = switchSymbolId(SYMBOL_SBT, ptn);

                  // 表示名を編集する

                  if (ptn > 0) {
                    jsonList.get(i).setDisp_name(disp_name[ptn - 1]);
                  }


                  jsonList.get(i).setSymbol_sbt(SYMBOL_SBT);
                  log("ptn=" + ptn);
                  log("★SYMBOL_SBT=" + SYMBOL_SBT);

                } else {
                  log("電文で設定済");
                }



              }
              break;

            }
          }

        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
      ptn = -1;
    } catch (Exception e) {
      e.printStackTrace();
      ptn = -1;
    } finally {
      // System.out.println("処理が完了しました");
    }

    /*
     * 
     * //2023.07.11 check追加 if (carcd == null || carcd.length() == 0) { //DAMS処理 2023.08.16
     * 
     * log("DAMS 処理"); term_type=0;
     * 
     * try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3); PreparedStatement ps
     * = conn.prepareStatement(SQL)) {
     * 
     * try (ResultSet rs = ps.executeQuery()) {
     * 
     * if (rs.next()) { reccnt++;
     * 
     * String JISIKI = rs.getString("JISIKI"); int RENBAN = rs.getInt("RENBAN"); String SUI_CD =
     * rs.getString("SUI_CD"); int BUSHO_MAX = rs.getInt("BUSHO_MAX"); int BUSHO_CARNUM =
     * rs.getInt("BUSHO_CARNUM"); int SITUATION_CD = rs.getInt("SITUATION_CD"); int USE_KAHI =
     * rs.getInt("USE_KAHI"); int AI_CARCD1 = rs.getInt("AI_CARCD1"); int AI_CARCD2 =
     * rs.getInt("AI_CARCD2");
     * 
     * String jointCarCode1 = Integer.valueOf(AI_CARCD1).toString(); String jointCarCode2 =
     * Integer.valueOf(AI_CARCD2).toString();;
     * 
     * bean.setSuiriStatusCode(SITUATION_CD); bean.setJointCarCode1(jointCarCode1);
     * bean.setJointCarCode2(jointCarCode2);
     * 
     * //水利使用可否が[0]なら[不能水利] if(USE_KAHI==0) { ptn = 3; }else { //部署済み車両数が1以上か？ if(BUSHO_CARNUM>= 1)
     * { log("部署済み車両数が1以上"); ptn = 1; }else { log("部署済み車両数が0"); ptn = 17; } }
     * 
     * } } } catch (SQLException e) { e.printStackTrace(); ptn = -1; } catch (Exception e) {
     * e.printStackTrace(); ptn = -1; } finally { //System.out.println("処理が完了しました"); } }else {
     * //受令端末処理 log("受令端末処理"); term_type=1; CAR_CD = Integer.parseInt(carcd);
     * 
     * try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3); PreparedStatement ps
     * = conn.prepareStatement(SQL)) {
     * 
     * try (ResultSet rs = ps.executeQuery()) {
     * 
     * if (rs.next()) { reccnt++;
     * 
     * String JISIKI = rs.getString("JISIKI"); int RENBAN = rs.getInt("RENBAN"); String SUI_CD =
     * rs.getString("SUI_CD"); int BUSHO_MAX = rs.getInt("BUSHO_MAX"); int BUSHO_CARNUM =
     * rs.getInt("BUSHO_CARNUM"); int SITUATION_CD = rs.getInt("SITUATION_CD"); int USE_KAHI =
     * rs.getInt("USE_KAHI"); int AI_CARCD1 = rs.getInt("AI_CARCD1"); int AI_CARCD2 =
     * rs.getInt("AI_CARCD2");
     * 
     * String jointCarCode1 = Integer.valueOf(AI_CARCD1).toString(); String jointCarCode2 =
     * Integer.valueOf(AI_CARCD2).toString();;
     * 
     * bean.setSuiriStatusCode(SITUATION_CD); bean.setJointCarCode1(jointCarCode1);
     * bean.setJointCarCode2(jointCarCode2);
     * 
     * 
     * // 部署車両テーブル(TBCK0002)の // 自車両レコードの水利コードの部署区分が1(部署) int kbn = CheckTBCK0002_01(SUIRI_CD,
     * CAR_CD);
     * 
     * log("部署車両テーブル(TBCK0002)の自車両レコードの水利コードの部署区分"+kbn); //2023.07.18 修正 if (kbn == 1) { ptn = 1; }
     * else { if (JISIKI.indexOf(jisiki) == 0) { log("事案識別子が一致"); //事案識別子が一致 if (BUSHO_CARNUM > 0) {
     * log("部署車両数が0以上"); if (KOZO_B == 2) { //双口 log("双口"); if (BUSHO_CARNUM == 1 && SITUATION_CD ==
     * 2) {ptn = 8;} if (BUSHO_CARNUM == 1 && SITUATION_CD == 1) {ptn = 9;} if (BUSHO_CARNUM == 1 &&
     * SITUATION_CD == 0 && AI_CARCD1 == 0 && AI_CARCD2 != 0) {ptn = 10;} if (BUSHO_CARNUM == 1 &&
     * SITUATION_CD == 0 && AI_CARCD1 != 0 && AI_CARCD2 == 0) {ptn = 11;} if (BUSHO_CARNUM >= 2 &&
     * SITUATION_CD == 3) {ptn = 12;} if (BUSHO_CARNUM >= 2 && SITUATION_CD == 1) {ptn = 13;} if
     * (BUSHO_CARNUM >= 2 && SITUATION_CD == 2) {ptn = 14;} if (BUSHO_CARNUM >= 2 && SITUATION_CD ==
     * 0) {ptn = 5;}
     * 
     * } else { //単口 log("単口"); if (SITUATION_CD == 0) { log("水利状況コードが0"); ptn = 7; } if
     * (SITUATION_CD == 1) { ///TBCK0001 最大部署数<=部署済車両数 ret =5 if (BUSHO_MAX <= BUSHO_CARNUM) {
     * log("最大部署数<=部署済車両数"); ptn = 5; } else { ptn = 7; } } } } else { log("部署車両数が0"); //
     * 部署車両テーブ(TBCK0002)の自車両レコードで // 部署区分が0(部署解除)＆割当区分が0以外 ret =16
     * 
     * if (CheckTBCK0002_03(jisiki, SUIRI_CD, CAR_CD) != 0) { ptn = 16; } else {
     * log("部署車両テーブル(TBCK0002)で対象事案が存在し、割り当て区分が0以外"); if (CheckTBCK0002_02(SUIRI_CD, CAR_CD) == 0) {
     * log("部署車両テーブル(TBCK0002)の自車両レコードで部署区分が０"); ptn=2; }else { ptn = 15; } } }
     * 
     * } else { log("事案識別子が一致しない"); //(TBCK0001)最大部署数<＝(TBCK0001)部署済車両数。 if (BUSHO_MAX <=
     * BUSHO_CARNUM) { log("(TBCK0001)最大部署数<＝(TBCK0001)部署済車両数"); ptn = 4; } else { if (BUSHO_CARNUM
     * > 0) { log("(TBCK0001)部署済車両数が0以上"); ptn = 6; } else { ptn = 16; } } } } } }
     * //水利部署テーブルに該当レコードがない //if (reccnt == 0) { //ptn = 17; //} } catch (SQLException e) {
     * e.printStackTrace(); ptn = -1; } catch (Exception e) { e.printStackTrace(); ptn = -1; }
     * finally { //System.out.println("処理が完了しました"); } }
     */

  }


  // -----------------------------------------------------------------------------------------------------------

  private int ReadStaus(String jiancode, int carcd, String suiriCode, int KOZO_B, WaterBean bean) {

    // KOZO_B 1:単口 2:双口

    int ret = -1;

    String SQL = "";
    ObjectMapper objectMapper = new ObjectMapper();

    try {
      JsonNode json = objectMapper.readTree(
          Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
      System.out.println(json);

      URL = json.get("conn_url").textValue();
      USER = json.get("conn_user").textValue();
      PASS = json.get("conn_pass").textValue();
    } catch (Exception e) {
      e.printStackTrace();
    }

    SQL = "select * from TBWG0009_N where termId =" + carcd + "  and jisiki = '" + jiancode
        + "'  and suiricode = '" + suiriCode + "'";

    System.out.println(SQL);

    Boolean isExit = false;

    try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {

          // String suiriCode;
          int suiriKahi = rs.getInt("suiriKahi");
          int suiriStatusCode = rs.getInt("suiriStatusCode");
          String jointCarCode1 = rs.getString("jointCarCode1");
          String jointCarCode2 = rs.getString("jointCarCode2");
          int busyoMax = rs.getInt("busyoMax");
          int busyoCarNum = rs.getInt("busyoCarNum");
          int hasMyCar = rs.getInt("hasMyCar");
          int hasSitei = rs.getInt("hasSitei");
          // Boolean underBusho = rs.getBoolean("underBusho");

          bean.setSuiriStatusCode(suiriStatusCode);
          bean.setJointCarCode1(jointCarCode1);
          bean.setJointCarCode2(jointCarCode2);

          if (suiriKahi == 0) {
            // 水利状態テーブルは[0]が使用不可
            log("使用不可");
            ret = 3;
          } else {
            if (hasMyCar == 1) {
              // 自車両
              log("自車両");
              ret = 1;
            } else {
              if (busyoCarNum == 0) {
                log("部署車両数が0");

                if (hasSitei == 0) {
                  log("水利指定が0");
                  ret = 16;
                }
                if (hasSitei == 2) {
                  log("水利指定が2");
                  ret = 15;
                }
                if (hasSitei == 1) {
                  log("水利指定が1");
                  ret = 2;
                }
              } else {
                if (KOZO_B == 2) {
                  log("双口");
                  // 双口
                  if (busyoCarNum == 1 && suiriStatusCode == 2) {
                    ret = 8;
                  }
                  if (busyoCarNum == 1 && suiriStatusCode == 1) {
                    ret = 9;
                  }
                  if (busyoCarNum == 1 && suiriStatusCode == 0 && jointCarCode1.indexOf("0000") == 0
                      && jointCarCode2.indexOf("0000") != 0) {
                    ret = 10;

                  }
                  if (busyoCarNum == 1 && suiriStatusCode == 0 && jointCarCode1.indexOf("0000") != 0
                      && jointCarCode2.indexOf("0000") == 0) {
                    ret = 11;
                  }
                  if (busyoCarNum >= 2 && suiriStatusCode == 3) {
                    ret = 12;
                  }
                  if (busyoCarNum >= 2 && suiriStatusCode == 1) {
                    ret = 13;
                  }
                  if (busyoCarNum >= 2 && suiriStatusCode == 2) {
                    ret = 14;
                  }
                  if (busyoCarNum >= 2 && suiriStatusCode == 0) {
                    ret = 5;
                  }

                } else {
                  log("単口");
                  // 単口
                  if (suiriStatusCode == 0) {
                    ret = 7;
                  }
                  if (suiriStatusCode == 1) {
                    if (busyoMax <= busyoCarNum) {
                      ret = 5;
                    } else {
                      ret = 7;
                    }
                  }

                }
              }
            }
          }

          log("ret=" + ret);
          isExit = true;
        } else {
          System.out.println("自車水利状態テーブルに該当レコードなし");
        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      // System.out.println("処理が完了しました");
    }
    return ret;
  }

  public int ReadTBCK0001(String SUIRI_CD, String jisiki, String carcd, int KOZO_B,
      WaterBean bean) {

    int ptn = -1;
    String SQL = "";

    if (MODE.indexOf("debug") == 0) {
      SQL = "select * from TBCK0001 WHERE SUI_CD='" + SUIRI_CD + "'";
    } else {
      SQL = "select * from SHASAI.TBCK0001 WHERE SUI_CD='" + SUIRI_CD + "'";
    }

    System.out.println(SQL);

    int reccnt = 0;
    Boolean IsJian = false;

    // 水利部署テーブルに該当レコードがあるか？

    int CAR_CD = 0;

    // 2023.08.16
    int term_type = 0;

    // 2023.07.11 check追加
    if (carcd == null || carcd.length() == 0) {
      // DAMS処理 2023.08.16

      log("DAMS 処理");
      term_type = 0;

      try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
          PreparedStatement ps = conn.prepareStatement(SQL)) {

        try (ResultSet rs = ps.executeQuery()) {

          if (rs.next()) {
            reccnt++;

            String JISIKI = rs.getString("JISIKI");
            int RENBAN = rs.getInt("RENBAN");
            String SUI_CD = rs.getString("SUI_CD");
            int BUSHO_MAX = rs.getInt("BUSHO_MAX");
            int BUSHO_CARNUM = rs.getInt("BUSHO_CARNUM");
            int SITUATION_CD = rs.getInt("SITUATION_CD");
            int USE_KAHI = rs.getInt("USE_KAHI");
            int AI_CARCD1 = rs.getInt("AI_CARCD1");
            int AI_CARCD2 = rs.getInt("AI_CARCD2");

            String jointCarCode1 = Integer.valueOf(AI_CARCD1).toString();
            String jointCarCode2 = Integer.valueOf(AI_CARCD2).toString();;

            bean.setSuiriStatusCode(SITUATION_CD);
            bean.setJointCarCode1(jointCarCode1);
            bean.setJointCarCode2(jointCarCode2);

            // 水利使用可否が[0]なら[不能水利]
            if (USE_KAHI == 0) {
              ptn = 3;
            } else {
              // 部署済み車両数が1以上か？
              if (BUSHO_CARNUM >= 1) {
                log("部署済み車両数が1以上");
                ptn = 1;
              } else {
                log("部署済み車両数が0");
                ptn = 17;
              }
            }

          }
        }
      } catch (SQLException e) {
        e.printStackTrace();
        ptn = -1;
      } catch (Exception e) {
        e.printStackTrace();
        ptn = -1;
      } finally {
        // System.out.println("処理が完了しました");
      }
    } else {
      // 受令端末処理
      log("受令端末処理");
      term_type = 1;
      CAR_CD = Integer.parseInt(carcd);

      try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
          PreparedStatement ps = conn.prepareStatement(SQL)) {

        try (ResultSet rs = ps.executeQuery()) {

          if (rs.next()) {
            reccnt++;

            String JISIKI = rs.getString("JISIKI");
            int RENBAN = rs.getInt("RENBAN");
            String SUI_CD = rs.getString("SUI_CD");
            int BUSHO_MAX = rs.getInt("BUSHO_MAX");
            int BUSHO_CARNUM = rs.getInt("BUSHO_CARNUM");
            int SITUATION_CD = rs.getInt("SITUATION_CD");
            int USE_KAHI = rs.getInt("USE_KAHI");
            int AI_CARCD1 = rs.getInt("AI_CARCD1");
            int AI_CARCD2 = rs.getInt("AI_CARCD2");

            String jointCarCode1 = Integer.valueOf(AI_CARCD1).toString();
            String jointCarCode2 = Integer.valueOf(AI_CARCD2).toString();;

            bean.setSuiriStatusCode(SITUATION_CD);
            bean.setJointCarCode1(jointCarCode1);
            bean.setJointCarCode2(jointCarCode2);


            // 部署車両テーブル(TBCK0002)の
            // 自車両レコードの水利コードの部署区分が1(部署)
            int kbn = CheckTBCK0002_01(SUIRI_CD, CAR_CD);

            log("部署車両テーブル(TBCK0002)の自車両レコードの水利コードの部署区分" + kbn);
            // 2023.07.18 修正
            if (kbn == 1) {
              ptn = 1;
            } else {
              if (JISIKI.indexOf(jisiki) == 0) {
                log("事案識別子が一致");
                // 事案識別子が一致
                if (BUSHO_CARNUM > 0) {
                  log("部署車両数が0以上");
                  if (KOZO_B == 2) {
                    // 双口
                    log("双口");
                    if (BUSHO_CARNUM == 1 && SITUATION_CD == 2) {
                      ptn = 8;
                    }
                    if (BUSHO_CARNUM == 1 && SITUATION_CD == 1) {
                      ptn = 9;
                    }
                    if (BUSHO_CARNUM == 1 && SITUATION_CD == 0 && AI_CARCD1 == 0
                        && AI_CARCD2 != 0) {
                      ptn = 10;
                    }
                    if (BUSHO_CARNUM == 1 && SITUATION_CD == 0 && AI_CARCD1 != 0
                        && AI_CARCD2 == 0) {
                      ptn = 11;
                    }
                    if (BUSHO_CARNUM >= 2 && SITUATION_CD == 3) {
                      ptn = 12;
                    }
                    if (BUSHO_CARNUM >= 2 && SITUATION_CD == 1) {
                      ptn = 13;
                    }
                    if (BUSHO_CARNUM >= 2 && SITUATION_CD == 2) {
                      ptn = 14;
                    }
                    if (BUSHO_CARNUM >= 2 && SITUATION_CD == 0) {
                      ptn = 5;
                    }

                  } else {
                    // 単口
                    log("単口");
                    if (SITUATION_CD == 0) {
                      log("水利状況コードが0");
                      ptn = 7;
                    }
                    if (SITUATION_CD == 1) {
                      /// TBCK0001 最大部署数<=部署済車両数 ret =5
                      if (BUSHO_MAX <= BUSHO_CARNUM) {
                        log("最大部署数<=部署済車両数");
                        ptn = 5;
                      } else {
                        ptn = 7;
                      }
                    }
                  }
                } else {
                  log("部署車両数が0");
                  // 部署車両テーブ(TBCK0002)の自車両レコードで
                  // 部署区分が0(部署解除)＆割当区分が0以外 ret =16

                  if (CheckTBCK0002_03(jisiki, SUIRI_CD, CAR_CD) != 0) {
                    ptn = 16;
                  } else {
                    log("部署車両テーブル(TBCK0002)で対象事案が存在し、割り当て区分が0以外");
                    if (CheckTBCK0002_02(SUIRI_CD, CAR_CD) == 0) {
                      log("部署車両テーブル(TBCK0002)の自車両レコードで部署区分が０");
                      ptn = 2;
                    } else {
                      ptn = 15;
                    }
                  }
                }

              } else {
                log("事案識別子が一致しない");
                // (TBCK0001)最大部署数<＝(TBCK0001)部署済車両数。
                if (BUSHO_MAX <= BUSHO_CARNUM) {
                  log("(TBCK0001)最大部署数<＝(TBCK0001)部署済車両数");
                  ptn = 4;
                } else {
                  if (BUSHO_CARNUM > 0) {
                    log("(TBCK0001)部署済車両数が0以上");
                    ptn = 6;
                  } else {
                    ptn = 16;
                  }
                }
              }
            }
          }
        }
        // 水利部署テーブルに該当レコードがない
        // if (reccnt == 0) {
        // ptn = 17;
        // }
      } catch (SQLException e) {
        e.printStackTrace();
        ptn = -1;
      } catch (Exception e) {
        e.printStackTrace();
        ptn = -1;
      } finally {
        // System.out.println("処理が完了しました");
      }
    }

    return ptn;

  }

  public int CheckTBCK0002_01(String SUI_CD, int carcd) {
    int ret = -1;

    String SQL = "";

    if (MODE.indexOf("debug") == 0) {
      SQL = "select * from TBCK0002 WHERE SUI_CD='" + SUI_CD + "' AND CAR_CD=" + carcd;
    } else {
      SQL = "select * from SHASAI.TBCK0002 WHERE SUI_CD='" + SUI_CD + "' AND CAR_CD=" + carcd;
    }

    System.out.println(SQL);

    try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {

          // System.out.println("車両テーブルに該当レコードがある");

          // 水利コードの部署区分が１
          int BUSHO_KBN = rs.getInt("BUSHO_KBN");
          if (BUSHO_KBN == 0) {
            ret = 0;
          }
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
    } catch (Exception e) {
      e.printStackTrace();
      ret = -1;
    } finally {
      // System.out.println("処理が完了しました");
    }
    return ret;
  }

  public int CheckTBCK0002_02(String SUI_CD, int carcd) {
    int ret = -1;

    String SQL = "";

    if (MODE.indexOf("debug") == 0) {
      SQL = "select * from TBCK0002 WHERE SUI_CD='" + SUI_CD + "' AND CAR_CD=" + carcd;
    } else {
      SQL = "select * from SHASAI.TBCK0002 WHERE SUI_CD='" + SUI_CD + "' AND CAR_CD=" + carcd;
    }

    System.out.println(SQL);

    try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {

          // System.out.println("車両テーブルに該当レコードがある");

          ret = 0;

          // 水利コードの部署区分が１
          int BUSHO_KBN = rs.getInt("BUSHO_KBN");
          int WARI_KBN = rs.getInt("WARI_KBN");

          if (BUSHO_KBN == 0 && WARI_KBN != 0) {
            ret = 0;
          }

        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
    } catch (Exception e) {
      e.printStackTrace();
      ret = -1;
    } finally {
      // System.out.println("処理が完了しました");
    }
    return ret;
  }

  public int CheckTBCK0002_03(String jisiki, String SUI_CD, int carcd) {
    int ret = -1;

    String SQL = "";

    if (MODE.indexOf("debug") == 0) {
      SQL = "select * from TBCK0002 WHERE SUI_CD='" + SUI_CD + "'";
    } else {
      SQL = "select * from SHASAI.TBCK0002 WHERE SUI_CD='" + SUI_CD + "'";
    }

    System.out.println(SQL);

    try (Connection conn = DriverManager.getConnection(URL3, USER3, PASS3);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        if (rs.next()) {

          System.out.println("車両テーブルに該当レコードがある");

          // int BUSHO_KBN = rs.getInt("BUSHO_KBN");
          int WARI_KBN = rs.getInt("WARI_KBN");

          if (WARI_KBN != 0) {
            ret = 0;
          }
        }
      }
    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
    } catch (Exception e) {
      e.printStackTrace();
      ret = -1;
    } finally {
      // System.out.println("処理が完了しました");
    }
    return ret;
  }

  private int switchSymbolId(int symbol_id, int ptn) {
    int ret = symbol_id;

    switch (ptn) {
      // 部署水利
      case 1:
        symbol_id += 150;
        ret = symbol_id;
        break;
      // 指定水利自車両
      case 2:
        symbol_id += 1000;
        ret = symbol_id;
        break;
      // 不能水利
      case 3:
        symbol_id += 1150;
        ret = symbol_id;
        break;
      // 他事案部署中
      case 4:
        symbol_id += 1150;
        ret = symbol_id;
        break;
      // 他車両部署中相掛否
      case 5:
        symbol_id += 325;
        ret = symbol_id;
        break;
      // 他事案部署中部署可
      case 6:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中相掛可
      case 7:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中部署可/相掛可
      case 8:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中相掛可/部署可
      case 9:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中部署可/相掛否
      case 10:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中相掛否/部署可
      case 11:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中相掛可/相掛可
      case 12:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中相掛可/相掛否
      case 13:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 他車両部署中相掛否/相掛可
      case 14:
        symbol_id += 200;
        ret = symbol_id;
        break;
      // 指定水利他車両
      case 15:
        symbol_id += 50;
        ret = symbol_id;
        break;
      // 使用可能水利
      case 16:
        symbol_id += 0;
        ret = symbol_id;
        break;
      // 通常
      case 17:
        symbol_id += 0;
        ret = symbol_id;
        break;
    }

    return ret;
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}

/*
 * GetCarInfo 春日井版
 */
package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetCarInfo
 */
@WebServlet("/GetCarInfo")
public class GetCarInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";
	String URL2 = "";
	String USER2 = "";
	String PASS2 = "";
	String URL3 = "";
	String USER3 = "";
	String PASS3 = "";
	String MODE = "";

	// 20240130 start
	int kijyunkei = 6;
	// 20240130 end

	// private String conn_str =
	// "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";
	// private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
	// private String conn_user = "DAMS";
	// private String conn_pass = "DAMS2022";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetCarInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		// 20240130 start
		//String coordinate = request.getParameter("coordinate");
		//if (coordinate == null) {
		//} else {
			//kijyunkei = Integer.parseInt(coordinate);
		//}
		// 20240130 end
		

		// 運用モード
		int OPE_MODE = 0;
		String ope_mode = request.getParameter("ope_mode");
		if (ope_mode == null) {
		} else {
			OPE_MODE = Integer.parseInt(ope_mode);
		}
		if (OPE_MODE == 0) {
			System.out.println("運用モードは[通常]");
		} else {
			System.out.println("運用モードは[訓練]");
		}

		// 設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			System.out.println(json);
			
			kijyunkei= Integer.parseInt(json.get("coordinate").textValue());

			if (OPE_MODE == 0) {
				URL = json.get("conn_url").textValue();
				USER = json.get("conn_user").textValue();
				PASS = json.get("conn_pass").textValue();
				URL2 = json.get("conn_url2").textValue();
				USER2 = json.get("conn_user2").textValue();
				PASS2 = json.get("conn_pass2").textValue();

				MODE = json.get("mode").textValue();
				if (MODE.indexOf("debug") == 0) {
					URL3 = json.get("conn_url").textValue();
					USER3 = json.get("conn_user").textValue();
					PASS3 = json.get("conn_pass").textValue();

				} else {
					URL3 = json.get("conn_url3").textValue();
					USER3 = json.get("conn_user3").textValue();
					PASS3 = json.get("conn_pass3").textValue();
				}

			} else {
				URL = json.get("conn_url_t").textValue();
				USER = json.get("conn_user_t").textValue();
				PASS = json.get("conn_pass_t").textValue();
				URL2 = json.get("conn_url2_t").textValue();
				USER2 = json.get("conn_user2_t").textValue();
				PASS2 = json.get("conn_pass2_t").textValue();

				MODE = json.get("mode").textValue();
				if (MODE.indexOf("debug") == 0) {
					URL3 = json.get("conn_url_t").textValue();
					USER3 = json.get("conn_user_t").textValue();
					PASS3 = json.get("conn_pass_t").textValue();

				} else {
					URL3 = json.get("conn_url3_t").textValue();
					USER3 = json.get("conn_user3_t").textValue();
					PASS3 = json.get("conn_pass3_t").textValue();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("kijyunkei"+kijyunkei);


		CarDto dto = new CarDto();
		PrintWriter out = response.getWriter();

		if (ReadDB(out, dto) == 0) {
			dto.setResult("OK");
		} else {
			dto.setResult("NG");
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();
		log("End");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	public int ReadDB(PrintWriter out, CarDto dto) {

		int ret = 0;

		// final String URL = conn_str;
		// final String USER = conn_user;
		// final String PASS = conn_pass;
		String[] RANGE_TBL = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };

		String SQL = "";

		SQL = "select FIRE.TBSSB024.*,FIRE.TBDSC210A.CAR_NM,FIRE.TBDSC210A.SYMBOL_CD,FIRE.TBDSC510A.DOUTAI_NM,FIRE.TBDSC390A.CODE_NM from FIRE.TBSSB024  ";
		SQL += " INNER JOIN FIRE.TBDSC210A ON TO_NUMBER(FIRE.TBSSB024.CAR_CD) = FIRE.TBDSC210A.CAR_CD ";
		SQL += " INNER JOIN FIRE.TBDSC510A ON FIRE.TBSSB024.MOVE_CD = FIRE.TBDSC510A.DOUTAI_CD";
		SQL += " INNER JOIN FIRE.TBDSC390A ON (TO_NUMBER(FIRE.TBSSB024.CAR_TYPE_CD) = FIRE.TBDSC390A.CODE AND FIRE.TBDSC390A.CODE_SYU=1020) ";
//		SQL += " WHERE FIRE.TBSSB024.CAR_CD='"+keyValue+"'";

		int reccnt = 0;
		List<JsonCarBean> jsonList = new ArrayList<>();

		System.out.println("URL2=" + URL2);
		System.out.println("USER2=" + USER2);
		System.out.println("PASS2=" + PASS2);

		try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;

					String CAR_CD = rs.getString("CAR_CD");
					String MOVE_CD = rs.getString("MOVE_CD");
					String ZAHYO_X = rs.getString("ZAHYO_X");
					String ZAHYO_Y = rs.getString("ZAHYO_Y");
					String DIRECTION = rs.getString("DIRECTION");
					int SYMBOL_CD = rs.getInt("SYMBOL_CD");
					String CAR_NM = rs.getString("CAR_NM");
					String DOUTAI_NM = rs.getString("DOUTAI_NM");
					String POS_REFLASH_DATE = rs.getString("POS_REFLASH_DATE");
					String SPEED = rs.getString("SPEED");
					String CODE_NM = rs.getString("CODE_NM");

//					String KANRISHARYO_CD = rs.getString("KANRISHARYO_CD");
					// String HOUKO = rs.getString("HOUKO");
					// String DOTAI_KIHON_CD = rs.getString("DOTAI_KIHON_CD");
					// String DOTAI_SYOSAI_CD = rs.getString("DOTAI_SYOSAI_CD");
					// String ITI_ZAHYO_X = rs.getString("ITI_ZAHYO_X");
					// String ITI_ZAHYO_Y = rs.getString("ITI_ZAHYO_Y");
					// String SYMBOL_CD = rs.getString("SYMBOL_CD");
					if (ZAHYO_X.length() > 13) {
						ZAHYO_X = "0";
					}
					if (ZAHYO_Y.length() > 13) {
						ZAHYO_Y = "0";
					}

					int zx = 0;
					int zy = 0;

					try {
						zx = Integer.parseInt(ZAHYO_X);
						zy = Integer.parseInt(ZAHYO_Y);
					} catch (Exception ex) {
						ex.printStackTrace();
					}

					MapConvert mc = new MapConvert();

					// 20240130 コメント
					// int kijyunkei = 6;

					double[] result = new double[2];
					result[0] = 0.0;
					result[1] = 0.0;

					mc.ConvertPos(zx, zy, kijyunkei, result);

					double zahyo_x = result[0];
					double zahyo_y = result[1];

					reccnt++;

					JsonCarBean jsonBean = new JsonCarBean();

					int dotai = 0;

					try {
						dotai = Integer.parseInt(MOVE_CD.replace(" ", ""));
					} catch (Exception ex) {
						System.out.println(ex.toString());
					}

					int HOUI_VAL = 0;

					/* 20251024
					for (int j = 0; j < RANGE_TBL.length; j++) {
						if (DIRECTION.indexOf(RANGE_TBL[j]) == 0) {
							HOUI_VAL = j;
						}
					}
					*/

					/*
					 * 
					 * 1,指揮車,1000,160
2,タンク車/ポンプ車,1100,161
3,救助車,1200,162
4,救助車,1200,163
5,水槽車,1300,164
6,NBC,1400,169
7,その他車両,1500,171
8,梯子車,1600,167
9,救急車,1700,168
					int symbol_no = SYMBOL_CD * 100 + HOUI_VAL;
					
					//20250526 Add
					if(SYMBOL_CD==150 ) {
						symbol_no = SYMBOL_CD * 100;
					}
					*/
					//20250526 END
					
//					int sym_ptncode = Integer.parseInt(CAR_CD);
					// int range = Integer.parseInt(HOUKO);

					// int symbolid = (sym_ptncode + 200) * 100 + range + 1;
					
					int symbolid=1000;
					int symbol_no=1000;

					jsonBean.setCar_cd(CAR_CD);
					jsonBean.setDotai(dotai);
					jsonBean.setHouko(DIRECTION);
					jsonBean.setSymbolid(symbol_no);

					jsonBean.setZx(zahyo_x);
					jsonBean.setZy(zahyo_y);

					// 20230906
					jsonBean.setCar_cd(CAR_CD);

			//		jsonBean.setCar_nm(CAR_NM);
			//		jsonBean.setDoutai_nm(DOUTAI_NM);
			//		jsonBean.setCartype_nm(CODE_NM);
			//		jsonBean.setUpdate_date(POS_REFLASH_DATE);
					jsonList.add(jsonBean);

					System.out.println(reccnt);

				}
				dto.setData(jsonList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;


	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

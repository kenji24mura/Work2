package com;

import java.util.List;

public class WaterDto {
	 private String result;
	 private String message;
	 private String sql;
	 private List<WaterBean> data;
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public List<WaterBean> getData() {
		return data;
	}
	public void setData(List<WaterBean> data) {
		this.data = data;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}

}

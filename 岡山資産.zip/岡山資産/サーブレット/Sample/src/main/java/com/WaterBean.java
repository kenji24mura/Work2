package com;

public class WaterBean {
	private String suiri_cd;
	private int suiri_sbt;
	private int symbol_sbt;
	private int shiyo_kahi;
	private int haikan_kokei;
	private String moji;
	private int izahyo_x;
	private int izahyo_y;
	private int kozo_b;
//	水利状態コード
	private int suiriStatusCode;
//	���|��ԗ��R�[�h�P
	private String jointCarCode1;
//	���|��ԗ��R�[�h�Q
	private String jointCarCode2;
//	�\����
	private String disp_name;

	public String getSuiri_cd() {
		return suiri_cd;
	}
	public void setSuiri_cd(String suiri_cd) {
		this.suiri_cd = suiri_cd;
	}
	public int getSuiri_sbt() {
		return suiri_sbt;
	}
	public void setSuiri_sbt(int suiri_sbt) {
		this.suiri_sbt = suiri_sbt;
	}
	public int getSymbol_sbt() {
		return symbol_sbt;
	}
	public void setSymbol_sbt(int symbol_sbt) {
		this.symbol_sbt = symbol_sbt;
	}
	public int getShiyo_kahi() {
		return shiyo_kahi;
	}
	public void setShiyo_kahi(int shiyo_kahi) {
		this.shiyo_kahi = shiyo_kahi;
	}
	public int getHaikan_kokei() {
		return haikan_kokei;
	}
	public void setHaikan_kokei(int haikan_kokei) {
		this.haikan_kokei = haikan_kokei;
	}
	public String getMoji() {
		return moji;
	}
	public void setMoji(String moji) {
		this.moji = moji;
	}
	public int getIzahyo_x() {
		return izahyo_x;
	}
	public void setIzahyo_x(int izahyo_x) {
		this.izahyo_x = izahyo_x;
	}
	public int getIzahyo_y() {
		return izahyo_y;
	}
	public void setIzahyo_y(int izahyo_y) {
		this.izahyo_y = izahyo_y;
	}
		public int getKozo_b() {
		return kozo_b;
	}
	public void setKozo_b(int kozo_b) {
		this.kozo_b = kozo_b;
	}
	public int getSuiriStatusCode() {
		return suiriStatusCode;
	}
	public void setSuiriStatusCode(int suiriStatusCode) {
		this.suiriStatusCode = suiriStatusCode;
	}
	public String getJointCarCode1() {
		return jointCarCode1;
	}
	public void setJointCarCode1(String jointCarCode1) {
		this.jointCarCode1 = jointCarCode1;
	}
	public String getJointCarCode2() {
		return jointCarCode2;
	}
	public void setJointCarCode2(String jointCarCode2) {
		this.jointCarCode2 = jointCarCode2;
	}
	public String getDisp_name() {
		return disp_name;
	}
	public void setDisp_name(String disp_name) {
		this.disp_name = disp_name;
	}

}

/*
String SUIRI_CD = rs.getString("SUIRI_CD");
int SUIRI_SBT = rs.getInt("SUIRI_SBT");
int SYMBOL_SBT = rs.getInt("SYMBOL_SBT");
int SHIYO_KAHI = rs.getInt("SHIYO_KAHI");
int HAIKAN_KOKEI = rs.getInt("HAIKAN_KOKEI");
String MOJI = rs.getString("MOJI");
int IZAHYO_X = rs.getInt("IZAHYO_X");
int IZAHYO_Y = rs.getInt("IZAHYO_Y");
*/
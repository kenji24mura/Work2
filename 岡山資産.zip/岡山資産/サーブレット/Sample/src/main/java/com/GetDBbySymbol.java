package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetDB
 *
 * GetDBbySymbol:シンボル指定で中間テーブルを検索する
 * 
 */
@WebServlet("/GetDBbySymbol")
public class GetDBbySymbol extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";
	
	//private String conn_str = "jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

	//private String conn_user = "WEBGIS";
	//private String conn_pass = "WEBGIS";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetDBbySymbol() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
//		SymbolInfoDto dto = new SymbolInfoDto();
		MiddleDto dto = new MiddleDto();

		try {
			String lay_no = request.getParameter("lay_no");
//			String item_no = request.getParameter("item_no");
			int symbol_no = Integer.parseInt(request.getParameter("symbol_no"));
			int lay_type = Integer.parseInt(request.getParameter("lay_type"));

			if(ReadDB(lay_no, symbol_no, lay_type, out, dto)==0) {
				dto.setResult("OK");
			}else {
				dto.setResult("NG");
			}
		} catch (Exception e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			dto.setResult("NG");
		} finally {
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		out.flush();

	}

	public int ReadDB(String lay_no, int symbol_no, int lay_type, PrintWriter out, MiddleDto dto) {

		int ret = -1;
		String SQL = "";

		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;

		if (lay_type == 1) {

			SQL = "select * from TBWG0001 WHERE lay_no='" + lay_no + "' AND symbol_no=" + symbol_no;
		} else {

			SQL = "select * from TBWG0002 WHERE lay_no='" + lay_no + "' AND symbol_no=" + symbol_no;
		}
		SQL += " order by lay_no,item_no";

		System.out.println(SQL);

		dto.setSql(SQL);

		List<MiddleBean> jsonList = new ArrayList<>();


		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {
					
					ret = 0;
					
					MiddleBean bean = new MiddleBean();


					int info_type = rs.getInt("info_type");
					String item_no = rs.getString("item_no");
					String info_summery = rs.getString("info_summery");
//					int symbol_no = rs.getInt("symbol_no");
					double zahyo_x = rs.getDouble("zahyo_x");
					double zahyo_y = rs.getDouble("zahyo_y");
					String strinfo1 = rs.getString("strinfo1");
					String strinfo2 = rs.getString("strinfo2");
					String strinfo3 = rs.getString("strinfo3");
					double str_zahyo_x = rs.getDouble("str_zahyo_x");
					double str_zahyo_y = rs.getDouble("str_zahyo_y");
					Date update = rs.getDate("UPDATE_DATE");

					bean.setLay_no(lay_no);
					bean.setItem_no(item_no);
					bean.setInfo_type(info_type);
					bean.setInfo_summery(info_summery);
					bean.setLay_type(lay_type);
					bean.setSymbol_no(symbol_no);
					bean.setZahyo_x(zahyo_x);
					bean.setZahyo_y(zahyo_y);
					bean.setStrinfo1(strinfo1);
					bean.setStrinfo2(strinfo2);
					bean.setStrinfo3(strinfo3);
					bean.setStr_zahyo_x(str_zahyo_x);
					bean.setStr_zahyo_y(str_zahyo_y);
/*
					dto.setLay_no(lay_no);
					dto.setItem_no(item_no);
					dto.setInfo_type(info_type);
					dto.setInfo_summery(info_summery);
					dto.setLay_type(lay_type);
					dto.setSymbol_no(symbol_no);
					dto.setZahyo_x(zahyo_x);
					dto.setZahyo_y(zahyo_y);
					dto.setStrinfo1(strinfo1);
					dto.setStrinfo2(strinfo2);
					dto.setStrinfo3(strinfo3);
					dto.setStr_zahyo_x(str_zahyo_x);
					dto.setStr_zahyo_y(str_zahyo_y);
*/
					if (lay_type == 1) {
						// シンボル
					} else {
						// 線・ポリゴン

						int zahyo_cnt = rs.getInt("zahyo_cnt");

//						dto.setZahyo_cnt(zahyo_cnt);
						bean.setZahyo_cnt(zahyo_cnt);


						Array zahyo_array = rs.getArray("zahyo_array");

						Object[] obj = (Object[]) zahyo_array.getArray();

						// dto.zp = new ZPoint[zahyo_cnt];

						List<ZPointBean> zlist = new ArrayList<>();

						for (int i = 0; i < obj.length; i++) {

							Struct zp = (Struct) obj[i];

							Object[] obj2 = zp.getAttributes();

							ZPointBean zpoint = new ZPointBean();
							zpoint.setX(Double.parseDouble(obj2[0].toString()));
							zpoint.setY(Double.parseDouble(obj2[1].toString()));

							zlist.add(zpoint);

						}
						bean.setData(zlist);

//						dto.setData(zlist);
					}
					if (update != null) {
						String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(update);
						bean.setUpdate_date(str);
					}

					/*
					 * ConstBean bean = new ConstBean();
					 * 
					 * bean.setCONST_KEY(key); bean.setCONST_VALUE1(value1);
					 * bean.setCONST_VALUE2(value2); bean.setConst_COMMENT(comment);
					 * bean.setUpdate_DATE(str);
					 * 
					 */

					jsonList.add(bean);
					
				}
				dto.setData(jsonList);
				dto.setMessage("検索処理が完了しました");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

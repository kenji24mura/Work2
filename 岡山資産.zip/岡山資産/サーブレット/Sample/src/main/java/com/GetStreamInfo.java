package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetStreamInfo
 */
@WebServlet("/GetStreamInfo")
public class GetStreamInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetStreamInfo() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		String publisher_id = request.getParameter("publisher_id");

		//設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			System.out.println(json);

			URL = json.get("conn_url").textValue();
			USER = json.get("conn_user").textValue();
			PASS = json.get("conn_pass").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();

		 ReadDB(publisher_id,out);
		 
		out.flush();
	}

	public String ReadDB(String publisher_id, PrintWriter out) {

		String ret = "OK";

		String SQL = "";

		//地番がない場合
		SQL = "select * from TBWG0010 WHERE publisher_id='" + publisher_id + "'";
		System.out.println(SQL);

		StreamDto dto = new StreamDto();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				if (rs.next()) {

					String publisher_name = rs.getString("publisher_name");
					String broadcast_name = rs.getString("broadcast_name");
					String publish_status = rs.getString("publish_status");
					String place = rs.getString("place");
					Date start_date = rs.getDate("start_date");
					Date end_date = rs.getDate("end_date");

					dto.setPublisher_id(publisher_id);
					dto.setPublisher_name(publisher_name);
					dto.setBroadcast_name(broadcast_name);
					dto.setPublish_status(publish_status);

					
					String str1="";
					String str2="";
					try {
						str1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(start_date);
						str2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(end_date);
					}catch(Exception ex) {
						
					}
					dto.setPublish_status(place);
					dto.setStart_date(str1);
					dto.setEnd_date(str2);

				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = "NG";
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = "NG";
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		ObjectMapper mapper = new ObjectMapper();
		dto.setResult(ret);

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			ret = "NG";
		}

		return ret;

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

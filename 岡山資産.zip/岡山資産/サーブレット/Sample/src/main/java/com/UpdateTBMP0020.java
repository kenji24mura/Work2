package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class UpdateTBMP0020
 */
@WebServlet("/UpdateTBMP0020")
public class UpdateTBMP0020 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateTBMP0020() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url2").textValue();
	        USER = json.get("conn_user2").textValue();
	        PASS = json.get("conn_pass2").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		
		//Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//String update_date = sdf.format(cl.getTime());
		
		
		String mode = request.getParameter("mode");
		String uke_date = request.getParameter("uke_date");
		String renban = request.getParameter("renban");
		String shori_kbn = request.getParameter("shori_kbn");
		String zukei_syu = request.getParameter("zukei_syu");
		String sen_syu = request.getParameter("sen_syu");
		String haba_syu = request.getParameter("haba_syu");
		String cl_cd = request.getParameter("cl_cd");
		String ht_cd = request.getParameter("ht_cd");
		String zahyo_su = request.getParameter("zahyo_su");
		String zahyo_kukei = request.getParameter("zahyo_kukei");
		String keizu_su = request.getParameter("keizu_su");
		String keizu = request.getParameter("keizu");
		
		System.out.println(uke_date);
		
		try {
			uke_date = uke_date.replace("'","");
			
			String UKE_DATE=uke_date;	//,受付日,1,,NO,DATE,1,
			int REMBAN=Integer.parseInt(renban);			//,連番,2,,NO,"NUMBER(4, 0)",2,
			int SHORI_KBN=Integer.parseInt(shori_kbn);		//,処理区分,3,,YES,"NUMBER(1, 0)",,
			int ZUKEI_SYU=Integer.parseInt(zukei_syu);		//,図形種別,4,,YES,"NUMBER(1, 0)",,
			int SEN_SYU=Integer.parseInt(sen_syu);		//,線種,5,,YES,"NUMBER(2, 0)",,
			int HABA_SYU=Integer.parseInt(haba_syu);		//,線幅,6,,YES,"NUMBER(1, 0)",,
			int CL_CD=Integer.parseInt(cl_cd);			//,色コード,7,,YES,"NUMBER(3, 0)",,
			int HT_CD=Integer.parseInt(ht_cd);			//,ハッチングパターン,8,,YES,"NUMBER(1, 0)",,
			int ZAHYO_SU=Integer.parseInt(zahyo_su);		//,座標数,9,,YES,"NUMBER(3, 0)",,
			String ZAHYO_KUKEI=zahyo_kukei;//,絶対座標,10,,YES,VARCHAR2(2600),,
			int KEIZU_SU=Integer.parseInt(keizu_su);		//,警防図数,11,,YES,"NUMBER(3, 0)",,
			String  KEIZU=keizu;		//,警防図番号,12,,YES,VARCHAR2(400),,
			InsertData(UKE_DATE,REMBAN,SHORI_KBN,ZUKEI_SYU,SEN_SYU,HABA_SYU,CL_CD,HT_CD,ZAHYO_SU,ZAHYO_KUKEI,KEIZU_SU,KEIZU,out);
			
		}catch(Exception ex) {
			out.write(ex.toString());
		}
		out.flush();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	public int InsertData(String UKE_DATE,int REMBAN,int SHORI_KBN,int ZUKEI_SYU,int SEN_SYU,int HABA_SYU,int CL_CD,int HT_CD,int ZAHYO_SU,String ZAHYO_KUKEI,int KEIZU_SU,String  KEIZU,PrintWriter out) {

		int ret = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());
		
		System.out.println(update_date);

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "insert into  SIREI.TBMP0020(UKE_DATE,REMBAN,SHORI_KBN,ZUKEI_SYU,SEN_SYU,HABA_SYU,CL_CD,HT_CD,ZAHYO_SU,ZAHYO_KUKEI,KEIZU_SU,KEIZU) ";
			sql += "values (TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'),?,?,?,?,?,?,?,?,?,?,?";
			sql += ")";
			
			out.write(sql);
			System.out.println(sql);
			
			pstmt = conn.prepareStatement(sql);

			int idx=1;
			pstmt.setString(idx, UKE_DATE);idx++;//
			pstmt.setInt(idx, REMBAN);idx++;//
			pstmt.setInt(idx, SHORI_KBN);idx++;//
			pstmt.setInt(idx, ZUKEI_SYU);idx++;//
			pstmt.setInt(idx, SEN_SYU);idx++;//
			pstmt.setInt(idx, HABA_SYU);idx++;//
			pstmt.setInt(idx, CL_CD);idx++;//
			pstmt.setInt(idx, HT_CD);idx++;//
			pstmt.setInt(idx, ZAHYO_SU);idx++;//
			pstmt.setString(idx, ZAHYO_KUKEI);idx++;//
			pstmt.setInt(idx, KEIZU_SU);idx++;//
			pstmt.setString(idx, KEIZU);idx++;//

			pstmt.executeUpdate();
			conn.commit();

		} catch (

		SQLException e) {
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
			out.write(ex.toString());
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
			out.write(ex.toString());
		}
		return ret;
	}
}

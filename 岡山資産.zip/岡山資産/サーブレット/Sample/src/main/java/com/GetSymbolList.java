package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetSymbolList
 */
@WebServlet("/GetSymbolList")
public class GetSymbolList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	String URL = "";
	String USER = "";
	String PASS = "";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetSymbolList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin","*"); //CROS対策
		response.setCharacterEncoding("utf-8");
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		SymbolListDto dto = new SymbolListDto();
		PrintWriter out = response.getWriter();
		
			if(ReadDB(out,dto)==0) {
				dto.setResult("OK");
			}else {
				dto.setResult("NG");
			}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();
		log("End");
		
	}
	public int ReadDB(PrintWriter out,SymbolListDto dto) {

		int ret =0;

		String SQL = "";
		SQL = "select * from TBWG0008 ";

		System.out.println(SQL);

		int reccnt = 0;
		List<JsonSymbolList> jsonList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {
					
					ret =0;
					
					

					/*
					SYMBOL_ID NUMBER(4) not null,
					SYMBOL_TYPE NUMBER(2),
					NAME1 varchar2(100),
					NAME2 varchar2(100),
					ICONPATH varchar2(100),
					INFO  varchar2(200),
					*/
					JsonSymbolList jsonBean = new JsonSymbolList();
					
					int SYMBOL_ID = rs.getInt("SYMBOL_ID");

					System.out.println(SYMBOL_ID);

					int SYMBOL_TYPE = rs.getInt("SYMBOL_TYPE");
					String NAME1 = rs.getString("NAME1");
					String NAME2 = rs.getString("NAME2");
					String ICONPATH  = rs.getString("ICONPATH");
					String INFO = rs.getString("INFO");
					

					jsonBean.setSymbol_id(SYMBOL_ID);
					jsonBean.setSymbol_type(SYMBOL_TYPE);
					jsonBean.setName1(NAME1);
					jsonBean.setName2(NAME2);
					
					jsonBean.setInfo(INFO);
					jsonBean.setIconpath(ICONPATH);
					
					jsonList.add(jsonBean);
					System.out.println(reccnt);
				}
				dto.setData(jsonList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

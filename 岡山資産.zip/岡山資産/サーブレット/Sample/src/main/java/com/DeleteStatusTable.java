package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class DeleteStatusTable
 */
@WebServlet("/DeleteStatusTable")
public class DeleteStatusTable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteStatusTable() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		//		response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); //CROS対策
		response.setCharacterEncoding("utf-8");
		
		
		try {
			int carcd = Integer.parseInt(request.getParameter("carcd"));

			//設定ファイル読み込み処理
			ObjectMapper objectMapper = new ObjectMapper();
			try {
				JsonNode json = objectMapper
						.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
				System.out.println(json);

				URL = json.get("conn_url").textValue();
				USER = json.get("conn_user").textValue();
				PASS = json.get("conn_pass").textValue();
			} catch (Exception e) {
				e.printStackTrace();
			}

			PrintWriter out = response.getWriter();

			Connection conn = null;
			PreparedStatement pstmt = null;

			int ret = 0;

			String sql = "";

			sql += "delete from TBWG0009";
			sql += " Where termId=? ";

			try {

				conn = DriverManager.getConnection(URL, USER, PASS);
				conn.setAutoCommit(false); // オートコミットはオフ

				pstmt = conn.prepareStatement(sql);

				pstmt.setInt(1, carcd);

				pstmt.executeUpdate();
				conn.commit();

			} catch (SQLException e) {
				e.printStackTrace();
				ret = -1;
			} finally {
			}
			try {
				if (pstmt != null) {
					pstmt.close();
					pstmt = null;
				}
			} catch (SQLException ex) {
			}
			try {
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException ex) {
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

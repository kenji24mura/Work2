package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class SearchDB
 */
@WebServlet("/SearchDB")
public class SearchDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String URL = "";
	String USER = "";
	String PASS = "";


//	final String URL = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
//	final String URL = "jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	final String URL= "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

	//final String USER = "WEBGIS";
	//final String PASS = "WEBGIS";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchDB() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		log("Start");
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		
		String strMode = request.getParameter("mode");
		String key = request.getParameter("key");
		String value1 = request.getParameter("value1");
		String value2 = request.getParameter("value2");
		String comment = request.getParameter("comment");
		
		if(strMode != null) {
			int mode = Integer.parseInt(strMode);
			
			switch(mode) {
			case 1://検索
				ReadDB(out);
				break;
			case 2://追加
				InsertDB(key,value1,value2,comment,out);
				break;
			case 3://更新
				UpdateDB(key,value1,value2,comment,out);
				break;
			case 4://削除
				DeleteDB(key,out);
				break;
			}
		}else {
			out.println("パラメータエラー");
		}
		
		log("END");
		out.flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public int ReadDB(PrintWriter out) {

		int ret = 0;
		String SQL = "";

		SQL = "select * from TBWG0006";
		
		log(SQL);
		
		List<ConstBean> jsonList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {
				
				while (rs.next()) {
					
					String key = rs.getString("CONST_KEY");
					String value1 = rs.getString("CONST_VALUE1");
					String value2 = rs.getString("CONST_VALUE2");
					String comment = rs.getString("CONST_COMMENT");
					Date update = rs.getDate("UPDATE_DATE");
					String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(update);
					
					ConstBean bean = new ConstBean();

					bean.setCONST_KEY(key);
					bean.setCONST_VALUE1(value1);
					bean.setCONST_VALUE2(value2);
					bean.setConst_COMMENT(comment);
					bean.setUpdate_DATE(str);
					

					jsonList.add(bean);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonData = mapper.writeValueAsString(jsonList);
			
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			ret = -1;
		}
		return ret;
	}
	
	public int InsertDB(String key,String value1,String value2,String comment,PrintWriter out) {
		int ret = 0;
		
		String sql = "";
		
        Calendar cl = Calendar.getInstance();
        
        //フォーマットを指定する
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String update_date = sdf.format(cl.getTime());
        System.out.println(sdf.format(cl.getTime()));

		sql += "insert into  TBWG0006 (const_key,const_value1,const_value2,const_comment,update_date) values (";

		log(sql);

		try {

			sql += "'";
			sql += key;
			sql += "'";
			sql += ",";

			sql += "'";
			sql += value1;
			sql += "'";
			sql += ",";

			sql += "'";
			sql += value2;
			sql += "'";
			sql += ",";
			
			sql += "'";
			sql += comment;
			sql += "'";
			sql += ",";
			
			sql += "TO_DATE('"+ update_date +"', 'YYYY-MM-DD HH24:MI:SS')";
			
			sql += ")";

			out.println(sql);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);
			Statement stmt = conn.createStatement();

			int num = stmt.executeUpdate(sql);
			out.println(num);

		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			out.println("処理が完了しました");
		}

		return ret;
	}
	public int DeleteDB(String key,PrintWriter out) {
		int ret = 0;

		String sql = "";
		
		sql += "delete from  TBWG0006 Where const_key='"+key+"'";

		log(sql);
		
		try {

			Connection conn = DriverManager.getConnection(URL, USER, PASS);

			Statement stmt = conn.createStatement();

			int num = stmt.executeUpdate(sql);
			out.println(num);
			
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			out.println("処理が完了しました");
		}
		return ret;

	}
	public int UpdateDB(String key,String value1,String value2,String comment,PrintWriter out) {
		int ret = 0;
		//UPDATE Test SET age=6,status=’小学生’ WHERE name=’鈴木花子’
		String sql = "";
		
        Calendar cl = Calendar.getInstance();
        
        //フォーマットを指定する
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String update_date = sdf.format(cl.getTime());
        System.out.println(sdf.format(cl.getTime()));

//		insert into TBWG0006 (const_key,const_value1,const_value2,const_comment,update_date) VALUES ('1','2','3','4',TO_DATE('2022/12/28 00:00:00', 'YYYY-MM-DD HH24:MI:SS'))

		sql += "UPDATE TBWG0006 SET ";

		log(sql);
		
		try {

			sql += "const_key=";

			sql += "'";
			sql += key;
			sql += "'";
			sql += ",";

			sql += "const_value1=";

			sql += "'";
			sql += value1;
			sql += "'";
			sql += ",";

			sql += "const_value2=";
			sql += "'";
			sql += value2;
			sql += "'";
			sql += ",";
			
			sql += "const_comment=";
			sql += "'";
			sql += comment;
			sql += "'";
			sql += ",";
			
			sql += "update_date=";
			sql += "TO_DATE('"+ update_date +"', 'YYYY-MM-DD HH24:MI:SS')";
			
			sql += "WHERE const_key = '";
			sql += key;
			sql += "'";

			out.println(sql);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);
			Statement stmt = conn.createStatement();

			int num = stmt.executeUpdate(sql);
			out.println(num);

		} catch (SQLException e) {
			e.printStackTrace();
			out.println(e.toString());
			ret = -1;
		} finally {
			out.println("処理が完了しました");
		}

		return ret;
	}
}

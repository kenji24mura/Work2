package com;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonCarBean {
	@JsonProperty("car_cd")
	 private String car_cd;
	@JsonProperty("houko")
	 private String houko;
	@JsonProperty("dotai")
	 private int dotai;
	@JsonProperty("symbolid")
	 private int symbolid;
	@JsonProperty("zx")
	 private double zx;
	@JsonProperty("zy")
	 private double zy;
	public String getCar_cd() {
		return car_cd;
	}
	public void setCar_cd(String car_cd) {
		this.car_cd = car_cd;
	}
	public String getHouko() {
		return houko;
	}
	public void setHouko(String houko) {
		this.houko = houko;
	}
	public double getZx() {
		return zx;
	}
	public void setZx(double zx) {
		this.zx = zx;
	}
	public double getZy() {
		return zy;
	}
	public void setZy(double zy) {
		this.zy = zy;
	}
	public void setDotai(int dotai) {
		// TODO 自動生成されたメソッド・スタブ
		this.dotai = dotai;
	}
	public int getSymbolid() {
		return symbolid;
	}
	public void setSymbolid(int symbolid) {
		this.symbolid = symbolid;
	}
}

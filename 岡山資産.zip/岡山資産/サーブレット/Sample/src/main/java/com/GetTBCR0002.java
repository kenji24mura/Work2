package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetTBCR0002
 * 指揮隊シンボル読み込み
 */
@WebServlet("/GetTBCR0002")
public class GetTBCR0002 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetTBCR0002() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		String jisiki = request.getParameter("jisiki");

		//設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			//System.out.println(json); 

			URL = json.get("conn_url3").textValue();
			USER = json.get("conn_user3").textValue();
			PASS = json.get("conn_pass3").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		TBCR0002Dto dto = new TBCR0002Dto();
		PrintWriter out = response.getWriter();

		if (ReadDB(jisiki, out, dto) == 0) {
			dto.setResult("OK");
		} else {
			dto.setResult("NG");
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();

		log("End");

	}

	public int ReadDB(String jisiki, PrintWriter out, TBCR0002Dto dto) {

		int ret = 0;

		String SQL = "";
		SQL = "select * from SHASAI.TBCR0002 WHERE jisiki='"+ jisiki +"'";

		int reccnt = 0;
		List<TBCR0002Bean> jsonList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					TBCR0002Bean jsonBean = new TBCR0002Bean();

					String JISIKI = rs.getString("JISIKI");
					int SYMBOL_ID = rs.getInt("SYMBOL_ID");
					int ZAHYO_X = rs.getInt("ZAHYO_X");
					int ZAHYO_Y = rs.getInt("ZAHYO_Y");
					System.out.println(JISIKI);
					System.out.println(SYMBOL_ID);

					jsonBean.setJisiki(JISIKI);
					jsonBean.setSymbol_id(SYMBOL_ID);
					jsonBean.setZahyo_x(ZAHYO_X);
					jsonBean.setZahyo_y(ZAHYO_Y);

					jsonList.add(jsonBean);
				}
				dto.setData(jsonList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

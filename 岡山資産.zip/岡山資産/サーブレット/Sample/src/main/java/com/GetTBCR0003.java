package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetTBCR0003
 */
@WebServlet("/GetTBCR0003")
public class GetTBCR0003 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String URL = "";
	String USER = "";
	String PASS = "";
	String MODE="";
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetTBCR0003() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		String jisiki = request.getParameter("jisiki");

		//設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			//System.out.println(json); 
			
			MODE = json.get("mode").textValue();
			if(MODE.indexOf("debug")==0) {
				URL = json.get("conn_url").textValue();
				USER = json.get("conn_user").textValue();
				PASS = json.get("conn_pass").textValue();
				
			}else{
				URL = json.get("conn_url3").textValue();
				USER = json.get("conn_user3").textValue();
				PASS = json.get("conn_pass3").textValue();
				
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		TBCR0003Dto dto = new TBCR0003Dto();
		PrintWriter out = response.getWriter();

		if (ReadDB(jisiki, out, dto) == 0) {
			dto.setResult("OK");
		} else {
			dto.setResult("NG");
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();

		log("End");
	}
	
	public int ReadDB(String jisiki, PrintWriter out, TBCR0003Dto dto) {

		int ret = 0;

		String SQL = "";

		if(MODE.indexOf("debug")==0) {
			SQL = "select * from TBCR0003 WHERE jisiki='"+ jisiki +"'";
		}else {
			SQL = "select * from SHASAI.TBCR0003 WHERE jisiki='"+ jisiki +"'";
		}

		int reccnt = 0;
		List<TBCR0003Bean> jsonList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					TBCR0003Bean jsonBean = new TBCR0003Bean();

					String JISIKI = rs.getString("JISIKI");
					int LINE_COLOR = rs.getInt("LINE_COLOR");
					int ZAHYO_NUM = rs.getInt("ZAHYO_NUM");
					
					String ZAHYO = rs.getString("ZAHYO");

					System.out.println(JISIKI);

					jsonBean.setJisiki(JISIKI);
					jsonBean.setLine_color(LINE_COLOR);
					jsonBean.setPoint_cnt(ZAHYO_NUM);

					//座標をバラしていれる
					//-000045585166-000143469385-000045585166-000143469385-000045585166-000143469385-000045584894-000143469521
					//-000045577273-000143478361-000045576593-000143478633-000045575368-000143478633-000045574280-000143478225
					
					List<PointBean> pointList = new ArrayList<>();

					
					for(int i=0;i<ZAHYO_NUM;i++) {
						String wzahyo = ZAHYO.substring(i*26,(i+1)*26);
						String wx = wzahyo.substring(0,13);
						String wy = wzahyo.substring(13,26);
						
						System.out.println(wx+","+wy);
						
						PointBean zp=new PointBean();
						zp.setX(Integer.parseInt(wx));
						zp.setY(Integer.parseInt(wy));
						pointList.add(zp);
					}
					
					jsonBean.setData(pointList);
					
					jsonList.add(jsonBean);
				}
				dto.setData(jsonList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;

	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

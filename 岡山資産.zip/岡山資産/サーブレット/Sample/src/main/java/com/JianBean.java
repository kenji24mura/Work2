package com;

public class JianBean {
    private String jisiki;
    private int saisyu;
    private String saisyunm;
    private String kosindt;
    private String sireibunnm;
    private int x_locate;
    private int y_locate;
	public String getJisiki() {
		return jisiki;
	}
	public void setJisiki(String jisiki) {
		this.jisiki = jisiki;
	}
	public int getSaisyu() {
		return saisyu;
	}
	public void setSaisyu(int saisyu) {
		this.saisyu = saisyu;
	}
	public String getSaisyunm() {
		return saisyunm;
	}
	public void setSaisyunm(String saisyunm) {
		this.saisyunm = saisyunm;
	}
	public String getKosindt() {
		return kosindt;
	}
	public void setKosindt(String kosindt) {
		this.kosindt = kosindt;
	}
	public String getSireibunnm() {
		return sireibunnm;
	}
	public void setSireibunnm(String sireibunnm) {
		this.sireibunnm = sireibunnm;
	}
	public int getX_locate() {
		return x_locate;
	}
	public void setX_locate(int x_locate) {
		this.x_locate = x_locate;
	}
	public int getY_locate() {
		return y_locate;
	}
	public void setY_locate(int y_locate) {
		this.y_locate = y_locate;
	}
}

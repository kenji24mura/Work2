package com;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class MiddleBean {
	@JsonProperty("lay_no")
	private String lay_no;
	@JsonProperty("item_no")
	private String item_no;
	@JsonProperty("info_type")
	private int info_type;
	@JsonProperty("info_summery")
	private String info_summery;
	@JsonProperty("lay_type")
	private int lay_type;
	@JsonProperty("symbol_no")
	private int symbol_no;
	@JsonProperty("zahyo_x")
	private Double zahyo_x;
	@JsonProperty("zahyo_y")
	private Double zahyo_y;
	@JsonProperty("strinfo1")
	private String strinfo1;
	@JsonProperty("strinfo2")
	private String strinfo2;
	@JsonProperty("strinfo3")
	private String strinfo3;
	@JsonProperty("str_zahyo_x")
	private Double str_zahyo_x;
	@JsonProperty("str_zahyo_y")
	private Double str_zahyo_y;
	@JsonProperty("zahyo_cnt")
	private int zahyo_cnt;
	@JsonProperty("data")
	private List<ZPointBean> data;
	@JsonProperty("update_date")
	private String update_date;
	private String item_no2;
	private int str_ptn;
	
	public String getLay_no() {
		return lay_no;
	}
	public void setLay_no(String lay_no) {
		this.lay_no = lay_no;
	}
	public String getItem_no() {
		return item_no;
	}
	public void setItem_no(String item_no) {
		this.item_no = item_no;
	}
	public String getUpdate_date() {
		return update_date;
	}
	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}
	public int getInfo_type() {
		return info_type;
	}
	public void setInfo_type(int info_type) {
		this.info_type = info_type;
	}
	public int getLay_type() {
		return lay_type;
	}
	public void setLay_type(int lay_type) {
		this.lay_type = lay_type;
	}
	public Double getZahyo_x() {
		return zahyo_x;
	}
	public void setZahyo_x(Double zahyo_x) {
		this.zahyo_x = zahyo_x;
	}
	public Double getZahyo_y() {
		return zahyo_y;
	}
	public void setZahyo_y(Double zahyo_y) {
		this.zahyo_y = zahyo_y;
	}
	public int getSymbol_no() {
		return symbol_no;
	}
	public void setSymbol_no(int symbol_no) {
		this.symbol_no = symbol_no;
	}
	public String getStrinfo1() {
		return strinfo1;
	}
	public void setStrinfo1(String strinfo1) {
		this.strinfo1 = strinfo1;
	}
	public String getStrinfo2() {
		return strinfo2;
	}
	public void setStrinfo2(String strinfo2) {
		this.strinfo2 = strinfo2;
	}
	public String getStrinfo3() {
		return strinfo3;
	}
	public void setStrinfo3(String strinfo3) {
		this.strinfo3 = strinfo3;
	}
	public Double getStr_zahyo_x() {
		return str_zahyo_x;
	}
	public void setStr_zahyo_x(Double str_zahyo_x) {
		this.str_zahyo_x = str_zahyo_x;
	}
	public Double getStr_zahyo_y() {
		return str_zahyo_y;
	}
	public void setStr_zahyo_y(Double str_zahyo_y) {
		this.str_zahyo_y = str_zahyo_y;
	}
	public String getInfo_summery() {
		return info_summery;
	}
	public void setInfo_summery(String info_summery) {
		this.info_summery = info_summery;
	}
	public int getZahyo_cnt() {
		return zahyo_cnt;
	}
	public void setZahyo_cnt(int zahyo_cnt) {
		this.zahyo_cnt = zahyo_cnt;
	}
	public List<ZPointBean> getData() {
		return data;
	}
	public void setData(List<ZPointBean> data) {
		this.data = data;
	}
	public String getItem_no2() {
		return item_no2;
	}
	public void setItem_no2(String item_no2) {
		this.item_no2 = item_no2;
	}
	public int getStr_ptn() {
		return str_ptn;
	}
	public void setStr_ptn(int str_ptn) {
		this.str_ptn = str_ptn;
	}
}

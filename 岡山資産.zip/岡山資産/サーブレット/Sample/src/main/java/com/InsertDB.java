package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class InsertDB
 * 
 * 中間テーブル登録
 */
@WebServlet("/InsertDB")
public class InsertDB extends HttpServlet {
  private static final long serialVersionUID = 1L;

  String URL = "";
  String USER = "";
  String PASS = "";
  // 20240130 start
  int kijyunkei = 6;
  // 20240130 end


  // private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
  // private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

  // private String conn_user = "WEBGIS";
  // private String conn_pass = "WEBGIS";

  /**
   * @see HttpServlet#HttpServlet()
   */
  public InsertDB() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub

    log("Start");

    request.setCharacterEncoding("UTF-8");

    // response.setContentType("text/html; charset=UTF-8");
    response.setContentType("text/html");
    response.setHeader("Cache-Control", "nocache");
    response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
    response.setCharacterEncoding("utf-8");

    // 20240130 start
    String coordinate = request.getParameter("coordinate");
    if (coordinate == null) {
    } else {
      kijyunkei = Integer.parseInt(coordinate);
    }
    // 20240130 end


    // 設定ファイル読み込み処理
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      JsonNode json = objectMapper.readTree(
          Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
      System.out.println(json);

      URL = json.get("conn_url").textValue();
      USER = json.get("conn_user").textValue();
      PASS = json.get("conn_pass").textValue();
    } catch (Exception e) {
      e.printStackTrace();
    }

    PrintWriter out = response.getWriter();


    DBDto dto = new DBDto();
    ObjectMapper mapper = new ObjectMapper();

    dto.setMessage("");
    //
    // シンボル登録
    //

    try {
      String lay_no = request.getParameter("lay_no");
      // String item_no=request.getParameter("item_no");
      int info_type = Integer.parseInt(request.getParameter("info_type"));



      String info_summery = request.getParameter("info_summery");
      String[] infos = info_summery.split(",");


      String json = "";

      json = "{";

      for (int i = 0; i < infos.length / 2; i++) {

        if (i > 0) {
          json += ",";
        }
        json += '"';
        json += infos[i * 2];
        json += '"';
        json += ":";
        json += '"';
        json += infos[i * 2 + 1];
        json += '"';

      }

      json += "}";


      int lay_type = Integer.parseInt(request.getParameter("lay_type")); // 1:シンボル 2:線 3:ポリゴン
      int symbol_no = Integer.parseInt(request.getParameter("symbol_no"));
      double zahyo_x = Double.parseDouble(request.getParameter("zahyo_x"));
      double zahyo_y = Double.parseDouble(request.getParameter("zahyo_y"));
      String strinfo1 = request.getParameter("strinfo1");
      String strinfo2 = request.getParameter("strinfo2");
      String strinfo3 = request.getParameter("strinfo3");
      double str_zahyo_x = Double.parseDouble(request.getParameter("str_zahyo_x"));
      double str_zahyo_y = Double.parseDouble(request.getParameter("str_zahyo_y"));
      int zahyo_cnt = Integer.parseInt(request.getParameter("zahyo_cnt"));
      String info_zahyo = request.getParameter("info_zahyo");;

      //
      // 新しいアイテム番号を返す
      //
      String item_no = GetMaxItemId(lay_type, info_type, symbol_no);
      String item_no2 = item_no;

      int ret = 0;

      switch (lay_type) {
        case 1:// シンボル

          // ret =
          // InsertSymbol(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,out);
          ret = InsertSymbol(lay_no, item_no, item_no2, info_type, json, lay_type, symbol_no,
              zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, out, dto);
          if (ret == 0) {
            dto.setResult("OK");
          }
          break;
        case 2:// 線
          String[] points = info_zahyo.split(",");

          ZPoint[] zp = new ZPoint[zahyo_cnt];
          // オブジェクト型の初期化が必要
          for (int i = 0; i < zahyo_cnt; i++) {
            zp[i] = new ZPoint();

            zp[i].x = Double.parseDouble(points[i * 2]);
            zp[i].y = Double.parseDouble(points[i * 2 + 1]);

          }

          // ret = DeletePolygon(lay_no,item_no,out);
          // if(ret == 0) {
          // out.println("処理が正常しました<br>");
          // }

          // ret =
          // InsertPolygon(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,zahyo_cnt,zp,out);
          ret =
              InsertPolygon(lay_no, item_no, info_type, json, lay_type, symbol_no, zahyo_x, zahyo_y,
                  strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, zp, out, dto);
          if (ret == 0) {
            dto.setResult("OK");
          }
          break;

        case 3:// ポリゴン
          String[] points2 = info_zahyo.split(",");

          ZPoint[] zp2 = new ZPoint[zahyo_cnt];
          // オブジェクト型の初期化が必要


          // 中心座標を算出する

          double minx = 0.0;
          double miny = 0.0;
          double maxx = 0.0;
          double maxy = 0.0;

          for (int i = 0; i < zahyo_cnt; i++) {
            zp2[i] = new ZPoint();

            zp2[i].x = Double.parseDouble(points2[i * 2]);
            zp2[i].y = Double.parseDouble(points2[i * 2 + 1]);

            if (i == 0) {
              minx = zp2[i].x;
              miny = zp2[i].y;
              maxx = zp2[i].x;
              maxy = zp2[i].y;
            } else {
              if (zp2[i].x < minx) {
                minx = zp2[i].x;
              }
              if (zp2[i].x > maxx) {
                maxx = zp2[i].x;
              }
              if (zp2[i].y < miny) {
                miny = zp2[i].y;
              }
              if (zp2[i].y > maxy) {
                maxy = zp2[i].y;
              }
            }

          }
          zahyo_x = (minx + maxx) / 2;
          zahyo_y = (miny + maxy) / 2;

          // ret = DeletePolygon(lay_no,item_no,out);
          // if(ret == 0) {
          // out.println("処理が正常しました<br>");
          // }

          // ret =
          // InsertPolygon(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,zahyo_cnt,zp2,out);
          ret =
              InsertPolygon(lay_no, item_no, info_type, json, lay_type, symbol_no, zahyo_x, zahyo_y,
                  strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, zp2, out, dto);
          if (ret == 0) {
            dto.setResult("OK");
          }
          System.out.println("lay_no=" + lay_no);


          // 届け出ポリゴンの場合、シンボルを追加する
          // == で比較してはいけない
          if (lay_no.equals("n@16-1")) {

            System.out.println("シンボルを追加");

            lay_type = 1;
            symbol_no = 2419;
            info_type = 16;

            item_no2 = item_no;// <--- ポリゴンのitem_noを設定する

            // シンボルのアイテム番号を採番する
            String item_no3 = "";
            item_no3 = GetMaxItemId(lay_type, info_type, symbol_no);

            ret = InsertSymbol(lay_no, item_no3, item_no2, info_type, json, lay_type, symbol_no,
                zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, out, dto);

            // 20230413
          }
          break;

        default:
          ret = -1;
          break;

      }

      // 2023.07.02
      dto.setZahyo_x(zahyo_x);
      dto.setZahyo_y(zahyo_y);

      dto.setItem_no(item_no);
      dto.setResult("OK");


    } catch (Exception e) {
      e.printStackTrace();
      // out.println(e.toString());
      dto.setMessage(e.toString());
      dto.setResult("NG");
    } finally {
      // out.println("処理が完了しました<br>");
    }


    String jsonData = mapper.writeValueAsString(dto);
    out.write(jsonData);

    out.flush();
    log("End");

  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

  //
  // シンボル追加
  //
  public int InsertSymbol(String lay_no, String item_no, String item_no2, int info_type,
      String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y,
      String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y,
      PrintWriter out, DBDto dto) {

    int ret = 0;


    // final String URL = conn_str;
    // final String USER = conn_user;
    // final String PASS = conn_pass;

    Connection conn = null;
    Statement stmt = null;

    // 20221228
    Calendar cl = Calendar.getInstance();

    // フォーマットを指定する
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String update_date = sdf.format(cl.getTime());


    String sql = "";
    sql +=
        "insert into  TBWG0001(lay_no,item_no,item_no2,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,update_date) values (";

    try {

      sql += "'";
      sql += lay_no;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += item_no;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += item_no2;
      sql += "'";
      sql += ",";

      sql += info_type;
      sql += ",";

      sql += "'";
      sql += info_summery;
      sql += "'";
      sql += ",";

      sql += lay_type;
      sql += ",";
      sql += symbol_no;
      sql += ",";
      sql += zahyo_x;
      sql += ",";
      sql += zahyo_y;
      sql += ",";

      sql += "'";
      sql += strinfo1;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += strinfo2;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += strinfo3;
      sql += "'";
      sql += ",";

      sql += str_zahyo_x;
      sql += ",";

      sql += str_zahyo_y;
      sql += ",";

      sql += "TO_DATE('" + update_date + "', 'YYYY-MM-DD HH24:MI:SS')";

      sql += ")";

      // out.println(sql);
      dto.setSql(sql);
      log(sql);

      conn = DriverManager.getConnection(URL, USER, PASS);
      stmt = conn.createStatement();

      int num = stmt.executeUpdate(sql);

    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
      dto.setMessage(e.toString());
    } finally {
      // out.println("処理が完了しました<br>");
    }
    try {
      if (stmt != null) {
        stmt.close();
        stmt = null;
      }
    } catch (SQLException ex) {
    }
    try {
      if (conn != null) {
        conn.close();
        conn = null;
      }
    } catch (SQLException ex) {
    }

    return ret;

  }

  //
  // ポリゴン追加
  //
  public int InsertPolygon(String lay_no, String item_no, int info_type, String info_summery,
      int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2,
      String strinfo3, double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, ZPoint[] zp,
      PrintWriter out, DBDto dto) {

    int ret = 0;

    // final String URL = conn_str;
    // final String USER = conn_user;
    // final String PASS = conn_pass;

    Connection conn = null;
    Statement stmt = null;

    // 20221228
    Calendar cl = Calendar.getInstance();

    // フォーマットを指定する
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String update_date = sdf.format(cl.getTime());

    // String SQL="";
    String sql = "";

    sql +=
        "insert into  TBWG0002(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,"
            + "str_zahyo_x,str_zahyo_y,zahyo_cnt," + "ZAHYO_ARRAY,update_date) values (";

    try {

      sql += "'";
      sql += lay_no;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += item_no;
      sql += "'";
      sql += ",";

      sql += info_type;
      sql += ",";

      sql += "'";
      sql += info_summery;
      sql += "'";
      sql += ",";

      sql += lay_type;
      sql += ",";
      sql += symbol_no;
      sql += ",";
      sql += zahyo_x;
      sql += ",";
      sql += zahyo_y;
      sql += ",";

      sql += "'";
      sql += strinfo1;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += strinfo2;
      sql += "'";
      sql += ",";

      sql += "'";
      sql += strinfo3;
      sql += "'";
      sql += ",";

      sql += str_zahyo_x;
      sql += ",";

      sql += str_zahyo_y;
      sql += ",";

      sql += zahyo_cnt;
      sql += ",";

      sql += "ARRAY_POINT(";

      for (int i = 0; i < zp.length; i++) {

        if (i > 0) {
          sql += ",";
        }
        sql += "POINT(";
        sql += zp[i].x;
        sql += ",";
        sql += zp[i].y;
        sql += ")";
      }

      sql += ")";

      sql += ",";

      sql += "TO_DATE('" + update_date + "', 'YYYY-MM-DD HH24:MI:SS')";


      sql += ")";

      // out.println(sql);
      dto.setSql(sql);
      log(sql);

      conn = DriverManager.getConnection(URL, USER, PASS);
      stmt = conn.createStatement();

      int num = stmt.executeUpdate(sql);

    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
      dto.setMessage(e.toString());
    } finally {
      // out.println("処理が完了しました<br>");
    }
    try {
      if (stmt != null) {
        stmt.close();
        stmt = null;
      }
    } catch (SQLException ex) {
    }
    try {
      if (conn != null) {
        conn.close();
        conn = null;
      }
    } catch (SQLException ex) {
    }

    return ret;

  }

  public int DeleteSymbol(String lay_no, String item_no, PrintWriter out, DBDto dto) {

    int ret = 0;

    // final String URL = conn_str;
    // final String USER = conn_user;
    // final String PASS = conn_pass;

    Connection conn = null;
    Statement stmt = null;

    String sql = "";

    sql += "delete from  TBWG0001 Where lay_no='" + lay_no + "' AND item_no='" + item_no + "'";
    out.println(sql);
    log(sql);

    try {


      conn = DriverManager.getConnection(URL, USER, PASS);
      stmt = conn.createStatement();

      int num = stmt.executeUpdate(sql);

    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
      dto.setMessage(e.toString());
    } finally {
      // out.println("処理が完了しました<br>");
    }
    try {
      if (stmt != null) {
        stmt.close();
        stmt = null;
      }
    } catch (SQLException ex) {
    }
    try {
      if (conn != null) {
        conn.close();
        conn = null;
      }
    } catch (SQLException ex) {
    }

    return ret;

  }

  public int DeletePolygon(String lay_no, String item_no, PrintWriter out, DBDto dto) {

    int ret = 0;

    // final String URL = conn_str;
    // final String USER = conn_user;
    // final String PASS = conn_pass;

    Connection conn = null;
    Statement stmt = null;

    String sql = "";
    out.println(sql);

    log(sql);

    sql += "delete from  TBWG0002 Where lay_no='" + lay_no + "' AND item_no='" + item_no + "'";

    try {


      conn = DriverManager.getConnection(URL, USER, PASS);
      stmt = conn.createStatement();

      int num = stmt.executeUpdate(sql);

    } catch (SQLException e) {
      e.printStackTrace();
      ret = -1;
      dto.setMessage(e.toString());
    } finally {
      // out.println("処理が完了しました<br>");
    }
    try {
      if (stmt != null) {
        stmt.close();
        stmt = null;
      }
    } catch (SQLException ex) {
    }
    try {
      if (conn != null) {
        conn.close();
        conn = null;
      }
    } catch (SQLException ex) {
    }

    return ret;

  }

  // 正規化座標(mm)を経度磯（世界測地に変換）
  // 呼ばれていない？
  public void ConvertXY(int zx, int zy, int kijyunkei, double[] retVal) {

    // int zx = -45237600;//mm
    // int zy = -150372500;//mm

    // int kijyunkei = 6;

    System.out.println("zx=" + zx);
    System.out.println("zy=" + zy);

    double[] ret = new double[2];
    ret[0] = 0.0;
    ret[1] = 0.0;

    // MapConvert class インスタンス
    MapConvert mc = new MapConvert();

    // 20240130 コメント
    // int kijyunkei = 6;

    mc.ConvertPos(zx, zy, kijyunkei, ret);

    System.out.println("lon=" + ret[0]);
    System.out.println("lat=" + ret[1]);
    retVal[0] = ret[0];
    retVal[1] = ret[1];
  }

  public String GetMaxItemId(int lay_type, int info_type, int symbol_no) {
    String SQL = "";

    // final String URL = conn_str;
    // final String USER = conn_user;
    // final String PASS = conn_pass;

    int number = 1;

    if (lay_type == 1) {
      SQL = "select max(item_no) from TBWG0001 where info_type =" + info_type + "  and symbol_no = "
          + symbol_no;
    } else {
      SQL = "select max(item_no) from TBWG0002 where info_type =" + info_type + "  and symbol_no = "
          + symbol_no;
    }

    log(SQL);

    try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        String item_no = rs.toString();

        if (rs.next()) {
          item_no = rs.getString(1);

          if (item_no == null) {
            System.out.println("no record");
          } else {
            System.out.println(item_no);

            String str = item_no.substring(item_no.length() - 6, item_no.length());
            System.out.println("str=" + str);
            number = Integer.parseInt(str) + 1;
            /*
             * if(item_no.length()==12) { String str = item_no.substring(6, 12);
             * System.out.println("str="+str); number = Integer.parseInt(str) + 1; }else {
             * 
             * //12桁に満たないデータがある場合 number = 1; }
             */
          }

        }
      }

    } catch (SQLException e) {
      e.printStackTrace();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      System.out.println("処理が完了しました");
    }
    String result = String.format("%02d", info_type) + String.format("%04d", symbol_no)
        + String.format("%06d", number);

    System.out.println(result);

    return result;

  }

}

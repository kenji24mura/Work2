package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetAttributes 属性情報取得
 */
@WebServlet("/GetAttributes")
public class GetAttributes extends HttpServlet {

	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";
	String URL2 = "";
	String USER2 = "";
	String PASS2 = "";
	String URL3 = "";
	String USER3 = "";
	String PASS3 = "";
	String MODE = "";
	// 20240130 start
	int kijyunkei = 6;

	// 20240130 end

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetAttributes() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		// 20240130 start
		String coordinate = request.getParameter("coordinate");
		if (coordinate == null) {
		} else {
			kijyunkei = Integer.parseInt(coordinate);
		}
		// 20240130 end

		// 運用モード
		int OPE_MODE = 0;
		String ope_mode = request.getParameter("ope_mode");
		if (ope_mode == null) {
		} else {
			OPE_MODE = Integer.parseInt(ope_mode);
		}
		if (OPE_MODE == 0) {
			System.out.println("運用モードは[通常]");
		} else {
			System.out.println("運用モードは[訓練]");
		}

		// 設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			
			kijyunkei= Integer.parseInt(json.get("coordinate").textValue());

			if (OPE_MODE == 0) {
				URL = json.get("conn_url").textValue();
				USER = json.get("conn_user").textValue();
				PASS = json.get("conn_pass").textValue();
				URL2 = json.get("conn_url2").textValue();
				USER2 = json.get("conn_user2").textValue();
				PASS2 = json.get("conn_pass2").textValue();

				MODE = json.get("mode").textValue();
				if (MODE.indexOf("debug") == 0) {
					URL3 = json.get("conn_url").textValue();
					USER3 = json.get("conn_user").textValue();
					PASS3 = json.get("conn_pass").textValue();
				} else {
					URL3 = json.get("conn_url3").textValue();
					USER3 = json.get("conn_user3").textValue();
					PASS3 = json.get("conn_pass3").textValue();
				}
			} else {
				URL = json.get("conn_url_t").textValue();
				USER = json.get("conn_user_t").textValue();
				PASS = json.get("conn_pass_t").textValue();
				URL2 = json.get("conn_url2_t").textValue();
				USER2 = json.get("conn_user2_t").textValue();
				PASS2 = json.get("conn_pass2_t").textValue();

				MODE = json.get("mode").textValue();
				if (MODE.indexOf("debug") == 0) {
					URL3 = json.get("conn_url_t").textValue();
					USER3 = json.get("conn_user_t").textValue();
					PASS3 = json.get("conn_pass_t").textValue();
				} else {
					URL3 = json.get("conn_url3_t").textValue();
					USER3 = json.get("conn_user3_t").textValue();
					PASS3 = json.get("conn_pass3_t").textValue();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		AttributesDto dto = new AttributesDto();
		PrintWriter out = response.getWriter();

		String layerId = request.getParameter("layerId");
		String keyValue = request.getParameter("keyValue");
		String keyValue2 = request.getParameter("keyValue2");
		String keyValue3 = request.getParameter("keyValue3");
		String subAttr = request.getParameter("subAttr");

		if (layerId == null || keyValue == null) {
			AddMessage(dto, "parametr is null");
			dto.setResult("NG");
		} else {
			System.out.println(layerId);

			AddMessage(dto, "layerID=" + layerId + " keyValue=" + keyValue);

			EditDto(layerId, keyValue, keyValue2, keyValue3, subAttr, dto);
			dto.setResult("OK");
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();
		log("End");
	}

	/**
	 * GetCodeValue
	 * 
	 * コードを取得する
	 * 
	 * @param type
	 * @param code
	 * @return 
	 */
	public String GetCodeValue(int type, int code) {
		String ret = "";

		String SQL = "";
		SQL += "select *  from TBDW0130A WHERE  CODE_SBT=" + type;
		SQL += "  AND CODE=" + code;

		System.out.println(SQL);

		try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
				PreparedStatement ps = conn.prepareStatement(SQL)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					String CDNAME_KANJI = rs.getString("CDNAME_KANJI");
					ret = CDNAME_KANJI;
				}
				rs.close();
			}
			conn.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
		}
		return ret;
	}
	
	/**
	 * GetTimeValue
	 * 
	 * 時刻を取得する
	 * 
	 * @param jisiki
	 * @param kubun
	 * @return ret
	 */
	public String GetTimeValue(String jisiki, int kubun) {
		String ret = "";

		String SQL = "";
		SQL += "select *  from TBTS0104 WHERE  JISIKI='" + jisiki + "'";
		SQL += "  AND TMJO_KB=" + kubun;

		System.out.println(SQL);

		try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
				PreparedStatement ps = conn.prepareStatement(SQL)) {
			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					String TMJO_DATE = rs.getString("TMJO_DATE");

					SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
					Date date = sdFormat.parse(TMJO_DATE);
					String str = new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").format(date);
					ret = str;
				}
				rs.close();
			}
			conn.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
		}
		return ret;
	}

	public String GetTeamValue(String jisiki) {
		int carcnt = 0;
		String ret = "";

		String SQL = "";
		SQL += "select *  from TBTS0109 WHERE  JISIKI='" + jisiki + "'";

		System.out.println(SQL);

		try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
				PreparedStatement ps = conn.prepareStatement(SQL)) {
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					if (carcnt > 0) {
						ret += ",";
					}
					String CARNO = rs.getString("CARNO");
					CARNO = CARNO.replace(" ", "");
					ret += CARNO;
					carcnt++;
				}
				rs.close();
			}
			conn.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
		}

		SQL = "";
		SQL += "select *  from TBSK0002 WHERE  JISIKI='" + jisiki + "' AND MAKE_KBN <> 'D'";

		System.out.println(SQL);

		try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
				PreparedStatement ps = conn.prepareStatement(SQL)) {
			try (ResultSet rs = ps.executeQuery()) {
				while (rs.next()) {
					if (carcnt > 0) {
						ret += ",";
					}
					String HENSEI_NAME = rs.getString("HENSEI_NAME");
					ret += HENSEI_NAME;
					carcnt++;
				}
				rs.close();
			}
			conn.close();
		} catch (SQLException e) {
			System.out.println(e.toString());
		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
		}

		return ret;
	}

	private void EditDto(String layerId, String keyValue, String keyValue2, String keyValue3, String subAttr,
			AttributesDto dto) {
		List<JsonAttributes> jsonList = new ArrayList<>();
		JsonAttributes json;
		String SQL = "";

		// 災害点関係
		if (layerId.indexOf("n@1-1") == 0) {
			SQL += "select * ";

			SQL += " from V_TBDAM001 WHERE  JISIKI='" + keyValue + "'";

			System.out.println(SQL);
			boolean IsSet = false;

			try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
					PreparedStatement ps = conn.prepareStatement(SQL)) {
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next()) {

						String JISIKI = rs.getString("JISIKI");
						String UKETUKE_DATE = rs.getString("UKETUKE_DATE");
						String KAKUCHI_DATE = rs.getString("KAKUCHI_DATE");
						String SAISYUNM = rs.getString("SAISYUNM");
						String SIREBUNNM = rs.getString("SIREBUNNM");
						/*
						int SAISYU = rs.getInt("SAISYU");
						int KINKYUDO_KB = rs.getInt("KINKYUDO_KB");
						String KAKUCHI_NO = rs.getString("KAKUCHI_NO");
						String SAIGAI_NO = rs.getString("SAIGAI_NO");
						String SIREBUNNM = rs.getString("SIREBUNNM");
						String ADSNM = rs.getString("ADSNM");
						String TAI_NM = rs.getString("TAI_NM");
						String SAIGAI_NM = rs.getString("SAIGAI_NM");
						String TUHO_NAME = rs.getString("TUHO_NAME");
						String TUIKI_NAIYO01 = rs.getString("TUIKI_NAIYO01");
						String TUIKI_NAIYO02 = rs.getString("TUIKI_NAIYO02");
*/
						json = new JsonAttributes();
						json.setKey("事案識別子");
						json.setValue(JISIKI);
						jsonList.add(json);
						
						json = new JsonAttributes();
						json.setKey("受付日時");
						json.setValue(UKETUKE_DATE);
						jsonList.add(json);
						
						json = new JsonAttributes();
						json.setKey("覚知日時");
						json.setValue(KAKUCHI_DATE);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("災害種別");
						json.setValue(SAISYUNM);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("指令分類");
						json.setValue(SIREBUNNM);
						jsonList.add(json);
	/*
						json = new JsonAttributes();
						json.setKey("緊急度");

						String codevalue = "";
						if (SAISYU == 4) {
							codevalue = GetCodeValue(8047, KINKYUDO_KB);
						} else {
							codevalue = GetCodeValue(8046, KINKYUDO_KB);
						}
						json.setValue(codevalue);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("覚知番号");
						json.setValue(KAKUCHI_NO);
						jsonList.add(json);
						json = new JsonAttributes();
						json.setKey("災害番号");
						
						if(SAIGAI_NO.length()>4) {
							json.setValue(SAIGAI_NO.substring(SAIGAI_NO.length() -4));
						}else {
							json.setValue(SAIGAI_NO);
						}
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("覚知時刻");
						String timevalue = "";
						timevalue = GetTimeValue(JISIKI, 2);
						json.setValue(timevalue);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("指令時刻");
						timevalue = "";
						timevalue = GetTimeValue(JISIKI, 4);
						json.setValue(timevalue);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("指令分類");
						json.setValue(SIREBUNNM);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("対応隊");

						String teamvalue = "";
						teamvalue = GetTeamValue(JISIKI);
						json.setValue(teamvalue);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("災害点");
						json.setValue(ADSNM);
						jsonList.add(json);
						json = new JsonAttributes();
						json.setKey("対象物名（追記文字含む）");

						String nm = "";

						if (TAI_NM != null) {
							nm = TAI_NM;
						}
						if (SAIGAI_NM != null) {
							nm += " ";
							nm += SAIGAI_NM;
						}
						json.setValue(nm);

						jsonList.add(json);
						json = new JsonAttributes();
						json.setKey("通報者名");
						json.setValue(TUHO_NAME);
						jsonList.add(json);
						json = new JsonAttributes();
						json.setKey("内容１");
						json.setValue(TUIKI_NAIYO01);
						jsonList.add(json);
						json = new JsonAttributes();
						json.setKey("内容２");
						json.setValue(TUIKI_NAIYO02);
						jsonList.add(json);
						*/

						dto.setData(jsonList);
					}
					rs.close();
				}
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.toString());
			} catch (Exception e) {
				System.out.println(e.toString());
			} finally {
			}
		}
		// 水利関係
		if (layerId.indexOf("n@2-1") == 0) {
			SQL += "select *  from FIRE.TBDMT340A WHERE SUIRI_CD='" + keyValue + "'";

			System.out.println(SQL);
			boolean IsSet = false;

			try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
					PreparedStatement ps = conn.prepareStatement(SQL)) {
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next()) {
						String SUIRI_CD = rs.getString("SUIRI_CD");
						String MOKUHYO = rs.getString("MOKUHYO");
						//int SUIRI_KBN = rs.getInt("SUIRI_KBN");
						//int SHIYO_KAHI = rs.getInt("SHIYO_KAHI");
						//int CHIIKI_DANSUI = rs.getInt("CHIIKI_DANSUI");
						//int SETCHI_BASHO = rs.getInt("SETCHI_BASHO");
						//String SHOSHO = rs.getString("SHOSHO");

						json = new JsonAttributes();
						json.setKey("水利コード");
						json.setValue(SUIRI_CD);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("目標");
						json.setValue(MOKUHYO);
						jsonList.add(json);
						
						//switch(SUIRI_SBT) {
						
						//}
					
						
						//json.setValue(SUIRI_SBT);
						//jsonList.add(json);

						//json = new JsonAttributes();
						//json.setKey("使用可否");
						// 0:使用可能
						// 1:使用不能(不能水利)

						//System.out.println(SHIYO_KAHI);
						//if (SHIYO_KAHI == 0) {
							//json.setValue("使用可能");
						//} else {
							//json.setValue("使用不能(不能水利)");
						//}
						//jsonList.add(json);

						// 0:使用可能
						// 1以上:地域断水指定あり
//						json = new JsonAttributes();
	//					json.setKey("地域断水");
		//				if (CHIIKI_DANSUI == 0) {
			//				json.setValue("使用可能");
				//		} else {
					//		json.setValue("地域断水指定あり");
			//			}
			//			jsonList.add(json);

						// 1:公設
						// 2:指定
						// 3:その他
				//		json = new JsonAttributes();
					//	json.setKey("水利区分");
					//	switch (SUIRI_KBN) {
//						case 1:
	//						json.setValue("公設");
		//					break;
			//			case 2:
				//			json.setValue("指定");
					//		break;
				//		case 3:
					//		json.setValue("その他");
					//		break;
				//		}
				//		jsonList.add(json);

					//	json = new JsonAttributes();
					//	json.setKey("署所コード");
					//	json.setValue(SHOSHO);
					//	jsonList.add(json);

						/*
						 * 10:道路 11:車道 12:歩道 13:自転車道 14:遊歩道 15:中央分離帯 16:高速（高架下含む） 17:私道 18:公園 19:緑地
						 * 20:児童遊園地 21:河川敷 22:防潮提 23:消防水利専用用地 24:消防署敷地内 25:学校敷地内 26:神社寺院境内 27:工場敷地内
						 */
						/*
						json = new JsonAttributes();
						json.setKey("設置場所");
						switch (SETCHI_BASHO) {
						case 10:
							json.setValue("道路");
							break;
						case 11:
							json.setValue("車道");
							break;
						case 12:
							json.setValue("歩道");
							break;
						case 13:
							json.setValue("自転車道");
							break;
						case 14:
							json.setValue("遊歩道");
							break;
						case 15:
							json.setValue("中央分離帯");
							break;
						case 16:
							json.setValue("高速（高架下含む");
							break;
						case 17:
							json.setValue("私道");
							break;
						case 18:
							json.setValue("公園");
							break;
						case 19:
							json.setValue("緑地");
							break;
						case 20:
							json.setValue("児童遊園地");
							break;
						case 21:
							json.setValue("河川敷");
							break;
						case 22:
							json.setValue("防潮提");
							break;
						case 23:
							json.setValue("消防水利専用用地");
							break;
						case 24:
							json.setValue("消防署敷地内");
							break;
						case 25:
							json.setValue("学校敷地内");
							break;
						case 26:
							json.setValue("神社寺院境内");
							break;
						case 27:
							json.setValue("工場敷地内");
							break;
						}
						jsonList.add(json);
						*/
					}
					rs.close();
				}
				conn.close();
			} catch (SQLException e) {
				System.out.println(e.toString());
			} catch (Exception e) {
				System.out.println(e.toString());
			} finally {
				System.out.println("処理が完了しました");
			}
			dto.setData(jsonList);
		}

		if (layerId.indexOf("n@3-1") == 0) {
		}
		if (layerId.indexOf("n@4-1") == 0) {
		}
		if (layerId.indexOf("n@5-1") == 0) {
		}
		if (layerId.indexOf("n@6-1") == 0) {
		}
		//車両
		if (layerId.indexOf("n@7-1") == 0) {
//			SQL = "select * from FIRE.V_TBMP0200 WHERE SHARYO_CD='" + keyValue + "'";;
//			SQL = "select * from FIRE.V_TBMP0200 WHERE SHARYO_CD='" + keyValue + "'";;

			
			SQL = "select FIRE.TBSSB024.*,FIRE.TBDSC210A.CAR_NM,FIRE.TBDSC210A.SYMBOL_CD,FIRE.TBDSC510A.DOUTAI_NM,FIRE.TBDSC390A.CODE_NM from FIRE.TBSSB024  ";
			SQL += " INNER JOIN FIRE.TBDSC210A ON TO_NUMBER(FIRE.TBSSB024.CAR_CD) = FIRE.TBDSC210A.CAR_CD ";
			SQL += " INNER JOIN FIRE.TBDSC510A ON FIRE.TBSSB024.MOVE_CD = FIRE.TBDSC510A.DOUTAI_CD";
			SQL += " INNER JOIN FIRE.TBDSC390A ON (TO_NUMBER(FIRE.TBSSB024.CAR_TYPE_CD) = FIRE.TBDSC390A.CODE AND FIRE.TBDSC390A.CODE_SYU=1020) ";
			SQL += " WHERE FIRE.TBSSB024.CAR_CD='"+keyValue+"'";
			System.out.println(SQL);
			boolean IsSet = false;

			try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
					PreparedStatement ps = conn.prepareStatement(SQL)) {
				try (ResultSet rs = ps.executeQuery()) {
					if (rs.next()) {
						String CAR_CD = rs.getString("CAR_CD");
						String CAR_NM = rs.getString("CAR_NM");
						String MOVE_CD = rs.getString("MOVE_CD");
						String DOUTAI_NM = rs.getString("DOUTAI_NM");
						String POS_REFLASH_DATE = rs.getString("POS_REFLASH_DATE");
						String CODE_NM = rs.getString("CODE_NM");

						json = new JsonAttributes();
						json.setKey("車両コード");
						json.setValue(CAR_CD);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("車両名");
						json.setValue(CAR_NM);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("車種");
						json.setValue(CODE_NM);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("車両動態コード");
						json.setValue(MOVE_CD);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("車両動態名称");
						json.setValue(DOUTAI_NM);
						jsonList.add(json);

						json = new JsonAttributes();
						json.setKey("位置更新時刻");
						
//						20240410125548
						if(POS_REFLASH_DATE.length()>=14) {
							String d = POS_REFLASH_DATE.substring(0,4)+"/"+POS_REFLASH_DATE.substring(4,6)+"/"+POS_REFLASH_DATE.substring(6,8)+" ";
							d +=POS_REFLASH_DATE.substring(8,10)+":"+POS_REFLASH_DATE.substring(10,12)+":"+POS_REFLASH_DATE.substring(12);
							json.setValue(d);
						}else {
							json.setValue(POS_REFLASH_DATE);
						}
						jsonList.add(json);

						dto.setData(jsonList);
					}
					rs.close();
				} catch (Exception ex) {
					System.out.println(ex.toString());
				}
				conn.close();
			} catch (Exception ex) {
				System.out.println(ex.toString());
			}
		}
		if (layerId.indexOf("n@8-1") == 0) {
		}
		if (layerId.indexOf("n@9-1") == 0) {
		}
		if (layerId.indexOf("n@10-1") == 0) {
		}
		if (layerId.indexOf("n@21-1") == 0) {
		}
		if (layerId.indexOf("n@22-1") == 0) {
		}
		if (layerId.indexOf("n@23-1") == 0) {
		}
		if (layerId.indexOf("n@24-1") == 0) {
		}
		if (layerId.indexOf("n@28-1") == 0) {
		}
	}

	private void AddMessage(AttributesDto dto, String msg) {
		String oldmsg = dto.getMessage();
		if (oldmsg == null) {
			dto.setMessage(msg);
		} else {
			dto.setMessage(oldmsg + "," + msg);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}

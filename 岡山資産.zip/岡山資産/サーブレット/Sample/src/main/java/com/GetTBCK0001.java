package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetTBCK0001
 */
@WebServlet("/GetTBCK0001")
public class GetTBCK0001 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetTBCK0001() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		log("Start");

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		String jisiki = request.getParameter("jisiki");
		String carcd = request.getParameter("carcd");

		//設定ファイル読み込み処理
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			JsonNode json = objectMapper
					.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
			//System.out.println(json); 

			URL = json.get("conn_url3").textValue();
			USER = json.get("conn_user3").textValue();
			PASS = json.get("conn_pass3").textValue();
		} catch (Exception e) {
			e.printStackTrace();
		}

		TBCK0001Dto dto = new TBCK0001Dto();
		PrintWriter out = response.getWriter();

		if (ReadDB(jisiki, carcd, out, dto) == 0) {
			dto.setResult("OK");
		} else {
			dto.setResult("NG");
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();

		log("End");

	}

	public int ReadDB(String jisiki, String carcd, PrintWriter out, TBCK0001Dto dto) {

		int ret = 0;

		String SQL = "";
		SQL = "select * from SHASAI.TBCK0001 WHERE jisiki='" + jisiki + "'";

		int reccnt = 0;
		List<TBCK0001Bean> jsonList = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					TBCK0001Bean jsonBean = new TBCK0001Bean();

					String JISIKI = rs.getString("JISIKI");
					int RENBAN = rs.getInt("RENBAN");
					String SUI_CD = rs.getString("SUI_CD");
					int BUSHO_MAX = rs.getInt("BUSHO_MAX");
					int BUSHO_CARNUM = rs.getInt("BUSHO_CARNUM");
					int SITUATION_CD = rs.getInt("SITUATION_CD");
					int USE_KAHI = rs.getInt("USE_KAHI");
					//int ZAHYO_X = rs.getInt("ZAHYO_X");
					//int ZAHYO_Y = rs.getInt("ZAHYO_Y");
					System.out.println(JISIKI + "," + RENBAN + "," + SUI_CD);
					//System.out.println(SYMBOL_ID);

					//マスタから座標を取得する

					int zx = 0;
					int zy = 0;
					int symbol_id=0;
					
					int[] retVal = new int[3];

					GetPos(SUI_CD, retVal);
					zx = retVal[0];
					zy = retVal[1];
					symbol_id = retVal[2];

					//
					//部署車両テーブルを見る
					//

					int CAR_CD = Integer.parseInt(carcd);
					int result = CheckTBCK0002(jisiki, SUI_CD, CAR_CD);

					int ptn=0;

					if (result < 0) {
						//TBCK0002に該当水利が存在しない
					} else {
						
						/*
						case 1://指定水利（自車以外）
						case 2://指定水利（自車）
						case 3://フリー
						case 4://不能
						case 5://部署水利
						case 6://相掛かり可能
						case 7://他部署
						*/						
					

						switch (result) {
						case 1:
							//他事案（自車両）
							if (BUSHO_MAX <= BUSHO_CARNUM) {
								//他事案部署中
							}
							break;
						case 2:
							//部署水利
							ptn =15;
							break;
						case 3:
							//指定水利（自車両）
							ptn = 2;
							break;
						case 4:
							//同一事案他車両
							break;
						case 5:
							//他事案（他車両）
							if (BUSHO_MAX <= BUSHO_CARNUM && SITUATION_CD==0) {
								//他車両部署中（相かかり可能）
								ptn = 7;
							}else {
								//水色
								ptn = 6;
							}
							break;
						default:
							break;
						}
					}
					//
					//シンボルID変換
					//
					
					symbol_id = switchSymbolId(symbol_id,ptn);

					jsonBean.setJisiki(JISIKI);
					jsonBean.setRenban(RENBAN);
					jsonBean.setSui_cd(SUI_CD);
					jsonBean.setZx(zx);
					jsonBean.setZy(zy);
					jsonBean.setSymbol_id(symbol_id);

					jsonList.add(jsonBean);
				}
				dto.setData(jsonList);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;

	}

	public int GetPos(String SUI_CD, int[] retVal) {

		int ret = -1;
		String SQL = "";

		SQL += "select *  from TBJS0100 WHERE SUIRI_CD='" + SUI_CD + "'";

		System.out.println(SQL);

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;

					String SUIRI_CD = rs.getString("SUIRI_CD");
					int SUIRI_SBT = rs.getInt("SUIRI_SBT");
					int SYMBOL_SBT = rs.getInt("SYMBOL_SBT");
					int SHIYO_KAHI = rs.getInt("SHIYO_KAHI");
					int HAIKAN_KOKEI = rs.getInt("HAIKAN_KOKEI");
					String MOJI = rs.getString("MOJI");
					int IZAHYO_X = rs.getInt("IZAHYO_X");
					int IZAHYO_Y = rs.getInt("IZAHYO_Y");

					retVal[0] = IZAHYO_X;
					retVal[1] = IZAHYO_Y;
					retVal[2] = SYMBOL_SBT;

				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.toString());
			ret = 1;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.toString());
			ret = 1;
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;
	}

	public int CheckTBCK0002(String jisiki, String SUI_CD, int carcd) {
		int ret = -1;

		String SQL = "";

		SQL = "select * from SHASAI.TBCK0002 WHERE SUI_CD='" + SUI_CD + "'";

		int reccnt = 0;

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;

					//水利コードの部署区分が１
					String JISIKI = rs.getString("JISIKI");
					int CAR_CD = rs.getInt("CAR_CD");
					int BUSYO_KBN = rs.getInt("BUSYO_KBN");
					int WARI_KBN = rs.getInt("WARI_KBN");

					if (JISIKI != jisiki) {
						if (CAR_CD == carcd) {
							//他事案（自車両）
							ret = 1;
						} else {
							//他事案（他車両）
							ret = 5;
						}
					} else {
						if (CAR_CD == carcd) {
							if (BUSYO_KBN == 1) {
								//部署水利
								ret = 2;
							} else {
								//指定水利（自車両）
								ret = 3;
							}
						} else {
							//他車両
							ret = 4;
						}
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;
	}
	
	
	private int  switchSymbolId(int symbol_id,int ptn) {
		int ret = symbol_id;
		
		
		switch(ptn) {
		case 1://指定水利（自車以外）
			symbol_id += 500;
			break;
		case 2://指定水利（自車）
			symbol_id += 1000;
			break;
		case 3://フリー
			symbol_id += 100;
			break;
		case 4://不能
			symbol_id += 1025;
			break;
		case 5://部署水利
			symbol_id += 150;
			break;
		case 6://相掛かり可能
			symbol_id += 200;
			break;
		case 7://他部署
			symbol_id += 325;
			break;
		}
		
		
		return ret;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

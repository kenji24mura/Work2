package com;

public class JsonSymbolList {
	 private int symbol_id;
	 private int symbol_type;
	 private String name1;
	 private String name2;
	 private String iconpath;
	 private String info;
	public int getSymbol_id() {
		return symbol_id;
	}
	public void setSymbol_id(int symbol_id) {
		this.symbol_id = symbol_id;
	}
	public int getSymbol_type() {
		return symbol_type;
	}
	public void setSymbol_type(int symbol_type) {
		this.symbol_type = symbol_type;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getName2() {
		return name2;
	}
	public void setName2(String name2) {
		this.name2 = name2;
	}
	public String getIconpath() {
		return iconpath;
	}
	public void setIconpath(String iconpath) {
		this.iconpath = iconpath;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
}

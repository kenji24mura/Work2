package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetStreamSymbol
 */
@WebServlet("/GetStreamSymbol")
public class GetStreamSymbol extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String URL = "";
	String USER = "";
	String PASS = "";
	
	//final String URL = "jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	final String URL = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";
	//final String USER = "WEBGIS";
	//final String PASS = "WEBGIS";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetStreamSymbol() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		MiddleDto dto = new MiddleDto();

		try {

			String lay_no = request.getParameter("lay_no");
			String symbol_no = request.getParameter("symbol_no");
			
			int sym_no = Integer.parseInt(symbol_no);
			
			ReadDB(lay_no,sym_no,dto);
			
		} catch (Exception e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			dto.setResult("NG");
		} finally {
		}

		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		out.flush();
	}
	
	
	public int ReadDB(String lay_no, int sym_no,MiddleDto dto) {
		
		int ret = -1;
		String SQL = "";

		SQL += "select lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y  from TBWG0001 WHERE  lay_no ='"+lay_no+ "' AND symbol_no="+sym_no; 

		dto.setSql(SQL);

		List<MiddleBean> jsonList = new ArrayList<>();

		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;

					MiddleBean bean = new MiddleBean();

					String item_no = rs.getString("ITEM_NO");
					int info_type = rs.getInt("INFO_TYPE");
					String info_summery = rs.getString("INFO_SUMMERY");
					int lay_type = rs.getInt("LAY_TYPE");
					int symbol_no = rs.getInt("SYMBOL_NO");
					Double zahyo_x = rs.getDouble("ZAHYO_X");
					Double zahyo_y = rs.getDouble("ZAHYO_Y");
					
					if(zahyo_x > 0 && zahyo_y >0) {
						bean.setLay_no(lay_no);
						bean.setItem_no(item_no);
						bean.setInfo_type(info_type);
						bean.setInfo_summery(info_summery);
						bean.setLay_type(lay_type);
						bean.setSymbol_no(symbol_no);
						bean.setZahyo_x(zahyo_x);
						bean.setZahyo_y(zahyo_y);
						jsonList.add(bean);
					}
					
				}
				dto.setData(jsonList);
				dto.setMessage("検索処理が完了しました");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			System.out.println(e.toString());
			ret = 1;
		} catch (Exception e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			System.out.println(e.toString());
			ret = 1;
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

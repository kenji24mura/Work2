package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class SearchMiddleTable
 */
@WebServlet("/SearchMiddleTable")
public class SearchMiddleTable extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchMiddleTable() {
		super();
	
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());

		log("Start");

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		MiddleDto dto = new MiddleDto();
		
		int ret = 0;

		try {

			int mode = Integer.parseInt(request.getParameter("mode")); // 1:検索 2:追加　3:更新　4:削除
			String lay_no = request.getParameter("lay_no");
			String item_no = request.getParameter("item_no");
			String s_lay_type = request.getParameter("lay_type"); // 1:シンボル 2:線 3:ポリゴン
			String s_info_type = request.getParameter("info_type");
			String info_summery = request.getParameter("info_summery");
			String s_symbol_no = request.getParameter("symbol_no");
			String s_zahyo_x = request.getParameter("zahyo_x");
			String s_zahyo_y = request.getParameter("zahyo_y");
			String strinfo1 = request.getParameter("strinfo1");
			String strinfo2 = request.getParameter("strinfo2");
			String strinfo3 = request.getParameter("strinfo3");
			String s_str_zahyo_x = request.getParameter("str_zahyo_x");
			String s_str_zahyo_y = request.getParameter("str_zahyo_y");
			String s_zahyo_cnt = request.getParameter("zahyo_cnt");
			String info_zahyo = request.getParameter("info_zahyo");
			String s_max_cnt = request.getParameter("max_cnt");
			String start_date = request.getParameter("start_date");
			String end_date = request.getParameter("end_date");
			String item_no2 = request.getParameter("item_no2");

			int lay_type = 0;
			int info_type = 0;
			int symbol_no = 0;
			double zahyo_x = 0;
			double zahyo_y = 0;
			double str_zahyo_x = 0;
			double str_zahyo_y = 0;
			int zahyo_cnt = 0;
			int max_cnt = 0;
			
			if (s_lay_type != null) {
				lay_type = Integer.parseInt(s_lay_type); // 1:シンボル 2:線 3:ポリゴン
			}
			if (s_info_type != null) {
				info_type = Integer.parseInt(s_info_type);
			}
			if (s_symbol_no != null ) {
				if(s_symbol_no.equals("")) {
					symbol_no=0;
				}else{
					symbol_no = Integer.parseInt(s_symbol_no);
				}
			}
			if (s_zahyo_x != null) {

				zahyo_x = Double.parseDouble(s_zahyo_x);
			}
			if (s_zahyo_y != null) {

				zahyo_y = Double.parseDouble(s_zahyo_y);
			}
			if (s_str_zahyo_x != null) {

				str_zahyo_x = Double.parseDouble(s_str_zahyo_x);
			}
			if (s_str_zahyo_y != null) {

				str_zahyo_y = Double.parseDouble(s_str_zahyo_y);
			}
			if (s_zahyo_cnt != null) {

				zahyo_cnt = Integer.parseInt(s_zahyo_cnt);
			}
			if (s_max_cnt != null) {

				max_cnt = Integer.parseInt(s_max_cnt);
			}

			switch (mode) {
			case 1:// 検索

				ret = ReadDB(lay_type, lay_no, symbol_no,max_cnt,start_date,end_date,dto);
				break;
			case 2:// 追加
				
				
				item_no= GetMaxItemId(lay_type,info_type ,symbol_no);
				item_no2 = item_no;

				
				if (lay_type == 1) {
					ret = InsertSymbol(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y,
							strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, item_no2,dto);
				} else {

					String[] points = info_zahyo.split(",");
					ZPoint[] zp = new ZPoint[zahyo_cnt];
					// オブジェクト型の初期化が必要
					for (int i = 0; i < zahyo_cnt; i++) {
						zp[i] = new ZPoint();

						zp[i].x = Double.parseDouble(points[i * 2]);
						zp[i].y = Double.parseDouble(points[i * 2 + 1]);
					}
					ret = InsertPolygon(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y,
							strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, zp, dto);
				}
				break;
			case 3:// 更新
				if (lay_type == 1) {
					ret = UpdateSymbol(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y,
							strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, item_no2,dto);
				} else {

					String[] points = info_zahyo.split(",");
					ZPoint[] zp = new ZPoint[zahyo_cnt];
					// オブジェクト型の初期化が必要
					for (int i = 0; i < zahyo_cnt; i++) {
						zp[i] = new ZPoint();

						zp[i].x = Double.parseDouble(points[i * 2]);
						zp[i].y = Double.parseDouble(points[i * 2 + 1]);
					}
					ret = UpdatePolygon(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y,
							strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, zp, dto);
				}
				break;
			case 4:// 削除
				ret = DeleteDB(lay_type, lay_no, item_no,  dto);
				break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			ret = -1;
		} finally {
		}
		
		if(ret == 0) {
			dto.setResult("OK");
		}else {
			dto.setResult("NG");
		}

		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonData = mapper.writeValueAsString(dto);

			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
		}
		out.flush();
		log("End");
	}

	public int ReadDB(int i_lay_type, String i_lay_no,int symbol_no,int max_cnt,String start_date,String end_date,MiddleDto dto) {

		int ret = -1;
		String SQL = "";
		
		int reccnt=0;
		

		if (i_lay_type == 1) {
			SQL += "select * from TBWG0001";
		} else {
			SQL += "select * from TBWG0002";
		}
		SQL += " where lay_no='" + i_lay_no + "'";
		if(symbol_no > 0) {
			SQL += " AND symbol_no=" + symbol_no;
		}

		if(start_date.equals("")==false)
		{
			SQL += " AND update_date >=TO_DATE('"+start_date+"', 'YYYY-MM-DD HH24:MI:SS')";
		}
		if(end_date.equals("")==false)
		{
			SQL += " AND update_date <=TO_DATE('"+end_date+"', 'YYYY-MM-DD HH24:MI:SS')";
		}
		
		SQL += " order by lay_no,item_no";

		dto.setSql(SQL);

		List<MiddleBean> jsonList = new ArrayList<>();
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					ret = 0;

					MiddleBean bean = new MiddleBean();

					String lay_no = rs.getString("LAY_NO");
					String item_no = rs.getString("ITEM_NO");
					int info_type = rs.getInt("INFO_TYPE");
					String info_summery = rs.getString("INFO_SUMMERY");
					int lay_type = rs.getInt("LAY_TYPE");
					symbol_no = rs.getInt("SYMBOL_NO");
					Double zahyo_x = rs.getDouble("ZAHYO_X");
					Double zahyo_y = rs.getDouble("ZAHYO_Y");
					String strinfo1 = rs.getString("STRINFO1");
					String strinfo2 = rs.getString("STRINFO2");
					String strinfo3 = rs.getString("STRINFO3");
					Double str_zahyo_x = rs.getDouble("STR_ZAHYO_X");
					Double str_zahyo_y = rs.getDouble("STR_ZAHYO_Y");
					Date update = rs.getDate("UPDATE_DATE");
					String item_no2 = rs.getString("ITEM_NO2");
					
					int str_ptn =0;
					if (i_lay_type == 1) {
						str_ptn = rs.getInt("STR_PTN");
					}
					
					bean.setLay_no(lay_no);
					bean.setItem_no(item_no);
					bean.setInfo_type(info_type);
					bean.setInfo_summery(info_summery);
					bean.setLay_type(lay_type);
					bean.setSymbol_no(symbol_no);
					bean.setZahyo_x(zahyo_x);
					bean.setZahyo_y(zahyo_y);
					bean.setStrinfo1(strinfo1);
					bean.setStrinfo2(strinfo2);
					bean.setStrinfo3(strinfo3);
					bean.setStr_zahyo_x(str_zahyo_x);
					bean.setStr_zahyo_y(str_zahyo_y);
					bean.setItem_no2(item_no2);
					bean.setStr_ptn(str_ptn);

					if (i_lay_type == 1) {
						// シンボル
					} else {
						// 線・ポリゴン

						int zahyo_cnt = rs.getInt("zahyo_cnt");

						bean.setZahyo_cnt(zahyo_cnt);

						Array zahyo_array = rs.getArray("zahyo_array");

						Object[] obj = (Object[]) zahyo_array.getArray();

						// dto.zp = new ZPoint[zahyo_cnt];

						List<ZPointBean> zlist = new ArrayList<>();

						for (int i = 0; i < obj.length; i++) {

							Struct zp = (Struct) obj[i];

							Object[] obj2 = zp.getAttributes();

							ZPointBean zpoint = new ZPointBean();
							zpoint.setX(Double.parseDouble(obj2[0].toString()));
							zpoint.setY(Double.parseDouble(obj2[1].toString()));

							zlist.add(zpoint);

						}
						bean.setData(zlist);

					}

					if (update != null) {
						String str = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(update);
						bean.setUpdate_date(str);
					}

					jsonList.add(bean);
					
					reccnt++;
					if(reccnt >= max_cnt) {
						break;
					}
				}
				dto.setData(jsonList);
				dto.setMessage("検索処理が完了しました");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			System.out.println(e.toString());
			ret = 1;
		} catch (Exception e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			System.out.println(e.toString());
			ret = 1;
		} finally {
			System.out.println("処理が完了しました");
		}

		return ret;
	}

	//
	// シンボル追加
	//
	public int InsertSymbol(String lay_no, String item_no, int info_type, String info_summery, int lay_type,
			int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3,
			double str_zahyo_x, double str_zahyo_y,String item_no2,MiddleDto dto) {

		int ret = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "insert into  TBWG0001(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,update_date,item_no2) ";
			sql += "values (?,?,?,?,?,?,?,?,?,?,?,?,?,TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'),?";
			sql += ")";
			dto.setSql(sql);
		
			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, lay_no);
			pstmt.setString(2, item_no);
			pstmt.setInt(3, info_type);
			pstmt.setString(4, info_summery);
			pstmt.setInt(5, lay_type);
			pstmt.setInt(6, symbol_no);
			pstmt.setDouble(7, zahyo_x);
			pstmt.setDouble(8, zahyo_y);
			pstmt.setString(9, strinfo1);
			pstmt.setString(10, strinfo2);
			pstmt.setString(11, strinfo3);
			pstmt.setDouble(12, str_zahyo_x);
			pstmt.setDouble(13, str_zahyo_y);
			pstmt.setString(14, update_date);
			pstmt.setString(15, item_no2);

			pstmt.executeUpdate();
			conn.commit();

			dto.setMessage("追加処理が完了しました");
		} catch (

		SQLException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}
		return ret;

	}
	
	
	//正規化座標(mm)を経度磯（世界測地に変換）
	public void ConvertXY(int zx,int zy,int kijyunkei,double[] retVal) {
		
//		int zx = -45237600;//mm
//		int zy = -150372500;//mm
		
//		int kijyunkei = 6;

		System.out.println("zx="+zx);
		System.out.println("zy="+zy);
		
		double[] ret = new double[2];
		ret[0] = 0.0;
		ret[1] = 0.0;

		//MapConvert class インスタンス
		MapConvert mc = new MapConvert();
		
		mc.ConvertPos(zx,zy,kijyunkei,ret);

		System.out.println("lon="+ret[0]);
		System.out.println("lat="+ret[1]);
		retVal[0] = ret[0];
		retVal[1] = ret[1];
	}
	
	public String GetMaxItemId(int lay_type,int info_type ,int symbol_no ) {
		String SQL="";
		
		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;
		
		int number = 1;

		if(lay_type==1) {
			SQL = "select max(item_no) from TBWG0001 where info_type =" + info_type +"  and symbol_no = "+symbol_no;
		}else {
			SQL = "select max(item_no) from TBWG0002 where info_type =" + info_type +"  and symbol_no = "+symbol_no;
		}
		
		log(SQL);
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {
				
				String item_no = rs.toString();
				
				if (rs.next()) {
					item_no = rs.getString(1);
					
					if(item_no == null) {
						System.out.println("no record");
					}else {
						System.out.println(item_no);
						
						String str="";
						if(symbol_no>9999) {
							str = item_no.substring(item_no.length() - 4, item_no.length());
						}else {
							str = item_no.substring(item_no.length() - 6, item_no.length());
						}
						System.out.println("str="+str);
						number = Integer.parseInt(str) + 1;
						/*
						if(item_no.length()==12) {
							String str = item_no.substring(6, 12);
							System.out.println("str="+str);
							number = Integer.parseInt(str) + 1;
						}else {
							
							//12桁に満たないデータがある場合
							number = 1;
						}
						*/
					}

				}
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("処理が完了しました");
		}
		String result="";
		if(symbol_no>9999) {
			result = String.format("%02d",info_type) + String.format("%06d",symbol_no)+String.format("%04d",number);
			
		}else {
			result = String.format("%02d",info_type) + String.format("%04d",symbol_no)+String.format("%06d",number);
			
		}

		System.out.println(result);
		
		return result;
		
	}


	//
	// ポリゴン追加
	//
	public int InsertPolygon(String lay_no, String item_no, int info_type, String info_summery, int lay_type,
			int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3,
			double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, ZPoint[] zp,MiddleDto dto) {

		int ret = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "insert into  TBWG0002(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,zahyo_cnt,zahyo_array,update_date) ";
			sql += "values (?,?,?,?,?,?,?,?,?,?,?,?,?,?";
			sql += ",ARRAY_POINT(";
			for (int i = 0; i < zp.length; i++) {
				if (i > 0) {
					sql += ",";
				}
				sql += "POINT(?,?)";
			}
			sql += ")";
			sql += ",TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS')";
			sql += ")";
			
			System.out.println(sql);
			dto.setSql(sql);
			
			pstmt = conn.prepareStatement(sql);

			int idx=1;
			pstmt.setString(idx, lay_no);idx++;//1
			pstmt.setString(idx, item_no);idx++;//2
			pstmt.setInt(idx, info_type);idx++;//3
			pstmt.setString(idx, info_summery);idx++;//4
			pstmt.setInt(idx, lay_type);idx++;//5
			pstmt.setInt(idx, symbol_no);idx++;//6
			pstmt.setDouble(idx, zahyo_x);idx++;//7
			pstmt.setDouble(idx, zahyo_y);idx++;//8
			pstmt.setString(idx, strinfo1);idx++;//9
			pstmt.setString(idx, strinfo2);idx++;//10
			pstmt.setString(idx, strinfo3);idx++;//11
			pstmt.setDouble(idx, str_zahyo_x);idx++;//12
			pstmt.setDouble(idx, str_zahyo_y);idx++;//13
			pstmt.setInt(idx, zahyo_cnt);idx++;//14
			
			for (int i = 0; i < zp.length; i++) {
				pstmt.setDouble(idx, zp[i].x);idx++;
				pstmt.setDouble(idx, zp[i].y);idx++;
			}
			
			pstmt.setString(idx, update_date);idx++;

			pstmt.executeUpdate();
			conn.commit();

			dto.setMessage("追加処理が完了しました");
		} catch (

		SQLException e) {
			dto.setMessage(e.toString());
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}
		
		return ret;

	}

	public int UpdateSymbol(String lay_no, String item_no, int info_type, String info_summery, int lay_type,
			int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3,
			double str_zahyo_x, double str_zahyo_y,String item_no2,MiddleDto dto) {
		int ret = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// カレンダーのフォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "update  TBWG0001 set lay_no=?, item_no=?, info_type=?, info_summery =?, lay_type = ?, symbol_no=? ,zahyo_x=?, zahyo_y =? ,strinfo1 =? ,strinfo2 =? ,strinfo3 =? ,str_zahyo_x=? ,str_zahyo_y =? ,update_date= TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS'),item_no2=? ";
			sql += "where  lay_no=? and item_no=? ";
			
			dto.setSql(sql);

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, lay_no);
			pstmt.setString(2, item_no);
			pstmt.setInt(3, info_type);
			pstmt.setString(4, info_summery);
			pstmt.setInt(5, lay_type);
			pstmt.setInt(6, symbol_no);
			pstmt.setDouble(7, zahyo_x);
			pstmt.setDouble(8, zahyo_y);
			pstmt.setString(9, strinfo1);
			pstmt.setString(10, strinfo2);
			pstmt.setString(11, strinfo3);
			pstmt.setDouble(12, str_zahyo_x);
			pstmt.setDouble(13, str_zahyo_y);
			pstmt.setString(14, update_date);
			pstmt.setString(15, item_no2);
			pstmt.setString(16, lay_no);
			pstmt.setString(17, item_no);

			pstmt.executeUpdate();
			conn.commit();

			dto.setMessage("更新処理が完了しました");
		} catch (

		SQLException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}

		return ret;

	}

	public int UpdatePolygon(String lay_no, String item_no, int info_type, String info_summery, int lay_type,
			int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3,
			double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, ZPoint[] zp,MiddleDto dto) {

		int ret = 0;

		Connection conn = null;
		PreparedStatement pstmt = null;

		Calendar cl = Calendar.getInstance();

		// フォーマットを指定する
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String update_date = sdf.format(cl.getTime());

		String sql = "";

		try {

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			sql += "update  TBWG0002 set lay_no=?, item_no=?, info_type=?, info_summery =?, lay_type = ?, symbol_no=? ,zahyo_x=?, zahyo_y =? ,strinfo1 =? ,strinfo2 =? ,strinfo3 =? ,str_zahyo_x=? ,str_zahyo_y =? ,zahyo_cnt=? ";
			sql += ",zahyo_array=ARRAY_POINT(";
			for (int i = 0; i < zp.length; i++) {
				if (i > 0) {
					sql += ",";
				}
				sql += "POINT(?,?)";
			}
			sql += ")";

			sql += ",update_date= TO_DATE(?, 'YYYY-MM-DD HH24:MI:SS') ";
			sql += "where  lay_no=? and item_no=? ";
			
			
			System.out.println(sql);
			dto.setSql(sql);

			pstmt = conn.prepareStatement(sql);

			int idx=1;
			pstmt.setString(idx, lay_no);idx++;//1
			pstmt.setString(idx, item_no);idx++;//2
			pstmt.setInt(idx, info_type);idx++;//3
			pstmt.setString(idx, info_summery);idx++;//4
			pstmt.setInt(idx, lay_type);idx++;//5
			pstmt.setInt(idx, symbol_no);idx++;//6
			pstmt.setDouble(idx, zahyo_x);idx++;//7
			pstmt.setDouble(idx, zahyo_y);idx++;//8
			pstmt.setString(idx, strinfo1);idx++;//9
			pstmt.setString(idx, strinfo2);idx++;//10
			pstmt.setString(idx, strinfo3);idx++;//11
			pstmt.setDouble(idx, str_zahyo_x);idx++;//12
			pstmt.setDouble(idx, str_zahyo_y);idx++;//13
			pstmt.setInt(idx, zahyo_cnt);idx++;//14
			
			for (int i = 0; i < zp.length; i++) {
				pstmt.setDouble(idx, zp[i].x);idx++;
				pstmt.setDouble(idx, zp[i].y);idx++;
			}
			
			pstmt.setString(idx, update_date);idx++;
			pstmt.setString(idx, lay_no);idx++;
			pstmt.setString(idx, item_no);

			pstmt.executeUpdate();
			conn.commit();

			dto.setMessage("更新処理が完了しました");
		} catch (

		SQLException e) {
			dto.setMessage(e.toString());
			e.printStackTrace();
			ret = -1;
		} finally {
			System.out.println("処理が完了しました");
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}

		return ret;
	}

	public int DeleteDB(int lay_type, String lay_no, String item_no, MiddleDto dto) {

		Connection conn = null;
		PreparedStatement pstmt = null;

		int ret = 0;

		String sql = "";

		if (lay_type == 1) {
			sql += "delete from TBWG0001";
		} else {
			sql += "delete from TBWG0002";
		}
		sql += " Where lay_no=? AND item_no=?";

		try {

			dto.setSql(sql);

			conn = DriverManager.getConnection(URL, USER, PASS);
			conn.setAutoCommit(false); // オートコミットはオフ

			pstmt = conn.prepareStatement(sql);

			pstmt.setString(1, lay_no);
			pstmt.setString(2, item_no);

			pstmt.executeUpdate();
			conn.commit();

			dto.setMessage("削除処理が完了しました");

		} catch (SQLException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			ret = -1;
		} finally {
		}
		try {
			if (pstmt != null) {
				pstmt.close();
				pstmt = null;
			}
		} catch (SQLException ex) {
		}
		try {
			if (conn != null) {
				conn.close();
				conn = null;
			}
		} catch (SQLException ex) {
		}
		return ret;

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

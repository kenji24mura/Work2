/*
	地図座標コンバートクラス
*/
package com;

public class MapConvert {
	//１９座標系原点定義
	int keido[] = {

			466200,
			471600,
			475800,
			480600,
			483600,
			489600,
			493800,
			498600,
			503400,
			507000,
			504900,
			512100,
			519300,
			511200,
			459000,
			446400,
			471600,
			489600,
			554400,
	};

	int ido[] = {
			118800,
			118800,
			129600,
			118800,
			129600,
			129600,
			129600,
			129600,
			129600,
			144000,
			158400,
			158400,
			158400,
			93600,
			93600,
			93600,
			93600,
			72000,
			93600,
	};

	//--------------------------------------------------------------------------------------------------------------
	//正規化座標を世界測地系の経緯度に変換する
	//                     zx,zy(mm 単位）-->経緯度(DEG)
	//--------------------------------------------------------------------------------------------------------------
	public void ConvertPos(int zx,int zy,int kijyunkei,double[] ret) {

		double lx=0.0;
		double ly=0.0;

		double[] ret2 = new double[2];
		
		lx = (double)zx/1000.0;
		ly = (double)zy/1000.0;

		//平面直角⇒経度緯度（秒）
		gpconv2(lx,ly,kijyunkei,ret2);
		
		double lx2 = ret2[0] * 1000;
		double ly2 = ret2[1] * 1000;

		//測地系（日本⇒世界）
		ConvJ2W(lx2, ly2, ret2);

		ret[0] = ret2[0]/(3600*1000);
		ret[1] = ret2[1]/(3600*1000);
		
	}
	//--------------------------------------------------------------------------------------------------------------
	//世界測地系を正規化座標に変換する
	//                    経緯度(DEG) -->zx,zy(mm 単位）
	//--------------------------------------------------------------------------------------------------------------
	public void ConvertPos2(double lon,double lat,int kijyunkei,int[] ret) {

		//const ret = {};
		 
		double wlon = lon * 3600 * 1000;
		double wlat = lat * 3600 * 1000;

			double[] lonlat = new double[2];

			//測地系変換
		  ConvW2J(wlon, wlat, lonlat);

		  double wlon2 = lonlat[0] / 1000;
		  double  wlat2 = lonlat[1] / 1000;

		  //経緯度を正規化座標に変換

		double[] xy = new double[2];
		  
		  gpconv(wlon2, wlat2, kijyunkei, xy);

		  int lx = (int)(xy[0] * 1000);//mm
		  int ly = (int)(xy[1] * 1000);//mm

		  ret[0] = lx;
		  ret[1] = ly;

		  /*
		double lx=0.0;
		double ly=0.0;

		double[] ret2 = new double[2];
		
		lx = (double)zx/1000.0;
		ly = (double)zy/1000.0;

		//平面直角⇒経度緯度（秒）
		gpconv2(lx,ly,kijyunkei,ret2);
		
		double lx2 = ret2[0] * 1000;
		double ly2 = ret2[1] * 1000;

		//測地系（日本⇒世界）
		ConvJ2W(lx2, ly2, ret2);

		ret[0] = ret2[0]/(3600*1000);
		ret[1] = ret2[1]/(3600*1000);
		*/
	}

	//--------------------------------------------------------------------------------------------------------------
	//経緯度を平面直角座標系に変換する
	//--------------------------------------------------------------------------------------------------------------
	public void gpconv(double m_keido, double m_ido, int kijyunkei, double[] ret) {
		double lx = 0.0;
		double ly = 0.0;

		double phi = 0.0;
		double lamda = 0.0;
		double x = 0.0;
		double y = 0.0;
		double phi0 = 0.0;
		double lamda0 = 0.0;

		double KJN_IDO = 0;
		double KJN_KDO = 0;

		KJN_IDO = ido[kijyunkei - 1];
		KJN_KDO = keido[kijyunkei - 1];

		double Ba = 0.0;
		double Bb = 0.0;
		double Bc = 0.0;
		double Bd = 0.0;
		double Be = 0.0;

		double A = 0.0;
		double E = 0.0;
		double SR = 0.0;
		double PAI = 0.0;

		A = 6377397.155; //'長半径(meter)
		E = 0.006674372231315; //'離心率の二乗
		SR = 206264.806; //'秒・ラジアン換算係数
		PAI = 3.14159265;

		double b = 0.0;
		double s = 0.0;
		double c = 0.0;
		double c2 = 0.0;
		double c4 = 0.0;
		double t = 0.0;
		double t2 = 0.0;
		double t4 = 0.0;
		double h2 = 0.0;
		double h4 = 0.0;
		double N = 0.0;
		double lam2 = 0.0;
		double lamc2 = 0.0;
		double lamc4 = 0.0;

		double x1 = 0.0;
		double x2 = 0.0;
		double y1 = 0.0;
		double y2 = 0.0;

		phi =m_ido;
		lamda = m_keido;

		phi0 = KJN_IDO;
		lamda0 = KJN_KDO;

		//    '秒からラジアンへ
		lamda = lamda - lamda0;
		lamda = (PAI / 180) * (lamda / 3600);
		phi = (PAI / 180) * (phi / 3600);
		phi0 = (PAI / 180) * (phi0 / 3600);

		s = Math.sin(phi);
		c = Math.cos(phi);
		c2 = c * c;
		c4 = c2 * c2;
		t = Math.tan(phi);
		t2 = t * t;
		t4 = t2 * t2;
		h2 = (E * c2) / (1 - E);
		h4 = h2 * h2;
		N = A / Math.sqrt(1 - E * s * s);
		lam2 = lamda * lamda;
		lamc2 = lam2 * c2;
		lamc4 = lamc2 * lamc2;

		double ph1 = 0.0;
		double ph2 = 0.0;

		ph1 = phi0;
		ph2 = phi;

		Ba = 1.005037306049 * (ph2 - ph1);
		Bb = (0.0050478492403 * (Math.sin(2 * ph2) - Math.sin(2 * ph1))) / 2;
		Bc = (0.0000105637868 * (Math.sin(4 * ph2) - Math.sin(4 * ph1))) / 4;
		Bd = (0.00000002063332 * (Math.sin(6 * ph2) - Math.sin(6 * ph1))) / 6;
		Be = (0.000000000038853 * (Math.sin(8 * ph2) - Math.sin(8 * ph1))) / 8;

		b = A * (1 - E) * (Ba - Bb + Bc - Bd + Be);

		x1 = (lamc2 * (5 - t2 + 9 * h2 + 4 * h4)) / 24;
		x2 = (lamc4 * (61 - 58 * t2 + t4 + 270 * h2 - 330 * h2 * t2)) / 720;
		y1 = (lamc2 * (1 - t2 + h2)) / 6;
		y2 = (lamc4 * (5 - 18 * t2 + t4 + 14 * h2 - 58 * h2 * t2)) / 120;
		x = 0.9999 * (b + N * s * c * lam2 * (0.5 + x1 + x2));
		y = 0.9999 * N * c * lamda * (1 + y1 + y2);

		// y,x 逆
		lx = y;
		ly = x;

//		System.out.println(lx);
//		System.out.println(ly);
	
		ret[0] = lx;
		ret[1] = ly;
	}

	//--------------------------------------------------------------------------------------------------------------
	//平面直角座標系を経緯度に変換する
	//--------------------------------------------------------------------------------------------------------------
	public void gpconv2(double lx, double ly, int kijyunkei,double[] ret) {
		double phi = 0.0;
		double lamda = 0.0;
		double phi0 = 0.0;
		double lamda0 = 0.0;
		double x = 0.0;
		double y = 0.0;

		double KJN_KDO = 0.0;
		double KJN_IDO = 0.0;


		KJN_IDO = ido[kijyunkei - 1];
		KJN_KDO = keido[kijyunkei - 1];

		//絶対座標取得
		x = ly;
		y = lx;

		//座標計算
		//            phi0 = KJN_IDO;
		//            lamda0 = KJN_KDO;
		phi0 = KJN_IDO;
		lamda0 = KJN_KDO;

		//平面直角座標系->極座標系

		double mot = 0.0;
		double m = 0.0;
		double s = 0.0;
		double ab = 0.0;
		double ph0 = 0.0;
		double ph1 = 0.0;
		double si = 0.0;
		double co = 0.0;

		double ri = 0.0;
		double ni = 0.0;
		double cr = 0.0;
		double eta2 = 0.0;
		double t = 0.0;
		double t2 = 0.0;
		double t4 = 0.0;
		double y1 = 0.0;
		double y2 = 0.0;
		double y4 = 0.0;
		double f1 = 0.0;
		double f2 = 0.0;
		double A = 0.0;
		double E = 0.0;
		double SR = 0.0;
		double PAI = 0.0;

		double wph1 = 0.0;
		double wph2=0.0;

		double Ba = 0.0;
		double Bb = 0.0;
		double Bc = 0.0;
		double Bd = 0.0;
		double Be = 0.0;

		A = 6377397.155; //長半径(meter)
		E = 0.006674372231315; //離心率の二乗
		SR = 206264.806; //秒・ラジアン換算係数
		PAI = 3.14159265358979;

		si = 0;

		//秒からラジアンへ
		lamda0 = (PAI / 180) * (lamda0 / 3600);
		phi0 = (PAI / 180) * (phi0 / 3600);

		ab = 1;
		ph0 = PAI * 0.2;

		wph1 = 0;
		///		wph2 = ph0;     20030731
		wph2 = phi0;

		Ba = 1.005037306049 * (wph2 - wph1);
		Bb = (0.0050478492403 * (Math.sin(2 * wph2) - Math.sin(2 * wph1))) / 2;
		Bc = (0.0000105637868 * (Math.sin(4 * wph2) - Math.sin(4 * wph1))) / 4;
		Bd = (0.00000002063332 * (Math.sin(6 * wph2) - Math.sin(6 * wph1))) / 6;
		Be = (0.000000000038853 * (Math.sin(8 * wph2) - Math.sin(8 * wph1))) / 8;

		m = x / 0.9999 + A * (1 - E) * (Ba - Bb + Bc - Bd + Be);
		y = y / 0.9999;
		mot = 1 / (A * (1 - E));

		while (ab > 0.00000000000001) {
			wph1 = 0;
			wph2 = ph0;
			Ba = 1.005037306049 * (wph2 - wph1);
			Bb = (0.0050478492403 * (Math.sin(2 * wph2) - Math.sin(2 * wph1))) / 2;
			Bc = (0.0000105637868 * (Math.sin(4 * wph2) - Math.sin(4 * wph1))) / 4;
			Bd = (0.00000002063332 * (Math.sin(6 * wph2) - Math.sin(6 * wph1))) / 6;
			Be = (0.000000000038853 * (Math.sin(8 * wph2) - Math.sin(8 * wph1))) / 8;
			s = A * (1 - E) * (Ba - Bb + Bc - Bd + Be);
			si = Math.sin(ph0);
			ph1 = ph0 + (m - s) * Math.pow(1 - E * si * si, 1.5) * mot;
			ab = ph1 - ph0;
			ph0 = ph1;
			if (ab < 0) {
				ab = -1 * ab;
			}
		}

		co = Math.cos(ph0);
		cr = Math.sqrt(1 - E * si * si);
		ni = cr / A;
		ri = cr * cr * cr * mot;
		eta2 = (co * co * E) / (1 - E);
		t = Math.tan(ph0);
		t2 = t * t;
		t4 = t2 * t2;
		y1 = y * ni;
		y2 = y1 * y1;
		y4 = y2 * y2;
		f1 = -8.33333333333333e-2 * y2 * (5 + 3 * t2 + eta2 - 9 * t2 * eta2);
		f2 = 2.77777777777778e-3 * y4 * (61 + 90 * t2 + 45 * t4);
		phi = ph0 - 0.5 * y * y1 * ri * t * (1 + f1 + f2);
		phi = ((phi * 180) / PAI) * 3600;
		f1 = -0.166666666666667 * y2 * (1 + 2 * t2 + eta2);
		f2 = 8.33333333333333e-3 * y4 * (5 + 28 * t2 + 24 * t4);
		lamda = lamda0 + (y1 / co) * (1 + f1 + f2);
		lamda = ((lamda * 180) / PAI) * 3600;

		//            m_keido = lamda;
		//            m_ido = phi;

//		System.out.println(lamda);
//		System.out.println(phi);
		
		ret[0] = lamda;
		ret[1] = phi;

	}

	//--------------------------------------------------------------------------------------------------------------
	//世界測地系→日本測地系
	//--------------------------------------------------------------------------------------------------------------
	public void ConvW2J(double Mx, double My, double[] ret) {

		double BTokyo = 0.0;
		double LTokyo = 0.0;
		double BWGS84 = 0.0;
		double LWGS84 = 0.0;

		LWGS84 = Mx / (3600 * 1000);
		BWGS84 = My / (3600 * 1000);

		BTokyo = BWGS84 + 0.00010696 * BWGS84 - 0.000017467 * LWGS84 - 0.004602;
		LTokyo = LWGS84 + 0.000046047 * BWGS84 + 0.000083049 * LWGS84 - 0.010041;

		ret[0] = LTokyo * 3600 * 1000;
		ret[1] = BTokyo * 3600 * 1000;

	}

	//--------------------------------------------------------------------------------------------------------------
	//日本測地系→世界測地系
	//--------------------------------------------------------------------------------------------------------------
	public void ConvJ2W(double Mx, double My, double[] ret) {

		double BTokyo = 0.0;
		double LTokyo = 0.0;
		double BWGS84 = 0.0;
		double LWGS84 = 0.0;

		LTokyo = Mx / (3600 * 1000);
		BTokyo = My / (3600 * 1000);

		LWGS84 = LTokyo - 0.000046038 * BTokyo - 0.000083043 * LTokyo + 0.01004;
		BWGS84 = BTokyo - 0.00010695 * BTokyo + 0.000017464 * LTokyo + 0.0046017;

		ret[0] = LWGS84 * 3600 * 1000;
		ret[1] = BWGS84 * 3600 * 1000;
	}

}

//
// 他事案シンボル取得
//

package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetOtherJianSymbol
 */
@WebServlet("/GetOtherJianSymbol")
public class GetOtherJianSymbol extends HttpServlet {
  private static final long serialVersionUID = 1L;

  String URL = "";
  String USER = "";
  String PASS = "";
  String URL2 = "";
  String USER2 = "";
  String PASS2 = "";
  String URL3 = "";
  String USER3 = "";
  String PASS3 = "";
  String MODE = "";
  // 20240130 start
  int kijyunkei = 6;
  // 20240130 end

  /**
   * @see HttpServlet#HttpServlet()
   */
  public GetOtherJianSymbol() {
    super();
    // TODO Auto-generated constructor stub
  }

  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    request.setCharacterEncoding("UTF-8");
    response.setContentType("text/html");
    response.setHeader("Cache-Control", "nocache");
    response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
    response.setCharacterEncoding("utf-8");

    // 20240130 start
    String coordinate = request.getParameter("coordinate");
    if (coordinate == null) {
    } else {
      kijyunkei = Integer.parseInt(coordinate);
    }
    // 20240130 end

    // 設定ファイル読み込み処理
    ObjectMapper objectMapper = new ObjectMapper();
    try {
      JsonNode json = objectMapper.readTree(
          Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
      System.out.println(json);
      
      kijyunkei= Integer.parseInt(json.get("coordinate").textValue());

      URL = json.get("conn_url").textValue();
      USER = json.get("conn_user").textValue();
      PASS = json.get("conn_pass").textValue();
      URL2 = json.get("conn_url2").textValue();
      USER2 = json.get("conn_user2").textValue();
      PASS2 = json.get("conn_pass2").textValue();

      MODE = json.get("mode").textValue();
      if (MODE.indexOf("debug") == 0) {
        URL3 = json.get("conn_url").textValue();
        USER3 = json.get("conn_user").textValue();
        PASS3 = json.get("conn_pass").textValue();

      } else {
        URL3 = json.get("conn_url3").textValue();
        USER3 = json.get("conn_user3").textValue();
        PASS3 = json.get("conn_pass3").textValue();
      }

    } catch (Exception e) {
      e.printStackTrace();
    }

    PrintWriter out = response.getWriter();
    JianDto dto = new JianDto();

    try {

      // 中心座標x(lon)
      // 中心座標y(lat)
      // 検索範囲(m)
      // 対象レイヤ

      String s_lon = request.getParameter("lon");
      String s_lat = request.getParameter("lat");
      String s_radius = request.getParameter("radius");
      String jisiki = request.getParameter("jisiki");
      // String carcd = request.getParameter("carcd");

      System.out.println(s_lon);
      System.out.println(s_lat);
      System.out.println(s_radius);

      double lon = 0.0;
      double lat = 0.0;
      int radius = 0;

      if (s_lon != null) {
        lon = Double.parseDouble(s_lon);
      }
      if (s_lat != null) {
        lat = Double.parseDouble(s_lat);
      }
      if (s_radius != null) {
        radius = Integer.parseInt(s_radius);
      }

      MapConvert mc = new MapConvert();

      // 20240130 コメント
      // int kijyunkei = 6;
      int xy[] = new int[2];

      mc.ConvertPos2(lon, lat, kijyunkei, xy);

      System.out.println(xy[0] + "," + xy[1]);

      int minx = xy[0] - radius * 1000;
      int miny = xy[1] - radius * 1000;
      int maxx = xy[0] + radius * 1000;
      int maxy = xy[1] + radius * 1000;

      double min_lonlat[] = new double[2];
      mc.ConvertPos(minx, miny, kijyunkei, min_lonlat);

      double max_lonlat[] = new double[2];
      mc.ConvertPos(maxx, maxy, kijyunkei, max_lonlat);

      System.out.println("min:" + min_lonlat[0] + "," + min_lonlat[1]);
      System.out.println("max:" + max_lonlat[0] + "," + max_lonlat[1]);

      ReadDB2(minx, miny, maxx, maxy, jisiki, dto);

      dto.setResult("OK");

    } catch (Exception e) {
      e.printStackTrace();
      AddMessage(dto, e.toString());
      dto.setResult("NG");
    } finally {
    }

    ObjectMapper mapper = new ObjectMapper();

    try {
      String jsonData = mapper.writeValueAsString(dto);
      out.write(jsonData);
    } catch (JsonProcessingException e) {
      e.printStackTrace();
    }

    out.flush();
    System.out.println("処理終了");
  }

  private void AddMessage(JianDto dto, String msg) {
    String oldmsg = dto.getMessage();
    if (oldmsg == null) {
      dto.setMessage(msg);
    } else {
      dto.setMessage(oldmsg + "," + msg);
    }
  }

  public int ReadDB2(int MINX, int MINY, int MAXX, int MAXY, String m_jisiki, JianDto dto) {

    int ret = -1;
    String SQL = "";

//    SQL += "select *  from V_TBSK0001 WHERE   ";
    SQL += "select *  from V_TBDAM001 WHERE   ";
    SQL += "  ( X_LOCATE BETWEEN " + MINX + " AND " + MAXX + " ) AND ( Y_LOCATE BETWEEN " + MINY
        + " AND " + MAXY + " ) ";
    SQL += " AND STATUS <> 3";

    Date date = new Date();
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.add(Calendar.DAY_OF_MONTH, -30);


    // フォーマットを指定する
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String update_date = sdf.format(calendar.getTime());

    SQL += " AND KOSINDT > TO_DATE('" + update_date + "', 'YYYY-MM-DD HH24:MI:SS')";
    System.out.println(SQL);

    List<JianBean> jsonList = new ArrayList<>();

    try (Connection conn = DriverManager.getConnection(URL2, USER2, PASS2);
        PreparedStatement ps = conn.prepareStatement(SQL)) {

      try (ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {

          ret = 0;

          JianBean bean = new JianBean();

          String jisiki = rs.getString("JISIKI");;
          int saisyu = rs.getInt("SAISYU");;
          String saisyunm = rs.getString("SAISYUNM");
          String kosindt = rs.getString("KOSINDT");
          String sireibunnm = rs.getString("SIREBUNNM");
          int x_locate = rs.getInt("X_LOCATE");;
          int y_locate = rs.getInt("Y_LOCATE");;

          AddMessage(dto, jisiki);

          // log("SUIRI_CD=" + jisiki);

          bean.setJisiki(jisiki);
          bean.setSaisyu(saisyu);
          bean.setSaisyunm(saisyunm);
          bean.setKosindt(kosindt);
          bean.setSireibunnm(sireibunnm);
          bean.setX_locate(x_locate);
          bean.setY_locate(y_locate);
          jsonList.add(bean);
        }
      }
      dto.setData(jsonList);
      AddMessage(dto, "検索処理が完了しました");
    } catch (SQLException e) {
      e.printStackTrace();
      AddMessage(dto, e.toString());
      System.out.println(e.toString());
      ret = 1;
    } catch (Exception e) {
      e.printStackTrace();
      AddMessage(dto, e.toString());
      System.out.println(e.toString());
      ret = 1;
    } finally {
      System.out.println("処理が完了しました");
    }
    return ret;
  }

  /**
   * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
   */
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
    // TODO Auto-generated method stub
    doGet(request, response);
  }

}

package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetAddr
 */
@WebServlet("/GetAddrName")
public class GetAddrName extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String URL = "";
	String USER = "";
	String PASS = "";


//	final String URL = "jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	final String URL = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

	//final String USER = "WEBGIS";
	//final String PASS = "WEBGIS";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetAddrName() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin","*"); //CROS対策
		response.setCharacterEncoding("utf-8");

		String strPrif = request.getParameter("prif");
		String strCity = request.getParameter("city");
		String strTown1 = request.getParameter("town1");
		String strTown2 = request.getParameter("town2");
//		String strNum = request.getParameter("num");
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		
		int prif=0;
		int city=0;
		int town1=0;
		int town2=0;
		//String num = "";
		
		prif = Integer.parseInt(strPrif);
		city = Integer.parseInt(strCity);
		town1 = Integer.parseInt(strTown1);
		town2 = Integer.parseInt(strTown2);
	//	num = strNum;
		
		String addr = "";
		addr += ReadDB(prif,0,0,0);
		if(city>0) {
			addr += ReadDB(prif,city,0,0);
		}
		if(town1>0) {
			addr += ReadDB(prif,city,town1,0);
		}
		if(town2>0) {
			addr += ReadDB(prif,city,town1,town2);
		}
		out.write(addr);
		out.flush();
	}
	
	public String  ReadDB(int prif,int city,int town1,int town2) {
		
		String ret="";
		
		String SQL="";

//		if(num=="") {
			//地番がない場合
			SQL = "select * from TBWG0023 WHERE prif=" + prif + " AND city="+city+" AND town1="+town1 +" AND town2 = "+town2;
	//	}else {
			//地番がある場合
		//	SQL = "select * from TBWG0003 WHERE prif=" + prif + " AND city="+city+" AND town1="+town1 +" AND town2 = "+town2;
		//}
		System.out.println(SQL);
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					//JsonAddrBean jsonBean = new JsonAddrBean();

					//int prifval = rs.getInt("prif");
					//int cityval = rs.getInt("city");
					//int town1val = rs.getInt("town1");
					//int town2val = rs.getInt("town2");
					//int zxval = rs.getInt("zx");
					//int zyval = rs.getInt("zy");
					//double lonval= rs.getDouble("lon");
					//double latval= rs.getDouble("lat");
					String nameval = rs.getString("name");
					//String kanaval = rs.getString("kana");
					
					ret = nameval;

//					jsonBean.setPrif(prifval);
//					jsonBean.setCity(cityval);
//					jsonBean.setTown1(town1val);
//					jsonBean.setTown2(town2val);
//					jsonBean.setZx(zxval);
//					jsonBean.setZy(zyval);
//					jsonBean.setLon(lonval);
//					jsonBean.setLat(latval);
//					jsonBean.setName(nameval);
//					jsonBean.setKana(kanaval);

//					jsonList.add(jsonBean);

				}
	//			dto.setData(jsonList);

			}
		} catch (SQLException e) {
		//	e.printStackTrace();
			ret ="";
	//		out.println(e.toString());
		} catch (Exception e) {
			//e.printStackTrace();
			ret ="";
	//		out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}


		return ret;
	}
	
/*	
	public String  ReadDB(int prif,int city,int town1,int town2,String num,PrintWriter out) {
		
		String ret="OK";
		
		
		final String URL = "jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
		final String USER = "WEBGIS";
		final String PASS = "WEBGIS";

		String SQL="";

		if(num=="") {
			//地番がない場合
			SQL = "select * from TBWG0003 WHERE prif=" + prif + " AND city="+city+" AND town1="+town1 +" AND town2 = "+town2;
		}else {
			//地番がある場合
			SQL = "select * from TBWG0003 WHERE prif=" + prif + " AND city="+city+" AND town1="+town1 +" AND town2 = "+town2;
		}
		System.out.println(SQL);
		
		AddrDto dto = new AddrDto();

		List<JsonAddrBean> jsonList = new ArrayList<>();

//		try {
	//		Class.forName("com.mysql.jdbc.Driver");
		//} catch (ClassNotFoundException e1) {
			// TODO 自動生成された catch ブロック
			//e1.printStackTrace();
		//}
		
		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {

					JsonAddrBean jsonBean = new JsonAddrBean();

					int prifval = rs.getInt("prif");
					int cityval = rs.getInt("city");
					int town1val = rs.getInt("town1");
					int town2val = rs.getInt("town2");
					int zxval = rs.getInt("zx");
					int zyval = rs.getInt("zy");
					double lonval= rs.getDouble("lon");
					double latval= rs.getDouble("lat");
					String nameval = rs.getString("name");
					String kanaval = rs.getString("kana");

					jsonBean.setPrif(prifval);
					jsonBean.setCity(cityval);
					jsonBean.setTown1(town1val);
					jsonBean.setTown2(town2val);
					jsonBean.setZx(zxval);
					jsonBean.setZy(zyval);
					jsonBean.setLon(lonval);
					jsonBean.setLat(latval);
					jsonBean.setName(nameval);
					jsonBean.setKana(kanaval);

					jsonList.add(jsonBean);

				}
				dto.setData(jsonList);

			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret ="NG";
			out.println(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret ="NG";
			out.println(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}

		ObjectMapper mapper = new ObjectMapper();
		dto.setResult(ret);

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
			ret ="NG";
		}
		
		return ret;
		
	}
*/

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class GetAddrPolygon
 */
@WebServlet("/GetAddrPolygon")
public class GetAddrPolygon extends HttpServlet {
	private static final long serialVersionUID = 1L;

	String URL = "";
	String USER = "";
	String PASS = "";
	
	//private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

//	private String conn_str = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
	//private String conn_user = "WEBGIS";
	//private String conn_pass = "WEBGIS";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GetAddrPolygon() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		AddrPolygonDto dto = new AddrPolygonDto();

		try {
			int prif = Integer.parseInt(request.getParameter("prif"));
			int city = Integer.parseInt(request.getParameter("city"));
			int town1 = Integer.parseInt(request.getParameter("town1"));
			int town2 = Integer.parseInt(request.getParameter("town2"));
			if(ReadDB(prif, city, town1, town2, out,dto)==0) {
				dto.setResult("OK");
			}else {
				dto.setResult("NG");
			}

		} catch (Exception e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			dto.setResult("NG");
		} finally {
//		out.println("処理が完了しました<br>");
		}
		
		ObjectMapper mapper = new ObjectMapper();

		try {
			String jsonData = mapper.writeValueAsString(dto);
			out.write(jsonData);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}

		//out.println("処理が完了しました<br>");
		out.flush();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public int ReadDB(int m_prif, int m_city, int m_town1, int m_town2, PrintWriter out,AddrPolygonDto dto) {

		int ret = -1;
		String SQL = "";

//		final String URL = conn_str;
//		final String USER = conn_user;
//		final String PASS = conn_pass;

		SQL = "select * from TBWG0007 WHERE ";
		SQL += "prif=" + m_prif;
		SQL += "AND city=" + m_city;
		SQL += "AND town1=" + m_town1;
		SQL += "AND town2=" + m_town2;

		System.out.println(SQL);


		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {
					
					ret =0;

					int prif = rs.getInt("prif");
					int city = rs.getInt("city");
					int town1 = rs.getInt("town1");
					int town2 = rs.getInt("town2");
					int zahyo_cnt = rs.getInt("zahyo_cnt");

					dto.setPrif(prif);
					dto.setCity(city);
					dto.setTown1(town1);
					dto.setTown2(town2);
					dto.setZahyo_cnt(zahyo_cnt);

					Array zahyo_array = rs.getArray("zahyo_array");

					Object[] obj = (Object[]) zahyo_array.getArray();

					List<ZPointBean> zlist = new ArrayList<>();

					for (int i = 0; i < obj.length; i++) {

						Struct zp = (Struct) obj[i];

						Object[] obj2 = zp.getAttributes();

						ZPointBean zpoint = new ZPointBean();
						zpoint.setX(Double.parseDouble(obj2[0].toString()));
						zpoint.setY(Double.parseDouble(obj2[1].toString()));

						zlist.add(zpoint);

					}
					dto.setData(zlist);
					
				}
			}

		} catch (SQLException e) {
			e.printStackTrace();
			dto.setMessage(e.toString());
			ret = -1;
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;

	}

}

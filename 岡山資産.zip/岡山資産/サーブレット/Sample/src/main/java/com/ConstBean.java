package com;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConstBean {

	// プロパティの先頭は小文字

	@JsonProperty("const_KEY")
	private String const_KEY;

	@JsonProperty("const_VALUE1")
	private String const_VALUE1;

	@JsonProperty("const_VALUE2")
	private String const_VALUE2;
	
	@JsonProperty("const_COMMENT")
	private String const_COMMENT;

	@JsonProperty("update_DATE")
	private String update_DATE;
	
	public String getCONST_KEY() {
		return const_KEY;
	}

	public void setCONST_KEY(String const_KEY) {
		this.const_KEY = const_KEY;
	}

	public String getCONST_VALUE1() {
		return const_VALUE1;
	}

	public void setCONST_VALUE1(String const_VALUE1) {
		this.const_VALUE1 = const_VALUE1;
	}

	public String getCONST_VALUE2() {
		return const_VALUE2;
	}

	public void setCONST_VALUE2(String const_VALUE2) {
		this.const_VALUE2 = const_VALUE2;
	}

	public String getConst_COMMENT() {
		return const_COMMENT;
	}

	public void setConst_COMMENT(String const_COMMENT) {
		this.const_COMMENT = const_COMMENT;
	}

	public String getUpdate_DATE() {
		return update_DATE;
	}

	public void setUpdate_DATE(String update_DATE) {
		this.update_DATE = update_DATE;
	}
}

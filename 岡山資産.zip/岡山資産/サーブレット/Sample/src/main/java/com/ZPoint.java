package com;

public class ZPoint {
	double x;
	double y;
}

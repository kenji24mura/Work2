package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class InsertAddrPolygon
 */
@WebServlet("/InsertAddrPolygon")
public class InsertAddrPolygon extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String URL = "";
	String USER = "";
	String PASS = "";
	
	//private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";

//	private String conn_str = "jdbc:oracle:thin:@localhost:1521/XEPDB1";
	//private String conn_user = "WEBGIS";
	//private String conn_pass = "WEBGIS";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InsertAddrPolygon() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");

		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}

		PrintWriter out = response.getWriter();
		//
		// 住所ポリゴン登録
		//

		try {
			int prif = Integer.parseInt(request.getParameter("prif"));
			int city = Integer.parseInt(request.getParameter("city"));
			int town1 = Integer.parseInt(request.getParameter("town1"));
			int town2 = Integer.parseInt(request.getParameter("town2"));
			int seqnum = Integer.parseInt(request.getParameter("seqnum"));
			int zahyo_cnt = Integer.parseInt(request.getParameter("zahyo_cnt"));
			String info_zahyo = request.getParameter("info_zahyo");

			String[] points = info_zahyo.split(",");

			ZPoint[] zp = new ZPoint[zahyo_cnt];
			// オブジェクト型の初期化が必要
			for (int i = 0; i < zahyo_cnt; i++) {
				zp[i] = new ZPoint();

				zp[i].x = Double.parseDouble(points[i * 2]);
				zp[i].y = Double.parseDouble(points[i * 2 + 1]);

			}

			int ret = 0;
			ret = InsertPolygon(prif,city,town1,town2,seqnum, zahyo_cnt, zp, out);
			if (ret == 0) {
				out.println("処理が正常しました<br>");
			}
		} catch (Exception e) {
			e.printStackTrace();
			out.println(e.toString());
		} finally {
//			out.println("処理が完了しました<br>");
		}

		out.println("処理が完了しました<br>");
		out.flush();
	}

	//
	// ポリゴン追加
	//
	public int InsertPolygon(int prif, int city, int town1, int town2, int seqnum, int zahyo_cnt, ZPoint[] zp,
			PrintWriter out) {

		int ret = 0;

		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;
		
        Calendar cl = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String update_date = sdf.format(cl.getTime());
        
		// String SQL="";
		String sql = "";

		sql += "insert into  TBWG0007(prif,city,town1,town2,seqnum,zahyo_cnt," + "ZAHYO_ARRAY,update_date) values (";

		try {

			sql += prif;
			sql += ",";
			sql += city;
			sql += ",";
			sql += town1;
			sql += ",";
			sql += town2;
			sql += ",";
			sql += seqnum;
			sql += ",";

			sql += zahyo_cnt;
			sql += ",";

			sql += "ARRAY_POINT(";

			for (int i = 0; i < zp.length; i++) {

				if (i > 0) {
					sql += ",";
				}
				sql += "POINT(";
				sql += zp[i].x;
				sql += ",";
				sql += zp[i].y;
				sql += ")";
			}

			sql += ")";
			
			sql += ",";
			sql += "TO_DATE('"+ update_date +"', 'YYYY-MM-DD HH24:MI:SS')";

			sql += ")";

			out.println(sql);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);
			Statement stmt = conn.createStatement();

			int num = stmt.executeUpdate(sql);
			
			out.println(num);

		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			// out.println("処理が完了しました<br>");
		}

		return ret;

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

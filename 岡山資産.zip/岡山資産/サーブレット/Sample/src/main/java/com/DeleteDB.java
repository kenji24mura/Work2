package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Array;
//import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Struct;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Servlet implementation class DeleteDB
 */
@WebServlet("/DeleteDB")
public class DeleteDB extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	String URL = "";
	String USER = "";
	String PASS = "";
	
//	private String conn_str="jdbc:oracle:thin:@172.18.73.12:1521/fire.osaka";
//	private String conn_str = "jdbc:oracle:thin:@172.23.124.202:1521/fire1.rac.osaka";
//private String conn_user = "WEBGIS";
//private String conn_pass = "WEBGIS";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DeleteDB() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		request.setCharacterEncoding("UTF-8");

		// response.setContentType("text/html; charset=UTF-8");
		response.setContentType("text/html");
		response.setHeader("Cache-Control", "nocache");
		response.setHeader("Access-Control-Allow-Origin", "*"); // CROS対策
		response.setCharacterEncoding("utf-8");
		
		//設定ファイル読み込み処理
		ObjectMapper  objectMapper = new ObjectMapper();
		try {
	        JsonNode json = objectMapper.readTree(Paths.get(getServletContext().getRealPath("/WEB-INF/webgis_config.json")).toFile());
	        System.out.println(json); 

	        URL = json.get("conn_url").textValue();
	        USER = json.get("conn_user").textValue();
	        PASS = json.get("conn_pass").textValue();
		}catch(Exception e){
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		SymbolInfoDto dto = new SymbolInfoDto();

		//
		//シンボル削除
		//
		
		try {
			String lay_no=request.getParameter("lay_no");
			String item_no=request.getParameter("item_no");
			int lay_type= Integer.parseInt(request.getParameter("lay_type"));			//1:シンボル　2:線　3:ポリゴン 
			
			int ret = 0;
			
			switch(lay_type) {
			case 1:

				ret = DeleteSymbol(lay_no,item_no,out);
				if(ret == 0) {
					out.println("処理が正常しました<br>");
				}
				
				break;
			case 2:
				ret = DeletePolygon(lay_no,item_no,out);
				if(ret == 0) {
					out.println("処理が正常しました<br>");
				}
				break;
				
			case 3:
				if(lay_no.equals("n@16-1")) {
					System.out.println("代表座標が同じシンボルを削除");
					
					ReadDB(lay_no,item_no,lay_type, out, dto);
					double zx = dto.getZahyo_x();
					double zy = dto.getZahyo_y();
					
					ret = DeleteSymbolByPosition(lay_no,zx,zy,out);
					
				}
				
				ret = DeletePolygon(lay_no,item_no,out);
				if(ret == 0) {
					out.println("処理が正常しました<br>");
				}
				break;
				
			default:
				ret =-1;
				break;
					
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			out.println(e.toString());
		} finally {
//			out.println("処理が完了しました<br>");
		}


		out.println("処理が完了しました<br>");
		out.flush();

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	public int DeleteSymbol(String lay_no,String item_no,PrintWriter out) {

		int ret = 0;

		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;

		String sql = "";
		
		sql += "delete from  TBWG0001 Where lay_no='"+lay_no+"' AND item_no='"+item_no+"'";

		try {

			out.println(sql);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);

			Statement stmt = conn.createStatement();

			stmt.executeUpdate(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			//out.println("処理が完了しました<br>");
		}
		return ret;

	}
	public int DeleteSymbolByPosition(String lay_no,double zx,double zy,PrintWriter out) {

		int ret = 0;

		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;

		String sql = "";
		
		sql += "delete from  TBWG0001 Where lay_no='"+lay_no+"' AND zahyo_x="+zx+" AND zahyo_y="+zy;

		try {

			out.println(sql);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);

			Statement stmt = conn.createStatement();

			stmt.executeUpdate(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			//out.println("処理が完了しました<br>");
		}
		return ret;

	}

	public int DeletePolygon(String lay_no,String item_no,PrintWriter out) {

		int ret = 0;

//		final String URL = conn_str;
	//	final String USER = conn_user;
		//final String PASS = conn_pass;

		String sql = "";
		
		sql += "delete from  TBWG0002 Where lay_no='"+lay_no+"' AND item_no='"+item_no+"'";

		try {

			out.println(sql);

			Connection conn = DriverManager.getConnection(URL, USER, PASS);

			Statement stmt = conn.createStatement();

			stmt.executeUpdate(sql);
			
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			out.println(e.toString());
		} finally {
			//out.println("処理が完了しました<br>");
		}
		return ret;

	}
	public int ReadDB(String lay_no, String item_no, int lay_type, PrintWriter out, SymbolInfoDto dto) {

		int ret = -1;
		String SQL = "";

		//final String URL = conn_str;
		//final String USER = conn_user;
		//final String PASS = conn_pass;

		if (lay_type == 1) {

			SQL = "select * from TBWG0001 WHERE lay_no='" + lay_no + "' AND item_no='" + item_no + "'";
		} else {

			SQL = "select * from TBWG0002 WHERE lay_no='" + lay_no + "' AND item_no='" + item_no + "'";
		}
		SQL += " order by lay_no,item_no";

		System.out.println(SQL);
		log(SQL);

		try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
				PreparedStatement ps = conn.prepareStatement(SQL)) {

			try (ResultSet rs = ps.executeQuery()) {

				while (rs.next()) {
					
					ret = 0;


					int info_type = rs.getInt("info_type");
					String info_summery = rs.getString("info_summery");
					int symbol_no = rs.getInt("symbol_no");
					double zahyo_x = rs.getDouble("zahyo_x");
					double zahyo_y = rs.getDouble("zahyo_y");
					String strinfo1 = rs.getString("strinfo1");
					String strinfo2 = rs.getString("strinfo2");
					String strinfo3 = rs.getString("strinfo3");
					double str_zahyo_x = rs.getDouble("str_zahyo_x");
					double str_zahyo_y = rs.getDouble("str_zahyo_y");

					dto.setLay_no(lay_no);
					dto.setItem_no(item_no);
					dto.setInfo_type(info_type);
					dto.setInfo_summery(info_summery);
					dto.setLay_type(lay_type);
					dto.setSymbol_no(symbol_no);
					dto.setZahyo_x(zahyo_x);
					dto.setZahyo_y(zahyo_y);
					dto.setStrinfo1(strinfo1);
					dto.setStrinfo2(strinfo2);
					dto.setStrinfo3(strinfo3);
					dto.setStr_zahyo_x(str_zahyo_x);
					dto.setStr_zahyo_y(str_zahyo_y);

					if (lay_type == 1) {
						// シンボル
					} else {
						// 線・ポリゴン

						int zahyo_cnt = rs.getInt("zahyo_cnt");

						dto.setZahyo_cnt(zahyo_cnt);

						Array zahyo_array = rs.getArray("zahyo_array");

						Object[] obj = (Object[]) zahyo_array.getArray();

						// dto.zp = new ZPoint[zahyo_cnt];

						List<ZPointBean> zlist = new ArrayList<>();

						for (int i = 0; i < obj.length; i++) {

							Struct zp = (Struct) obj[i];

							Object[] obj2 = zp.getAttributes();

							ZPointBean zpoint = new ZPointBean();
							zpoint.setX(Double.parseDouble(obj2[0].toString()));
							zpoint.setY(Double.parseDouble(obj2[1].toString()));

							zlist.add(zpoint);

						}
						dto.setData(zlist);
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} catch (Exception e) {
			e.printStackTrace();
			ret = -1;
			dto.setMessage(e.toString());
		} finally {
			System.out.println("処理が完了しました");
		}
		return ret;
	}
	
}

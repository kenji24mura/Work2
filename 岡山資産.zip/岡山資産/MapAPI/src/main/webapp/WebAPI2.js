﻿/**
 *
 */

//var GIS_SERVER_IP = "172.23.29.1";//現地環境
var GIS_SERVER_IP = "10.50.60.110";//岡山


var windowObject2 = null;

var facade2 = null;
var kijyunkei = 5;

var lonlat = new Array();
var retval = new Array(); //座標変換用


var c_layerId="";
var c_itemId = [];//同心円処理用
var c_flg = false;

//var tmplayId="";

var init_lon2 = 133.88139367902798; //初期経度
var init_lat2 = 34.6543893655995; //初期緯度

var init_zoom2 = 18;         //初期倍率


var MapObj2 = {
  init2(w_lon,w_lat,w_zoom){

    console.log("MapObj2.init2");

    PRAn2LonLatW(w_lon, w_lat, kijyunkei, retval);

    init_lon2 = retval[0];
    init_lat2 = retval[1];
    init_zoom2 = w_zoom;
    this.init();
  },
  init() {

    console.log("MapObj2.init");

    var consolelog = function (ret) {
      console.log(ret);
      document.getElementById("console").innerText = JSON.stringify(ret);
    };

    var protocol = window.location.protocol;
    var port = window.location.port;
    var path = window.location.pathname;
    var html = path.split("/").pop();
    path = path.replace("/" + html, "");

//    var url = "https://"+ GIS_SERVER_IP+":1443/proj";
    var url = "https://"+ GIS_SERVER_IP+":1443/proj2";


console.log(url);

    //console.log("append");

    $("body").append(
      '<form action="' +
        url +
//                '/StartGisJS" method="post" target="mapPrevframe2" id="postToIframe2"></form>'
        "/StartGisJS?jb_lon=" +
        init_lon2 +
        "&jb_lat=" +
        init_lat2 +
        "&jb_zl=" +
        init_zoom2 +
        '&jb_layouttype=easy" method="post" target="mapPrevframe2" id="postToIframe2"></form>'
    );
    $("#postToIframe2").append(
      '<input type="hidden" name="user_id" value="1" />'
    );
    $("#postToIframe2").append(
      '<input type="hidden" name="terminal_type" value="0" />'
    );
    $("#postToIframe2").submit().remove();

    windowObject2 = mapPrevframe2.window;

    var circleId = 0;

    var options = {
    }
    //Facadeをインスタンス化
    facade2 = new ifxApiFacadePostUtil(url, windowObject2, options);

  },
    //位置指定
  setPosition(position, animateFlag, callback) {
    PRAn2LonLatW(position.lon, position.lat, kijyunkei, retval);

    facade2.setPosition(
      {
        lat: retval[1],
        lon: retval[0],
      },
      animateFlag,
      function (ret) {
        callback(ret);
      }
    );
  },
    //ズームレベル指定
  setScale(zoomLevel, animateFlag, callback) {
    var zoom = parseInt(zoomLevel);

    facade2.setScale(zoom, animateFlag, function (ret) {
      callback(ret);
    });
  },
  //左クリックイベントリスナ
  addListener(eventType, eventId, callback) {

    facade2.addListener(eventType, eventId, function (ret) {
	
      console.log(ret);

      var e = ret.value;
      var data = e.data;


      if (eventType == "singleSnap") {

        console.log("[緯度]" + data.pos.lat + "," + "[経度]" + data.pos.lon);

        LonLatW2PRAn(data.pos.lon, data.pos.lat, kijyunkei, retval);

        ret.lon = retval[0];
        ret.lat = retval[1];

        console.log(data);
        
        ret.data = data;
      }
      if (eventType == "longPress") {
      }
      if (eventType == "rightClicked") {
      }
      if (eventType == "changeView") {
      }

      callback(ret);
    });
  },

};
//--------------------------------------------------------------------------------------------------------------
//平面直角座標系を経緯度に変換する
//--------------------------------------------------------------------------------------------------------------
function PRAn2LonLatW(lx, ly, kijyunkei, retval) {
  const ret = {};
  var v_lx = lx / 1000;
  var v_ly = ly / 1000;

  //経緯度に変換
  gpconv2(v_lx, v_ly, kijyunkei, lonlat);

  var lx2 = lonlat[0] * 1000;
  var ly2 = lonlat[1] * 1000;

  //測地系（日本⇒世界）
  ConvJ2W(lx2, ly2, lonlat);

  var lon = lonlat[0] / (3600 * 1000);
  var lat = lonlat[1] / (3600 * 1000);

  retval[0] = lon;
  retval[1] = lat;
}

//--------------------------------------------------------------------------------------------------------------
//経緯度を平面直角座標系に変換する
//--------------------------------------------------------------------------------------------------------------
function LonLatW2PRAn(lon, lat, kijyunkei, retval) {
  const ret = {};
  lx = lon * 3600 * 1000;
  ly = lat * 3600 * 1000;

  //座標を正規化座標に変換

  //測地系変換
  ConvW2J(lx, ly, lonlat);

  var lx2 = lonlat[0] / 1000;
  var ly2 = lonlat[1] / 1000;

  //経緯度を正規化座標に変換

  gpconv(lx2, ly2, kijyunkei, lonlat);

  lx2 = lonlat[0] * 1000;
  ly2 = lonlat[1] * 1000;

  retval[0] = lx2;
  retval[1] = ly2;
}

//--------------------------------------------------------------------------------------------------------------
//経緯度を平面直角座標系に変換する
//--------------------------------------------------------------------------------------------------------------
function gpconv(m_keido, m_ido, kijyunkei, ret) {
  var lx = 0.0;
  var ly = 0.0;

  var phi = 0.0;
  var lamda = 0.0;
  var x = 0.0;
  var y = 0.0;
  var phi0 = 0.0;
  var lamda0 = 0.0;

  var KJN_IDO = 0;
  var KJN_KDO = 0;
  /*
	  var KJN_IDO1 = 0;
	  var KJN_IDO2 = 0;
	  var KJN_IDO3 = 0;
	  var KJN_IDO4 = 0;
	  var KJN_KDO1 = 0;
	  var KJN_KDO2 = 0;
	  var KJN_KDO3 = 0;
	  var KJN_KDO4 = 0;
  
	  switch (kijyunkei) {
		  case 0:
		  case 1:
			  KJN_IDO1 = 33;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 129;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 2:
			  KJN_IDO1 = 33;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 131;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 3:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 132;
			  KJN_KDO2 = 10;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 4:
			  KJN_IDO1 = 33;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 133;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 5:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 134;
			  KJN_KDO2 = 20;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 6:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 136;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 7:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 137;
			  KJN_KDO2 = 10;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 8:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 138;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 9:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 139;
			  KJN_KDO2 = 50;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 10:
			  KJN_IDO1 = 40;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 140;
			  KJN_KDO2 = 50;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 11:
			  KJN_IDO1 = 44;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 140;
			  KJN_KDO2 = 15;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 12:
			  KJN_IDO1 = 44;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 142;
			  KJN_KDO2 = 15;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 13:
			  KJN_IDO1 = 44;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 144;
			  KJN_KDO2 = 15;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 14:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 142;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 15:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 127;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 16:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 124;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 17:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 131;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 18:
			  KJN_IDO1 = 20;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 136;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 19:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 154;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
	  }
	  KJN_IDO = 3600 * KJN_IDO1 + 60 * KJN_IDO2 + KJN_IDO3 + 0.01 * KJN_IDO4;
	  KJN_KDO = 3600 * KJN_KDO1 + 60 * KJN_KDO2 + KJN_KDO3 + 0.01 * KJN_KDO4;
  */
  var keido = [
    466200, 471600, 475800, 480600, 483600, 489600, 493800, 498600, 503400,
    507000, 504900, 512100, 519300, 511200, 459000, 446400, 471600, 489600,
    554400,
  ];

  var ido = [
    118800, 118800, 129600, 118800, 129600, 129600, 129600, 129600, 129600,
    144000, 158400, 158400, 158400, 93600, 93600, 93600, 93600, 72000, 93600,
  ];

  KJN_IDO = ido[kijyunkei - 1];
  KJN_KDO = keido[kijyunkei - 1];

  var Ba = 0.0;
  var Bb = 0.0;
  var Bc = 0.0;
  var Bd = 0.0;
  var Be = 0.0;

  var A = 0.0;
  var E = 0.0;
  var SR = 0.0;
  var PAI = 0.0;

  A = 6377397.155; //'長半径(meter)
  E = 0.006674372231315; //'離心率の二乗
  SR = 206264.806; //'秒・ラジアン換算係数
  PAI = 3.14159265;

  var b = 0.0;
  var s = 0.0;
  var c = 0.0;
  var c2 = 0.0;
  var c4 = 0.0;
  var t = 0.0;
  var t2 = 0.0;
  var t4 = 0.0;
  var h2 = 0.0;
  var h4 = 0.0;
  var N = 0.0;
  var lam2 = 0.0;
  var lamc2 = 0.0;
  var lamc4 = 0.0;

  var x1 = 0.0;
  var x2 = 0.0;
  var y1 = 0.0;
  var y2 = 0.0;

  phi = parseFloat(String(m_ido));
  lamda = parseFloat(String(m_keido));

  phi0 = parseFloat(String(KJN_IDO));
  lamda0 = parseFloat(String(KJN_KDO));

  //    '秒からラジアンへ
  lamda = lamda - lamda0;
  lamda = (PAI / 180) * (lamda / 3600);
  phi = (PAI / 180) * (phi / 3600);
  phi0 = (PAI / 180) * (phi0 / 3600);

  s = Math.sin(phi);
  c = Math.cos(phi);
  c2 = c * c;
  c4 = c2 * c2;
  t = Math.tan(phi);
  t2 = t * t;
  t4 = t2 * t2;
  h2 = (E * c2) / (1 - E);
  h4 = h2 * h2;
  N = A / Math.sqrt(1 - E * s * s);
  lam2 = lamda * lamda;
  lamc2 = lam2 * c2;
  lamc4 = lamc2 * lamc2;

  var ph1 = 0.0;
  var ph2 = 0.0;

  ph1 = phi0;
  ph2 = phi;

  Ba = 1.005037306049 * (ph2 - ph1);
  Bb = (0.0050478492403 * (Math.sin(2 * ph2) - Math.sin(2 * ph1))) / 2;
  Bc = (0.0000105637868 * (Math.sin(4 * ph2) - Math.sin(4 * ph1))) / 4;
  Bd = (0.00000002063332 * (Math.sin(6 * ph2) - Math.sin(6 * ph1))) / 6;
  Be = (0.000000000038853 * (Math.sin(8 * ph2) - Math.sin(8 * ph1))) / 8;

  b = A * (1 - E) * (Ba - Bb + Bc - Bd + Be);

  x1 = (lamc2 * (5 - t2 + 9 * h2 + 4 * h4)) / 24;
  x2 = (lamc4 * (61 - 58 * t2 + t4 + 270 * h2 - 330 * h2 * t2)) / 720;
  y1 = (lamc2 * (1 - t2 + h2)) / 6;
  y2 = (lamc4 * (5 - 18 * t2 + t4 + 14 * h2 - 58 * h2 * t2)) / 120;
  x = 0.9999 * (b + N * s * c * lam2 * (0.5 + x1 + x2));
  y = 0.9999 * N * c * lamda * (1 + y1 + y2);

  // y,x 逆
  lx = y;
  ly = x;

  ret[0] = lx;
  ret[1] = ly;
}
//--------------------------------------------------------------------------------------------------------------
//平面直角座標系を経緯度に変換する
//--------------------------------------------------------------------------------------------------------------
function gpconv2(lx, ly, kijyunkei, ret) {
  var phi = 0.0;
  var lamda = 0.0;
  var phi0 = 0.0;
  var lamda0 = 0.0;
  var x = 0.0;
  var y = 0.0;

  var KJN_KDO = 0;
  var KJN_IDO = 0;
  /*
	  var KJN_IDO2 = 0;
	  var KJN_IDO3 = 0;
	  var KJN_IDO4 = 0;
	  var KJN_KDO1 = 0;
	  var KJN_KDO2 = 0;
	  var KJN_KDO3 = 0;
	  var KJN_KDO4 = 0;
  	
  	
	  switch (kijyunkei) {
		  case 0:
		  case 1:
			  KJN_IDO1 = 33;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 129;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 2:
			  KJN_IDO1 = 33;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 131;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 3:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 132;
			  KJN_KDO2 = 10;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 4:
			  KJN_IDO1 = 33;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 133;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 5:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 134;
			  KJN_KDO2 = 20;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 6:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 136;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 7:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 137;
			  KJN_KDO2 = 10;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 8:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 138;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 9:
			  KJN_IDO1 = 36;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 139;
			  KJN_KDO2 = 50;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 10:
			  KJN_IDO1 = 40;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 140;
			  KJN_KDO2 = 50;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 11:
			  KJN_IDO1 = 44;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 140;
			  KJN_KDO2 = 15;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 12:
			  KJN_IDO1 = 44;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 142;
			  KJN_KDO2 = 15;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 13:
			  KJN_IDO1 = 44;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 144;
			  KJN_KDO2 = 15;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 14:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 142;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 15:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 127;
			  KJN_KDO2 = 30;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 16:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 124;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 17:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 131;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 18:
			  KJN_IDO1 = 20;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 136;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
		  case 19:
			  KJN_IDO1 = 26;
			  KJN_IDO2 = 00;
			  KJN_IDO3 = 00;
			  KJN_IDO4 = 00;
			  KJN_KDO1 = 154;
			  KJN_KDO2 = 00;
			  KJN_KDO3 = 00;
			  KJN_KDO4 = 00;
			  break;
	  }
  //	KJN_IDO = 3600 * KJN_IDO1 + 60 * KJN_IDO2 + KJN_IDO3 + 0.01 * KJN_IDO4;
  //	KJN_KDO = 3600 * KJN_KDO1 + 60 * KJN_KDO2 + KJN_KDO3 + 0.01 * KJN_KDO4;
  */

  var keido = [
    466200, 471600, 475800, 480600, 483600, 489600, 493800, 498600, 503400,
    507000, 504900, 512100, 519300, 511200, 459000, 446400, 471600, 489600,
    554400,
  ];

  var ido = [
    118800, 118800, 129600, 118800, 129600, 129600, 129600, 129600, 129600,
    144000, 158400, 158400, 158400, 93600, 93600, 93600, 93600, 72000, 93600,
  ];

  KJN_IDO = ido[kijyunkei - 1];
  KJN_KDO = keido[kijyunkei - 1];

  //絶対座標取得
  x = parseFloat(String(ly));
  y = parseFloat(String(lx));

  //座標計算
  //            phi0 = KJN_IDO;
  //            lamda0 = KJN_KDO;
  phi0 = parseFloat(String(KJN_IDO));
  lamda0 = parseFloat(String(KJN_KDO));

  //平面直角座標系->極座標系

  var mot = 0.0;
  var m = 0.0;
  var s = 0.0;
  var ab = 0.0;
  var ph0 = 0.0;
  var ph1 = 0.0;
  var si = 0.0;
  var co = 0.0;

  var ri = 0.0;
  var ni = 0.0;
  var cr = 0.0;
  var eta2 = 0.0;
  var t = 0.0;
  var t2 = 0.0;
  var t4 = 0.0;
  var y1 = 0.0;
  var y2 = 0.0;
  var y4 = 0.0;
  var f1 = 0.0;
  var f2 = 0.0;
  var A = 0.0;
  var E = 0.0;
  var SR = 0.0;
  var PAI = 0.0;

  var wph1 = 0.0;
  var wph2;

  var Ba = 0.0;
  var Bb = 0.0;
  var Bc = 0.0;
  var Bd = 0.0;
  var Be = 0.0;

  A = 6377397.155; //長半径(meter)
  E = 0.006674372231315; //離心率の二乗
  SR = 206264.806; //秒・ラジアン換算係数
  PAI = 3.14159265358979;

  si = 0;

  //秒からラジアンへ
  lamda0 = (PAI / 180) * (lamda0 / 3600);
  phi0 = (PAI / 180) * (phi0 / 3600);

  ab = 1;
  ph0 = PAI * 0.2;

  wph1 = 0;
  ///		wph2 = ph0;     20030731
  wph2 = phi0;

  Ba = 1.005037306049 * (wph2 - wph1);
  Bb = (0.0050478492403 * (Math.sin(2 * wph2) - Math.sin(2 * wph1))) / 2;
  Bc = (0.0000105637868 * (Math.sin(4 * wph2) - Math.sin(4 * wph1))) / 4;
  Bd = (0.00000002063332 * (Math.sin(6 * wph2) - Math.sin(6 * wph1))) / 6;
  Be = (0.000000000038853 * (Math.sin(8 * wph2) - Math.sin(8 * wph1))) / 8;

  m = x / 0.9999 + A * (1 - E) * (Ba - Bb + Bc - Bd + Be);
  y = y / 0.9999;
  mot = 1 / (A * (1 - E));

  while (ab > 0.00000000000001) {
    wph1 = 0;
    wph2 = ph0;
    Ba = 1.005037306049 * (wph2 - wph1);
    Bb = (0.0050478492403 * (Math.sin(2 * wph2) - Math.sin(2 * wph1))) / 2;
    Bc = (0.0000105637868 * (Math.sin(4 * wph2) - Math.sin(4 * wph1))) / 4;
    Bd = (0.00000002063332 * (Math.sin(6 * wph2) - Math.sin(6 * wph1))) / 6;
    Be = (0.000000000038853 * (Math.sin(8 * wph2) - Math.sin(8 * wph1))) / 8;
    s = A * (1 - E) * (Ba - Bb + Bc - Bd + Be);
    si = Math.sin(ph0);
    ph1 = ph0 + (m - s) * Math.pow(1 - E * si * si, 1.5) * mot;
    ab = ph1 - ph0;
    ph0 = ph1;
    if (ab < 0) {
      ab = -1 * ab;
    }
  }

  co = Math.cos(ph0);
  cr = Math.sqrt(1 - E * si * si);
  ni = cr / A;
  ri = cr * cr * cr * mot;
  eta2 = (co * co * E) / (1 - E);
  t = Math.tan(ph0);
  t2 = t * t;
  t4 = t2 * t2;
  y1 = y * ni;
  y2 = y1 * y1;
  y4 = y2 * y2;
  f1 = -8.33333333333333e-2 * y2 * (5 + 3 * t2 + eta2 - 9 * t2 * eta2);
  f2 = 2.77777777777778e-3 * y4 * (61 + 90 * t2 + 45 * t4);
  phi = ph0 - 0.5 * y * y1 * ri * t * (1 + f1 + f2);
  phi = ((phi * 180) / PAI) * 3600;
  f1 = -0.166666666666667 * y2 * (1 + 2 * t2 + eta2);
  f2 = 8.33333333333333e-3 * y4 * (5 + 28 * t2 + 24 * t4);
  lamda = lamda0 + (y1 / co) * (1 + f1 + f2);
  lamda = ((lamda * 180) / PAI) * 3600;

  //            m_keido = lamda;
  //            m_ido = phi;

  ret[0] = lamda;
  ret[1] = phi;

  return 0;
}
//--------------------------------------------------------------------------------------------------------------
//世界測地系→日本測地系
//--------------------------------------------------------------------------------------------------------------
function ConvW2J(Mx, My, ret) {
  var BTokyo = 0.0;
  var LTokyo = 0.0;
  var BWGS84 = 0.0;
  var LWGS84 = 0.0;

  LWGS84 = Mx / (3600 * 1000);
  BWGS84 = My / (3600 * 1000);

  BTokyo = BWGS84 + 0.00010696 * BWGS84 - 0.000017467 * LWGS84 - 0.004602;
  LTokyo = LWGS84 + 0.000046047 * BWGS84 + 0.000083049 * LWGS84 - 0.010041;

  ret[0] = LTokyo * 3600 * 1000;
  ret[1] = BTokyo * 3600 * 1000;
}
//--------------------------------------------------------------------------------------------------------------
//日本測地系→世界測地系
//--------------------------------------------------------------------------------------------------------------
function ConvJ2W(Mx, My, ret) {
  var BTokyo = 0.0;
  var LTokyo = 0.0;
  var BWGS84 = 0.0;
  var LWGS84 = 0.0;

  //console.log("Mx=" + Mx);
  //console.log("My=" + My);

  LTokyo = Mx / (3600 * 1000);
  BTokyo = My / (3600 * 1000);

  LWGS84 = LTokyo - 0.000046038 * BTokyo - 0.000083043 * LTokyo + 0.01004;
  BWGS84 = BTokyo - 0.00010695 * BTokyo + 0.000017464 * LTokyo + 0.0046017;

  ret[0] = LWGS84 * 3600 * 1000;
  ret[1] = BWGS84 * 3600 * 1000;
}


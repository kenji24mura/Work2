﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.WebRequestMethods;

namespace CSVTOMDB
{
    public partial class Form1 : Form
    {

        string CSV_PATH = @"C:\D_DRV\page.csv";
        string MDB_PATH = @"C:\D_DRV\FIIM_PAGE.mdb";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ImportProc(CSV_PATH, MDB_PATH,true);
        }
        private void ImportProc(string src, string dest,bool IsDelete)
        {
            // 接続文字列
            string connectionString = $@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={dest};";

            try
            {
                // 接続を開く
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    if (IsDelete == true)
                    {
                        string insertQuery = "DELETE FROM ページ検索テーブル";

                        using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
                        {
                            int rowsAffected = command.ExecuteNonQuery();
                            //Console.WriteLine($"{rowsAffected} 行が挿入されました。");
                        }
                    }

                    try
                    {
                        using (StreamReader reader = new StreamReader(src))
                        {
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {
                                string[] param = line.Split(',');

                                string insertQuery = "INSERT INTO ページ検索テーブル (";
                                insertQuery += "冊,ページ,枝,左右,図面名,スケール,表示地図種別,";
                                insertQuery += "左下座標Ｘ,";
                                insertQuery += "左下座標Ｙ,";
                                insertQuery += "左上座標Ｘ,";
                                insertQuery += "左上座標Ｙ,";
                                insertQuery += "右上座標Ｘ,";
                                insertQuery += "右上座標Ｙ,";
                                insertQuery += "右下座標Ｘ,";
                                insertQuery += "右下座標Ｙ,";
                                insertQuery += "左下正規化座標Ｘ,";
                                insertQuery += "左下正規化座標Ｙ,";
                                insertQuery += "左上正規化座標Ｘ,";
                                insertQuery += "左上正規化座標Ｙ,";
                                insertQuery += "右上正規化座標Ｘ,";
                                insertQuery += "右上正規化座標Ｙ,";
                                insertQuery += "右下正規化座標Ｘ,";
                                insertQuery += "右下正規化座標Ｙ";
                                insertQuery += ") VALUES (";
                                insertQuery += Int32.Parse(param[0]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[1]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[2]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[3]);
                                insertQuery += ",";
                                insertQuery += param[4];
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[5]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[6]);
                                insertQuery += ",";

                                insertQuery += Int32.Parse(param[7]);//
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[8]);//
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[9]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[10]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[11]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[12]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[13]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[14]);
                                insertQuery += ",";

                                insertQuery += Int32.Parse(param[15]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[16]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[17]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[18]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[19]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[20]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[21]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[22]);
                                insertQuery += ")";
                                // コマンドを実行
                                using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
                                {
                                    int rowsAffected = command.ExecuteNonQuery();
                                    //Console.WriteLine($"{rowsAffected} 行が挿入されました。");
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.ToString());    
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("エラー: " + ex.Message);
            }
        }
    }
}

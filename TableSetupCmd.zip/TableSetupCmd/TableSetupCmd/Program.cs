﻿//
//春日井用セットアップ
//

using com;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace TableSetupCmd
{
    class Program
    {
        static string CONN_STRING = "User ID=WEBGIS; Password=WEBGIS; Data Source=10.10.20.51:1521/floex";
        static string CONN_STRING2 = "User ID=fire; Password=fire; Data Source=10.10.20.51:1521/floex";
//        static string CONN_STRING3 = "User ID=KEIBO; Password=KEIBO; Data Source=172.23.124.202:1522/fire2.rac.osaka";

  //      static string CONN_STRING2_T = "User ID=DAMS; Password=DAMS2022; Data Source=172.23.120.119:1521/fire1T.osaka";
    //    static string CONN_STRING3_T = "User ID=KEIBO; Password=KEIBO; Data Source=172.23.120.119:1522/fire2T.osaka";

        public static String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];

        static Log lg = new Log();

        static int kijyunkei = 6;

        static void Main(string[] args)
        {
            lg.LOGFNAME = DATA_PATH + "\\log\\TableSetupCmd.log";
            lg.loglimit = 1000000;
            lg.logmax = 10;

            string LogDir = DATA_PATH + "\\log";

            if (Directory.Exists(LogDir) == false)
            {
                Directory.CreateDirectory(LogDir);
            }


            //災害点
            if (args[0] == "V_TBDAM001")
            {
                int range = 0;
                if (args.Length >= 2)
                {
                    range = Int32.Parse(args[1]);
                }
                ReadDB_V_TBDAM001(range);
            }
            //車両
            if (args[0] == "TBMP0200")
            {
                ReadDB_TBMP0200();
            }
            if (args[0] == "TBSSB024")
            {
                ReadDB_TBSSB024();
            }
            //水利
            if (args[0] == "TBDSC340")
            {
                ReadDB_TBDSC340();
            }

            //目標物
            if (args[0] == "TBDSC110")
            {
                ReadDB_TBDSC110();
            }
            //対象物
            if (args[0] == "TBDSC120")
            {
                ReadDB_TBDSC120();
            }
            //危険物
            if (args[0] == "TBDSC130")
            {
                ReadDB_TBDSC130();
            }
            //個人情報
            if (args[0] == "TBDSC150")
            {
                ReadDB_TBDSC150();
            }


            //目標物
            if (args[0] == "TBDMT119")
            {
                DelData("n@6-1");
                ReadDB_TBDMT119();
                ReadDB_TBDMT129();
                ReadDB_TBDMT139();
                ReadDB_TBDMT159();
            }

            MsgOut("END");
        }

        //--------------------------------------------------------------------------
        //　　災害点
        //--------------------------------------------------------------------------


        static int GetRange()
        {
            int ret = 0;
            string sqlStr = "select * from TBSK1101 WHERE SETTING_ID=19 AND SETTING_SUB_ID=1";

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String Range = reader["SETTING_VALUE"].ToString();

                                ret = Int32.Parse(Range);

                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
            return ret;
        }


        static private void ReadDB_V_TBDAM001(int range)
        {

            DelData3("n@1-1", 1);

            //string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;


            //            int range = Int32.Parse(textBox1.Text);

         //   if (range == 0)
          //  {
        //        range = GetRange();
        //    }


            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(range, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from FIRE.V_TBDAM001 WHERE UKETUKE_DATE > TO_DATE('" + result + "', 'YYYY-MM-DD HH24:MI:SS') ";
            sqlStr += " AND STATUS <> 3";//条件追加　20230903

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String JISIKI = reader["JISIKI"].ToString();
                                String SAISYU = reader["SAISYU"].ToString();
                                String SAISYUNM = reader["SAISYUNM"].ToString();
                                String KOSINDT = reader["KOSINDT"].ToString();
                                String SIREBUNNM = reader["SIREBUNNM"].ToString();
                                String X_LOCATE = reader["X_LOCATE"].ToString();
                                String Y_LOCATE = reader["Y_LOCATE"].ToString();
                                String STATUS = reader["STATUS"].ToString();
                                String UPD_DATE = reader["UPD_DATE"].ToString();


                                Console.WriteLine(STATUS);
                                //訓練区分処理追加　20230903
                                //String KUNRENKB = reader["KUNRENKB"].ToString();

                                MsgOut(JISIKI + "," + UPD_DATE);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;

                                //訓練区分処理追加　20230903
                                //int kunrenkb = Int32.Parse(KUNRENKB);

                                try
                                {
                                    lx = Double.Parse(X_LOCATE);
                                    ly = Double.Parse(Y_LOCATE);
                                }
                                catch (Exception ex)
                                {
                                    Console.WriteLine(ex);
                                }

                                //                                lx = -45237600;
                                //                                ly = -150372500;

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@1-1";
                                item_no = cnt.ToString();
                                info_type = 1;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("事案識別子");
                                value.Add(JISIKI);
                                key.Add("発生日時");
                                value.Add(KOSINDT);
                                key.Add("対応状況");
                                value.Add("");
                                key.Add("災害種別コード");
                                value.Add(SAISYUNM);
                                key.Add("災害分類コード");
                                value.Add(SIREBUNNM);

                                editinfo(key, value, ref info);


                                info_summery = info;
                                /*
                                info_summery += "{";
                                info_summery += "\"事案識別子\":";
                                info_summery += "\"";
                                info_summery += JISIKI;
                                info_summery += "\"";
                                info_summery += ",\"発生日時\":";
                                info_summery += "\"";
                                info_summery += KOSINDT;
                                info_summery += "\"";
                                info_summery += ",\"対応状況\":";
                                info_summery += "\"";
                                info_summery += "\"";
                                info_summery += ",\"災害種別コード\":";
                                info_summery += "\"";
                                info_summery += SAISYUNM;
                                info_summery += "\"";
                                info_summery += ",\"災害分類コード\":";
                                info_summery += "\"";
                                info_summery += SIREBUNNM;
                                info_summery += "\"";
                                info_summery += ",\"備考\":";
                                info_summery += "\"";
                                info_summery += "";
                                info_summery += "\"";
                                info_summery += "}";
                                */

                                lay_type = 1;
                                symbol_no = 111;


                                int saisyu_no = 0;
                                try
                                {
                                    saisyu_no = Int32.Parse(SAISYU);
                                }catch(Exception ex)
                                {

                                }

                                /*
                                if (SAISYUNM != "")
                                {

                                    if (SAISYUNM.IndexOf("火　災") == 0)
                                    {
                                        symbol_no = 101;
                                    }
                                    if (SAISYUNM.IndexOf("救　急") == 0)
                                    {
                                        symbol_no = 102;
                                    }
                                    if (SAISYUNM.IndexOf("救　助") == 0)
                                    {
                                        symbol_no = 103;
                                    }
                                    if (SAISYUNM.IndexOf("その他") == 0)
                                    {
                                        symbol_no = 104;
                                    }
                                }
                                */

                                if (saisyu_no > 0)
                                {
                                    switch (saisyu_no)
                                    {
                                        case 1://火災
                                            symbol_no = 101;
                                            break;
                                        case 2://救急
                                            symbol_no = 103;
                                            break;
                                        case 3://救助
                                            symbol_no = 105;
                                            break;
                                        case 4://その他
                                            symbol_no = 107;
                                            break;
                                        case 5://災害
                                            symbol_no = 109;
                                            break;
                                    }
                                }


                                    zahyo_x = (double)m_keido_w / (3600 * 1000);
                                    zahyo_y = (double)m_ido_w / (3600 * 1000);
                                    strinfo1 = "";
                                    strinfo2 = "";
                                    strinfo3 = "";
                                    str_zahyo_x = 0.0;
                                    str_zahyo_y = 0.0;

                                    item_no = info_type.ToString("D2");
                                    item_no += symbol_no.ToString("D4");
                                    item_no += cnt.ToString("D6");

                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }

        static void editinfo(List<string> key, List<string> value, ref string info)
        {
            info += "{\"備考\":";
            info += "{";
            for (int i = 0; i < key.Count; i++)
            {
                if (i > 0)
                {
                    info += ",";
                }
                info += "\"";
                info += key[i];
                info += "\"";
                info += ":";
                info += "\"";
                info += value[i];
                info += "\"";

            }
            info += "}";
            info += "}";
        }

        //--------------------------------------------------------------------------
        //　　車両
        //--------------------------------------------------------------------------
        static private void ReadDB_TBSSB024()
        {
            DelData3("n@7-1", 7);
            List<CarTypeTbl> list = new List<CarTypeTbl>();

            LoadCarTypeCSV(ref list);

            List<StrPtnTbl> list2 = new List<StrPtnTbl>();

            LoadStrPtnCSV(ref list2);


            string[] RANGE_TBL = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };



            //var findVal = list.Find(x => x.kind == kind);
            //sym_ptncode = findVal.sym_ptncode;
            //sym_size = findVal.sym_size;


            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            //DateTime dt = DateTime.Now;
            //TimeSpan sp1 = new TimeSpan(30, 0, 0, 0);

            //string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            //            string sqlStr = "select * from TBMP0200 WHERE UPD_DATE > TO_DATE('" + result + "', 'YYYY-MM-DD HH24:MI:SS') ";

            string sqlStr = "select FIRE.TBSSB024.*,FIRE.TBDSC210A.CAR_NM,FIRE.TBDSC210A.SYMBOL_CD from FIRE.TBSSB024 ";
            sqlStr += " INNER JOIN FIRE.TBDSC210A ON TO_NUMBER(FIRE.TBSSB024.CAR_CD) = FIRE.TBDSC210A.CAR_CD";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String CAR_CD = reader["CAR_CD"].ToString();
                                String CAR_TYPE_CD = reader["CAR_TYPE_CD"].ToString();
                                String DIRECTION = reader["DIRECTION"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();
                                String MOVE_CD = reader["MOVE_CD"].ToString();
                                String CAR_NM = reader["CAR_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();

                                //String KANRISHARYO_CD = reader["KANRISHARYO_CD"].ToString();
                                //String SHARYO_CD = reader["SHARYO_CD"].ToString();
                                //String HOUKO = reader["HOUKO"].ToString();
                                //String DOTAI_KIHON_CD = reader["DOTAI_KIHON_CD"].ToString();
                                //String DOTAI_SYOSAI_CD = reader["DOTAI_SYOSAI_CD"].ToString();
                                //String ITI_ZAHYO_X = reader["ITI_ZAHYO_X"].ToString();
                                //String ITI_ZAHYO_Y = reader["ITI_ZAHYO_Y"].ToString();
                                //String CAR_NM = reader["CAR_NM"].ToString();
                                //String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                //String CARSYU_CD = reader["CARSYU_CD"].ToString();
                                //String HISYO_CD = reader["HISYO_CD"].ToString();

                                MsgOut(CAR_CD);


                                if (CAR_CD.IndexOf("1067") == 0)
                                {
                                    MsgOut(CAR_CD);
                                }

                                //動態コード
                                int status = 0;

                                //status = Int32.Parse(DOTAI_KIHON_CD) * 100 + Int32.Parse(DOTAI_SYOSAI_CD);
                                status = Int32.Parse(MOVE_CD);


                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;

                                //if (ZAHYO_X.Length < 10 || ZAHYO_Y.Length < 10)
                                //{
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);

                                    //lx = -45237600;
                                    //ly = -150372500;

                                    //int kijyunkei = 6;
                                    double m_keido = 0.0;
                                    double m_ido = 0.0;
                                    long m_keido_w = 0;
                                    long m_ido_w = 0;

                                    //正規化座標(m)→経緯度（日本）(秒）
                                    cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                    //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                    cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);
                                    zahyo_x = (double)m_keido_w / (3600 * 1000);
                                    zahyo_y = (double)m_ido_w / (3600 * 1000);
                                //}
                                //else
                                //{
                                  //  zahyo_x = 0.0;
                                  //  zahyo_y = 0.0;
                                //}


                                cnt++;

                                lay_no = "n@7-1";
                                item_no = cnt.ToString();
                                info_type = 7;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("車両コード");
                                value.Add(CAR_CD);
                                key.Add("車両動態");
                                value.Add(status.ToString());
                                key.Add("方向");
                                value.Add(DIRECTION);
                                key.Add("車両名称");
                                value.Add(CAR_NM);
                                key.Add("車種");
                                value.Add(CAR_TYPE_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;


                                /*
                                                                info_summery += "{\"備考\":";
                                                                info_summery += "{";

                                                                info_summery += "\"車両コード\":";
                                                                info_summery += "\"";
                                                                info_summery += KANRISHARYO_CD;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"車両動態\":";
                                                                info_summery += "\"";
                                                                info_summery += status;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"方向\":";
                                                                info_summery += "\"";
                                                                info_summery += HOUKO;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"車両名称\":";
                                                                info_summery += "\"";
                                                                info_summery += CAR_NM;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"車種\":";
                                                                info_summery += "\"";
                                                                info_summery += CARSYU_CD;
                                                                info_summery += "\"";

                                                                info_summery += "}";
                                                                info_summery += "}";

                                  */
                                lay_type = 1;


                                try
                                {
                                    int sym_id = Int32.Parse(SYMBOL_CD);

                                    //var findVal = list.Find(x => x.OldCode == sym_id);
                                    //int sym_ptncode = findVal.NewCode;


                                    int HOUI_VAL = 0;

                                    for (int j = 0; j < RANGE_TBL.Length; j++)
                                    {
                                        if (DIRECTION.IndexOf(RANGE_TBL[j]) == 0)
                                        {
                                            HOUI_VAL = j;
                                        }
                                    }


                                    symbol_no = sym_id * 100 + HOUI_VAL;
                                    //symbol_no = sym_id;
                                    //                                strinfo1 = KANRISHARYO_CD;
                                    strinfo1 = CAR_NM;
                                    strinfo2 = "";
                                    strinfo3 = "";
                                    str_zahyo_x = 0.0;
                                    str_zahyo_y = 0.0;

                                    item_no = info_type.ToString("D2");
                                    item_no += symbol_no.ToString("D5");
                                    item_no += cnt.ToString("D4");

                                    var findVal = list2.Find(x => x.status == status);
                                    int str_ptn = findVal.ptn;

                                    //
                                    //帰署は対象外
                                    if (status != 70 && status != 80)
                                    {
                                        AddData2(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, str_ptn);
                                    }

                                    //
                                    //DAMS DBを更新する
                                    //
                                    DateTime dt = DateTime.Now;


                                    //try
                                    //{
                                    //UpdateDAMSTable(Int32.Parse(KANRISHARYO_CD), Int32.Parse(DOTAI_KIHON_CD), Int32.Parse(DOTAI_SYOSAI_CD), Int32.Parse(ITI_ZAHYO_X), Int32.Parse(ITI_ZAHYO_Y), dt);
                                    //}
                                    //catch (Exception ex)
                                    //{

                                    //}

                                    //AddTBDAM400(Int32.Parse(KANRISHARYO_CD), CAR_NM, Int32.Parse(ITI_ZAHYO_X), Int32.Parse(ITI_ZAHYO_Y), status, Int32.Parse(HISYO_CD));
                                    ModTBDAM400(Int32.Parse(CAR_CD), Int32.Parse(ZAHYO_X), Int32.Parse(ZAHYO_Y), status);
                                }
                                catch (Exception ex)
                                {

                                }
                            }
                        }
                    }
                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }



        }

        static private void ReadDB_TBMP0200()
        {
            DelData3("n@7-1", 7);
            //DelTBDAM400();


            List<CarTypeTbl> list = new List<CarTypeTbl>();

            LoadCarTypeCSV(ref list);

            List<StrPtnTbl> list2 = new List<StrPtnTbl>();

            LoadStrPtnCSV(ref list2);



            //var findVal = list.Find(x => x.kind == kind);
            //sym_ptncode = findVal.sym_ptncode;
            //sym_size = findVal.sym_size;


            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            //DateTime dt = DateTime.Now;
            //TimeSpan sp1 = new TimeSpan(30, 0, 0, 0);

            //string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            //            string sqlStr = "select * from TBMP0200 WHERE UPD_DATE > TO_DATE('" + result + "', 'YYYY-MM-DD HH24:MI:SS') ";
            string sqlStr = "select * from FIRE.V_TBMP0200";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {

                                String KANRISHARYO_CD = reader["KANRISHARYO_CD"].ToString();
                                String SHARYO_CD = reader["SHARYO_CD"].ToString();
                                String HOUKO = reader["HOUKO"].ToString();
                                String DOTAI_KIHON_CD = reader["DOTAI_KIHON_CD"].ToString();
                                String DOTAI_SYOSAI_CD = reader["DOTAI_SYOSAI_CD"].ToString();
                                String ITI_ZAHYO_X = reader["ITI_ZAHYO_X"].ToString();
                                String ITI_ZAHYO_Y = reader["ITI_ZAHYO_Y"].ToString();
                                String CAR_NM = reader["CAR_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String CARSYU_CD = reader["CARSYU_CD"].ToString();
                                String HISYO_CD = reader["HISYO_CD"].ToString();

                                MsgOut(KANRISHARYO_CD);

                                //動態コード
                                int status = 0;

                                //status = Int32.Parse(DOTAI_KIHON_CD) * 100 + Int32.Parse(DOTAI_SYOSAI_CD);
                                status = Int32.Parse(DOTAI_KIHON_CD);


                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;

                                if (ITI_ZAHYO_X.Length < 10 || ITI_ZAHYO_Y.Length < 10)
                                {
                                    lx = Double.Parse(ITI_ZAHYO_X);
                                    ly = Double.Parse(ITI_ZAHYO_Y);

                                    //lx = -45237600;
                                    //ly = -150372500;

                                    //int kijyunkei = 6;
                                    double m_keido = 0.0;
                                    double m_ido = 0.0;
                                    long m_keido_w = 0;
                                    long m_ido_w = 0;

                                    //正規化座標(m)→経緯度（日本）(秒）
                                    cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                    //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                    cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);
                                    zahyo_x = (double)m_keido_w / (3600 * 1000);
                                    zahyo_y = (double)m_ido_w / (3600 * 1000);
                                }
                                else
                                {
                                    zahyo_x = 0.0;
                                    zahyo_y = 0.0;
                                }


                                cnt++;

                                lay_no = "n@7-1";
                                item_no = cnt.ToString();
                                info_type = 7;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("車両コード");
                                value.Add(KANRISHARYO_CD);
                                key.Add("車両動態");
                                value.Add(status.ToString());
                                key.Add("方向");
                                value.Add(HOUKO);
                                key.Add("車両名称");
                                value.Add(CAR_NM);
                                key.Add("車種");
                                value.Add(CARSYU_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;


                                /*
                                                                info_summery += "{\"備考\":";
                                                                info_summery += "{";

                                                                info_summery += "\"車両コード\":";
                                                                info_summery += "\"";
                                                                info_summery += KANRISHARYO_CD;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"車両動態\":";
                                                                info_summery += "\"";
                                                                info_summery += status;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"方向\":";
                                                                info_summery += "\"";
                                                                info_summery += HOUKO;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"車両名称\":";
                                                                info_summery += "\"";
                                                                info_summery += CAR_NM;
                                                                info_summery += "\"";
                                                                info_summery += ",";

                                                                info_summery += "\"車種\":";
                                                                info_summery += "\"";
                                                                info_summery += CARSYU_CD;
                                                                info_summery += "\"";

                                                                info_summery += "}";
                                                                info_summery += "}";

                                  */
                                lay_type = 1;


                                try
                                {
                                    int sym_id = Int32.Parse(SYMBOL_CD);

                                    //var findVal = list.Find(x => x.OldCode == sym_id);
                                    //int sym_ptncode = findVal.NewCode;


                                    symbol_no = sym_id * 100 + Int32.Parse(HOUKO);
                                    //symbol_no = sym_id;
                                    //                                strinfo1 = KANRISHARYO_CD;
                                    strinfo1 = CAR_NM;
                                    strinfo2 = "";
                                    strinfo3 = "";
                                    str_zahyo_x = 0.0;
                                    str_zahyo_y = 0.0;

                                    item_no = info_type.ToString("D2");
                                    item_no += symbol_no.ToString("D5");
                                    item_no += cnt.ToString("D4");

                                    var findVal = list2.Find(x => x.status == status);
                                    int str_ptn = findVal.ptn;

                                    //
                                    //帰署は対象外
                                    if (status != 70 && status != 80)
                                    {
                                        AddData2(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y,str_ptn);
                                    }

                                    //
                                    //DAMS DBを更新する
                                    //
                                    DateTime dt = DateTime.Now;


                                    //try
                                    //{
                                    //UpdateDAMSTable(Int32.Parse(KANRISHARYO_CD), Int32.Parse(DOTAI_KIHON_CD), Int32.Parse(DOTAI_SYOSAI_CD), Int32.Parse(ITI_ZAHYO_X), Int32.Parse(ITI_ZAHYO_Y), dt);
                                    //}
                                    //catch (Exception ex)
                                    //{

                                    //}

                                    //AddTBDAM400(Int32.Parse(KANRISHARYO_CD), CAR_NM, Int32.Parse(ITI_ZAHYO_X), Int32.Parse(ITI_ZAHYO_Y), status, Int32.Parse(HISYO_CD));
                                    ModTBDAM400(Int32.Parse(KANRISHARYO_CD), Int32.Parse(ITI_ZAHYO_X), Int32.Parse(ITI_ZAHYO_Y), status);
                                }
                                catch (Exception ex)
                                {

                                }
                            }
                        }
                    }
                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }

        static void AddTBDAM400(int SHARYO_CD, string SHARYO_NAME, int ZAHYO_X, int ZAHYO_Y, int DOUTAI_KIHON, int HAICHI_SHOSHO_CD)
        {
            string msg;

            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                string sql = "insert into  FIRE.TBDAM400(SHARYO_CD,SHARYO_NAME,ZAHYO_X,ZAHYO_Y,DOUTAI_KIHON,DOUTAI_SYOSAI,HAICHI_SHOSHO_CD,UPD_DATE)";
                sql += " VALUES(:SHARYO_CD,:SHARYO_NAME,:ZAHYO_X,:ZAHYO_Y,:DOUTAI_KIHON,:DOUTAI_SYOSAI,:HAICHI_SHOSHO_CD,:UPD_DATE)";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":SHARYO_CD", OracleDbType.Int32,
                                    SHARYO_CD, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":SHARYO_NAME", OracleDbType.Varchar2,
                                    SHARYO_NAME, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":ZAHYO_X", OracleDbType.Double,
                                    ZAHYO_X, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":ZAHYO_Y", OracleDbType.Double,
                                    ZAHYO_Y, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":DOUTAI_KIHON", OracleDbType.Int32,
                                    DOUTAI_KIHON, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":DOUTAI_SYOSAI", OracleDbType.Int32,
                                    DOUTAI_KIHON, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":HAICHI_SHOSHO_CD", OracleDbType.Int32,
                                    HAICHI_SHOSHO_CD, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":UPD_DATE", OracleDbType.Date,
                                    dt, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();

                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                    conn.Close();
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }


        }
        static void ModTBDAM400(int SHARYO_CD, int ZAHYO_X, int ZAHYO_Y, int DOUTAI_KIHON)
        {
            string msg;

            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                //string sql = "insert into  FIRE.TBDAM400(SHARYO_CD,SHARYO_NAME,ZAHYO_X,ZAHYO_Y,DOUTAI_KIHON,DOUTAI_SYOSAI,HAICHI_SHOSHO_CD,UPD_DATE)";
                //sql += " VALUES(:SHARYO_CD,:SHARYO_NAME,:ZAHYO_X,:ZAHYO_Y,:DOUTAI_KIHON,:DOUTAI_SYOSAI,:HAICHI_SHOSHO_CD,:UPD_DATE)";

                string sql = "update FIRE.TBDAM400　set ZAHYO_X=:ZAHYO_X,ZAHYO_Y=:ZAHYO_Y,DOUTAI_KIHON=:DOUTAI_KIHON,DOUTAI_SYOSAI=:DOUTAI_SYOSAI,UPD_DATE=:UPD_DATE";
                sql += " WHERE SHARYO_CD=:SHARYO_CD";


                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":SHARYO_CD", OracleDbType.Int32,
                                    SHARYO_CD, ParameterDirection.Input));
                                //cmd.Parameters.Add(new OracleParameter(":SHARYO_NAME", OracleDbType.Varchar2,
                                //    SHARYO_NAME, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":ZAHYO_X", OracleDbType.Double,
                                    ZAHYO_X, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":ZAHYO_Y", OracleDbType.Double,
                                    ZAHYO_Y, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":DOUTAI_KIHON", OracleDbType.Int32,
                                    DOUTAI_KIHON, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":DOUTAI_SYOSAI", OracleDbType.Int32,
                                    DOUTAI_KIHON, ParameterDirection.Input));
                                //cmd.Parameters.Add(new OracleParameter(":HAICHI_SHOSHO_CD", OracleDbType.Int32,
                                //    HAICHI_SHOSHO_CD, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":UPD_DATE", OracleDbType.Date,
                                    dt, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();

                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                    conn.Close();
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }


        }

        static void LoadCarTypeCSV(ref List<CarTypeTbl> list)
        {
            string CSVFNAME = @"F:\setup\data\csv\車両シンボル対応表.csv";

            System.IO.StreamReader sr = null;
            try
            {
                sr = new StreamReader(CSVFNAME, System.Text.Encoding.GetEncoding("UTF-8"));
                string line = null;

                while ((line = sr.ReadLine()) != null)
                {
                    string[] param = line.Split(',');
                    try
                    {
                        list.Add(new CarTypeTbl() { ID = Int32.Parse(param[0]), Name = param[1], NewCode = Int32.Parse(param[2]), OldCode = Int32.Parse(param[3]) });
                    }
                    catch (Exception ex)
                    {

                    }

                }
                sr.Close();

            }
            catch (Exception ex)
            {
            }













        }
        static void LoadWaterTypeCSV(ref List<WaterTypeTbl> list)
        {
            string CSVFNAME = @"F:\setup\data\csv\水利シンボル対応表.csv";

            System.IO.StreamReader sr = null;
            try
            {
                sr = new StreamReader(CSVFNAME, System.Text.Encoding.GetEncoding("UTF-8"));
                string line = null;

                while ((line = sr.ReadLine()) != null)
                {
                    string[] param = line.Split(',');
                    try
                    {
                        list.Add(new WaterTypeTbl() { ID = Int32.Parse(param[0]), Name = param[1], NewCode = Int32.Parse(param[2]), OldCode = Int32.Parse(param[3]) });
                    }
                    catch (Exception ex)
                    {

                    }

                }
                sr.Close();

            }
            catch (Exception ex)
            {
            }


        }
        static void LoadStrPtnCSV(ref List<StrPtnTbl> list)
        {
            string CSVFNAME = @"F:\setup\data\csv\動態文字色パターン.csv";

            System.IO.StreamReader sr = null;
            try
            {
                sr = new StreamReader(CSVFNAME, System.Text.Encoding.GetEncoding("UTF-8"));
                string line = null;

                while ((line = sr.ReadLine()) != null)
                {
                    string[] param = line.Split(',');
                    try
                    {
                        list.Add(new StrPtnTbl() { status = Int32.Parse(param[0]), Name = param[1], ptn = Int32.Parse(param[4]) });
                    }
                    catch (Exception ex)
                    {

                    }

                }
                sr.Close();

            }
            catch (Exception ex)
            {
            }


        }
        //--------------------------------------------------------------------------
        //　　水利
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDSC340()
        {
            DelData("n@2-1");
            string msg;

            List<WaterTypeTbl> list = new List<WaterTypeTbl>();

            LoadWaterTypeCSV(ref list);


            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
           // string sqlStr = "select * from TBDSC340B WHERE U_KB <> 'D'";
            string sqlStr = "select * from TBDMT340A";
            

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String SUIRI_CD = reader["SUIRI_CD"].ToString();
                                String SUIRI_SBT = reader["SUIRI_SBT"].ToString();
                                String SYMBOL_SBT = reader["SYMBOL_CD"].ToString();
                                //String SHIYO_KAHI = reader["SHIYO_KAHI"].ToString();
                                //String HAIKAN_KOKEI = reader["HAIKAN_KOKEI"].ToString();
                                //String MOJI = reader["MOJI"].ToString();
                                String IZAHYO_X = reader["ZAHYO_X"].ToString();
                                String IZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(SUIRI_CD);


                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(IZAHYO_X);
                                    ly = Double.Parse(IZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@2-1";
                                item_no = cnt.ToString();
                                info_type = 2;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("水利コード");
                                value.Add(SUIRI_CD);
                                key.Add("水利種別");
                                value.Add(SUIRI_SBT);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                /*
                                                                info_summery += "{";
                                                                info_summery += "\"水利コード\":";
                                                                info_summery += "\"";
                                                                info_summery += SUIRI_CD;
                                                                info_summery += "\"";
                                                                info_summery += ",\"水利種別\":";
                                                                info_summery += "\"";
                                                                info_summery += SUIRI_SBT;
                                                                info_summery += "\"";
                                                                info_summery += ",\"配管口径\":";
                                                                info_summery += "\"";
                                                                //info_summery += HAIKAN_KOKEI;
                                                                info_summery += "\"";
                                                                info_summery += ",\"部署台数\":";
                                                                info_summery += "\"";
                                                                info_summery += "0";
                                                                info_summery += "\"";
                                                                info_summery += ",\"使用可否\":";
                                                                info_summery += "\"";
                                                                //info_summery += SHIYO_KAHI;
                                                                info_summery += "\"";
                                                                info_summery += ",\"備考\":";
                                                                info_summery += "\"";
                                                                info_summery += "";
                                                                info_summery += "\"";
                                                                info_summery += "}";
                                */
                                lay_type = 1;

                                //if (Int32.Parse(SHIYO_KAHI) == 1)
                                //{
                                //symbol_no = Int32.Parse(SYMBOL_SBT)+1150;
                                //}
                                //else
                                //{
                                symbol_no = Int32.Parse(SYMBOL_SBT);
                                //}
                                /*
                                var findVal = list.Find(x => x.OldCode == symbol_no);
                                symbol_no = findVal.NewCode;
                                */
                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                if (SUIRI_CD.Length > 4)
                                {
                                    strinfo1 = SUIRI_CD.Substring(SUIRI_CD.Length-4);
                                }
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //--------------------------------------------------------------------------
        //　　目標物
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDSC110()
        {
            DelData("n@6-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDSC110A WHERE U_KB <> 'D'";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String MOKUBT_CD = reader["MOKUBT_CD"].ToString();
                                String MOKUBT_NM = reader["MOKUBT_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(MOKUBT_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@6-1";
                                item_no = cnt.ToString();
                                info_type = 6;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("目標物コード");
                                value.Add(MOKUBT_CD);
                                key.Add("目標物名称");
                                value.Add(MOKUBT_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = MOKUBT_NM;
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                if(symbol_no>=1 && symbol_no != 61 && symbol_no != 62 && symbol_no != 63)
                                {
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                                }


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //--------------------------------------------------------------------------
        //　　目標物(TBDMT119)
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDMT119()
        {
            DelData("n@6-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDMT119A ";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String MOKUBT_CD = reader["MOKUBT_CD"].ToString();
                                String MOKUBT_NM = reader["MOKUBT_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(MOKUBT_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@6-1";
                                item_no = cnt.ToString();
                                info_type = 6;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("目標物コード");
                                value.Add(MOKUBT_CD);
                                key.Add("目標物名称");
                                value.Add(MOKUBT_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = "";
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                if (symbol_no >= 1 && symbol_no != 61 && symbol_no != 62 && symbol_no != 63)
                                {
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                                }


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //--------------------------------------------------------------------------
        //　　対象物(TBDMT129)
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDMT129()
        {
//            DelData("n@6-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDMT129A ";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String TAISBT_CD = reader["TAISBT_CD"].ToString();
                                String TAISBT_NM = reader["TAISBT_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(TAISBT_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@6-1";
                                item_no = cnt.ToString();
                                info_type = 6;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("対象物コード");
                                value.Add(TAISBT_CD);
                                key.Add("対象物名称");
                                value.Add(TAISBT_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = "";
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                if (symbol_no != 99)
                                {
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                                }


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //--------------------------------------------------------------------------
        //　　危険物(TBDMT139)
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDMT139()
        {
            //            DelData("n@6-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDMT139A ";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String KIKEN_CD = reader["KIKEN_CD"].ToString();
                                String KIKEN_NM = reader["KIKEN_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(KIKEN_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@6-1";
                                item_no = cnt.ToString();
                                info_type = 6;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("危険物コード");
                                value.Add(KIKEN_CD);
                                key.Add("危険物名称");
                                value.Add(KIKEN_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = "";
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                //if (symbol_no >= 1 && symbol_no != 61 && symbol_no != 62 && symbol_no != 63)
                                //{
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                                //}
                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //--------------------------------------------------------------------------
        //　　個人情報(TBDMT159)
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDMT159()
        {
            //            DelData("n@6-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDMT159A ";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String KOJIN_CD = reader["KOJIN_CD"].ToString();
                                String KOJIN_NM = reader["KOJIN_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(KOJIN_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@6-1";
                                item_no = cnt.ToString();
                                info_type = 6;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("個人情報コード");
                                value.Add(KOJIN_CD);
                                key.Add("個人情報名称");
                                value.Add(KOJIN_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = "";
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

//                                if (symbol_no >= 1 && symbol_no != 61 && symbol_no != 62 && symbol_no != 63)
  //                              {
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
    //                            }


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        //--------------------------------------------------------------------------
        //　　危険物
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDSC130()
        {
            DelData("n@3-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDSC130A WHERE U_KB <> 'D'";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String KIKENBT_CD = reader["KIKENBT_CD"].ToString();
                                String KIKEN_NM = reader["KIKEN_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(KIKENBT_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@3-1";
                                item_no = cnt.ToString();
                                info_type = 3;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("危険物コード");
                                value.Add(KIKENBT_CD);
                                key.Add("危険物名称");
                                value.Add(KIKEN_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = KIKEN_NM;
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                //if(symbol_no>=80 && symbol_no <= 87)
                                //{
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                                //}
                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //--------------------------------------------------------------------------
        //　　個人情報
        //--------------------------------------------------------------------------
        static private void ReadDB_TBDSC150()
        {
            DelData("n@5-1");
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDSC150B WHERE U_KB <> 'D'";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String KOJIN_CD = reader["KOJIN_CD"].ToString();
                                String KOJIN_NM = reader["KOJIN_NM"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();


                                MsgOut(KOJIN_CD);

                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(ZAHYO_X);
                                    ly = Double.Parse(ZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                //int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                cnt++;

                                lay_no = "n@5-1";
                                item_no = cnt.ToString();
                                info_type = 5;
                                info_summery = "";

                                string info = "";

                                List<string> key = new List<string>();
                                List<string> value = new List<string>();

                                key.Add("個人番号");
                                value.Add(KOJIN_CD);
                                key.Add("個人名称");
                                value.Add(KOJIN_NM);
                                key.Add("シンボル種別");
                                value.Add(SYMBOL_CD);

                                editinfo(key, value, ref info);


                                info_summery = info;

                                lay_type = 1;

                                symbol_no = Int32.Parse(SYMBOL_CD);

                                zahyo_x = (double)m_keido_w / (3600 * 1000);
                                zahyo_y = (double)m_ido_w / (3600 * 1000);
                                strinfo1 = KOJIN_NM;
                                strinfo2 = "";
                                strinfo3 = "";
                                str_zahyo_x = 0.0;
                                str_zahyo_y = 0.0;

                                item_no = info_type.ToString("D2");
                                item_no += symbol_no.ToString("D4");
                                item_no += cnt.ToString("D6");

                                if (symbol_no >= 90 && symbol_no <= 93)
                                {
                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);
                                }
                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        static private void DelData(String layerID)
        {
            string msg;

            try
            {
                //プレースホルダでバインドする
                string sql = "delete from  TBWG0001 Where lay_no=:lay_no";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                    layerID, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();
                                msg = "Delete Commit! [" + layerID + "]";
                                MsgOut(msg);
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }
        }
        static private void DelTBDAM400()
        {
            string msg;

            try
            {
                //プレースホルダでバインドする
                string sql = "delete from  FIRE.TBDAM400";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {

                                cmd.ExecuteNonQuery();
                                transaction.Commit();
                                msg = "Delete Commit!";
                                MsgOut(msg);
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }
        }

        static private void DelData2(String layerID, int symbol_no)
        {
            string msg;

            try
            {
                //プレースホルダでバインドする
                string sql = "delete from  TBWG0001 Where lay_no=:lay_no AND symbol_no=:symbol_no";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                    layerID, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Int32,
                                    symbol_no, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();
                                msg = "Delete Commit! [" + layerID + "]";
                                MsgOut(msg);
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }
        }
        static private void DelData3(String layerID, int info_type)
        {
            string msg;

            try
            {
                //プレースホルダでバインドする
                string sql = "delete from  TBWG0001 Where lay_no=:lay_no AND info_type=:info_type";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                    layerID, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":info_type", OracleDbType.Int32,
                                    info_type, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();
                                msg = "Delete Commit! [" + layerID + "]";
                                MsgOut(msg);
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }
        }

        static private void AddData(String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y)
        {
            String msg;
            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                string sql = "insert into  TBWG0001(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,update_date)";
                sql += " VALUES(:lay_no,:item_no,:info_type,:info_summery,:lay_type,:symbol_no,:zahyo_x,:zahyo_y,:strinfo1,:strinfo2,:strinfo3,:str_zahyo_x,:str_zahyo_y,:update_date)";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                    lay_no, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":item_no", OracleDbType.Varchar2,
                                    item_no, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":info_type", OracleDbType.Int32,
                                    info_type, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":info_summery", OracleDbType.Varchar2,
                                    info_summery, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":lay_type", OracleDbType.Varchar2,
                                    lay_type, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Varchar2,
                                    symbol_no, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":zahyo_x", OracleDbType.Double,
                                    zahyo_x, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":zahyo_y", OracleDbType.Double,
                                    zahyo_y, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":strinfo1", OracleDbType.Varchar2,
                                    strinfo1, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":strinfo2", OracleDbType.Varchar2,
                                    strinfo2, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":strinfo3", OracleDbType.Varchar2,
                                    strinfo3, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":str_zahyo_x", OracleDbType.Double,
                                    str_zahyo_x, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":str_zahyo_y", OracleDbType.Double,
                                    str_zahyo_y, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":update_date", OracleDbType.Date,
                                    dt, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();

                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                    conn.Close();
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }

        }
        static private void AddData2(String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y, int str_ptn)
        {
            String msg;
            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                string sql = "insert into  TBWG0001(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,str_ptn,update_date)";
                sql += " VALUES(:lay_no,:item_no,:info_type,:info_summery,:lay_type,:symbol_no,:zahyo_x,:zahyo_y,:strinfo1,:strinfo2,:strinfo3,:str_zahyo_x,:str_zahyo_y,:str_ptn,:update_date)";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = CONN_STRING;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                    lay_no, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":item_no", OracleDbType.Varchar2,
                                    item_no, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":info_type", OracleDbType.Int32,
                                    info_type, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":info_summery", OracleDbType.Varchar2,
                                    info_summery, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":lay_type", OracleDbType.Varchar2,
                                    lay_type, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Varchar2,
                                    symbol_no, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":zahyo_x", OracleDbType.Double,
                                    zahyo_x, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":zahyo_y", OracleDbType.Double,
                                    zahyo_y, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":strinfo1", OracleDbType.Varchar2,
                                    strinfo1, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":strinfo2", OracleDbType.Varchar2,
                                    strinfo2, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":strinfo3", OracleDbType.Varchar2,
                                    strinfo3, ParameterDirection.Input));

                                cmd.Parameters.Add(new OracleParameter(":str_zahyo_x", OracleDbType.Double,
                                    str_zahyo_x, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":str_zahyo_y", OracleDbType.Double,
                                    str_zahyo_y, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":str_ptn", OracleDbType.Int32,
                                    str_ptn, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":update_date", OracleDbType.Date,
                                    dt, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();

                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                    conn.Close();
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }

        }

        static public void MsgOut(string msg)
        {
            DateTime dt = DateTime.Now;

            Console.WriteLine(dt.ToString() + "," + msg);
            lg.LogOut(dt.ToString() + "," + msg);
        }


        //--------------------------------------------------------------------------
        //　　対象物
        //--------------------------------------------------------------------------
        private static void ReadDB_TBDSC120()
        {
            DelData("n@4-1");

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(30, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBDSC120A ";

            int cnt = 0;

            try
            {
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING2;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String TAISBT_CD = reader["TAISBT_CD"].ToString();
                                String SYMBOL_CD = reader["SYMBOL_CD"].ToString();
                                String TAISBT_NM = reader["TAISBT_NM"].ToString();
                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();

                                MsgOut(TAISBT_CD);
                                symbol_no = Int32.Parse(SYMBOL_CD);

                                if((symbol_no >=91 && symbol_no <= 94) || (symbol_no >= 133 && symbol_no <= 140))
                                {
                                    MapCom.Convert cs = new MapCom.Convert();

                                    double lx = 0.0;
                                    //int kijyunkei = 6;
                                    double m_keido = 0.0;
                                    double m_ido = 0.0;
                                    long m_keido_w = 0;
                                    long m_ido_w = 0;
                                    double ly = 0.0;

                                    //if (ZAHYO_X.Length < 10 || IZAHYO_Y.Length < 10)
                                    //{
                                    try
                                    {
                                        lx = Double.Parse(ZAHYO_X);
                                        ly = Double.Parse(ZAHYO_Y);
                                    }
                                    catch (Exception ex)
                                    {

                                    }


                                    //                                lx = -45237600;
                                    //                                ly = -150372500;


                                    //正規化座標(m)→経緯度（日本）(秒）
                                    cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                    //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                    cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                                    //}

                                    cnt++;

                                    lay_no = "n@4-1";
                                    item_no = cnt.ToString();
                                    info_type = 4;
                                    info_summery = "";

                                    /*
                                    info_summery += "{";
                                    info_summery += "\"対象物コード\":";
                                    info_summery += "\"";
                                    info_summery += TAISBT_CD;
                                    info_summery += "\"";
                                    info_summery += ",\"種別コード\":";
                                    info_summery += "\"";
                                    info_summery += "";
                                    info_summery += "\"";
                                    info_summery += ",\"備考\":";
                                    info_summery += "\"";
                                    info_summery += TAISBT_NM;
                                    info_summery += "\"";
                                    info_summery += "}";
                                    */

                                    string info = "";

                                    List<string> key = new List<string>();
                                    List<string> value = new List<string>();

                                    key.Add("対象物コード");
                                    value.Add(TAISBT_CD);
                                    key.Add("名称");
                                    value.Add(TAISBT_NM);

                                    editinfo(key, value, ref info);

                                    info_summery = info;

                                    lay_type = 1;
                                    zahyo_x = (double)m_keido_w / (3600 * 1000);
                                    zahyo_y = (double)m_ido_w / (3600 * 1000);
                                    strinfo1 = "";
                                    strinfo2 = "";
                                    strinfo3 = "";
                                    str_zahyo_x = 0.0;
                                    str_zahyo_y = 0.0;

                                    item_no = info_type.ToString("D2");
                                    item_no += symbol_no.ToString("D4");
                                    item_no += cnt.ToString("D6");

                                    AddData(lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);



                                }

                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
    }
    public class CarTypeTbl
    {
        //1   ST車 201 60
        public int ID { get; set; }
        public string Name { get; set; }
        public int NewCode { get; set; }
        public int OldCode { get; set; }
    }
    public class WaterTypeTbl
    {
        //1   ST車 201 60
        public int ID { get; set; }
        public string Name { get; set; }
        public int NewCode { get; set; }
        public int OldCode { get; set; }
    }
    public class StrPtnTbl
    {
        //1   ST車 201 60
        public int status { get; set; }
        public string Name { get; set; }
        public int ForeColor { get; set; }
        public int BackColor { get; set; }
        public int ptn { get; set; }
    }
}

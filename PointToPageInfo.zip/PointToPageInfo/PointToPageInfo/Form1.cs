﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PointToPageInfo
{
    public partial class Form1 : Form
    {
        string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= " + "C:\\D_DRV\\FIIM_PAGE.mdb";
        string CON_STR2 = "User ID=WEBGIS; Password=WEBGIS; Data Source=172.20.10.10:1521/fire.osaka";

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "-3975000";
            textBox2.Text = "-12800000";

        }

        private void button1_Click(object sender, EventArgs e)
        {

            OracleConnection conn = new OracleConnection();

            try
            {
                conn.ConnectionString = CON_STR2;
                //DBを読みながら、更新する

                string sqlStr = "select * from TBJS0100";

                //コマンドを生成する
                using (OracleCommand command = new OracleCommand(sqlStr))
                {
                    command.Connection = conn;
                    command.CommandType = CommandType.Text;

                    //コマンドを実行する
                    using (OracleDataReader reader = command.ExecuteReader())
                    {
                        //検索結果が存在する間ループする
                        while (reader.Read())
                        {
                            String SUIRI_CD = reader["SUIRI_CD"].ToString();
                            String SUIRI_SBT = reader["SUIRI_SBT"].ToString();
                            String SYMBOL_SBT = reader["SYMBOL_SBT"].ToString();
                            String SHIYO_KAHI = reader["SHIYO_KAHI"].ToString();
                            String HAIKAN_KOKEI = reader["HAIKAN_KOKEI"].ToString();
                            String MOJI = reader["MOJI"].ToString();
                            String IZAHYO_X = reader["IZAHYO_X"].ToString();
                            String IZAHYO_Y = reader["IZAHYO_Y"].ToString();

                            int x = Int32.Parse(IZAHYO_X);
                            int y = Int32.Parse(IZAHYO_Y);

                            string pageInfo = "";

                            GetPageInfo(x, y, ref pageInfo);

                            textBox3.Text = pageInfo;

                            string[] param = pageInfo.Split(',');

                            if (param.Length >= 6)
                            {
                                string book = param[0];
                                string page = param[1];
                                string leftright = param[2];
                                string str_meshx = param[3];
                                string str_meshy = param[4];
                                string submesh_x = param[5];
                                string submesh_y = param[6];

                                ModRec(conn, book, page, leftright, str_meshx, str_meshy, submesh_x, submesh_y);
                                

                            }




                        }
                    }
                }


                conn.Open();
                conn.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }

            private void GetPageInfo(int x, int y, ref string pageInfo)
        {
            string constr = CON_STR;
            OleDbConnection dbcon = new OleDbConnection(constr);

            string[] str_meshx = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J" };
            string[] str_meshy = { "5", "4", "3", "2", "1" };

            //int x = -3975000;
            //int y = -12800000;

            string query = "SELECT * FROM ページ検索テーブル WHERE [左下正規化座標X] <= " + x + " AND [右上正規化座標X] >=" + x;
            query += "AND [左下正規化座標Y] <= " + y + " AND [右上正規化座標Y] >=" + y;


            OleDbCommand cmd = dbcon.CreateCommand();
            dbcon.Open();


            OleDbCommand command = new OleDbCommand(query, dbcon);
            OleDbDataReader reader = command.ExecuteReader();

            if (reader.Read())
            {
                string book = reader["冊"].ToString();
                string page = reader["ページ"].ToString();
                string leftright = reader["左右"].ToString();
                string scale = reader["スケール"].ToString();

                int ld_x = Int32.Parse(reader["左下正規化座標X"].ToString());
                int ld_y = Int32.Parse(reader["左下正規化座標Y"].ToString());
                int ru_x = Int32.Parse(reader["右上正規化座標X"].ToString());
                int ru_y = Int32.Parse(reader["右上正規化座標Y"].ToString());

                int w = (ru_x - ld_x) / 5;
                int h = (ru_y - ld_y) / 5;

                int mx = x - ld_x;
                int my = y - ld_y;

                int subw = w / 10;
                int subh = h / 10;

                int mesh_x = mx / w;
                int mesh_y = my / h;


                if (mesh_x == 5)
                {
                    mesh_x--;
                }
                if (mesh_y == 5)
                {
                    mesh_y--;
                }


                int submesh_x = (mx % w) / subw;//サブメッシュのあまりを出す
                int submesh_y = 9 - (my % h) / subh;//サブメッシュのあまりを出す

                string line = "";

                line += book;
                line += ",";
                line += page;
                line += ",";
                line += leftright;
                line += ",";

                if (leftright.IndexOf("0") == 0)
                {
                    line += str_meshx[mesh_x];
                    line += ",";
                    line += str_meshy[mesh_y];
                    line += ",";
                    line += submesh_x.ToString();
                    line += ",";
                    line += submesh_y.ToString();

                }
                else
                {
                    line += str_meshx[mesh_x + 5];
                    line += ",";
                    line += str_meshy[mesh_y];
                    line += ",";
                    line += submesh_x.ToString();
                    line += ",";
                    line += submesh_y.ToString();
                }
                pageInfo = line;

            }

            dbcon.Close();
        }
        private static void ModRec(OracleConnection a_conn, string book, string page, string eftright, string str_meshx, string str_meshy, string submesh_x, string submesh_y)
        {

                try
                {
                    string sql = "update TBSK0006　set MANCHO_CHOI=:MANCHO_CHOI,MANCHO_DATE=:MANCHO_DATE,KANCHO_CHOI=:KANCHO_CHOI,KANCHO_DATE=:KANCHO_DATE,upd_date=:upd_date";
                    sql += " WHERE MANCHO_KANCHO_ID=1";

                    using (OracleTransaction transaction = a_conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, a_conn))
                            {
                                cmd.BindByName = true;
//
    //                            cmd.Parameters.Add(new OracleParameter(":MANCHO_CHOI", OracleDbType.Int32)).Value = next_high_tide_level;

  //                              cmd.Parameters.Add(new OracleParameter(":MANCHO_DATE", OracleDbType.Date)).Value = next_high_tide_date;

      //                          cmd.Parameters.Add(new OracleParameter(":KANCHO_CHOI", OracleDbType.Int32)).Value = next_low_tide_date;

        //                        cmd.Parameters.Add(new OracleParameter(":KANCHO_DATE", OracleDbType.Date)).Value = next_high_tide_date;

          //                      cmd.Parameters.Add(new OracleParameter(":upd_date", OracleDbType.Date)).Value = upd_date;


                                cmd.ExecuteNonQuery();

                                transaction.Commit();
//                                MsgOut("UPDATE Commit!");
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            Console.WriteLine(ex.ToString());
  //                          MsgOut(ex.ToString());
                        }
                    }
                }
                catch (Exception ex)
                {
    //                MsgOut(ex.ToString());
                    Console.WriteLine(ex.Message.ToString());
                }
                //コネクションを切断する
//                a_conn.Close();
                //コネクションを破棄する
//                a_conn.Dispose();
        //    }
        }
    }
}

﻿using CsUsrlayManager.Models;
using Common;
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace CsUsrlayManager
{
    static class Program
    {
        /// <summary>アプリ名</summary>
        public const string thisAppName = "CsUsrlayManager";

        /// <summary>Mutex名</summary>
        private const string mutexName = "AVM_USRLAY_MANAGE_TOOL";

        // 外部プロセスのメイン・ウィンドウを起動するためのWin32 API
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);
        [DllImport("user32.dll")]
        private static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
        [DllImport("user32.dll")]
        private static extern bool IsIconic(IntPtr hWnd);

        // 多重起動を防止するミューテックス
        private static System.Threading.Mutex mutexObject;

        /// <summary>iniファイル設定</summary>
        public static IniSettings IniFileSettings = new IniSettings();

        /// <summary>iniファイル設定</summary>
        public static LogClass Log = new LogClass(thisAppName, IniFileSettings.LogSettings.LogFileSizeMax, IniFileSettings.LogSettings.LogGeneration);

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Log = new LogClass(thisAppName, IniFileSettings.LogSettings.LogFileSizeMax, IniFileSettings.LogSettings.LogGeneration) ;

            Log.OutPutLog("I", "◇ ------------- 起動 ------------- ◇");
            try
            {
                // ミューテックスを生成する
                mutexObject = new System.Threading.Mutex(false, mutexName);
            }
            catch (ApplicationException)
            {
                // グローバル・ミューテックスの多重起動禁止
                Log.OutPutLog("I", "◇ ------------- 多重起動禁止 ------------- ◇");
                return;
            }

            // ミューテックスを取得する
            if (mutexObject.WaitOne(0, false))
            {
                // アプリケーションを実行
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new MainForm());

                // ミューテックスを解放する
                mutexObject.ReleaseMutex();
            }
            else
            {
                // 実行中の同じアプリケーションのウィンドウ・ハンドルの取得
                Process prevProcess = GetPreviousProcess();
                if ((prevProcess != null) && (prevProcess.MainWindowHandle != IntPtr.Zero))
                {
                    // 起動中のアプリケーションを最前面に表示
                    Log.OutPutLog("I", "◇ ------------- 多重起動禁止 ------------- ◇");
                }
            }

            // ミューテックスを破棄する
            mutexObject.Close();
        }


        public static Process GetPreviousProcess()
        {
            Process currentProcess = Process.GetCurrentProcess();
            Process[] processes = Process.GetProcessesByName(currentProcess.ProcessName);

            foreach (Process checkProcess in processes)
            {
                if (checkProcess.Id != currentProcess.Id)
                {
                    if (String.Compare(
                        checkProcess.MainModule.FileName,
                        currentProcess.MainModule.FileName, true) == 0)
                    {
                        return checkProcess;
                    }
                }
            }
            return null;
        }
    }
}

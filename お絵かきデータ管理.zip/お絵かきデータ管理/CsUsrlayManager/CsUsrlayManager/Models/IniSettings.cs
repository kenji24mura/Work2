﻿using Common;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace CsUsrlayManager.Models
{
    public class IniSettings
    {
        /// <summary>INIファイルパス</summary>
        private const string FILE_PATH_INI = "CsUsrlayManager.ini";
        /// <summary>Settings</summary>
        private const string INI_SECTION_SETTINGS = "Settings";

        /// <summary>デフォルト値_SHAPEファイル更新チェックのタイマー時間間隔（秒）</summary>
        private const int DEFAULT_WATCH_INTERVAL = 60;
        /// <summary>お絵かきデータファイル世代管理数のデフォルト値</summary>
        private const int DEFAULT_USRLAY_ZIP_GENERATION = 100;
        /// <summary>ログファイル最大サイズ(MB)のデフォルト値</summary>
        private const long DEFAULT_LOG_FILESIZE_MAX = 1;
        /// <summary>ログファイル世代管理数のデフォルト値</summary>
        private const int DEFAULT_LOG_GENERATION = 100;

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>Settings</summary>
        private const string INI_SECTION_CREATE_IMAGE_SETTINGS = "CreateImageSettings";
        /// <summary>お絵かきデータ画像ファイル作成有無のデフォルト値</summary>
        private const bool DEFAULT_CREATE_USRLAY_IMAGE_USE = false;
        /// <summary>お絵かきデータ画像を作成する最小スケールのデフォルト値</summary>
        private const int DEFAULT_USRLAY_SCALE_MIN = 1;
        /// <summary>お絵かきデータ画像を作成する最大スケールのデフォルト値</summary>
        private const int DEFAULT_USRLAY_SCALE_MAX = 3;
        /// <summary>お絵かきデータ画像を作成する最小・最大スケールの下限</summary>
        private const int USRLAY_SCALE_LOWER_LIMIT = 1;
        /// <summary>お絵かきデータ画像を作成する最小・最大スケールの上限</summary>
        private const int USRLAY_SCALE_UPPER_LIMIT = 15;

        /// <summary>お絵かきデータカラー定義のデフォルト値</summary>
        private static ReadOnlyCollection<Color> DEFAULT_USRLAY_COLOR { get; } = new[]
        {
            Color.FromArgb(0, 0, 0),            // 0:黒
            Color.FromArgb(255, 0, 0),          // 1:赤
            Color.FromArgb(255, 0, 255),        // 2:ピンク
            Color.FromArgb(0, 0, 255),          // 3:青
            Color.FromArgb(51, 255, 255),       // 4:水色
            Color.FromArgb(190, 190, 190),      // 5:灰色
            Color.FromArgb(0, 255, 0),          // 6:緑
            Color.FromArgb(255, 255, 255),      // 7:白色
            Color.FromArgb(255, 128, 0),        // 8:オレンジ
            Color.FromArgb(0, 128, 0),          // 9:深緑
            Color.FromArgb(204, 153, 102),      // 10:茶色
            Color.FromArgb(192, 220, 192),      // 11:緑(建物)
        }
        .ToList().AsReadOnly();

        /// <summary>お絵かきデータ画像ファイルの文字列フォントのデフォルト値</summary>
        private const string DEFAULT_USRLAY_TEXT_FONT = "ＭＳ Ｐゴシック";
        // 2024/05/17 Add End

        /// <summary>セクション：Settings</summary>
        public SectionSettings Settings { get; private set; } = new SectionSettings();
        /// <summary>セクション：Log_Settings</summary>
        public SectionLogSettings LogSettings { get; private set; } = new SectionLogSettings();

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>セクション：CreateImageSettings</summary>
        public SectionCreateImageSettings CreateImageSettings { get; private set; } = new SectionCreateImageSettings();
        // 2024/05/17 Add End

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public IniSettings()
        {
            LogSettings.LogGeneration = IniReader.StringToIntForIniFile(IniReader.GetIniSectionLog(FILE_PATH_INI, "LOG_GENERATION"), DEFAULT_LOG_GENERATION);
            LogSettings.LogFileSizeMax = IniReader.StringToLongForIniFile(IniReader.GetIniSectionLog(FILE_PATH_INI, "LOG_FILESIZE_MAX"), DEFAULT_LOG_FILESIZE_MAX);
        }

        /// <summary>
        /// iniファイル読込
        /// </summary>
        public void ReadIniFile()
        {
            Settings.SaveDirAvmUpdate = StringGetSectionSettings("SAVE_DIR_AVM_UPDATE");
            Settings.SaveDirUsrlayZip = StringGetSectionSettings("SAVE_DIR_USRLAY_ZIP");
            Settings.AVMServerHostName = StringGetSectionSettings("AVM_SERVER_HOST_NAME");
            Settings.UsrlayZipLatestInfo = StringGetSectionSettings("LATESTINFO");
            Settings.UsrlayZipDistributeInfo = StringGetSectionSettings("DISTRIBUTEINFO");
            Settings.ServerUsrLayVersionTxtFile = StringGetSectionSettings("SERVER_USRLAY_VERSION_TEXT");
            Settings.UsrlayZipWatchInterval = IniReader.StringToIntForIniFile(StringGetSectionSettings("USRLAY_ZIP_WATCH_INTERVAL"), DEFAULT_WATCH_INTERVAL);
            Settings.DistributeResultAVMDir = StringGetSectionSettings("AVM_USRLAY_DISTRIBUTE_RESULTFILE_PATH");
            Settings.DistributeResultDMDir = StringGetSectionSettings("DM_USRLAY_DISTRIBUTE_RESULTFILE_PATH");
            Settings.UsrlayZipGeneration = IniReader.StringToIntForIniFile(StringGetSectionSettings("USRLAY_ZIP_GENERATION"), DEFAULT_USRLAY_ZIP_GENERATION);

            // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
            CreateImageSettings.CreateUsrlayImageUse = IniReader.StringToBoolForIniFile(StringGetSectionCreateImageSettings("CREATE_USRLAY_IMAGE_USE"), DEFAULT_CREATE_USRLAY_IMAGE_USE);

            CreateImageSettings.CreateUsrlayImageWorkPath = StringGetSectionCreateImageSettings("CREATE_USRLAY_IMAGE_WORK_PATH");

            CreateImageSettings.UsrlayScaleMin = IniReader.StringToIntForIniFile(StringGetSectionCreateImageSettings("USRLAY_SCALE_MIN"), USRLAY_SCALE_LOWER_LIMIT, USRLAY_SCALE_UPPER_LIMIT, DEFAULT_USRLAY_SCALE_MIN);
            CreateImageSettings.UsrlayScaleMax = IniReader.StringToIntForIniFile(StringGetSectionCreateImageSettings("USRLAY_SCALE_MAX"), USRLAY_SCALE_LOWER_LIMIT, USRLAY_SCALE_UPPER_LIMIT, DEFAULT_USRLAY_SCALE_MAX);

            CreateImageSettings.UsrlayColor.Clear();
            for (int index = 0; index < DEFAULT_USRLAY_COLOR.Count; index++)
            {
                Color usrlayColor = IniReader.StringToColorForIniFile(StringGetSectionCreateImageSettings($"USRLAY_COLOR_{index + 1}"), DEFAULT_USRLAY_COLOR[index]);
                CreateImageSettings.UsrlayColor.Add(usrlayColor);
            }

            CreateImageSettings.UsrlayTextFont = StringGetSectionCreateImageSettings("USRLAY_TEXT_FONT", DEFAULT_USRLAY_TEXT_FONT);
            // 2024/05/17 Add End
        }

        /// <summary>
        /// セクション：Settings
        /// </summary>
        public class SectionSettings
        {
            /// <summary>保存先(車両端末用更新ファイル格納フォルダ)</summary>
            public string SaveDirAvmUpdate { get; set; }
            /// <summary>保存先(お絵かきzipファイル)</summary>
            public string SaveDirUsrlayZip { get; set; }
            /// <summary>AVMサーバのホスト名</summary>
            public string AVMServerHostName { get; set; }
            /// <summary>お絵かきZIP最新情報ファイル</summary>
            public string UsrlayZipLatestInfo { get; set; }
            /// <summary>お絵かきZIP配信情報ファイル</summary>
            public string UsrlayZipDistributeInfo { get; set; }
            /// <summary>車両端末配布用バージョン情報テキストファイル</summary>
            public string ServerUsrLayVersionTxtFile { get; set; }
            /// <summary>お絵かきZIP格納フォルダの監視間隔(秒)</summary>
            public int UsrlayZipWatchInterval { get; set; }
            /// <summary>お絵かきデータ配信結果ファイル格納フォルダ(AVM)</summary>
            public string DistributeResultAVMDir { get; set; }
            /// <summary>お絵かきデータ配信結果ファイル格納フォルダ(DM)</summary>
            public string DistributeResultDMDir { get; set; }
            /// <summary>お絵かきデータファイル世代管理数</summary>
            public int UsrlayZipGeneration { get; set; }
        }

        private static string StringGetSectionSettings(string key)
        {
            return StringGetSetteing(INI_SECTION_SETTINGS, key);
        }

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        private static string StringGetSectionCreateImageSettings(string key, string defaultValue = "")
        {
            return IniReader.GetIniValue(Program.Log, FILE_PATH_INI, INI_SECTION_CREATE_IMAGE_SETTINGS, key, defaultValue);
        }
        // 2024/05/17 Add End

        private static string StringGetSetteing(string section, string key)
        {
            return IniReader.GetIniValue(Program.Log, FILE_PATH_INI, section, key);
        }

        /// <summary>
        /// セクション：Log_Settings
        /// </summary>
        public class SectionLogSettings
        {
            /// <summary>ログファイル最大サイズ(mb)</summary>
            public long LogFileSizeMax { get; set; }
            /// <summary>ログファイル世代管理数</summary>
            public int LogGeneration { get; set; }
        }

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// セクション：CreateImageSettings
        /// </summary>
        public class SectionCreateImageSettings
        {
            /// <summary>お絵かきデータ画像ファイル作成有無</summary>
            public bool CreateUsrlayImageUse { get; set; }

            /// <summary>お絵かきデータ画像ファイル作成用の作業フォルダ</summary>
            public string CreateUsrlayImageWorkPath { get; set; }

            /// <summary>お絵かきデータ画像を作成する最小スケール</summary>
            public int UsrlayScaleMin { get; set; }

            /// <summary>お絵かきデータ画像を作成する最大スケール</summary>
            public int UsrlayScaleMax { get; set; }

            /// <summary>お絵かきデータカラー定義</summary>
            public List<Color> UsrlayColor { get; private set; } = new List<Color>();

            /// <summary>お絵かきデータの文字列描画用フォント</summary>
            public string UsrlayTextFont { get; set; }
        }
        // 2024/05/17 Add End
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace CsUsrlayManager.Models
{
    /// <summary>
    /// ユーザレイヤデータ
    /// </summary>
    public class UserLayerData
    {
        /// <summary>
        /// 元データ (1行分)
        /// </summary>
        public string SourceLine { get; private set; }
        
        /// <summary>
        /// 種別
        /// </summary>
        public UserLayerDataKind DataKind { get; private set; }

        /// <summary>
        /// 座標
        /// </summary>
        public List<CoordinatePoint> Points { get; private set; } = new List<CoordinatePoint>();

        /// <summary>
        /// 線の種類 (線、ポリゴン、矩形、円、自由線)
        /// </summary>
        public int LineKind { get; private set; }

        /// <summary>
        ///  線の色 (線、ポリゴン、矩形、円、自由線)
        /// </summary>
        public int LineColor { get; private set; }

        /// <summary>
        /// ブラシの種類 (ポリゴン、矩形、円)
        /// </summary>
        public int BrushKind { get; private set; }

        /// <summary>
        /// ブラシの色 (ポリゴン、矩形、円)
        /// </summary>
        public int BrushColor { get; private set; }

        /// <summary>
        /// シンボル番号 (シンボル)
        /// </summary>
        public int SymbolNo { get; private set; }

        /// <summary>
        /// シンボルの角度 (シンボル)
        /// （-2147483648°～2147483647°）
        /// </summary>
        public int SymbolAngle { get; private set; }

        /// <summary>
        /// 文字列の内容 (文字列)
        /// </summary>
        public string Text { get; private set; }

        /// <summary>
        /// 文字列の装飾 (文字列)
        /// (丸付き:1000、枠付き:0100、太字:0010、縦書き:0001)
        /// </summary>
        public int TextDecoration { get; private set; }

        /// <summary>
        /// 文字色 (文字列)
        /// </summary>
        public int TextColor { get; private set; }

        /// <summary>
        /// 文字サイズ (文字列)
        /// </summary>
        public int TextSize { get; private set; }

        /// <summary>
        /// 文字列の角度 (文字列)
        /// 
        /// </summary>
        public int TextAngle { get; private set; }

        /// <summary>
        /// ユーザレイヤインデックス
        /// </summary>
        public int LayerIndex { get; private set; }

        /// <summary>
        /// 更新年月日時分秒
        /// </summary>
        public DateTime UpdateDateTime { get; private set; }

        /// <summary>
        /// ホスト名
        /// </summary>
        public string HostName { get; private set; }

        /// <summary>
        /// 不明な値 (24000固定)
        /// </summary>
        public string UnknownData { get; private set; }

        /// <summary>
        /// 文字列が縦書きかどうかを取得する。
        /// </summary>
        public bool IsTextVertical
        {
            get => (TextDecoration % 10) != 0;
        }

        /// <summary>
        /// 文字列が太字かどうかを取得する。
        /// </summary>
        public bool IsTextBold
        {
            get
            {
                // 枠付き、丸付きの場合は太字にしない
                if (IsTextBoxed || IsTextCircled)
                {
                    return false;
                }

                return ((TextDecoration / 10) % 10) != 0;
            }
        }

        /// <summary>
        /// 文字列が枠付きかどうかを取得する。
        /// </summary>
        public bool IsTextBoxed
        {
            get => ((TextDecoration / 100) % 10) != 0;
        }

        /// <summary>
        /// 文字列が丸付きかどうかを取得する。
        /// </summary>
        public bool IsTextCircled
        {
            get => ((TextDecoration / 1000) % 10) != 0;
        }

        /// <summary>
        /// ユーザレイヤデータ(1行分)を UserLayerData に変換する。
        /// </summary>
        public static UserLayerData Parse(string SourceLine)
        {
            var userLayerData = new UserLayerData();

            userLayerData.SourceLine = SourceLine;

            var items = SourceLine.Split(new[] { ',' }, StringSplitOptions.None);
            var index = 0;

            // 種別
            Enum.TryParse(items[index], out UserLayerDataKind dataKind);
            userLayerData.DataKind = dataKind;
            index++;

            // 座標数
            int.TryParse(items[index], out int coordinatePointCount);
            index++;

            // 座標
            for (int i = 0; i < coordinatePointCount; i++)
            {
                decimal.TryParse(items[index], out decimal x);
                index++;
                decimal.TryParse(items[index], out decimal y);
                index++;

                userLayerData.Points.Add(new CoordinatePoint(x, y));
            }

            // 要素1
            switch (userLayerData.DataKind)
            {
                case UserLayerDataKind.Line:        // 線
                case UserLayerDataKind.Polygon:     // ポリゴン
                case UserLayerDataKind.Rectangle:   // 矩形
                case UserLayerDataKind.Circle:      // 円
                case UserLayerDataKind.FreeLine:    // 自由線
                    // 線の種類
                    int.TryParse(items[index], out int lineKind);
                    userLayerData.LineKind = lineKind;
                    index++;
                    break;

                case UserLayerDataKind.Text:        // 文字列
                    // 文字列の内容
                    userLayerData.Text = items[index];
                    index++;
                    break;

                case UserLayerDataKind.Symbol:      // シンボル
                    // シンボル番号
                    int.TryParse(items[index], out int symbolNo);
                    userLayerData.SymbolNo = symbolNo;
                    index++;
                    break;
            }

            // 要素2
            switch (userLayerData.DataKind)
            {
                case UserLayerDataKind.Line:        // 線
                case UserLayerDataKind.FreeLine:    // 自由線
                    // 線の色
                    int.TryParse(items[index], out int lineColor);
                    userLayerData.LineColor = lineColor;
                    index++;
                    break;

                case UserLayerDataKind.Polygon:     // ポリゴン
                case UserLayerDataKind.Rectangle:   // 矩形
                case UserLayerDataKind.Circle:      // 円
                    // ブラシの種類
                    int.TryParse(items[index], out int brushKind);
                    userLayerData.BrushKind = brushKind;
                    index++;
                    break;

                case UserLayerDataKind.Text:        // 文字列
                    // 文字列の装飾
                    int.TryParse(items[index], out int textDecoration);
                    userLayerData.TextDecoration = textDecoration;
                    index++;
                    break;

                case UserLayerDataKind.Symbol:      // シンボル
                    // 0固定
                    index++;
                    break;
            }

            // 要素3
            switch (userLayerData.DataKind)
            {
                case UserLayerDataKind.Line:        // 線
                case UserLayerDataKind.FreeLine:    // 自由線
                    // 省略
                    break;

                case UserLayerDataKind.Polygon:     // ポリゴン
                case UserLayerDataKind.Rectangle:   // 矩形
                case UserLayerDataKind.Circle:      // 円
                    // 線の色
                    int.TryParse(items[index], out int lineColor);
                    userLayerData.LineColor = lineColor;
                    index++;
                    break;


                case UserLayerDataKind.Text:        // 文字列
                    // 文字サイズ
                    int.TryParse(items[index], out int textSize);
                    userLayerData.TextSize = textSize;
                    index++;
                    break;

                case UserLayerDataKind.Symbol:      // シンボル
                    // シンボルの角度
                    int.TryParse(items[index], out int angle);
                    userLayerData.SymbolAngle = angle;
                    index++;
                    break;
            }

            // 要素4
            switch (userLayerData.DataKind)
            {
                case UserLayerDataKind.Line:        // 線
                case UserLayerDataKind.FreeLine:    // 自由線
                    // 省略
                    break;

                case UserLayerDataKind.Polygon:     // ポリゴン
                case UserLayerDataKind.Rectangle:   // 矩形
                case UserLayerDataKind.Circle:      // 円
                    // ブラシの色
                    int.TryParse(items[index], out int brushColor);
                    userLayerData.BrushColor = brushColor;
                    index++;
                    break;

                case UserLayerDataKind.Text:        // 文字列
                    // 文字列の角度
                    int.TryParse(items[index], out int textAngle);
                    userLayerData.TextAngle = textAngle;
                    index++;
                    break;

                case UserLayerDataKind.Symbol:      // シンボル
                    // 省略
                    break;
            }

            // 要素5
            switch (userLayerData.DataKind)
            {
                case UserLayerDataKind.Line:        // 線
                case UserLayerDataKind.Polygon:     // ポリゴン
                case UserLayerDataKind.Rectangle:   // 矩形
                case UserLayerDataKind.Circle:      // 円
                case UserLayerDataKind.FreeLine:    // 自由線
                    // 省略
                    break;

                case UserLayerDataKind.Text:        // テキスト
                    // 文字色
                    int.TryParse(items[index], out int textColor);
                    userLayerData.TextColor = textColor;
                    index++;
                    break;

                case UserLayerDataKind.Symbol:      // シンボル
                    // 省略
                    break;
            }

            // 更新年月日時分秒
            if (DateTime.TryParseExact(items[index], "yyyyMMddHHmmss", null, DateTimeStyles.None, out DateTime updateDateTime))
            {
                userLayerData.UpdateDateTime = updateDateTime;
            }
            index++;

            // ホスト名
            userLayerData.HostName = items[index];
            index++;

            // ユーザレイヤインデックス
            int.TryParse(items[index], out int layerIndex);
            userLayerData.LayerIndex = layerIndex;
            index++;

            // 不明な値 (24000固定)
            userLayerData.UnknownData = items[index];

            return userLayerData;
        }
    }

    /// <summary>
    /// ユーザレイヤのデータ種別
    /// </summary>    
    public enum UserLayerDataKind
    {
        /// <summary>
        /// 不明
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// 線
        /// </summary>
        Line = 2,

        /// <summary>
        /// ポリゴン
        /// </summary>
        Polygon = 3,
        
        /// <summary>
        /// 文字列
        /// </summary>
        Text = 4,
        
        /// <summary>
        /// 矩形
        /// </summary>
        Rectangle = 5,
        
        /// <summary>
        /// 円
        /// </summary>
        Circle = 6,
        
        /// <summary>
        /// 自由線
        /// </summary>
        FreeLine = 7,
        
        /// <summary>
        /// シンボル
        /// </summary>
        Symbol = 8,
    }
}

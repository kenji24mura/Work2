﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsUsrlayManager.Models
{
    /// <summary>
    /// お絵描きデータ(文字列)画像管理データ
    /// </summary>
    class UserLayerTextImageManagementData
    {
        /// <summary>
        /// 連番
        /// </summary>
        public int Number { get; set; }

        /// <summary>
        /// スケール
        /// </summary>
        public int Scale { get; set; }

        /// <summary>
        /// 画像分割数
        /// </summary>
        public int NumOfImages {
            get
            {
                return ImageSizeList.Count;
            }
        }

        /// <summary>
        /// 文字列
        /// </summary>
        public string Text { get; set; }

        /// <summary>
        /// 文字サイズ
        /// </summary>
        public int TextSize { get; set; }

        /// <summary>
        /// 文字色
        /// </summary>
        public int TextColor { get; set; }

        /// <summary>
        /// 縦書きフラグ
        /// </summary>
        public bool IsVertical { get; set; }

        /// <summary>
        /// 太字フラグ
        /// </summary>
        public bool IsBold { get; set; }

        /// <summary>
        /// 文字列画像サイズリスト
        /// </summary>
        public List<Size> ImageSizeList { get; private set; } = new List<Size>();

        /// <summary>
        /// お絵描きデータ(文字列)画像管理データ(1行分)に変換する。
        /// </summary>
        public override string ToString()
        {
            var data = new List<string>();

            // 連番
            data.Add($"{Number}");

            // スケール
            data.Add($"{Scale}");

            // 画像分割数
            data.Add($"{NumOfImages}");

            // 文字列
            data.Add($"{Text}");

            // 文字サイズ
            data.Add($"{TextSize}");

            // 文字色
            data.Add($"{TextColor}");

            // 縦書きフラグ
            data.Add($"{(IsVertical ? 1 : 0)}");

            // 太字フラグ
            data.Add($"{(IsBold ? 1 : 0)}");

            // 文字列画像サイズ
            data.AddRange(ImageSizeList.Select(x => $"{x.Width},{x.Height}"));

            return string.Join(",", data);
        }
    }
}

﻿namespace CsUsrlayManager.Models
{
    /// <summary>
    /// XY座標
    /// </summary>
    public class CoordinatePoint
    {
        /// <summary>
        /// X座標
        /// </summary>
        public decimal X { get; set; }

        /// <summary>
        /// Y座標
        /// </summary>
        public decimal Y { get; set; }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="x">X座標</param>
        /// <param name="y">Y座標</param>
        public CoordinatePoint(decimal x, decimal y)
        {
            X = x;
            Y = y;
        }
    }
}

﻿using Common;
using CsUsrlayManager.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CsUsrlayManager
{
    public partial class MainForm : Form
    {
        /// <summary>お絵かきZIP最新情報ファイルのIndex</summary>
        private enum LatestInfoRowIndex
        {
            /// <summary>お絵かきZIPファイル名</summary>
            ZipFileName = 1,
            /// <summary>シェープファイル最終更新日時</summary>
            LastUpdateUsrlayDateTime = 2,
            /// <summary>以降の行は送信先端末名(地図サーバでのみ使用)</summary>
            SendTermHostName
        }

        /// <summary>お絵かきZIP最新情報ファイル監視後の処理遅延</summary>
        private static readonly int FILE_SYSTEM_WATCHER_START_DELAY = 3;

        /// <summary>ログ表示最大行数</summary>
        private static readonly int LOG_DISP_MAX = 1000;

        /// <summary>お絵かきデータ保存先</summary>
        private static string _usrlayForder;
        /// <summary>お絵かきZIP最新情報ファイルパス</summary>
        private static string _latestInfoFilePath;
        /// <summary>お絵かきZIP配信情報ファイルパス</summary>
        private static string _distributeInfoFilePath;
        /// <summary>お絵かきデータ配信結果ファイル格納フォルダ(AVM)</summary>
        private static string _distributeResultAVMServerFilePath;
        /// <summary>お絵かきデータ配信結果ファイル格納フォルダ(DM)</summary>
        private static string _distributeResultDMFilePath;
        /// <summary>車両端末用更新ファイル格納フォルダお絵かきZIPファイルパス</summary>
        private static string _AVMUpdateUsrLayPath;
        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>車両端末用更新ファイル格納フォルダお絵かきデータ画像ZIPファイルパス</summary>
        private static string _AVMUpdateUsrlayImageZipPath;
        // 2024/05/17 Add End
        /// <summary>車両端末用更新ファイルパス</summary>
        private static string _AVMUpdateUsrlayTxtPath;

        /// <summary>フォルダ監視タイマー</summary>
        readonly Timer timerMonitorFolders = new Timer();

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // iniファイル読込
            Program.IniFileSettings.ReadIniFile();

            // お絵かきデータ保存先
            _usrlayForder = Program.IniFileSettings.Settings.SaveDirUsrlayZip;
            string domainName = Program.IniFileSettings.Settings.AVMServerHostName;
            string distributeResultFile = domainName + ".txt";

            // お絵かきZIP最新情報ファイル保存先
            _latestInfoFilePath = Path.Combine(_usrlayForder, Program.IniFileSettings.Settings.UsrlayZipLatestInfo);
            // お絵かきZIP配信情報ファイル保存先
            _distributeInfoFilePath = Path.Combine(_usrlayForder, Program.IniFileSettings.Settings.UsrlayZipDistributeInfo);
            // お絵かきデータ配信結果ファイル格納フォルダ(AVM)
            _distributeResultAVMServerFilePath = Path.Combine(Program.IniFileSettings.Settings.DistributeResultAVMDir, distributeResultFile);
            // お絵かきデータ配信結果ファイル格納フォルダ(DM)
            // 2024/05/17 Mod Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
            //_distributeResultDMFilePath = Path.Combine(Program.IniFileSettings.Settings.DistributeResultDMDir, distributeResultFile);
            if (!string.IsNullOrWhiteSpace(Program.IniFileSettings.Settings.DistributeResultDMDir))
            {
                _distributeResultDMFilePath = Path.Combine(Program.IniFileSettings.Settings.DistributeResultDMDir, distributeResultFile);
            }
            // 2024/05/17 Mod End
            // 車両端末配布用お絵かきZIPファイルパス
            _AVMUpdateUsrLayPath = Path.Combine(Program.IniFileSettings.Settings.SaveDirAvmUpdate, "usrlay.zip");
            // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
            // 車両端末用更新ファイル格納フォルダお絵かきデータ画像ZIPファイルパス
            _AVMUpdateUsrlayImageZipPath = Path.Combine(Program.IniFileSettings.Settings.SaveDirAvmUpdate, Constants.UsrlayImageZip);
            // 2024/05/17 Add End
            // 車両端末配布用バージョン情報テキストファイルパス
            _AVMUpdateUsrlayTxtPath = Path.Combine(Program.IniFileSettings.Settings.SaveDirAvmUpdate, Program.IniFileSettings.Settings.ServerUsrLayVersionTxtFile);

            // お絵かきZIP最新情報ファイル監視設定
            fileSystemWatcher.Path = Program.IniFileSettings.Settings.SaveDirUsrlayZip;
            fileSystemWatcher.Filter = Program.IniFileSettings.Settings.UsrlayZipLatestInfo;
            fileSystemWatcher.SynchronizingObject = this;

            // お絵かきZIP最新情報ファイル監視タイマー設定
            timerMonitorFolders.Tick += new EventHandler(this.MonitorFilesTask);
            int distributeFileWatcherInterval = Program.IniFileSettings.Settings.UsrlayZipWatchInterval;
            timerMonitorFolders.Interval = distributeFileWatcherInterval * 1000;
            OutputInformationLog($"お絵かきZIP最新情報ファイル格納フォルダ監視タイマー起動間隔[{distributeFileWatcherInterval}]秒");

            OutputInformationLog("お絵かきZIP最新情報ファイル格納フォルダ監視タイマー開始");
            // タイマーを開始
            timerMonitorFolders.Start();
        }

        /// <summary>
        /// お絵かきZIP最新情報ファイル監視更新イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fileSystemWatcher_Changed(object sender, System.IO.FileSystemEventArgs e)
        {
            try
            {
                fileSystemWatcher.EnableRaisingEvents = false;
                OutputInformationLog("【お絵かきZIP最新情報ファイル監視】変更検知");
                // 即実行するとお絵かきZIP最新情報ファイルがロックされている可能性があるため待機させる
                OutputInformationLog($"【お絵かきZIP最新情報ファイル監視】{FILE_SYSTEM_WATCHER_START_DELAY}秒待機");
                System.Threading.Thread.Sleep(FILE_SYSTEM_WATCHER_START_DELAY * 1000);
                UsrlayZipWatchFunc();
            }
            finally
            {
                fileSystemWatcher.EnableRaisingEvents = true;
            }
        }

        /// <summary>
        /// お絵かきZIP最新情報ファイル監視作成イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fileSystemWatcher_Created(object sender, System.IO.FileSystemEventArgs e)
        {
            try
            {
                fileSystemWatcher.EnableRaisingEvents = false;
                OutputInformationLog("【お絵かきZIP最新情報ファイル監視】作成検知");
                // 即実行するとお絵かきZIP最新情報ファイルがロックされている可能性があるため待機させる
                OutputInformationLog($"【お絵かきZIP最新情報ファイル監視】{FILE_SYSTEM_WATCHER_START_DELAY}秒待機");
                System.Threading.Thread.Sleep(FILE_SYSTEM_WATCHER_START_DELAY * 1000);
                UsrlayZipWatchFunc();
            }
            finally
            {
                fileSystemWatcher.EnableRaisingEvents = true;
            }
        }

        /// <summary>
        /// お絵かきZIP最新情報ファイル監視ファイル名変更イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
        {
            try
            {
                fileSystemWatcher.EnableRaisingEvents = false;
                OutputInformationLog("【お絵かきZIP最新情報ファイル監視】ファイル名変更検知");
                // 即実行するとお絵かきZIP最新情報ファイルがロックされている可能性があるため待機させる
                OutputInformationLog($"【お絵かきZIP最新情報ファイル監視】{FILE_SYSTEM_WATCHER_START_DELAY}秒待機");
                System.Threading.Thread.Sleep(FILE_SYSTEM_WATCHER_START_DELAY * 1000);
                UsrlayZipWatchFunc();
            }
            finally
            {
                fileSystemWatcher.EnableRaisingEvents = true;
            }
        }

        /// <summary>
        /// お絵かきZIP最新情報ファイル監視タイマー起動時イベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MonitorFilesTask(object sender, EventArgs e)
        {
            OutputInformationLog("【お絵かきZIP最新情報ファイル格納フォルダ監視タイマー】処理起動");
            UsrlayZipWatchFunc();
            OutputInformationLog("【お絵かきZIP最新情報ファイル格納フォルダ監視タイマー】処理終了");
        }

        /// <summary>
        /// お絵かきZIP最新情報ファイル更新チェック
        /// </summary>
        private void UsrlayZipWatchFunc()
        {
            OutputInformationLog("お絵かきZIP最新情報ファイル格納フォルダ監視タイマー停止");
            timerMonitorFolders.Stop();

            OutputInformationLog("■お絵かきZIP最新情報ファイル更新チェック処理開始");
            try
            {
                string latestZipFileName = "";
                string distributeZipFileName = "";
                string usrlayLastUpdateDatetime = "";

                // お絵かきZIP最新情報ファイル読込
                if (File.Exists(_latestInfoFilePath))
                {
                    using (StreamReader sr = new StreamReader(_latestInfoFilePath))
                    {
                        int index = 1;
                        while (sr.EndOfStream == false)
                        {
                            switch (index)
                            {
                                case (int)LatestInfoRowIndex.ZipFileName:
                                    latestZipFileName = sr.ReadLine();
                                    OutputInformationLog($"お絵かきZIP最新情報ファイル読込：お絵かきZIPファイル名[{latestZipFileName}]");
                                    break;
                                case (int)LatestInfoRowIndex.LastUpdateUsrlayDateTime:
                                    usrlayLastUpdateDatetime = sr.ReadLine();
                                    OutputInformationLog($"お絵かきZIP最新情報ファイル読込：シェープファイル最終更新日時[{usrlayLastUpdateDatetime}]");
                                    break;
                                default:
                                    break;
                            }
                            index++;
                        }
                    }
                }
                else
                {
                    OutputInformationLog($"お絵かきZIP最新情報ファイル読込失敗：{_latestInfoFilePath}");
                    WriteDistributeResult(StatusCode.RetrieveZipFailed, null);
                    return;
                }

                // お絵かきZIP配信情報ファイル読込
                if (File.Exists(_distributeInfoFilePath))
                {
                    using (StreamReader sr = new StreamReader(_distributeInfoFilePath))
                    {
                        distributeZipFileName = sr.ReadToEnd();
                        OutputInformationLog($"お絵かきZIP配信情報ファイル読込：{distributeZipFileName}");
                    }
                }
                else
                {
                    // 存在しない場合は初回起動時想定のため処理を続行
                    OutputInformationLog($"お絵かきZIP配信情報ファイル読込失敗：{_distributeInfoFilePath}");
                }

                // 同じであれば更新なしのため処理終了
                if (latestZipFileName.Equals(distributeZipFileName))
                {
                    OutputInformationLog($"配布済みのため処理終了");
                    return;
                }

                string usrlayZipLatestPath = Path.Combine(_usrlayForder, latestZipFileName);

                if (File.Exists(usrlayZipLatestPath))
                {
                    // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
                    // お絵かきデータ画像ファイル作成
                    if (Program.IniFileSettings.CreateImageSettings.CreateUsrlayImageUse)
                    {
                        var usrlayImageZipLatestPath = Path.Combine(_usrlayForder, Path.GetFileNameWithoutExtension(usrlayZipLatestPath) + "_" + Constants.UsrlayImageZip);

                        CreateUsrlayImages(usrlayZipLatestPath, usrlayImageZipLatestPath);

                        // ZIPファイルコピー
                        try
                        {
                            File.Copy(usrlayImageZipLatestPath, _AVMUpdateUsrlayImageZipPath, true);
                            OutputInformationLog($"お絵かきデータ画像ZIP最新ファイルを作業フォルダへコピー コピー元：[{usrlayImageZipLatestPath}] コピー先：[{_AVMUpdateUsrlayImageZipPath}]");
                        }
                        catch
                        {
                            OutputErrorLog($"お絵かきデータ画像ZIP最新ファイルを作業フォルダへコピー失敗 コピー元：[{usrlayImageZipLatestPath}] コピー先：[{_AVMUpdateUsrlayImageZipPath}]");
                            WriteDistributeResult(StatusCode.FileCopyError, null);
                            throw;
                        }
                    }
                    // 2024/05/17 Add End

                    // ZIPファイルコピー
                    try
                    {
                        File.Copy(usrlayZipLatestPath, _AVMUpdateUsrLayPath, true);
                        OutputInformationLog($"お絵かきZIP最新ファイルを作業フォルダへコピー コピー元：[{usrlayZipLatestPath}] コピー先：[{_AVMUpdateUsrLayPath}]");
                    }
                    catch (Exception ex)
                    {
                        OutputErrorLog($"お絵かきZIP最新ファイルを作業フォルダへコピー失敗 コピー元：[{usrlayZipLatestPath}] コピー先：[{_AVMUpdateUsrLayPath}]");
                        WriteDistributeResult(StatusCode.FileCopyError, null);
                        throw ex;
                    }

                    // 車両端末配布用バージョン情報テキストファイル更新
                    string writeTime = File.GetLastWriteTime(usrlayZipLatestPath).ToString("yyyyMMddHHmmss");
                    File.WriteAllText(_AVMUpdateUsrlayTxtPath, writeTime);
                    OutputInformationLog($"車両端末配布用バージョン情報テキストファイル更新　[{_AVMUpdateUsrlayTxtPath}] ファイル内容：{writeTime}");

                    // お絵かきZIP配信情報ファイル更新
                    File.WriteAllText(_distributeInfoFilePath, latestZipFileName);
                    OutputInformationLog($"お絵かきZIP配信情報ファイル更新　[{_distributeInfoFilePath}] ファイル内容：{latestZipFileName}");

                    // お絵かきデータ配信結果ファイルをデータメンテ端末へアップロード
                    WriteDistributeResult(StatusCode.Completed, usrlayLastUpdateDatetime);

                    // 世代管理
                    FileGenerationManagement.UsrlayZipFileGeneration(_usrlayForder, Program.IniFileSettings.Settings.UsrlayZipGeneration, Program.Log);
                }
                else
                {
                    OutputErrorLog($"お絵かきZIP最新ファイルが存在しないため処理終了：[{usrlayZipLatestPath}]");
                }
            }
            catch (Exception ex)
            {
                OutputErrorLog($"システムエラー：[{ex}]");
            }
            finally
            {
                OutputInformationLog($"■お絵かきZIP最新情報ファイル更新チェック処理終了");
                OutputInformationLog("お絵かきZIP最新情報ファイル格納フォルダ監視タイマー開始");
                timerMonitorFolders.Start();
            }

        }

        /// <summary>
        /// お絵かきデータ配信結果ファイル更新&コピー
        /// </summary>
        /// <param name="status"></param>
        /// <param name="latestDatetime"></param>
        private void WriteDistributeResult(StatusCode status, string latestDatetime)
        {
            // AVMサーバのお絵かきデータ配信結果ファイル読込
            DistributeResult avmDistributeResult = new DistributeResult();
            if (File.Exists(_distributeResultAVMServerFilePath))
            {
                using (StreamReader sr = new StreamReader(_distributeResultAVMServerFilePath))
                {
                    string distributeResult = sr.ReadToEnd();
                    avmDistributeResult = new DistributeResult(distributeResult);
                }
            }

            avmDistributeResult.DistributeStatusCode = status;
            if (!string.IsNullOrEmpty(latestDatetime)) { avmDistributeResult.UpdateDatetime = latestDatetime; }

            string distributeTxt = avmDistributeResult.GetModelToDistributeResultTxt();
            File.WriteAllText(_distributeResultAVMServerFilePath, distributeTxt);
            OutputInformationLog($"お絵かきZIP配信情報ファイル更新 [{_distributeResultAVMServerFilePath}]：{distributeTxt}");

            // 2024/05/17 Mod Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
            //File.Copy(_distributeResultAVMServerFilePath, _distributeResultDMFilePath, true);
            //OutputInformationLog($"お絵かきZIP配信情報ファイルコピー コピー元：[{_distributeResultAVMServerFilePath}] コピー先：[{_distributeResultDMFilePath}]");
            if (!string.IsNullOrWhiteSpace(_distributeResultDMFilePath))
            {
                File.Copy(_distributeResultAVMServerFilePath, _distributeResultDMFilePath, true);
                OutputInformationLog($"お絵かきZIP配信情報ファイルコピー コピー元：[{_distributeResultAVMServerFilePath}] コピー先：[{_distributeResultDMFilePath}]");
            }
            // 2024/05/17 Mod End
        }

        /// <summary>
        /// 閉じるボタンイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonClose_Click(object sender, EventArgs e)
        {
            OutputOperationLog("【閉じるボタン】押下");
            string msg = $"AVMサーバお絵かきデータ管理画面を閉じると、お絵かきデータの更新が行われなくなります。\r\n本当に閉じてもよろしいでしょうか？";
            DialogResult result = MessageBox.Show(msg, this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.Yes)
            {
                OutputOperationLog("【確認ダイアログ - はい】押下");
                this.Close();
            }
            else
            {
                OutputOperationLog("【確認ダイアログ - いいえ】押下");
                return;
            }
        }

        /// <summary>
        /// ログ表示リストボックス更新
        /// </summary>
        /// <param name="msg"></param>
        private void ListBoxLogDispAdd(string msg)
        {
            if (listBoxLogDisp.Items.Count > LOG_DISP_MAX)
            {
                listBoxLogDisp.Items.RemoveAt(0);
            }
            listBoxLogDisp.Items.Add(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + " ： " + msg);

            // 表示位置スクロール
            listBoxLogDisp.EndUpdate();
            listBoxLogDisp.TopIndex = listBoxLogDisp.Items.Count - 1;
        }

        /// <summary>
        /// ログ出力
        /// </summary>
        /// <param name="msgLevel"></param>
        /// <param name="msg"></param>
        static void OutputLog(string msgLevel, string msg)
        {
            Program.Log.OutPutLog(msgLevel, msg);
        }

        /// <summary>
        /// 情報ログ出力 (コンソール出力あり)
        /// </summary>
        /// <param name="msg"></param>
        private void OutputInformationLog(string msg)
        {
            OutputLog("I", msg);
            ListBoxLogDispAdd(msg);
        }

        /// <summary>
        /// 情報ログ出力 
        /// </summary>
        /// <param name="msg"></param>
        static void OutputOperationLog(string msg)
        {
            OutputLog("O", msg);
        }

        /// <summary>
        /// エラーログ出力 (コンソール出力あり)
        /// </summary>
        /// <param name="msg"></param>
        private void OutputErrorLog(string msg)
        {
            OutputLog("E", msg);
            ListBoxLogDispAdd(msg);
        }

        /// <summary>
        /// CreateParamsプロパティオーバーライド
        /// フォーム右上の閉じるボタンを無効化
        /// </summary>
        protected override CreateParams CreateParams
        {
            get
            {
                const int CS_NOCLOSE = 0x200;

                CreateParams createParams = base.CreateParams;
                createParams.ClassStyle |= CS_NOCLOSE;

                return createParams;
            }
        }

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// お絵かきデータ画像ファイル作成
        /// </summary>
        private void CreateUsrlayImages(string usrlayZipPath, string usrlayImageZipPath)
        {
            DirectoryInfo workFolder;
            DirectoryInfo usrlayImageFolder;
            string usrlayFolderPath;

            try
            {
                // 作業用フォルダを取得 (存在しない場合は作成)
                workFolder = Directory.CreateDirectory(Program.IniFileSettings.CreateImageSettings.CreateUsrlayImageWorkPath);

                // 作業用フォルダ内にファイルが残っている場合は削除
                workFolder.EnumerateFiles().ToList().ForEach(x => x.Delete());

                // 作業用フォルダ内のサブフォルダも削除
                workFolder.EnumerateDirectories().ToList().ForEach(x => x.Delete(true));

                // 作業フォルダに文字列画像ファイル格納フォルダを作成
                usrlayImageFolder = Directory.CreateDirectory(Path.Combine(workFolder.FullName, Constants.UsrlayImageFolderName));

                // コピーしたお絵かきZIPファイルを解凍
                ZipFile.ExtractToDirectory(usrlayZipPath, workFolder.FullName);

                // お絵かきデータフォルダパス
                usrlayFolderPath = Path.Combine(workFolder.FullName, Constants.UsrlayFolderName);

                OutputInformationLog($"お絵かきデータ画像ファイル生成準備:成功");
            }
            catch (Exception ex)
            {
                OutputErrorLog($"お絵かきデータ画像ファイル生成準備:失敗：{ex}");
                WriteDistributeResult(StatusCode.GenerateImageFileError, null);
                throw;
            }

            List<UserLayerTextImageManagementData> userLayerTextImageManagementDataList;
            
            try
            {
                // 住宅地図のお絵かきデータファイルをすべて読み込む
                var userLayerDataList = ReadAllUserLayerFiles(Path.Combine(usrlayFolderPath, Constants.UsrlayTownMapFolderName));

                userLayerTextImageManagementDataList = CreateUserLayerTextImageData(userLayerDataList, usrlayImageFolder.FullName);

                OutputInformationLog($"お絵かきデータ（文字列）画像ファイル生成:成功");
            }
            catch (Exception ex)
            {
                OutputErrorLog($"お絵かきデータ（文字列）画像ファイル生成:失敗：{ex}");
                WriteDistributeResult(StatusCode.GenerateImageFileError, null);
                throw;
            }

            // お絵かきデータ（文字列）画像管理ファイル作成
            var textImageManegementFilePath = Path.Combine(usrlayImageFolder.FullName, Constants.UsrlayTextImageManagementFile);

            try
            {
                var imageDataList = userLayerTextImageManagementDataList.Select(x => x.ToString());

                File.WriteAllLines(textImageManegementFilePath, imageDataList, Encoding.GetEncoding("shift_jis"));

                OutputInformationLog($"お絵かきデータ（文字列）画像管理ファイル生成:成功");
            }
            catch (Exception ex)
            {
                OutputErrorLog($"お絵かきデータ（文字列）画像管理ファイル生成:失敗：{ex}");
                WriteDistributeResult(StatusCode.GenerateImageManagementFileError, null);
                throw;
            }

            // お絵かきデータ（文字列）画像ファイル格納フォルダをzip圧縮
            ZipFile.CreateFromDirectory(usrlayImageFolder.FullName, usrlayImageZipPath, CompressionLevel.Optimal, true);
        }
        // 2024/05/17 Add End

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// 指定されたフォルダ内のお絵かきデータファイルを全て読み込み、UserLayerData のリストを返す
        /// </summary>
        private List<UserLayerData> ReadAllUserLayerFiles(string userLayerFolderPath)
        {
            var userLayerDataList = new List<UserLayerData>();

            var userLayerFiles = Directory.EnumerateFiles(userLayerFolderPath, "*.txt");

            foreach (var filePath in userLayerFiles)
            {
                OutputInformationLog($"お絵かきデータファイル読込：{filePath}");

                string[] sourceLines;

                try
                {
                    sourceLines = File.ReadAllLines(filePath, Encoding.GetEncoding("shift_jis"));
                }
                catch (Exception ex)
                {
                    OutputErrorLog($"お絵かきデータファイル読込エラー：{filePath}{Environment.NewLine}{ex}");
                    continue;
                }

                int lineNo = 0;
                foreach (var source in sourceLines)
                {
                    lineNo++;

                    if (source.StartsWith("#"))
                    {
                        // 削除済みデータ
                        continue;
                    }

                    UserLayerData userLayerData;

                    try
                    {
                        userLayerData = UserLayerData.Parse(source);
                    }
                    catch (Exception ex)
                    {
                        OutputErrorLog($"お絵かきデータ解析処理エラー：{filePath} ({lineNo}){Environment.NewLine}{source}{Environment.NewLine}{ex}");
                        continue;
                    }

                    userLayerDataList.Add(userLayerData);
                }
            }

            return userLayerDataList;
        }
        // 2024/05/17 Add End

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// 指定されたお絵かきデータからテキスト画像ファイルを作成し、UserLayerTextImageManagementData のリストを返す
        /// </summary>
        private List<UserLayerTextImageManagementData> CreateUserLayerTextImageData(List<UserLayerData> userLayerDataList, string usrlayImageFolderPath)
        {
            var fontSizeCoefficient = new Dictionary<int, double>();
            fontSizeCoefficient[1] = 0.74;
            fontSizeCoefficient[2] = 0.37;
            fontSizeCoefficient[3] = 0.14;
            fontSizeCoefficient[4] = 0.06;

            var imageDataList = new List<UserLayerTextImageManagementData>();

            var number = 0;

            // お絵かきデータのリストを絞り込む
            var userLayerTextDataList = userLayerDataList.Where(x => x.DataKind == UserLayerDataKind.Text);

            foreach (var userLayerData in userLayerTextDataList)
            {
                if (imageDataList.Any(x =>
                    x.Text == userLayerData.Text &&
                    x.TextSize == userLayerData.TextSize &&
                    x.TextColor == userLayerData.TextColor &&
                    x.IsVertical == userLayerData.IsTextVertical &&
                    x.IsBold == userLayerData.IsTextBold))
                {
                    // 重複データは除外
                    continue;
                }

                number++;

                for (var scale = Program.IniFileSettings.CreateImageSettings.UsrlayScaleMin; scale <= Program.IniFileSettings.CreateImageSettings.UsrlayScaleMax; scale++)
                {
                    var imageData = new UserLayerTextImageManagementData
                    {
                        Number = number,
                        Scale = scale,
                        Text = userLayerData.Text,
                        TextSize = userLayerData.TextSize,
                        TextColor = userLayerData.TextColor,
                        IsVertical = userLayerData.IsTextVertical,
                        IsBold = userLayerData.IsTextBold
                    };

                    var textSize = (float)(imageData.TextSize * (fontSizeCoefficient.ContainsKey(scale) ? fontSizeCoefficient[scale] : 0.05));
                    
                    var font = new Font(Program.IniFileSettings.CreateImageSettings.UsrlayTextFont, textSize, (imageData.IsBold ? FontStyle.Bold : FontStyle.Regular));

                    var color = Program.IniFileSettings.CreateImageSettings.UsrlayColor[imageData.TextColor];

                    var images = GenerateStringImages(imageData.Text, color, imageData.IsVertical, font, new Size(Constants.UsrlayImageSizeMaxWidth, Constants.UsrlayImageSizeMaxHeight), Constants.UsrlayImageMargin);

                    foreach ((Bitmap image, int index) in images.Select((image, index) => (image, index)))
                    {
                        imageData.ImageSizeList.Add(image.Size);

                        var filename = $"{Constants.UsrlayTextImagePrefix}_{imageData.Number}_{imageData.Scale}_{index + 1}.{Constants.UsrlayTextImageExtension}";

                        image.Save(Path.Combine(usrlayImageFolderPath, filename));

                    }

                    imageDataList.Add(imageData);
                }
            }
            
            return imageDataList;
        }
        // 2024/05/17 Add End

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// 指定されたテキストの画像データを作成し、Bitmap のリストを返す
        /// </summary>
        List<Bitmap> GenerateStringImages(string text, Color color, bool isVertical, Font font, Size maxSize, int margin)
        {
            var images = new List<Bitmap>();

            var brush = new SolidBrush(color);

            using (var stringFormat = new StringFormat(StringFormat.GenericTypographic))
            {
                stringFormat.Alignment = StringAlignment.Near;
                stringFormat.LineAlignment = StringAlignment.Near;

                stringFormat.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces;

                if (isVertical)
                {
                    stringFormat.FormatFlags |= StringFormatFlags.DirectionVertical;
                }

                var beginIndex = 0;
                for (var index = 0; index <= text.Length; index++)
                {
                    string textPart;
                    Size size;

                    if (index < text.Length)
                    {
                        textPart = text.Substring(beginIndex, index - beginIndex + 1);
                    
                        size = MeasureStringAdjustment(textPart, font, stringFormat);

                        if (size.Width < maxSize.Width - margin * 2 && size.Height < maxSize.Height - margin * 2)
                        {
                            // 最大サイズを超えていない場合、一文字増やして再度計測する。
                            continue;
                        }

                        // 最大サイズを超えている場合、1文字前までの画像を作成する。
                        textPart = text.Substring(beginIndex, index - beginIndex);

                        size = MeasureStringAdjustment(textPart, font, stringFormat);
                    }
                    else
                    {
                        // 最後の文字を超えたので、残りの文字列の画像を作成する。
                        textPart = text.Substring(beginIndex, text.Length - beginIndex);

                        size = MeasureStringAdjustment(textPart, font, stringFormat);
                    }

                    var bmp = new Bitmap(size.Width + margin * 2, size.Height + margin * 2);

                    using (var graphics = Graphics.FromImage(bmp))
                    {
                        graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
                        graphics.PageUnit = GraphicsUnit.Pixel;

                        graphics.DrawString(textPart, font, brush, margin, margin, stringFormat);
                    }

                    images.Add(bmp);

                    beginIndex = index;
                }
            }

            return images;
        }
        // 2024/05/17 Add End

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// 指定されたテキストの画像データを作成し、Bitmap のリストを返す
        /// </summary>
        static Size MeasureStringAdjustment(string text, Font font, StringFormat stringFormat)
        {
            using (var bmp = new Bitmap(1, 1))
            using (var graphics = Graphics.FromImage(bmp))
            {
                graphics.TextRenderingHint = TextRenderingHint.AntiAlias;
                graphics.PageUnit = GraphicsUnit.Pixel;
                var sizef = graphics.MeasureString(text, font, int.MaxValue, stringFormat);
                return Size.Ceiling(sizef);
            }
        }
        // 2024/05/17 Add End
    }
}

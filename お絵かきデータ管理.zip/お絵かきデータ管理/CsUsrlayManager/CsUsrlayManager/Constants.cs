﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsUsrlayManager
{
    /// <summary>
    /// 定数定義
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// お絵かきデータZIPファイル名
        /// </summary>
        public const string UsrlayZip = "usrlay.zip";

        /// <summary>
        /// お絵かきデータ画像ZIPファイル名
        /// </summary>
        public const string UsrlayImageZip = "usrlayImage.zip";

        /// <summary>
        /// お絵かきデータ(文字列)画像管理ファイル名
        /// </summary>
        public const string UsrlayTextImageManagementFile = "usrlayTextImageManagement.txt";

        /// <summary>
        /// お絵かきデータフォルダ名
        /// </summary>
        public const string UsrlayFolderName = "usrlay";

        /// <summary>
        /// 住宅地図用のお絵かきデータフォルダ名
        /// </summary>
        public const string UsrlayTownMapFolderName = "011";

        /// <summary>
        /// お絵かきデータ(文字列)画像ファイル格納用のフォルダ名
        /// </summary>
        public const string UsrlayImageFolderName = "usrlayImage";

        /// <summary>
        /// お絵かきデータ(文字列)画像ファイルのプレフィックス
        /// </summary>
        public const string UsrlayTextImagePrefix = "text";

        /// <summary>
        /// お絵かきデータ画像ファイルの拡張子
        /// </summary>
        public const string UsrlayTextImageExtension = "png";

        /// <summary>
        /// お絵かきデータ画像ファイルの幅の最大値 (ピクセル)
        /// </summary>
        public const int UsrlayImageSizeMaxWidth = 256;

        /// <summary>
        /// お絵かきデータ画像ファイルの高さの最大値 (ピクセル)
        /// </summary>
        public const int UsrlayImageSizeMaxHeight = 256;

        /// <summary>
        /// お絵かきデータ画像ファイルのマージン (ピクセル)
        /// </summary>
        public const int UsrlayImageMargin = 2;
    }
}

﻿using System;
using System.ComponentModel;

namespace Common
{
    public class DistributeResult
    {
        /// <summary>お絵かきデータ配信結果ファイルフォーマット</summary>
        private enum DistributeResultTextOrder
        {
            /// <summary>配信状況コード</summary>
            DistributeStatusCode,
            /// <summary>最終更新日時</summary>
            UpdateDatetime
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="text"></param>
        public DistributeResult()
        {
            DistributeStatusCode = StatusCode.FileOpenError;
            UpdateDatetime = "-";
        }

        /// <summary>
        /// お絵かきデータ配信結果ファイル変換用コンストラクタ
        /// </summary>
        /// <param name="text"></param>
        public DistributeResult(string text)
        {
            string[] arr = text.Split(',');
            if (arr.Length == Enum.GetNames(typeof(DistributeResultTextOrder)).Length)
            {
                DistributeStatusCode = (StatusCode)int.Parse(arr[(int)DistributeResultTextOrder.DistributeStatusCode]);
                UpdateDatetime = arr[(int)DistributeResultTextOrder.UpdateDatetime];
            }
            else
            {
                DistributeStatusCode = StatusCode.FileOpenError;
                UpdateDatetime = "-";
            }
        }

        /// <summary>
        /// DistributeResultモデルからお絵かきデータ配信結果ファイル出力用のString配列を作成
        /// </summary>
        /// <returns></returns>
        public string GetModelToDistributeResultTxt()
        {
            string[] distributeTxtList = { ((int)DistributeStatusCode).ToString(), UpdateDatetime };
            return string.Join(",", distributeTxtList, 0, distributeTxtList.Length);
        }

        /// <summary>配信状況コード</summary>
        [DisplayName("配信状況コード")]
        public StatusCode DistributeStatusCode { get; set; }

        /// <summary>最終更新日時</summary>
        [DisplayName("最終更新日時")]
        public string UpdateDatetime { get; set; }
    }
}

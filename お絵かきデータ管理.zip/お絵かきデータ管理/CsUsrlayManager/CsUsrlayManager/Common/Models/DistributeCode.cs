﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace Common
{
    /// <summary>配信状況コード</summary>
    public enum StatusCode
    {
        /// <summary>正常終了</summary>
        [Display(Name = "正常終了")]
        Completed = 0,
        /// <summary>配信中</summary>
        [Display(Name = "配信中")]
        InProgressDistribute = 1,
        /// <summary>アップロード失敗</summary>
        [Display(Name = "アップロード失敗")]
        UploadFailed = 11,
        /// <summary>タイムアウト</summary>
        [Display(Name = "タイムアウト")]
        TimeOut = 12,
        /// <summary>お絵かきZIP取得失敗</summary>
        [Display(Name = "お絵かきデータ取得失敗")]
        RetrieveZipFailed = 21,
        /// <summary>お絵かきデータ展開エラー</summary>
        [Display(Name = "お絵かきデータ展開エラー")]
        ExtracteZipFailed = 22,
        /// <summary>お絵かきデータファイルコピーエラー</summary>
        [Display(Name = "お絵かきデータファイルコピーエラー")]
        FileCopyError = 23,

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>お絵かきデータ（文字列）画像ファイル生成エラー</summary>
        [Display(Name = "お絵かきデータ（文字列）画像ファイル生成エラー")]
        GenerateImageFileError = 31,
        /// <summary>お絵かきデータ（文字列）画像ファイル生成エラー</summary>
        [Display(Name = "お絵かきデータ（文字列）画像管理ファイル生成エラー")]
        GenerateImageManagementFileError = 32,
        // 2024/05/17 Add End

        /// <summary>配信結果ファイル読込エラー</summary>
        [Display(Name = "配信結果ファイル読込エラー")]
        FileOpenError = 91,
        /// <summary>配信結果ファイルがありません</summary>
        [Display(Name = "配信結果ファイルがありません")]
        FileNotFound = 92
    }

    /// <summary>配信結果コード</summary>
    public enum ResultCode
    {
        /// <summary>正常：○</summary>
        [Display(Name = "○")]
        Completed,
        /// <summary>異常：×</summary>
        [Display(Name = "×")]
        Failed,
        /// <summary>その他：―</summary>
        [Display(Name = "―")]
        Other
    }

    /// <summary>Enum拡張メソッド用クラス</summary>
    public static class EnumExtension
    {
        /// <summary>EnumのDisplay要素を取得</summary>
        public static TAttribute GetAttribute<TAttribute>(this Enum enumValue)
                where TAttribute : Attribute
        {
            try
            {
                return enumValue.GetType()
                .GetMember(enumValue.ToString())
                .First()
                .GetCustomAttribute<TAttribute>();
            }
            catch (Exception)
            {
                Enum errorEnum = enumValue;
                if (enumValue is StatusCode)
                {
                    errorEnum = StatusCode.FileOpenError;
                }
                if (enumValue is ResultCode)
                {
                    errorEnum = ResultCode.Other;
                }
                return errorEnum.GetType()
                .GetMember(errorEnum.ToString())
                .First()
                .GetCustomAttribute<TAttribute>();
            }

        }
    }

    public static class DistributeCode
    {
        /// <summary>配信状況から配信結果を取得</summary>
        public static ResultCode GetResultCode(StatusCode status)
        {
            switch (status)
            {
                // 正常
                case StatusCode.Completed:
                    return ResultCode.Completed;
                // 異常
                case StatusCode.UploadFailed:
                case StatusCode.TimeOut:
                case StatusCode.RetrieveZipFailed:
                case StatusCode.ExtracteZipFailed:
                case StatusCode.FileCopyError:
                // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
                case StatusCode.GenerateImageFileError:
                case StatusCode.GenerateImageManagementFileError:
                    // 2024/05/17 Add End
                    return ResultCode.Failed;
                // その他
                case StatusCode.InProgressDistribute:
                case StatusCode.FileOpenError:
                case StatusCode.FileNotFound:
                default:
                    return ResultCode.Other;
            }
        }
    }

}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Common
{
    class FileGenerationManagement
    {
        /// <summary>お絵かきZIPファイル名パターン</summary>
        private const string usrlayZipNamePattern = "usrlay_??????????????.zip";

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>お絵かきデータ画像ZIPファイル名パターン</summary>
        private const string usrlayImageZipNamePattern = "usrlay_??????????????_usrlayImage.zip";
        // 2024/05/17 Add End

        /// <summary>
        /// お絵かきデータZIPファイル世代管理
        /// </summary>
        /// <param name="dir"></param>
        /// <param name="generationNum"></param>
        /// <param name="logClass"></param>
        public static void UsrlayZipFileGeneration(string dir, int generationNum, LogClass logClass)
        {
            ExecuteManageFileGeneration(dir, generationNum, usrlayZipNamePattern, logClass);
            // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
            ExecuteManageFileGeneration(dir, generationNum, usrlayImageZipNamePattern, logClass);
            // 2024/05/17 Add End
        }

        /// <summary>
        /// ファイル世代管理
        /// </summary>
        /// <param name="dir"></param>
        /// <param name="generationNum"></param>
        /// <param name="pattern"></param>
        /// <param name="logClass"></param>
        private static void ExecuteManageFileGeneration(string dir, int generationNum, string pattern, LogClass logClass)
        {
            logClass.OutPutLog("I", "ファイル世代管理処理開始");
            // 対象のファイル名を取得
            // ファイル名の日時情報("yyyymmddHHMMSS"の部分)が古いファイル名を取得したいめ、昇順でソートする
            string searchPattern = pattern;
            DirectoryInfo di = new DirectoryInfo(dir);
            List<FileInfo> files = di.GetFiles(searchPattern).OrderBy(f => f.Name).ToList();

            // ファイル数を取得
            int fileCount = files.Count;

            logClass.OutPutLog("I", $"対象フォルダ[{dir}] ファイル数[{fileCount}] ファイル世代管理数[{generationNum}]");

            // ファイル世代管理数に達した場合
            if (fileCount > generationNum)
            {
                logClass.OutPutLog("I", "ファイル世代管理数に達したためファイル削除処理実行");
                // ファイル世代管理数を超えている場合は、古い方から順に削除する
                foreach (FileInfo file in files)
                {
                    // 保存数オーバーのファイル削除
                    try
                    {
                        logClass.OutPutLog("I", $"ファイル削除：{file.Name}");
                        file.Delete();
                    }
                    catch (Exception ex)
                    {
                        logClass.OutPutLog( "E", $"ファイル削除失敗：{file.Name}{Environment.NewLine}{ex}");
                    }

                    // ファイル数をデクリメント
                    fileCount--;
                    if (fileCount <= generationNum)
                    {
                        break;
                    }
                }
            }
            logClass.OutPutLog("I", "ファイル世代管理処理終了");
        }
    }
}

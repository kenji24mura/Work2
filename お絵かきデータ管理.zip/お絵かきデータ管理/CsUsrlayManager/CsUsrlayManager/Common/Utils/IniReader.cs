﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace Common
{
    class IniReader
    {
        /// <summary>Log_Settings</summary>
        private const string INI_SECTION_LOG = "Log_Settings";

        [DllImport("kernel32.dll")]
        private static extern int GetPrivateProfileString(string lpAppName, string lpKeyName, string lpDefault,
             StringBuilder lpReturnedString, int nSize, string lpFileName);

        /// <summary>
        /// INIファイル読込
        /// </summary>
        /// <param name="strSection"></param>
        /// <param name="strKey"></param>
        /// <param name="strDefault"></param>
        /// <returns></returns>
        private static string GetIniString(string filepath, string strSection, string strKey, string strDefault = "")
        {
            // INIファイルから読み込み
            StringBuilder sb = new StringBuilder(1024);
            int iRead = GetPrivateProfileString(strSection, strKey, strDefault, sb, sb.Capacity, AppDomain.CurrentDomain.BaseDirectory + filepath);

            if (iRead == 0)
                return strDefault;

            return sb.ToString();
        }

        /// <summary>
        /// INIファイル読込
        /// </summary>
        /// <param name="strKey"></param>
        /// <param name="strDefault"></param>
        /// <returns></returns>
        public static string GetIniValue(LogClass log, string filepath, string section, string strKey, string strDefault = "")
        {
            string value = GetIniString(filepath, section, strKey, strDefault);
            OutputLog(section, strKey, value, log);
            return value;
        }

        /// <summary>
        /// INIファイル読込_Log
        /// </summary>
        /// <param name="strKey"></param>
        /// <param name="strDefault"></param>
        /// <returns></returns>
        public static string GetIniSectionLog(string filepath, string strKey, string strDefault = "")
        {
            return GetIniString(filepath, INI_SECTION_LOG, strKey, strDefault);
        }

        /// <summary>
        /// ログ出力
        /// </summary>
        /// <param name="section"></param>
        /// <param name="key"></param>
        /// <param name="value"></param>
        static void OutputLog(string section, string key, string value, LogClass log)
        {
            log.OutPutLog("I", $"INIファイル読込：Section=[{section}] key=[{key}] value=[{value}]");
        }

        /// <summary>
        /// INIファイルの設定値string→int変換
        /// </summary>
        /// <param name="str"></param>
        /// <param name="defaultNum"></param>
        /// <returns></returns>
        public static int StringToIntForIniFile(string str, int defaultNum)
        {
            int num = defaultNum;
            if (!string.IsNullOrEmpty(str))
            {
                if (int.TryParse(str, out int iBuf))
                {
                    // 1以上を有効とし、0以下はデフォルト値
                    if (iBuf > 0)
                    {
                        num = iBuf;
                    }
                }
            }
            return num;
        }

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// INIファイルの設定値string→int変換
        /// </summary>
        /// <param name="str"></param>
        /// <param name="lowerLimit"></param>
        /// <param name="upperLimit"></param>
        /// <param name="defaultNum"></param>
        /// <returns></returns>
        public static int StringToIntForIniFile(string str, int lowerLimit, int upperLimit, int defaultNum)
        {
            int num = StringToIntForIniFile(str, defaultNum);

            // 範囲外の場合はデフォルト値とする
            if (num < lowerLimit)
            {
                num = defaultNum;
            }

            if (num > upperLimit)
            {
                num = defaultNum;
            }

            return num;
        }
        // 2024/05/17 Add End

        /// <summary>
        /// INIファイルの設定値string→long変換
        /// </summary>
        /// <param name="str"></param>
        /// <param name="defaultNum"></param>
        /// <returns></returns>
        public static long StringToLongForIniFile(string str, long defaultNum)
        {
            long num = defaultNum;
            if (!string.IsNullOrEmpty(str))
            {
                if (int.TryParse(str, out int iBuf))
                {
                    // 1以上を有効とし、0以下はデフォルト値
                    if (iBuf > 0)
                    {
                        num = iBuf;
                    }
                }
            }
            return num;
        }

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// INIファイルの設定値string→bool変換
        /// 0：false、1：true、その他は全てデフォルト値とする。
        /// </summary>
        /// <param name="str"></param>
        /// <param name="defaultNum"></param>
        /// <returns></returns>
        public static bool StringToBoolForIniFile(string str, bool defaultNum)
        {
            if (string.IsNullOrWhiteSpace(str))
            {
                return defaultNum;
            }
            
            if (int.TryParse(str, out int iBuf))
            {
                switch (iBuf)
                {
                    case 0:
                        return false;
                    case 1:
                        return true;
                    default:
                        return defaultNum;
                }
            }

            return defaultNum;
        }
        // 2024/05/17 Add End

        // 2024/05/17 Add Start 【柏羽藤】マップルナビ住宅地図取込対応 No.3：マップルナビへのお絵かきデータ登録機能追加 東都）古谷
        /// <summary>
        /// INIファイルの設定値string→Color変換
        /// </summary>
        /// <param name="str"></param>
        /// <param name="defaultNum"></param>
        /// <returns></returns>
        public static Color StringToColorForIniFile(string str, Color defaultNum)
        {
            var rgb = str.Split(',');

            if (rgb.Length != 3)
            {
                return defaultNum;
            }

            if (!byte.TryParse(rgb[0], out byte red))
            {
                return defaultNum;
            }

            if (!byte.TryParse(rgb[1], out byte green))
            {
                return defaultNum;
            }

            if (!byte.TryParse(rgb[2], out byte blue))
            {
                return defaultNum;
            }

            return Color.FromArgb(red, green, blue);
        }
        // 2024/05/17 Add End
    }
}

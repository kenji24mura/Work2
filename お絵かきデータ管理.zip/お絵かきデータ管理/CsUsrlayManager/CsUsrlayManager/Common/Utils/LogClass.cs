﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;

namespace Common
{
    /// <summary>
    /// ログ出力クラス
    /// </summary>
    public class LogClass
    {
        private static readonly DefaultTraceListener drl = (DefaultTraceListener)Trace.Listeners["Default"];

        /// <summary>ログ初期処理フラグ</summary>
        private static bool _LogInitFlg = true;
        /// <summary>ログファイルパス</summary>
        private static string _LogFilePath;
        /// <summary>ログファイルパス</summary>
        private static string _LogFolderPath;

        /// <summary>アプリケーション名</summary>
        private string AppName { get; set; }
        /// <summary>ログファイル最大サイズ(MB)</summary>
        private long LogFilesizeMax { get; set; }
        /// <summary>ログファイル世代管理数</summary>
        private int LogGeneration { get; set; }


        public LogClass(string appName, long logFileSizeMax, int logGeneration)
        {
            AppName = appName;
            // ログ設定(共通)のログファイル最大サイズを設定
            LogFilesizeMax = logFileSizeMax * 1024 * 1024;
            // ログ設定(共通)のログファイル世代管理数を取得
            LogGeneration = logGeneration;
        }

        /// <summary>
        /// ログを出力する
        /// </summary>
        /// <param name="strMsgLevel">メッセージの出力レベル Ｉ(information)/W(warning)/E(Error)/D(Debug)/O(Operation)</param>
        /// <param name="strInfo">メッセージの出力内容</param>
        public void OutPutLog(String strMsgLevel, String strInfo)
        {
            string proc_name = Process.GetCurrentProcess().ProcessName.Split('.')[0];
            _LogFolderPath = Path.Combine(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), "log");

            string startLog = "";           // 開始ログ

            // ログ初期処理フラグがONの場合、初期処理を実施する
            if (_LogInitFlg)
            {
                Directory.CreateDirectory(_LogFolderPath);

                // バージョン情報を取得
                string path = proc_name + @".exe";
                FileVersionInfo fvi = FileVersionInfo.GetVersionInfo(path);
                string fileVersion = fvi.FileVersion;

                // 開始ログ作成
                startLog = "◇----------プロセス起動(Ver." + fileVersion + ")----------◇";

                // ログファイル名取得
                string logFileName = proc_name + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".log";
                _LogFilePath = Path.Combine(_LogFolderPath, logFileName);
                drl.LogFileName = _LogFilePath;

                // ログ初期処理フラグをOFF
                _LogInitFlg = false;
            }

            // ログ世代管理
            _LogFilePath = LogGenerationManagement(proc_name, _LogFilePath, LogFilesizeMax, LogGeneration);
            drl.LogFileName = _LogFilePath;

            // 開始ログが格納されている場合は出力する
            if (!string.IsNullOrEmpty(startLog))
            {
                drl.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff") + "," + AppName + "," + startLog, "I");
            }

            drl.WriteLine(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff") + "," + AppName + "," + strInfo, "■" + strMsgLevel);

            drl.Flush();
        }

        /// <summary>
        /// ログ世代管理
        /// </summary>
        /// <param name="AppName">ファイル名称</param>
        /// <param name="LogFilePath">ログファイルパス</param>
        /// <param name="LogFilesizeMax">ログファイル最大サイズ</param>
        /// <param name="LogGeneration">ログファイル世代管理数</param>
        /// <returns>最新のログファイルパス</returns>
        private static String LogGenerationManagement(String AppName, String LogFilePath, long LogFilesizeMax, int LogGeneration)
        {
            String newLogFileName = "";     // 新しいログファイル名
            String newLogFilePath = "";     // 新しいログファイルパス

            try
            {
                if (!File.Exists(LogFilePath))
                {
                    // 何もしない
                    return LogFilePath;
                }

                // ログファイルのサイズを取得
                FileInfo fi = new FileInfo(LogFilePath);

                // ログファイル最大サイズを超えていない場合
                if (fi.Length <= LogFilesizeMax)
                {
                    // パラメータのログファイルパスを返却
                    return LogFilePath;
                }

                // 対象のログファイル名を取得
                // ログファイル名の日時情報("yyyymmdd_HHMMSS"の部分)が古いログファイル名を取得したいめ、昇順でソートする
                string searchPattern = AppName + "_????????_??????.log";
                DirectoryInfo di = new DirectoryInfo(Path.GetDirectoryName(LogFilePath));
                List<FileInfo> files = di.GetFiles(searchPattern).OrderBy(f => f.Name).ToList();

                // ログファイル数を取得
                int fileCount = files.Count;

                // ログファイル世代管理数に達した場合
                if (fileCount >= LogGeneration)
                {
                    // ログファイル世代管理数を超えている場合は、古い方から順に削除する
                    foreach (FileInfo file in files)
                    {
                        // 保存数オーバーのファイル削除
                        try
                        {
                            file.Delete();
                        }
                        catch (Exception ex)
                        {
                            Trace.WriteLine("■" + ex.Message + " " + file.FullName);
                        }

                        // ログファイル数をデクリメント
                        fileCount--;
                        if (fileCount < LogGeneration)
                        {
                            break;
                        }
                    }
                }

                // 新しいログファイル名を取得
                newLogFileName = GetLogFileName(AppName, true);
                newLogFilePath = Path.Combine(_LogFolderPath, newLogFileName);
            }
            catch (Exception ex)
            {
                // 何もしない
                Trace.WriteLine("■" + ex.Message);
                // パラメータのログファイルパスを返却
                return LogFilePath;
            }

            // 新しいログファイルパスを返却
            return newLogFilePath;
        }

        /// <summary>
        /// ログファイル名取得
        /// </summary>
        /// <param name="AppName">ファイル名称</param>
        /// <param name="NewFlg">新規フラグ(trueの場合、新しいログファイル名を作成する)</param>
        /// <returns>最新のログファイル名</returns>
        private static String GetLogFileName(String AppName, bool NewFlg = false)
        {
            // 現在日時で新しいログファイル名を作成
            String logFileName = AppName + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".log";

            // 新規フラグがONの場合
            if (NewFlg)
            {
                // 新しいログファイル名を返却
                return logFileName;
            }

            // 対象のログファイル名を取得
            // ログファイル名の日時情報("yyyymmdd_HHMMSS"の部分)が最新のログファイル名を取得したいめ、降順でソートする
            string searchPattern = AppName + "_????????_??????.log";
            DirectoryInfo di = new DirectoryInfo(_LogFolderPath);
            List<FileInfo> files = di.GetFiles(searchPattern).OrderByDescending(f => f.Name).ToList();

            // 対象のログファイル名が存在しない場合
            if (files.Count < 1)
            {
                // 新しいログファイル名を返却
                return logFileName;
            }

            // 最新のログファイル名を返却
            logFileName = files.First().Name;
            return logFileName;
        }


    }
}

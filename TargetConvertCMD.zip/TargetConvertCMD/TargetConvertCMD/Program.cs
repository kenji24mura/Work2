﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using com;


namespace TargetConvertCMD
{
    internal class Program
    {
        static string DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];
        static string PROVIDER = System.Configuration.ConfigurationManager.AppSettings["PROVIDER"];
        static Log lg = new Log();

        static void Main(string[] args)
        {

            lg.LOGFNAME = DATA_PATH + "\\log\\TargetConvertCMD.log";
            lg.loglimit = 1000000;
            lg.logmax = 10;

            string LogDir = DATA_PATH + "\\log";

            if (Directory.Exists(LogDir) == false)
            {
                Directory.CreateDirectory(LogDir);
            }


            MsgOut("処理開始");
            if (args.Length < 2)
            {
                MsgOut("args エラー:  TargetConvertCMD [INDBPATH] [OUTDBPATH] ");
                MsgOut("処理終了");
                return;
            }


            string DB1 =args[0];
            string DB2 = args[1];

            MsgOut("データをコピーします");
            DataCopy(DB1, DB2);

            MsgOut("DBを更新します");
            ReadDB(DB1,DB2);

            MsgOut("処理終了");

        }

        static void MsgOut(string msg)
        {
            Console.WriteLine(msg);
            lg.LogOut(msg);

        }

        static private void DataCopy(string DB1,string DB2)
        {
            if (File.Exists(DB1))
            {
                File.Delete(DB2);
            }

            File.Copy(DB1, DB2, true);

        }
        static private void ReadDB(string DB1,string DB2)
        {
            try
            {
                OleDbConnection dbcon = new OleDbConnection(PROVIDER+ ";Data Source=" + DB1);

                OleDbCommand cmd = dbcon.CreateCommand();
                dbcon.Open();


                OleDbConnection dbcon2 = new OleDbConnection(PROVIDER + ";Data Source=" + DB2);
                dbcon2.Open();

                string query = "SELECT * FROM 目標物テーブル";

                OleDbCommand command = new OleDbCommand(query, dbcon);
                OleDbDataReader reader = command.ExecuteReader();

                int write_cnt = 0;

                var utf8Encoding = System.Text.Encoding.UTF8;


                int readcnt = 0;

                while (reader.Read())
                {

                    try
                    {
                        int kind = Int32.Parse(reader["種別"].ToString());
                        int target = Int32.Parse(reader["目標物"].ToString());
                        string name = reader["消防コード"].ToString();

                        if (kind >= 70 && kind <= 97)
                        {
                            string NewName = "";

                            //1024900022
                            //                            1～2桁 消火栓種別   例：10＝公設消火栓等 ×（非表示）
                            //3桁目 管轄  1＝中署
                            //2＝北署
                            //3＝島本    ○（表示）
                            //中、北、島で表示
                            //4～5桁 区間番号    例：04＝04区    ○（表示）
                            //6～10桁 水利連番    例：00023→0023号として表示  ○（下4桁のみ表示）

                            if (name.Substring(2, 1).IndexOf("1") == 0)
                            {
                                NewName += "中";
                            }
                            if (name.Substring(2, 1).IndexOf("2") == 0)
                            {
                                NewName += "北";
                            }
                            if (name.Substring(2, 1).IndexOf("3") == 0)
                            {
                                NewName += "島";
                            }

                            NewName += name.Substring(3, 2) + "区";
                            NewName += name.Substring(6, 4);
                            NewName += "号";


                            string updateQuery = "UPDATE 目標物テーブル SET 名称 = '" + NewName + "' WHERE 種別 =" + kind + " AND 目標物=" + target;

                            UpdateDB(dbcon2, updateQuery);

                        }
                    }
                    catch (Exception ex)
                    {
                        MsgOut(ex.ToString());
                    }
                    readcnt++;
                    if (readcnt % 1000 == 0)
                    {
                        MsgOut(readcnt.ToString()+"件処理");
                    }

                }
                reader.Close();

                dbcon.Close();
                dbcon2.Close();
            }
            catch (Exception ex)
            {
                MsgOut("エラーが発生しました: " + ex.ToString());
            }
        }
        static private void UpdateDB(OleDbConnection dbcon, string updateQuery)
        {
            try
            {
                // コマンドを実行
                using (OleDbCommand command = new OleDbCommand(updateQuery, dbcon))
                {
                    int rowsAffected = command.ExecuteNonQuery();
//                    MsgOut($"{rowsAffected} 行が更新されました。");
                }
            }
            catch (Exception ex)
            {
                MsgOut("エラーが発生しました: " + ex.Message);
            }
        }

    }
}

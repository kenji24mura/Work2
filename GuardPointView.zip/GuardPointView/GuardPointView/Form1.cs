﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GuardPointView
{
    public partial class Form1 : Form
    {
        DataGridViewColumn[] viewColumn = new DataGridViewColumn[30];

        string DATA_PATH = @"D:\osaka\setup\data\guard";

        string[] area = { "北島・桜島", "常吉", "安治川左岸", "埠頭", "福崎・尻無川右岸", "本土", "鶴町", "船町", "平林" };
        Color[] ctabl = { Color.Red, Color.SkyBlue, Color.LawnGreen,Color.LightGray,Color.Magenta,Color.Yellow,Color.Aqua,Color.Cyan,Color.Olive};

        List<CellInfo> cellInfos = new List<CellInfo>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;

            textBox1.Text = DATA_PATH +"\\防潮扉（市）.txt";

            for (int i =0; i < area.Length; i++)
            {
                comboBox1.Items.Add(area[i]);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fileName = textBox1.Text;

            dataGridView1.Columns.Clear();

            ReadFile(fileName);
            LoadDef();
        }

        private void ReadFile(string filePath)
        {
            //viewColumn[0] = new DataGridViewColumn();
            //viewColumn[0].Name = "";                         //列の名前
            //viewColumn[0].HeaderText = "";                   //ヘッダーに表示される名称
            //viewColumn[0].CellTemplate = new DataGridViewTextBoxCell();  //セルのタイプ
            //dataGridView1.Columns.Add(viewColumn[0]);

            for (int i = 0; i < 30; i++)
            {
                viewColumn[i] = new DataGridViewColumn();
                viewColumn[i].Name = i.ToString();                         //列の名前
                viewColumn[i].HeaderText = i.ToString();                   //ヘッダーに表示される名称
                viewColumn[i].CellTemplate = new DataGridViewTextBoxCell();  //セルのタイプ
                dataGridView1.Columns.Add(viewColumn[i]);
            }

            //try
            //{
            try
            {
                // CSVファイルの読み込み
                // StreamReaderクラスをインスタンス化
                StreamReader reader = new StreamReader(filePath, Encoding.GetEncoding("UTF-8"));

                int x = 0;
                int y = 0;

                // 最後まで読み込む
                while (reader.Peek() >= 0)
                {
                    string line = reader.ReadLine();

                    string[] param = line.Split(',');
                    var view_param = new object[param.Length];

                    x = 0;

                    //view_param[0] = y.ToString();

                    for (int i = 0; i < param.Length; i++)
                    {

                        int idx = param[i].IndexOf(":");

                        if (idx > 0)
                        {
                            string num = param[i].Substring(0, idx);
                            string col = param[i].Substring(idx + 1);

                            col = col.Replace(" ", "");
                            col = col.Replace("-", ",");

                            if (col.IndexOf("white") >= 0)
                            {
                                Console.WriteLine(x + "-" + y + " " + param[i]);
                            }
                            else
                            {
                                if (col.IndexOf("rgb(") >= 0)
                                {
                                    Console.WriteLine(x + "-" + y + " " + param[i]);
                                }
                            }


                            view_param[i] = param[i];

                            //if (i == 0)
                            //{
                            //  string name = "";
                            //  GetArea(x, y, ref name);
                            //  view_param[i + 1] = name + " " + param[i];
                            //}
                            //else
                            //{
                            //   view_param[i + 1] = param[i];
                            //}
                        }
                        x++;
                    }
                    dataGridView1.Rows.Add(view_param);
                    y++;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

//            SetColor();
            //}
            //catch (Exception ex)
            //{
            //  Console.WriteLine(ex);
            //}

        }
        private void GetArea(int x, int y, ref string name)
        {
            string filePath = @"C:\D_DRV\WEBGIS.TBWG0040.csv";

            try
            {
                // CSVファイルの読み込み
                // StreamReaderクラスをインスタンス化
                StreamReader reader = new StreamReader(filePath, Encoding.GetEncoding("UTF-8"));

                int linecnt = 0;
                // 最後まで読み込む
                while (reader.Peek() >= 0)
                {
                    string line = reader.ReadLine();

                    string[] param = line.Split(',');

                    //1,1,"10","此花","北島・桜島","民間",2,21,"white",2210,135.4177000000,34.6586000000,,2025/09/19 14:43:53

                    if (linecnt > 0)
                    {
                        int mx = Int32.Parse(param[6]);
                        int my = Int32.Parse(param[7]);

                        if (mx == x && my == y)
                        {
                            name = param[4];
                            break;
                        }


                    }
                    linecnt++;

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void SetColor()
        {

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Rows[i].Cells.Count; j++)
                {
                    var value = dataGridView1[j, i].Value;

                    if (value != null)
                    {

                        for(int m = 0; m < area.Length; m++)
                        {
                            if (value.ToString().IndexOf(area[m]) >= 0)
                            {
                                dataGridView1[j, i].Style.BackColor = ctabl[m];
                                break;
                            }
                        }
                    }
                }

            }
        }


        private void SetCellColor()
        {

            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Rows[i].Cells.Count; j++)
                {
                    dataGridView1[j, i].Style.BackColor = Color.White;
                }
            }

            dataGridView1.CurrentCell = null;

            for (int i = 0; i < cellInfos.Count; i++)
            {

                int x = cellInfos[i].x;
                int y = cellInfos[i].y;

                dataGridView1[x, y].Style.BackColor = ctabl[cellInfos[i].areaidx];
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int x = e.ColumnIndex;
            int y = e.RowIndex;

            string val = dataGridView1[x, y].Value.ToString();

            int idx = val.IndexOf(":");

            if(idx > 0)
            {
                val = val.Substring(0, idx);
            }

            bool IsExit = false;
            for (int i = 0; i < cellInfos.Count; i++)
            {
                if(x == cellInfos[i].x && y == cellInfos[i].y)
                {
                    cellInfos.RemoveAt(i);
                    SetCellColor();
                    //設定済
                    IsExit = true;
                    break;
                }
            }

            if (IsExit == false)
            {

                if (comboBox1.SelectedIndex < 0)
                {
                    return;
                }

                CellInfo ci = new CellInfo();

                ci.x = x;
                ci.y = y;

                ci.area = comboBox1.SelectedItem.ToString();
                ci.areaidx = comboBox1.SelectedIndex;
                ci.number = val;
                cellInfos.Add(ci);
                SetCellColor();

            }
            //            dataGridView1[x, y].Style.BackColor = Color.Red;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string file = DATA_PATH + "\\guarddef.txt";


            if (File.Exists(file) == true)
            {
                File.Delete(file);
            }

            try
            {
                Encoding enc = Encoding.GetEncoding("UTF-8");
                StreamWriter writer = new StreamWriter(file, true, enc);


                for (int i = 0; i < cellInfos.Count; i++)
                {
                    string line = "";

                    line += cellInfos[i].areaidx.ToString();
                    line += ",";
                    line += cellInfos[i].area;
                    line += ",";
                    line += cellInfos[i].number;
                    line += ",";

                    line += cellInfos[i].x;
                    line += ",";
                    line += cellInfos[i].y;

                    writer.WriteLine(line);
                }

                writer.Close();
            }
            catch (Exception ex)
            {
            }


        }

        public void LoadDef()
        {

            cellInfos.Clear();

            string filePath = DATA_PATH + "\\guarddef.txt";

            try
            {
                // CSVファイルの読み込み
                // StreamReaderクラスをインスタンス化
                StreamReader reader = new StreamReader(filePath, Encoding.GetEncoding("UTF-8"));

                int linecnt = 0;
                // 最後まで読み込む
                while (reader.Peek() >= 0)
                {
                    string line = reader.ReadLine();

                    string[] param = line.Split(',');

                    //0,北島・桜島,3,3,4
                    CellInfo cs = new CellInfo();
                    cs.areaidx = Int32.Parse(param[0]);
                    cs.area = param[1];
                    cs.number = param[2];
                    cs.x = Int32.Parse(param[3]);
                    cs.y = Int32.Parse(param[4]);

                    cellInfos.Add(cs);


                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

            SetCellColor();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // OpenFileDialogオブジェクトの生成
            OpenFileDialog od = new OpenFileDialog();
            od.Title = "ファイルを開く";  //ダイアログ名
            od.InitialDirectory = @"C:\";  //初期フォルダ
            od.FileName = @"sample.txt";  //初期選択ファイル名
            od.Filter = "テキストファイル(*.txt;*.text)|*.txt;*.text|すべてのファイル(*.*)|*.*";  //選択できる拡張子
            od.FilterIndex = 1;  //初期の拡張子

            // ダイアログを表示する
            DialogResult result = od.ShowDialog();


            // 選択後の判定
            if (result == DialogResult.OK)
            {
                //「開く」ボタンクリック時の処理
               textBox1.Text = od.FileName;  //これで選択したファイルパスを取得できる
            }
            else if (result == DialogResult.Cancel)
            {
                //「キャンセル」ボタンクリック時の処理
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string filePath = DATA_PATH + "\\guarddef.txt";

            try
            {
                // CSVファイルの読み込み
                // StreamReaderクラスをインスタンス化
                StreamReader reader = new StreamReader(filePath, Encoding.GetEncoding("UTF-8"));

                // 最後まで読み込む
                while (reader.Peek() >= 0)
                {
                    string line = reader.ReadLine();

                    string[] param = line.Split(',');

                    //0,北島・桜島,3,3,4
                    int areaidx = Int32.Parse(param[0]);
                    string area = param[1];
                    string number = param[2];
                    int x = Int32.Parse(param[3]);
                    int y = Int32.Parse(param[4]);

                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            cellInfos.Clear();
            SetCellColor();
        }
    }
    class CellInfo
    {
        public int x;
        public int y;
        public string area;
        public string number;
        public int areaidx;
    }
}

// @(h) DeviceManagerException.h V01L01 (2016/12/19  TECS�j�F�� )
// @(s) �ԍڃ~�h��
//�@�@�@�@Copyright (C) FUJITSU LIMITED 2016
//�@�@�@�@�f�o�C�X�}�l�[�W���[��O�N���X�̃w�b�_�t�@�C��
//�@�@�@�@�f�o�C�X�}�l�[�W���[�N���X�p�̗�O�N���X
//�@�@�@
#pragma once
#include "Exception.h"

#ifdef _DEBUG
#define DBG_PRINT
#else
#undef DBG_PRINT
#endif

#undef	_MODULE_
#define	_MODULE_	"DeviceManagerException"

// �s�����܂ޗ�O�}�N��
#define DEVICE_MANAGER_EXCEPTION(msg) DeviceManagerException(msg, _MODULE_, __LINE__);
// ��O�������܂ޗ�O�}�N��
#define DEVICE_MANAGER_KEEP_EXCEPTION(obj, msg) DeviceManagerException(obj, msg, _MODULE_, __LINE__);


namespace fujitsu {	// fujitsu�̖��O���
namespace police {	// ���x�V�X�e���̖��O���

class DeviceManagerException : public CmException {	// �V�X�e���e�[�u����O�N���X

public:
	inline explicit DeviceManagerException(const std::string& message) : CmException(message)
	{
#ifdef DBG_PRINT
		printf("<%s> %s\n", _MODULE_, message.c_str());
#endif
	};
	inline explicit DeviceManagerException(const char* message) : CmException(message)
	{
#ifdef DBG_PRINT
		printf("<%s> %s\n", _MODULE_, message);
#endif
	};
	inline DeviceManagerException(const std::string& message, const std::string& module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message.c_str());
#endif
	};
	inline DeviceManagerException(const std::string& message, const char* module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message.c_str());
#endif
	};
	inline DeviceManagerException(const char* message, const std::string& module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message);
#endif
	};
	inline DeviceManagerException(const char* message, const char* module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message);
#endif
	};
	inline DeviceManagerException(const CmException& obj, const std::string& message, const std::string& module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message.c_str());
#endif
	};
	inline DeviceManagerException(const CmException& obj, const std::string& message, const char* module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message.c_str());
#endif
	};
	inline DeviceManagerException(const CmException& obj, const char* message, const std::string& module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message);
#endif
	};
	inline DeviceManagerException(const CmException& obj, const char* message, const char* module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message);
#endif
	};
};

}	// namespace fujitsu
}	// namespace police

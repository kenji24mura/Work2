// @(h) CarinfDataException.h V01L01 (2016/08/09  TECS�j�F�� )
// @(s) �ԍڃ~�h��
//�@�@�@�@Copyright (C) FUJITSU LIMITED 2016
//�@�@�@�@�V�X�e���e�[�u����O�N���X�̃w�b�_�t�@�C��
//�@�@�@�@�V�X�e���e�[�u���N���X�p�̗�O�N���X
//�@�@�@
#pragma once
#include "Exception.h"

#ifdef _DEBUG
#define DBG_PRINT
#else
#undef DBG_PRINT
#endif

#undef	_MODULE_
#define	_MODULE_	"CarinfDataException"

// �s�����܂ޗ�O�}�N��
#define CARINF_DATA_EXCEPTION(msg) CarinfDataException(msg, _MODULE_, __LINE__);
// ��O�������܂ޗ�O�}�N��
#define CARINF_DATA_KEEP_EXCEPTION(obj, msg) CarinfDataException(obj, msg, _MODULE_, __LINE__);


namespace fujitsu {	// fujitsu�̖��O���
namespace police {	// ���x�V�X�e���̖��O���

class CarinfDataException : public CmException {	// �V�X�e���e�[�u����O�N���X

public:
	inline explicit CarinfDataException(const std::string& message) : CmException(message)
	{
#ifdef DBG_PRINT
		printf("<%s> %s\n", _MODULE_, message.c_str());
#endif
	};
	inline explicit CarinfDataException(const char* message) : CmException(message)
	{
#ifdef DBG_PRINT
		printf("<%s> %s\n", _MODULE_, message);
#endif
	};
	inline CarinfDataException(const std::string& message, const std::string& module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message.c_str());
#endif
	};
	inline CarinfDataException(const std::string& message, const char* module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message.c_str());
#endif
	};
	inline CarinfDataException(const char* message, const std::string& module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message);
#endif
	};
	inline CarinfDataException(const char* message, const char* module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message);
#endif
	};
	inline CarinfDataException(const CmException& obj, const std::string& message, const std::string& module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message.c_str());
#endif
	};
	inline CarinfDataException(const CmException& obj, const std::string& message, const char* module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message.c_str());
#endif
	};
	inline CarinfDataException(const CmException& obj, const char* message, const std::string& module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message);
#endif
	};
	inline CarinfDataException(const CmException& obj, const char* message, const char* module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message);
#endif
	};
};

}	// namespace fujitsu
}	// namespace police

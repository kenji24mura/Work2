// @(h) CMW_BASEException.h V01L01 (2016/08/09  TECS�j�F�� )
// @(s) �ԍڃ~�h��
//�@�@�@�@Copyright (C) FUJITSU LIMITED 2016
//�@�@�@�@�ԍڃ~�h������O�N���X�̃w�b�_�t�@�C��
//�@�@�@�@�ԍڃ~�h�����N���X�p�̗�O�N���X
//�@�@�@
#pragma once
#include "Exception.h"

#ifdef _DEBUG
#define DBG_PRINT
#else
#undef DBG_PRINT
#endif

#undef	_MODULE_
#define	_MODULE_	"CMW_BASEException"

// �s�����܂ޗ�O�}�N��
#define CMW_BASE_EXCEPTION(msg) CMW_BASEException(msg, _MODULE_, __LINE__);
// ��O�������܂ޗ�O�}�N��
#define CMW_BASE_KEEP_EXCEPTION(obj, msg) CMW_BASEException(obj, msg, _MODULE_, __LINE__);


namespace fujitsu {	// fujitsu�̖��O���
namespace police {	// ���x�V�X�e���̖��O���

class CMW_BASEException : public CmException {	// �ԍڃ~�h������O�N���X

public:
	inline explicit CMW_BASEException(const std::string& message) : CmException(message)
	{
#ifdef DBG_PRINT
		printf("<%s> %s\n", _MODULE_, message.c_str());
#endif
	};
	inline explicit CMW_BASEException(const char* message) : CmException(message)
	{
#ifdef DBG_PRINT
		printf("<%s> %s\n", _MODULE_, message);
#endif
	};
	inline CMW_BASEException(const std::string& message, const std::string& module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message.c_str());
#endif
	};
	inline CMW_BASEException(const std::string& message, const char* module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message.c_str());
#endif
	};
	inline CMW_BASEException(const char* message, const std::string& module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message);
#endif
	};
	inline CMW_BASEException(const char* message, const char* module, ULONG line) : CmException(message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message);
#endif
	};
	inline CMW_BASEException(const CmException& obj, const std::string& message, const std::string& module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message.c_str());
#endif
	};
	inline CMW_BASEException(const CmException& obj, const std::string& message, const char* module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message.c_str());
#endif
	};
	inline CMW_BASEException(const CmException& obj, const char* message, const std::string& module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module.c_str(), line, message);
#endif
	};
	inline CMW_BASEException(const CmException& obj, const char* message, const char* module, ULONG line) : CmException(obj, message, module, line)
	{
#ifdef DBG_PRINT
		printf("<%s>[%lu] %s\n", module, line, message);
#endif
	};
};

}	// namespace fujitsu
}	// namespace police

// @(h) CMW_CCTL.h V01L01 (2016/08/09  TECS�j�F�� )
// @(s) �ԍڃ~�h��
//�@�@�@�@Copyright (C) FUJITSU LIMITED 2016
//�@�@�@�@��O���N���X�̒�`
//�@�@�@�@�ԍڃ~�h���̗�O���N���X
//�@�@�@
#pragma once

#include "BaseInc.h"
#include <sstream>

// �s�����܂ޗ�O�}�N��
#define CM_EXCEPTION(msg) CmException(msg, __LINE__);

namespace fujitsu{	// fujitsu�̖��O���
namespace police{	// ���x�V�X�e���̖��O���

class CmException : public std::runtime_error{	// ��O���N���X

public:
	inline explicit CmException(const std::string& message) : runtime_error(message), m_line(0), m_module("")
	{
		std::ostringstream oss;
		oss << "(" << m_line << ")";

		m_history = m_module + oss.str() + message;
	}
	inline explicit CmException(const char* message) : runtime_error(message), m_line(0), m_module("")
	{
		std::ostringstream oss;
		oss << "(" << m_line << ")";

		m_history = m_module + oss.str() + message;
	}
	inline CmException(const std::string& message, const std::string& module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = module + oss.str() + message;
	}
	inline CmException(const char* message, const std::string& module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = module + oss.str() + message;
	}
	inline CmException(const std::string& message, const char* module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = module + oss.str() + message;
	}
	inline CmException(const char* message, const char* module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = module + oss.str() + message;
	}
	inline CmException(const CmException& obj, const std::string& message, const std::string& module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = obj.m_history + "," + module + oss.str() + message;
	}
	inline CmException(const CmException& obj, const char* message, const std::string& module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = obj.m_history + "," + module + oss.str() + message;
	}
	inline CmException(const CmException& obj, const std::string& message, const char* module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = obj.m_history + "," + module + oss.str() + message;
	}
	inline CmException(const CmException& obj, const char* message, const char* module, ULONG line) : runtime_error(message), m_line(line), m_module(module)
	{
		std::ostringstream oss;
		oss << "(" << line << ")";

		m_history = obj.m_history + "," + module + oss.str() + message;
	}
	inline const ULONG getLine() const
	{
		return m_line;
	}
	inline const std::string getModule() const
	{
		return m_module;
	}
	inline const std::string getHistory() const
	{
		return m_history;
	}

private:
	const ULONG	m_line;			// �����s��
	const std::string m_module;	// ���W���[����
	std::string m_history;		// ��O����

};

}	// namespace fujitsu
}	// namespace police

#pragma once

#include "BaseInc.h"
#include "CMW_COMLIB.h"
#pragma comment(lib, "CMW_COMLIB.lib")
#include "MessageType.h"

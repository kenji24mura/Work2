﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TargetConvert
{
    public partial class Form1 : Form
    {
        string DB1 = "c:\\D_DRV\\FIIM_TARGET.mdb";
        string DB2 = "c:\\D_DRV\\FIIM_TARGET_wk.mdb";

        string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= ";
        string CON_STR2 = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= ";


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (File.Exists(DB2))
            {
                File.Delete(DB2);
            }

            File.Copy(DB1, DB2, true);
            ReadDB();
        }

        

        private void ReadDB()
        {
            try
            {
                OleDbConnection dbcon = new OleDbConnection(CON_STR+DB1);

                OleDbCommand cmd = dbcon.CreateCommand();
                dbcon.Open();


                OleDbConnection dbcon2 = new OleDbConnection(CON_STR + DB2);
                dbcon2.Open();

                string query = "SELECT * FROM 目標物テーブル";

                OleDbCommand command = new OleDbCommand(query, dbcon);
                OleDbDataReader reader = command.ExecuteReader();

                int write_cnt = 0;

                var utf8Encoding = System.Text.Encoding.UTF8;


                int readcnt = 0;

                while (reader.Read())
                {

                    try
                    {
                        int kind = Int32.Parse(reader["種別"].ToString());
                        int target = Int32.Parse(reader["目標物"].ToString());
                        string name = reader["消防コード"].ToString();

                        if (kind >= 70 && kind <= 97)
                        {
                            string NewName = "";

                            //1024900022
                            //                            1～2桁 消火栓種別   例：10＝公設消火栓等 ×（非表示）
                            //3桁目 管轄  1＝中署
                            //2＝北署
                            //3＝島本    ○（表示）
                            //中、北、島で表示
                            //4～5桁 区間番号    例：04＝04区    ○（表示）
                            //6～10桁 水利連番    例：00023→0023号として表示  ○（下4桁のみ表示）

                            if (name.Substring(2, 1).IndexOf("1") == 0)
                            {
                                NewName += "中";
                            }
                            if (name.Substring(2, 1).IndexOf("2") == 0)
                            {
                                NewName += "北";
                            }
                            if (name.Substring(2, 1).IndexOf("3") == 0)
                            {
                                NewName += "島";
                            }

                            NewName += name.Substring(3, 2) + "区";
                            NewName += name.Substring(6, 4);
                            NewName += "号";


                            string updateQuery = "UPDATE 目標物テーブル SET 名称 = '" + NewName + "' WHERE 種別 =" + kind + " AND 目標物=" + target;

                            UpdateDB(dbcon2, updateQuery);

                        }
                    }
                    catch (Exception ex)
                    {
                        MsgOut(ex.ToString());
                    }
                    readcnt++;
                    MsgOut(readcnt.ToString());

                }
                reader.Close();

                dbcon.Close();
                dbcon2.Close();
            }
            catch (Exception ex)
            {
                MsgOut(ex.ToString());
            }
        }
        private void UpdateDB(OleDbConnection dbcon,string updateQuery)
        {
            try
            {
                    // コマンドを実行
                    using (OleDbCommand command = new OleDbCommand(updateQuery, dbcon))
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MsgOut($"{rowsAffected} 行が更新されました。");
                    }
            }
            catch (Exception ex)
            {
                MsgOut("エラーが発生しました: " + ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }
    }
}

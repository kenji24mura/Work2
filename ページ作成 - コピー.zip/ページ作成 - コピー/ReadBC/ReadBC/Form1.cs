﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ZMDCom;
using COM;
using System.Net.NetworkInformation;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.OleDb;

namespace ReadBC
{
    public partial class Form1 : Form
    {
        int ZMDORGX = -18750000;//cm
        int ZMDORGY = -32500000;//cm

        public  String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];

        MapComLib.Convert cv = new MapComLib.Convert();

        UInt32 mask = 0;
        int maxlay = 0;

        //リソース
        Pen[] pe = new Pen[16];
        Font[] f = new Font[16];
        SolidBrush[] b = new SolidBrush[16];

        Bitmap current_image;

        Bitmap canvas;//地図描画用canvas
        Graphics g;

        Bitmap bg_canvas;//バックグラウンドイメージ
        Graphics bg_g;//バックグラウンドグラフィックス

        Boolean createbg = false;

        Point Offset;
        double rate = 1.0;
        int offset_w;
        int offset_h;

        //正規化係数
        int NormarizeParam = 1;


        int msize_w = 0;
        int msize_h = 0;

        int click_mode = 0;

        Boolean IsMouseDown = false;

        Boolean drawAllPage = false;
        Point start_p;
        Point end_p;

        List<Mesh> mesh = new List<Mesh>();
        List<NumberInfo> numberinfo = new List<NumberInfo>();

        public bool[] zmd_layer_disp = new bool[128];
        public bool[] layer_disp = new bool[16];

        string[] book = new string[99];
        string[] mapinfo = new string[99];
        string[] pageinfo = new string[99];
        Point[] bookorg = new Point[99];
        Point[] bookoffset = new Point[99];

        int max_x = 0;
        int max_y = 0;

        Mesh mdata;

        SolidBrush[] opaqueBrush = new SolidBrush[5];

        int ORGX = 0;//cm
        int ORGY = 0;//cm

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

            textZMDFile.Text = "";
            textRate.Text = "5.0";

            textX.Text = "0";
            textY.Text = "0";

            textPageSize.Text = "1";

            canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(canvas);

            bg_canvas = new Bitmap(pictureBox1.Width * 10, pictureBox1.Height * 10);
            bg_g = Graphics.FromImage(bg_canvas);

            pe[0] = new Pen(Color.Green, 1);
            pe[1] = new Pen(Color.Blue, 1);
            pe[2] = new Pen(Color.Yellow, 1);
            pe[3] = new Pen(Color.Red, 1);
            pe[4] = new Pen(Color.Magenta, 1);
            pe[5] = new Pen(Color.LightBlue, 1);
            b[0] = new SolidBrush(Color.Green);
            b[1] = new SolidBrush(Color.Blue);
            b[2] = new SolidBrush(Color.Yellow);
            b[3] = new SolidBrush(Color.Red);
            b[4] = new SolidBrush(Color.Magenta);




            opaqueBrush[0] = new SolidBrush(Color.FromArgb(128, 0, 0, 255));
            opaqueBrush[1] = new SolidBrush(Color.FromArgb(128, 255, 0, 255));
            opaqueBrush[2] = new SolidBrush(Color.FromArgb(128, 0, 255, 255));


            for (int i = 0; i < zmd_layer_disp.Length; i++)
            {
                zmd_layer_disp[i] = true;
            }
            for (int i = 0; i < layer_disp.Length; i++)
            {
                layer_disp[i] = true;
            }

            checkBox1.Text = "文字";
            checkBox2.Text = "部品";
            checkBox3.Text = "折れ線";
            checkBox4.Text = "単純ポリゴン";
            checkBox5.Text = "****";
            checkBox6.Text = "****";
            checkBox7.Text = "****";

            checkBox1.Checked = layer_disp[0];
            checkBox2.Checked = layer_disp[1];
            checkBox3.Checked = layer_disp[2];
            checkBox4.Checked = layer_disp[3];
            checkBox5.Checked = layer_disp[4];
            checkBox6.Checked = layer_disp[5];
            checkBox7.Checked = layer_disp[6];

            LoadList();

        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            Reload();
        }

        private void Reload()
        {
            LoadList();
            g.Clear(Color.White);
            bg_g.Clear(Color.White);

            int ORGX = 0;//cm
            int ORGY = 0;//cm

            textX.Text = "0";
            textY.Text = "0";
            textCenterX.Text = "0";
            textCenterY.Text = "0";

            pictureBox1.Image = canvas;
        }


        private void LoadList()
        {
            listBook.Items.Clear();

            string filePath = DATA_PATH + "\\def\\book.def";

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    int idx = 0;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] param = line.Split(',');

                        listBook.Items.Add(param[1]);
                        book[idx] = param[0];
//                        mapinfo[idx] = DATA_PATH + "\\" + param[2];
                        mapinfo[idx] = param[2];
                        pageinfo[idx] = DATA_PATH + "\\txt\\" + param[1] + "_page.txt";

                        bookorg[idx].X = 0;
                        bookorg[idx].Y = 0;

                        try
                        {
                            bookorg[idx].X = Int32.Parse(param[3]);
                            bookorg[idx].Y = Int32.Parse(param[4]);
                        }
                        catch (Exception ex)
                        {

                        }

                        bookoffset[idx].X = 0;
                        bookoffset[idx].Y = 0;

                        try
                        {

                           bookoffset[idx].X = Int32.Parse(param[5]);
                           bookoffset[idx].Y = Int32.Parse(param[6]);
                        }
                        catch (Exception ex)
                        {

                        }
                        idx++;
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
            int cnt = listBox1.Items.Count;


            listBox1.SelectedIndex = cnt - 1;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

            LoadMap();
            //            drawAllPage = false;
            //            LoadData(false);
        }

        private void LoadMap()
        {
            if (listBook.SelectedItems.Count == 0)
            {
                g.Clear(Color.White);
                bg_g.Clear(Color.White);

                pictureBox1.Image = canvas;

            }

            if (listBook.SelectedItems.Count > 1)
            {

                var items = listBook.SelectedIndices;

                LoadMultiItems(false);
            }
            else
            {
                btnAdd.Enabled = true;
                drawAllPage = false;

                LoadData(false);

            }

        }


        private void LoadData(Boolean MovePos)
        {
            MsgOut("LoadDat");
            mdata = new Mesh();
            mesh.Clear();
            numberinfo.Clear();

            int idx = listBook.SelectedIndex;
            if (idx == -1) return;

            textBook.Text = book[idx]; 
            textZMDFile.Text = mapinfo[idx];

            textORGX.Text = bookorg[idx].X.ToString();//cm
            textORGY.Text = bookorg[idx].Y.ToString();//cm

            rate = Double.Parse(textRate.Text);

            //
            int orgx = Int32.Parse(textORGX.Text);//cm
            int orgy = Int32.Parse(textORGY.Text);//cm

            double gx = (double)bookoffset[idx].X;
            double gy = (double)bookoffset[idx].Y;


            if(gx!=0 && gy != 0)
            {
                if (MovePos == true)
                {
                    offset_w = pictureBox1.Width / 2 - (int)((gx - orgx) / (rate * 100));
                    offset_h = pictureBox1.Height / 2 - (int)((orgy - gy) / (rate * 100));

                    //            offset_w = bookoffset[idx].X;
                    //            offset_h = bookoffset[idx].Y;

                    textX.Text = offset_w.ToString();
                    textY.Text = offset_h.ToString();
                }
            }

            //

            g.Clear(Color.White);
            bg_g.Clear(Color.White);

            int mx = 0;
            int my = 0;
            string zmdfile = "";

            zmdfile = mapinfo[idx];
            mx = 0;
            my = 0;

            int startidx = 0;

            LoadDataFile(zmdfile, mx, my);

            if (drawAllPage == false)
            {
                SetORGPoint(idx, startidx);
            }

            CopyImage(offset_w, offset_h);

            DrawPage(g,idx);

            pictureBox1.Image = canvas;

            SetCenterPos();
            click_mode = 0;
        }

        private void btnAllDraw_Click(object sender, EventArgs e)
        {
            LoadMultiItems(false);
        }
        private void LoadMultiItems(Boolean MovePos) {

            var items = listBook.SelectedIndices;

            btnAdd.Enabled = false;
            //LoadList();

            drawAllPage = true;
            rate = Double.Parse(textRate.Text);

            mdata = new Mesh();
            mesh.Clear();
            numberinfo.Clear();

            g.Clear(Color.White);
            bg_g.Clear(Color.White);

            int idx_cnt = 0;

            int start_idx = 0;

            foreach (int idx in items)
            {
                if (idx_cnt == 0)
                {
                    start_idx = idx;
                }
                idx_cnt++;
            }


            int orgx = bookorg[start_idx].X;//cm
            int orgy = bookorg[start_idx].Y;//cm

            double gx = (double)bookoffset[start_idx].X;
            double gy = (double)bookoffset[start_idx].Y;


            if (MovePos == true)
            {
                offset_w = pictureBox1.Width / 2 - (int)((gx - orgx) / (rate * 100));
                offset_h = pictureBox1.Height / 2 - (int)((orgy - gy) / (rate * 100));

                textX.Text = offset_w.ToString();
                textY.Text = offset_h.ToString();
            }

            textORGX.Text = bookorg[start_idx].X.ToString();
            textORGY.Text = bookorg[start_idx].Y.ToString();

            foreach (int idx in items)
            {
                int mx = 0;
                int my = 0;
                string zmdfile = "";

                zmdfile = mapinfo[idx];

                textZMDFile.Text = mapinfo[idx];

                //
                //先頭の基準位置からの差分を設定する
                //(
                double sx = (double)(bookorg[idx].X - bookorg[start_idx].X) / 100;
                double sy = (double)(bookorg[start_idx].Y - bookorg[idx].Y) / 100;

                mx = (int)(sx / rate);
                my = (int)(sy / rate);

                LoadDataFile(zmdfile, mx, my);

                idx_cnt++;
            }

            CopyImage(offset_w, offset_h);

            DrawAllPage();

            pictureBox1.Image = canvas;
            SetCenterPos();

            click_mode = 0;

        }

        private void DrawAllPage()
        {

            var items = listBook.SelectedIndices;
            int idx_cnt = 0;

            int start_idx = 0;

            foreach (int idx in items)
            {
                if (idx_cnt == 0)
                {
                    start_idx = idx;
                }
                idx_cnt++;
            }
            foreach (int idx in items)
            {
                int mx = 0;
                int my = 0;
                string zmdfile = "";

                zmdfile = mapinfo[idx];

                textZMDFile.Text = mapinfo[idx];

                //
                //先頭の基準位置からの差分を設定する
                //(
                int sx = (bookorg[idx].X - bookorg[start_idx].X) / 100;
                int sy = (bookorg[start_idx].Y - bookorg[idx].Y) / 100;

                mx = (int)((double)sx / rate);
                my = (int)((double)sy / rate);

                DrawPage(g, idx);

            }

        }


        private void SetORGPoint(int idx, int startidx)
        {
            for (int i = 0; i < numberinfo.Count; i++)
            {
                if (numberinfo[i].x >= mesh[startidx].minx && numberinfo[i].x <= mesh[startidx].maxx && numberinfo[i].y >= mesh[startidx].miny && numberinfo[i].y <= mesh[startidx].maxy)
                {
                    int mx = 0;
                    int my = 0;

                    NumberToXY(numberinfo[i].number, ref mx, ref my);

                    //左下座標X
                    //左下座標Y

                    //mesh[0].minx;
                    //mesh[0].maxy;

                    int sx = (mx - 1) * 75000 + +ZMDORGX;//cm
                    int sy = (my -1 ) * 50000 + ZMDORGY;//cm


                    //
                    //原点
                    //
                    ORGX = sx - (int)(mesh[startidx].minx * 100 * rate);
                    ORGY = sy + (int)(mesh[startidx].maxy * 100 * rate);

                }

            }
            MsgOut("ORGX=" + ORGX + ",ORGY=" + ORGY);

            string filePath = DATA_PATH + "\\def\\book.def";
            string tmpPath = DATA_PATH + "\\def\\book.def.tmp";

            try
            {

                using (StreamWriter writer = new StreamWriter(tmpPath, false))
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        int line_idx = 0;
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {

                            if (line_idx == idx)
                            {

                                string[] param = line.Split(',');
                                string outline = "";

                                outline += param[0];
                                outline += ",";
                                outline += param[1];
                                outline += ",";
                                outline += param[2];
                                outline += ",";

                                if (param[3].Length == 0)
                                {
                                    outline += ORGX.ToString();
                                }
                                else
                                {
                                    outline += param[3];
                                }

                                outline += ",";

                                if (param[4].Length == 0)
                                {
                                    outline += ORGY.ToString();
                                }
                                else
                                {
                                    outline += param[4];
                                }
                                outline += ",";
                                outline += param[5];
                                outline += ",";
                                outline += param[6];

                                writer.WriteLine(outline);

                            }
                            else
                            {

                                writer.WriteLine(line);
                            }
                            line_idx++;
                        }
                    }
                }

                if (File.Exists(filePath) == true)
                {
                    File.Delete(filePath);
                }

                File.Move(tmpPath, filePath);
            }
            catch (Exception e)
            {
                MsgOut(e.ToString());
            }

        }

        private void LoadDataFile(string zmdfile, int mx, int my)
        {

            int start1 = zmdfile.IndexOf("\\BC06");

            if (start1 < 0) return;
 

            string passfile = zmdfile.Substring(0, start1) + "\\PASSWORD.DAT";

            int start2 = zmdfile.IndexOf("\\FRM");

            string baafile = zmdfile.Replace("\\FRM\\", "\\ATR\\");
            baafile = baafile.Replace(".BCF", ".BCA");

            mask = GetMask(passfile);

//            rate = Double.Parse(textRate.Text);

            offset_w = 0;
            offset_h = 0;

            //ReadBAA(baafile, passfile, 0);

            layer_disp[0] = checkBox1.Checked;
            layer_disp[1] = checkBox2.Checked;
            layer_disp[2] = checkBox3.Checked;
            layer_disp[3] = checkBox4.Checked;
            layer_disp[4] = checkBox5.Checked;
            layer_disp[5] = checkBox6.Checked;
            layer_disp[6] = checkBox7.Checked;


            offset_w = Int32.Parse(textX.Text);
            offset_h = Int32.Parse(textY.Text);

            // mesh.Clear();
            // numberinfo.Clear();

            ReadFile(zmdfile, passfile, rate, mx, my);

            //            CopyImage(offset_w, offset_h);

            //            DrawPage();

            //            pictureBox1.Image = canvas;

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }
        private void DrawGrid()
        {
            int w = 75000 / NormarizeParam;
            int h = 50000 / NormarizeParam;

            int cx = max_x / w;
            int cy = max_y / h;

            int width = (int)(w / rate);
            int height = (int)(h / rate);


            Point[] pInfo = new Point[4];
            for (int i = 0; i < cx; i++)
            {
                for (int j = 0; j < cy; j++)
                {

                    pInfo[0].X = i * width + offset_w;
                    pInfo[0].Y = j * height + offset_h;
                    pInfo[1].X = (i + 1) * width + offset_w;
                    pInfo[1].Y = j * height + offset_h;
                    pInfo[2].X = (i + 1) * width + offset_w;
                    pInfo[2].Y = (j + 1) * height + offset_h;
                    pInfo[3].X = i * width + offset_w;
                    pInfo[3].Y = (j + 1) * height + offset_h;

                    g.DrawPolygon(pe[1], pInfo);

                }
            }

        }

        private void CopyImage(int sx, int sy)
        {
            g.DrawImage(bg_canvas, sx, sy, bg_canvas.Width, bg_canvas.Height);
        }


        private void ReadFile(string zmdfile, string passfile, double m_rate, int mx, int my)
        {
            string fname = Path.GetFileNameWithoutExtension(zmdfile);

            if (File.Exists(zmdfile) == false) return;

            FileStream fs = new FileStream(zmdfile, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            FRM_HEAD_NOMESH frm_head = new FRM_HEAD_NOMESH();

            //int header_length = sizeof(FRM_HEAD_NOMESH);

            frm_head.pickind = new PicKind_Code();
            frm_head.pickind.pic1 = br.ReadByte();
            frm_head.pickind.pic2 = br.ReadByte();
            frm_head.pickind.pic3 = br.ReadByte();
            frm_head.pickind.pic4 = br.ReadByte();

            frm_head.date = new Date();
            frm_head.date.y = br.ReadUInt16();
            frm_head.date.m = br.ReadByte();
            frm_head.date.d = br.ReadByte();

            frm_head.zno = new ZNO();
            frm_head.zno.x = br.ReadUInt16();
            frm_head.zno.y = br.ReadUInt16();


            frm_head.org_lon = br.ReadInt32();//座標系の原点の経度
            frm_head.org_lat = br.ReadInt32();//座標系の原点の緯度
            frm_head.offset_x1 = br.ReadInt32();//座標系の原点からZMD原点へのX方向オフセット
            frm_head.offset_y1 = br.ReadInt32();//座標系の原点からZMD原点へのY方向オフセット
            frm_head.offset_x2 = br.ReadUInt32();//ZMD原点から図の原点へのX方向の距離
            frm_head.offset_y2 = br.ReadUInt32();//ZMD原点から図の原点へのY方向の距離

            frm_head.org_x = br.ReadInt32();//図の原点の経度
            frm_head.org_y = br.ReadInt32();//図の原点の緯度
            frm_head.x_width = br.ReadUInt32();//図あたりのX方向の幅
            frm_head.y_width = br.ReadUInt32();//図あたりのY方向の幅
            frm_head.x_cnt = br.ReadInt16();//図あたりのX方向座標数
            frm_head.y_cnt = br.ReadInt16();//図あたりのY方向座標数
            frm_head.param = br.ReadUInt32();//正規化係数
            frm_head.x_prk = br.ReadUInt16();//X方向ブロック化係数
            frm_head.y_prk = br.ReadUInt16();//Y方向ブロック化係数

            frm_head.parent_zu_type = new PicKind_Code();
            frm_head.parent_zu_type.pic1 = br.ReadByte();
            frm_head.parent_zu_type.pic2 = br.ReadByte();
            frm_head.parent_zu_type.pic3 = br.ReadByte();
            frm_head.parent_zu_type.pic4 = br.ReadByte();


            frm_head.parent_zno = new ZNO();
            frm_head.parent_zno.x = br.ReadUInt16();
            frm_head.parent_zno.y = br.ReadUInt16();

            frm_head.parent_attr_num = br.ReadUInt32();

            frm_head.up_zno = new ZNO();

            frm_head.up_zno.x = br.ReadUInt16();
            frm_head.up_zno.y = br.ReadUInt16();


            frm_head.down_zno = new ZNO();
            frm_head.down_zno.x = br.ReadUInt16();
            frm_head.down_zno.y = br.ReadUInt16();


            frm_head.left_zno = new ZNO();
            frm_head.left_zno.x = br.ReadUInt16();
            frm_head.left_zno.y = br.ReadUInt16();


            frm_head.right_zno = new ZNO();
            frm_head.right_zno.x = br.ReadUInt16();
            frm_head.right_zno.y = br.ReadUInt16();

            frm_head.maxlay = br.ReadUInt16();           // 最大レイヤ番号
            frm_head.rsv = br.ReadUInt16();              // リザーブ
            frm_head.brk_ptr = br.ReadUInt32();          // ブロック管理部アドレス
            frm_head.brk_cnt = br.ReadUInt32();          // ブロック情報部レコード数
            frm_head.inf_ptr = br.ReadUInt32();          // 属性対応管理部アドレス
            frm_head.inf_cnt = br.ReadUInt32();          // 属性対応情報部レコード数
            frm_head.brk_str = br.ReadUInt32();          // ブロック部開始アドレス
            frm_head.ref_ptr = br.ReadUInt32();          // 関連図管理部アドレス
            frm_head.ref_cnt = br.ReadUInt32();          // 関連図情報部レコード数
            frm_head.rsv_ptr = br.ReadUInt32();          // 予約領域部アドレス
            frm_head.file_sz = br.ReadUInt32();          // ファイル容量

            maxlay = frm_head.maxlay;

            listInfo.Items.Clear();

            listInfo.Items.Add("座標系の原点の経度:" + frm_head.org_lon);//座標系の原点の経度
            listInfo.Items.Add("座標系の原点の緯度:" + frm_head.org_lat);//座標系の原点の緯度
            listInfo.Items.Add("座標系の原点からZMD原点へのX方向オフセット:" + frm_head.offset_x1);//座標系の原点からZMD原点へのX方向オフセット
            listInfo.Items.Add("座標系の原点からZMD原点へのY方向オフセット:" + frm_head.offset_y1);//座標系の原点からZMD原点へのY方向オフセット
            listInfo.Items.Add("ZMD原点から図の原点へのX方向の距離:" + frm_head.offset_x2);//ZMD原点から図の原点へのX方向の距離
            listInfo.Items.Add("ZMD原点から図の原点へのY方向の距離:" + frm_head.offset_y2);//ZMD原点から図の原点へのY方向の距離

            listInfo.Items.Add("図の原点の経度:" + frm_head.org_x);//図の原点の経度
            listInfo.Items.Add("図の原点の緯度:" + frm_head.org_y);//図の原点の緯度
            listInfo.Items.Add("図あたりのX方向の幅:" + frm_head.x_width);//図あたりのX方向の幅
            listInfo.Items.Add("図あたりのY方向の幅:" + frm_head.y_width);//図あたりのY方向の幅
            listInfo.Items.Add("図あたりのX方向座標数:" + frm_head.x_cnt);//図あたりのX方向座標数
            listInfo.Items.Add("図あたりのY方向座標数:" + frm_head.y_cnt);//図あたりのY方向座標数
            listInfo.Items.Add("正規化係数:" + frm_head.param);//正規化係数
            listInfo.Items.Add("X方向ブロック化係数:" + frm_head.x_prk);//X方向ブロック化係数
            listInfo.Items.Add("Y方向ブロック化係数:" + frm_head.y_prk);//Y方向ブロック化係数

            //座標最大値
            max_x = frm_head.x_cnt;
            max_y = frm_head.y_cnt;


            NormarizeParam = (int)frm_head.param;

            double pVal = rate * (double)100 / (double)NormarizeParam;

            //rate = rate * p;


            //            if (createbg == false)
            //          {
            //            bg_canvas = new Bitmap((int)(frm_head.x_cnt / rate), (int)(frm_head.y_cnt / rate));
            //          bg_g = Graphics.FromImage(bg_canvas);
            //        createbg = true;
            //  }

            int sx = 75000 / (int)frm_head.param;
            int sy = 50000 / (int)frm_head.param;

//            msize_w = sx;//メッシュサイズW取得
//            msize_h = sy;//メッシュサイズh取得
            msize_w = 750;//メッシュサイズW取得
            msize_h = 500;//メッシュサイズh取得

            Offset.X = 0; Offset.Y = frm_head.y_cnt;//メッシュの最大値


            char[] s_fname = new char[256];

            s_fname = fname.ToCharArray();

            byte[] s1 = new byte[4];
            byte[] s2 = new byte[4];
            byte[] s3 = new byte[4];
            byte[] s4 = new byte[4];

            System.UInt32[] brkptr = new System.UInt32[99];
            System.UInt32[] brksize = new System.UInt32[99];


            int valx = 0;
            int valy = 0;

            for (int j = 0; j < 4; j++)
            {
                if (s_fname[j] >= 'A' && s_fname[j] <= 'P')
                {
                    valx += (int)(s_fname[j] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valx += (int)(s_fname[j] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                if (s_fname[j + 4] >= 'A' && s_fname[j + 4] <= 'P')
                {
                    valy += (int)(s_fname[j + 4] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }


                else
                {
                    valy += (int)(s_fname[j + 4] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
            }

            s1 = BitConverter.GetBytes(valx);
            s2 = BitConverter.GetBytes(valy);

            FRM_BRK frm_brk = new FRM_BRK();
            FRM_INF frm_inf = new FRM_INF();
            FRM_LAY frm_lay = new FRM_LAY();


            //
            //ブロック管理部
            //

            fs.Seek(frm_head.brk_ptr, SeekOrigin.Begin);

            for (int i = 0; i < frm_head.brk_cnt; i++)
            {
                frm_brk.brk_ptr = br.ReadUInt32();
                frm_brk.brk_sz = br.ReadUInt32();

                s3 = BitConverter.GetBytes(frm_brk.brk_ptr);


                s3[0] = (byte)(s3[0] ^ s1[0]);
                s3[1] = (byte)(s3[1] ^ s1[1]);
                s3[2] = (byte)(s3[2] ^ s2[0]);
                s3[3] = (byte)(s3[3] ^ s2[1]);
                //マスクとのXOR
                s3[1] = (byte)(s3[1] ^ mask);
                s3[2] = (byte)(s3[2] ^ mask);


                frm_brk.brk_ptr = BitConverter.ToUInt32(s3, 0);

                brkptr[i] = frm_brk.brk_ptr;
                brksize[i] = frm_brk.brk_sz;
            }


            string baafile = zmdfile.Replace("\\FRM\\", "\\ATR\\");
            baafile = baafile.Replace(".BCF", ".BCA");

            //
            //属性対応情報管理部
            //

            fs.Seek(frm_head.inf_ptr, SeekOrigin.Begin);


            for (int i = 0; i < frm_head.inf_cnt; i++)
            {
                frm_inf.inf_num = br.ReadUInt32();          // 図内属性番号
                frm_inf.inf_z_brk = br.ReadUInt16();        // 図形形状所属ブロック
                frm_inf.inf_m_brk = br.ReadUInt16();        // 文字形状所属ブロック
                frm_inf.inf_z_off = br.ReadUInt32();        // 図形形状ブロック内オフセット
                frm_inf.inf_m_off = br.ReadUInt32();        // 文字形状ブロック内オフセット
                frm_inf.inf_recnum = br.ReadUInt32();       // 属性情報部レコード番号
                frm_inf.rsv = br.ReadUInt32();             // リザーブ

                ReadBAA(baafile, passfile, (int)frm_inf.inf_recnum);

            }

            //
            //ブロック部
            //

            for (int i = 0; i < frm_head.brk_cnt; i++)
            {
                if (brksize[i] > 0)
                {
                    fs.Seek(brkptr[i], SeekOrigin.Begin);

                    //FrmSub(g, i, fs, br, brksize[i], rate, offset_w, offset_h);
                    FrmSub(bg_g, i, fs, br, brksize[i], pVal, mx, my);

                    //f1.PaintView();
                }
            }

            //
            //関連情報管理部
            //

            //
            //予約領域部
            //

            fs.Close();
            br.Close();

        }


        public void FrmSub(Graphics g, int brkno, FileStream fs, BinaryReader br, System.UInt32 brksize, double pVal, int offset_w, int offset_h)
        {

            FRM_FRMCOM frm_com = new FRM_FRMCOM();

            List<Poly> po = new List<Poly>();

            //形状情報部

            Boolean EOF = false;
            byte[] buf = new byte[2048];


            UInt32[] lay_off = new UInt32[maxlay];
            UInt32[] lay_size = new UInt32[maxlay];
            UInt32[] lay_frm_off = new UInt32[maxlay];


            int flg = 0;
            int newbufcnt = 0;

            //
            //ブロックの先頭ポインタ
            //
            int brkstart = (int)fs.Seek(0, SeekOrigin.Current);

            int size = 0;

            //レイヤ情報部
            for (int j = 0; j < maxlay; j++)
            {

                lay_off[j] = br.ReadUInt32();
                lay_size[j] = br.ReadUInt32();
                lay_frm_off[j] = br.ReadUInt32();
                size += 12;
            }

            while (EOF != true)
            {
                int cur = (int)fs.Seek(0, SeekOrigin.Current) - brkstart;

                //
                //レイヤ番号判定
                //
                int layno = -1;

                for (int k = 0; k < maxlay; k++)
                {
                    if (lay_frm_off[k] != 0xffffffff && cur >= lay_off[k] && cur < lay_off[k] + lay_size[k])
                    {
                        layno = k + 1;
                        break;
                    }
                }

                frm_com.frmcom_recnum = br.ReadUInt32();
                frm_com.frmcom_size = br.ReadUInt16();
                frm_com.frmcom_type = br.ReadByte();
                frm_com.frmcom_status = br.ReadByte();

                size += 8;

                int type = (int)frm_com.frmcom_type;
                int len = frm_com.frmcom_size - (8);

                buf = br.ReadBytes(len);

                FRM_AREAPOLY frm_areapoly = new FRM_AREAPOLY();
                frm_areapoly.ldxy = new XY();
                frm_areapoly.ruxy = new XY();
                FRM_STRINF frm_strinf = new FRM_STRINF();
                frm_strinf.ldxy = new XY();
                frm_strinf.ruxy = new XY();
                FRM_STRLINE frm_strline = new FRM_STRLINE();
                frm_strline.kxy = new XY();
                FRM_SYMBOL frm_symbol = new FRM_SYMBOL();
                frm_symbol.ldxy = new XY();
                frm_symbol.ruxy = new XY();
                frm_symbol.kxy = new XY();
                FRM_LINES frm_lines = new FRM_LINES();
                frm_lines.ldxy = new XY();
                frm_lines.ruxy = new XY();

                FRM_POLYGON frm_polygon = new FRM_POLYGON();
                frm_polygon.ldxy = new XY();
                frm_polygon.ruxy = new XY();

                FRM_OUTPOLY frm_outpoly = new FRM_OUTPOLY();
                frm_outpoly.ldxy = new XY();
                frm_outpoly.ruxy = new XY();

                FRM_INPOLY frm_inpoly = new FRM_INPOLY();
                FRM_INPOLY frm_areainpoly = new FRM_INPOLY();

                FRM_STRSYM frm_strsym = new FRM_STRSYM();
                frm_strsym.ldxy = new XY();
                frm_strsym.ruxy = new XY();
                frm_strsym.kxy = new XY();


                int offset = 0;

                int wx = 0;
                int wy = 0;

                switch (type)
                {
                    case 1://文字
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        {
                            frm_strinf.ldxy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.ldxy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.ruxy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.ruxy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.height = BitConverter.ToUInt16(buf, offset);
                            offset += 2;
                            frm_strinf.angle = BitConverter.ToUInt16(buf, offset);
                            offset += 2;

                            frm_strinf.c1 = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;
                            frm_strinf.c2 = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;
                            frm_strinf.form = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;
                            frm_strinf.line = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;

                            for (int k = 0; k < frm_strinf.line; k++)
                            {
                                frm_strline.kxy.x = BitConverter.ToInt16(buf, offset);
                                offset += 2;
                                frm_strline.kxy.y = BitConverter.ToInt16(buf, offset);
                                offset += 2;
                                frm_strline.width = BitConverter.ToUInt16(buf, offset);
                                offset += 2;
                                frm_strline.height = BitConverter.ToUInt16(buf, offset);
                                offset += 2;
                                frm_strline.cnt = BitConverter.ToUInt16(buf, offset);
                                offset += 2;

                                byte[] strbuf1 = new byte[frm_strline.cnt * 2];
                                Array.Copy(buf, offset, strbuf1, 0, frm_strline.cnt * 2);

                                byte[] strbuf2 = jis2sj.Jis2Sjis(strbuf1);

                                string text = System.Text.Encoding.GetEncoding("shift_jis").GetString(strbuf2);

                                wx = frm_strline.kxy.x - Offset.X;
                                wy = frm_strline.kxy.y - Offset.Y;

                                int str_sx = (int)((double)wx / pVal) + offset_w;
                                int str_sy = (int)((double)(-wy) / pVal) + offset_h;


                                if (layno == 113)
                                {
                                    NumberInfo num = new NumberInfo();
                                    //                                    num.x = frm_strline.kxy.x + 10;
                                    //                                    num.y = frm_strline.kxy.y;
                                    num.x = str_sx + 10;
                                    num.y = str_sy;
                                    num.number = text;
                                    numberinfo.Add(num);
                                }


                                int font_size = (int)((double)frm_strline.height / pVal);

                                //★計算は暫定

                                Font s_font;

                                SolidBrush s_br;//文字用

                                if (pVal > 20)
                                {
                                    pVal = 20;
                                }
                                else
                                {
                                }

                                if (layno >= 96 && layno <= 99)
                                {
                                    font_size = (int)(30 / pVal);
                                    s_br = new SolidBrush(Color.Red);
                                }
                                else
                                {
                                    font_size = 20;
                                    s_br = new SolidBrush(Color.Black);
                                }

                                //}



                                //font_size = 24;

                                FontFamily fontFamily = new FontFamily("ＭＳ Ｐゴシック");
                                s_font = new Font(
                                fontFamily,
                                    font_size,
                                   FontStyle.Regular,
                                   GraphicsUnit.Pixel);


                                var format = new StringFormat();
                                format.Alignment = StringAlignment.Near;      // 左右方向は中心寄せ
                                format.LineAlignment = StringAlignment.Near;  // 上下方向は中心寄せ

                                g.SmoothingMode = SmoothingMode.AntiAlias;
                                if (frm_strinf.form == 2)
                                {


                                    format.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                                    StringCOM.DrawString(g, text, s_font, s_br, str_sx, str_sy - font_size, -frm_strinf.angle, format);
                                }
                                else
                                {

                                    format.FormatFlags = StringFormatFlags.DirectionVertical;
                                    StringCOM.DrawString(g, text, s_font, s_br, str_sx - font_size, str_sy, -frm_strinf.angle, format);
                                }
                                s_br.Dispose();
                                s_font.Dispose();
                                offset += frm_strline.cnt * 2;
                            }
                        }

                        break;
                    case 2://部品

                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_symbol.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.width = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_symbol.angle = BitConverter.ToUInt16(buf, offset);//角度
                        offset += 2;
                        frm_symbol.kxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.kxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.symno = BitConverter.ToUInt16(buf, offset);//部品番号
                        offset += 2;

                        wx = frm_symbol.kxy.x - Offset.X;
                        wy = frm_symbol.kxy.y - Offset.Y;

                        int symbol_sx = (int)((double)wx / pVal) + offset_w;
                        int symbol_sy = (int)((double)(-wy) / pVal) + offset_h;

                        //MsgOut("symno=" + frm_symbol.symno.ToString());

                        //角度を考慮するとどうなるか？
                        //Image image = SymbolImage[frm_symbol.symno];
                        //double deg = frm_symbol.angle;
                        //Point iconP = new Point(symbol_sx, symbol_sy);
                        //int iconSize = 32;

                        //DrawIcon(g, image, deg, iconP, iconSize);
                        //                        g.DrawImage(SymbolImage[frm_symbol.symno], symbol_sx - 16, symbol_sy - 16, 32, 32);

                        break;
                    case 3://折れ線

                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_lines.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        XY lines_xy = new XY();
                        Point[] lines_pnt = new Point[frm_lines.cnt];

                        for (int k = 0; k < frm_lines.cnt; k++)
                        {
                            lines_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            lines_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = lines_xy.x - Offset.X;
                            wy = lines_xy.y - Offset.Y;

                            lines_pnt[k].X = (int)((double)wx / pVal) + offset_w;
                            lines_pnt[k].Y = (int)((double)(-wy) / pVal) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawLines(pe[0], lines_pnt);

                        break;
                    case 4://単純ポリゴン
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_polygon.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        XY polygon_xy = new XY();
                        Point[] draw_polygon_pnt = new Point[frm_polygon.cnt];
                        Point[] polygon_pnt = new Point[frm_polygon.cnt];

                        for (int k = 0; k < frm_polygon.cnt; k++)
                        {
                            polygon_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            polygon_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            polygon_pnt[k].X = polygon_xy.x;
                            polygon_pnt[k].Y = polygon_xy.y;

                            wx = polygon_xy.x - Offset.X;
                            wy = polygon_xy.y - Offset.Y;

                            draw_polygon_pnt[k].X = (int)((double)wx / pVal) + offset_w;
                            draw_polygon_pnt[k].Y = (int)((double)(-wy) / pVal) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        if (layno == 8 || layno == 18)
                        {
                            //g.FillPolygon(b[3], polygon_pnt);
                        }
                        else
                        {
                            //g.FillPolygon(b[1], polygon_pnt);
                        }

                        //                        if (pcnt == 0)
                        //                      {
                        // g.DrawPolygon(pe[1], draw_polygon_pnt);

                        g.DrawPolygon(pe[1], draw_polygon_pnt);

                        //Mesh mdata = new Mesh();

                        int minx = int.MaxValue, miny = int.MaxValue;
                        int maxx = int.MinValue, maxy = int.MinValue;


                        for (int k = 0; k < draw_polygon_pnt.Length; k++)
                        {
                            if (minx > draw_polygon_pnt[k].X)
                            {
                                minx = draw_polygon_pnt[k].X;
                            }
                            if (maxx < draw_polygon_pnt[k].X)
                            {
                                maxx = draw_polygon_pnt[k].X;
                            }
                            if (miny > draw_polygon_pnt[k].Y)
                            {
                                miny = draw_polygon_pnt[k].Y;
                            }
                            if (maxy < draw_polygon_pnt[k].Y)
                            {
                                maxy = draw_polygon_pnt[k].Y;
                            }
                        }

                        mdata.minx = minx;
                        mdata.maxx = maxx;
                        mdata.miny = miny;
                        mdata.maxy = maxy;

                        mesh.Add(mdata);


                        //MsgOut("meshcnt=" + mesh.Count);
                        //                    }

                        //pcnt++;

                        break;
                    case 5://中抜きポリゴン
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_outpoly.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.inpoly = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        flg = frm_outpoly.cnt;

                        if (flg < 16)
                        {
                            flg = 16;
                        }
                        else
                        {
                            int s = flg / 16; //16の倍数
                            int a = flg % 16; //16で割ったあまり

                            if (a > 0)
                            {
                                flg = 16 * (s + 1);
                            }
                            else
                            {
                                flg = 16 * s;
                            }

                        }

                        newbufcnt = flg / 8;

                        byte[] outpolybuf = new byte[newbufcnt];
                        Array.Copy(buf, offset, outpolybuf, 0, newbufcnt);

                        offset += newbufcnt;//バイト分シフト

                        XY outpoly_xy = new XY();
                        Point[] outpoly_pnt = new Point[frm_outpoly.cnt];


                        for (int k = 0; k < frm_outpoly.cnt; k++)
                        {
                            outpoly_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;


                            outpoly_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = outpoly_xy.x - Offset.X;
                            wy = outpoly_xy.y - Offset.Y;


                            outpoly_pnt[k].X = (int)((double)wx / pVal) + offset_w;
                            outpoly_pnt[k].Y = (int)((double)(-wy) / pVal) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        if (layno == 8 || layno == 18)
                        {
                            g.FillPolygon(b[3], outpoly_pnt);
                        }
                        else
                        {
                            g.FillPolygon(b[1], outpoly_pnt);
                        }

                        g.DrawPolygon(pe[2], outpoly_pnt);

                        //中抜きポリゴン
                        for (int m = 0; m < frm_outpoly.inpoly; m++)
                        {
                            frm_inpoly.cnt = BitConverter.ToUInt16(buf, offset);
                            offset += 2;

                            flg = frm_inpoly.cnt;

                            if (flg < 16)
                            {
                                flg = 16;
                            }
                            else
                            {
                                int s = flg / 16; //16の倍数
                                int a = flg % 16; //16で割ったあまり

                                if (a > 0)
                                {
                                    flg = 16 * (s + 1);
                                }
                                else
                                {
                                    flg = 16 * s;
                                }

                            }

                            newbufcnt = flg / 8;

                            byte[] inpolybuf = new byte[newbufcnt];
                            Array.Copy(buf, offset, inpolybuf, 0, newbufcnt);

                            offset += newbufcnt;//バイト分シフト

                            XY inpoly_xy = new XY();
                            Point[] inpoly_pnt = new Point[frm_inpoly.cnt];


                            for (int k = 0; k < frm_inpoly.cnt; k++)
                            {
                                inpoly_xy.x = BitConverter.ToInt16(buf, offset);
                                offset += 2;


                                inpoly_xy.y = BitConverter.ToInt16(buf, offset);
                                offset += 2;

                                wx = inpoly_xy.x - Offset.X;
                                wy = inpoly_xy.y - Offset.Y;

                                inpoly_pnt[k].X = (int)((double)wx / pVal) + offset_w;
                                inpoly_pnt[k].Y = (int)((double)(-wy) / pVal) + offset_h;

                            }
                            g.SmoothingMode = SmoothingMode.AntiAlias;
                            if (layno == 8 || layno == 18)
                            {
                                g.FillPolygon(b[3], inpoly_pnt);
                            }
                            else
                            {
                                g.FillPolygon(b[1], inpoly_pnt);
                            }
                            g.DrawPolygon(pe[2], inpoly_pnt);


                        }



                        break;
                    case 6://行政ポリゴン
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_areapoly.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr1 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr2 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr3 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr4 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.inpoly = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;


                        flg = frm_areapoly.cnt;

                        if (flg < 16)
                        {
                            flg = 16;
                        }
                        else
                        {
                            int s = flg / 16; //16の倍数
                            int a = flg % 16; //16で割ったあまり

                            if (a > 0)
                            {
                                flg = 16 * (s + 1);
                            }
                            else
                            {
                                flg = 16 * s;
                            }

                        }

                        newbufcnt = flg / 8;

                        byte[] areapolybuf = new byte[newbufcnt];
                        Array.Copy(buf, offset, areapolybuf, 0, newbufcnt);

                        offset += newbufcnt;//バイト分シフト

                        XY areapoly_xy = new XY();
                        Point[] areapoly_pnt = new Point[frm_areapoly.cnt];


                        for (int k = 0; k < frm_areapoly.cnt; k++)
                        {
                            areapoly_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            areapoly_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = areapoly_xy.x - Offset.X;
                            wy = areapoly_xy.y - Offset.Y;

                            areapoly_pnt[k].X = (int)((double)wx / pVal) + offset_w;
                            areapoly_pnt[k].Y = (int)((double)(-wy) / pVal) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawPolygon(pe[1], areapoly_pnt);

                        //中抜きポリゴン（行政界）
                        for (int m = 0; m < frm_areapoly.inpoly; m++)
                        {
                            frm_areainpoly.cnt = BitConverter.ToUInt16(buf, offset);
                            offset += 2;

                            flg = frm_areainpoly.cnt;

                            if (flg < 16)
                            {
                                flg = 16;
                            }
                            else
                            {
                                int s = flg / 16; //16の倍数
                                int a = flg % 16; //16で割ったあまり

                                if (a > 0)
                                {
                                    flg = 16 * (s + 1);
                                }
                                else
                                {
                                    flg = 16 * s;
                                }

                            }

                            newbufcnt = flg / 8;

                            byte[] areainpolybuf = new byte[newbufcnt];
                            Array.Copy(buf, offset, areainpolybuf, 0, newbufcnt);

                            offset += newbufcnt;//バイト分シフト

                            XY areainpoly_xy = new XY();
                            Point[] areainpoly_pnt = new Point[frm_areainpoly.cnt];


                            for (int k = 0; k < frm_areainpoly.cnt; k++)
                            {
                                areainpoly_xy.x = BitConverter.ToInt16(buf, offset);
                                offset += 2;

                                areainpoly_xy.y = BitConverter.ToInt16(buf, offset);
                                offset += 2;

                                wx = areainpoly_xy.x - Offset.X;
                                wy = areainpoly_xy.y - Offset.Y;

                                areainpoly_pnt[k].X = (int)((double)wx / pVal) + offset_w;
                                areainpoly_pnt[k].Y = (int)((double)(-wy) / pVal) + offset_h;

                            }

                            g.SmoothingMode = SmoothingMode.AntiAlias;
                            g.DrawPolygon(pe[2], areainpoly_pnt);
                        }

                        break;
                    case 7://文字付部品
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_strsym.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.width = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_strsym.angle = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_strsym.kxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.kxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.symno = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_strsym.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        wx = frm_strsym.kxy.x - Offset.X;
                        wy = frm_strsym.kxy.y - Offset.Y;


                        int strsymbol_sx = (int)((double)wx / pVal) + offset_w;
                        int strsymbol_sy = (int)((double)(-wy) / pVal) + offset_h;

                        //g.DrawString("☆", f[0], b[0], strsymbol_sx, strsymbol_sy);

                        byte[] strsymbuf1 = new byte[frm_strsym.cnt * 2];
                        Array.Copy(buf, offset, strsymbuf1, 0, frm_strsym.cnt * 2);

                        byte[] strsymbuf2 = jis2sj.Jis2Sjis(strsymbuf1);

                        string strtext = System.Text.Encoding.GetEncoding("shift_jis").GetString(strsymbuf2);


                        Point p = new Point(strsymbol_sx, strsymbol_sy);

                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        if (layno == 100)
                        {
                            ////DrawGaiku(g, p, strtext);
                        }
                        else
                        {
                            g.DrawString(strtext, f[0], b[0], strsymbol_sx - 10, strsymbol_sy - 10);
                        }

                        break;
                    default:
                        if (zmd_layer_disp[layno - 1] == false) break;
                        break;

                }

                size += len;

                if (size >= brksize)
                {
                    EOF = true;
                }
            }

        }

        public UInt32 GetMask(string PasswordFile)
        {
            int m_mask = 0;

            System.UInt32[] data = new System.UInt32[18];

            char[] passwd = new char[256];

            string str_passwd = "";

            if (File.Exists(PasswordFile) == false) return 0;


            StreamReader sr = new StreamReader(PasswordFile, Encoding.GetEncoding("Shift_JIS"));

            while (sr.Peek() != -1)
            {
                string header = "PassWord1=";

                string line = sr.ReadLine();

                if (line.IndexOf(header) == 0)
                {
                    str_passwd = line.Substring(header.Length);
                }
            }
            sr.Close();

            passwd = str_passwd.ToCharArray();

            int j = 0;
            for (int i = 0; i < 18; i++)
            {

                if (passwd[i] >= 'a' && passwd[i] <= 'z')
                {
                    data[j] = (System.UInt32)(122 - passwd[i]);
                }
                else if (passwd[i] == '#')
                {
                    data[j] = 26;
                }
                else if (passwd[i] >= '0' && passwd[i] <= '9')
                {
                    data[j] = (System.UInt32)(passwd[i] - 21);
                }
                else if (passwd[i] == '%')
                {
                    data[j] = 37;
                }
                if (passwd[i] >= 'A' && passwd[i] <= 'Z')
                {
                    data[j] = (System.UInt32)(passwd[i] - 27);
                }
                j++;
            }
            m_mask = (int)(data[7] << 6 | ((data[8] << 2) >> 2));


            string bit = "";
            for (int i = 0; i < data.Length; i++)
            {
                if (i == 4 || i == 9)//c5 c10以外
                {

                }
                else
                {
                    bit += Convert.ToString(data[i], 2).PadLeft(6, '0');
                }
            }

            int cnt = bit.Length / 8;
            string[] param = new string[cnt];
            UInt32[] t = new UInt32[cnt];

            for (int i = 0; i < cnt; i++)
            {
                param[i] = bit.Substring(i * 8, 8);
                Console.WriteLine(param[i]);


                t[i] = Convert.ToUInt32(param[i], 2);
            }

            //
            //t[8]:単独図の復号キー
            //

            return t[8];
        }
        private void ReadBAA(string BaaFile, string PasswordFile, int recnum)
        {

            mask = GetMask(PasswordFile);

            string baa_fname = BaaFile;

            FileStream fs = new FileStream(baa_fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            byte[] buf = new byte[2048];
            byte[] wbuf16 = new byte[16];
            byte[] wbuf62 = new byte[62];


            buf = br.ReadBytes(4);//図種別
            UInt16 zno_x = br.ReadUInt16();//図番号X
            UInt16 zno_y = br.ReadUInt16();//図番号Y

            uint ptr1 = br.ReadUInt32();//住所索引管理部アドレス
            uint rec1 = br.ReadUInt32();//住所索引情報部レコード数
            uint ptr2 = br.ReadUInt32();//属性情報管理部アドレス
            uint rec2 = br.ReadUInt32();//属性情報部レコード数
            uint ptr3 = br.ReadUInt32();//別記属性管理部アドレス
            uint rec3 = br.ReadUInt32();//別記属性管理部容量

            fs.Seek(ptr1, SeekOrigin.Begin);

            for (int i = 0; i < rec1; i++)
            {
                UInt16 city = br.ReadUInt16();
                UInt16 town1 = br.ReadUInt16();
                UInt16 town2 = br.ReadUInt16();
                UInt16 gcode = br.ReadUInt16();
                uint z_ptr = br.ReadUInt32();
                uint z_cnt = br.ReadUInt32();
            }

            byte[] s1 = new byte[4];
            byte[] s2 = new byte[4];
            byte[] s3 = new byte[4];
            byte[] s4 = new byte[4];

            int valx = 0;
            int valy = 0;

            string fname = Path.GetFileNameWithoutExtension(baa_fname);

            char[] s_fname = new char[256];
            s_fname = fname.ToCharArray();


            for (int j = 0; j < 4; j++)
            {
                if (s_fname[j] >= 'A' && s_fname[j] <= 'P')
                {
                    valx += (int)(s_fname[j] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valx += (int)(s_fname[j] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                if (s_fname[j + 4] >= 'A' && s_fname[j + 4] <= 'P')
                {
                    valy += (int)(s_fname[j + 4] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valy += (int)(s_fname[j + 4] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
            }

            s1 = BitConverter.GetBytes(valx);
            s2 = BitConverter.GetBytes(valy);

            s3 = BitConverter.GetBytes(ptr2);

            s3[0] = (byte)(s3[0] ^ s1[0]);
            s3[1] = (byte)(s3[1] ^ s1[1]);
            s3[2] = (byte)(s3[2] ^ s2[0]);
            s3[3] = (byte)(s3[3] ^ s2[1]);
            //マスクとのXOR
            s3[1] = (byte)(s3[1] ^ mask);
            s3[2] = (byte)(s3[2] ^ mask);


            ptr2 = BitConverter.ToUInt32(s3, 0);
            fs.Seek(ptr2, SeekOrigin.Begin);

            for (int i = 0; i < rec2; i++)
            {
                uint zno = br.ReadUInt32();//図番号
                UInt16 ztype = br.ReadUInt16();//属性種別
                UInt16 zcity = br.ReadUInt16();//拡張市町村
                UInt16 ztown1 = br.ReadUInt16();//大字
                UInt16 ztown2 = br.ReadUInt16();//丁目
                UInt16 zgcode = br.ReadUInt16();//街区

                buf = br.ReadBytes(2);

                wbuf16 = br.ReadBytes(16);//地番
                byte[] number_buf = jis2sj.Jis2Sjis(wbuf16);
                string number = System.Text.Encoding.GetEncoding("shift_jis").GetString(number_buf);

                byte septype = br.ReadByte();
                byte seppos = br.ReadByte();

                wbuf62 = br.ReadBytes(62);//名称
                byte[] name_buf = jis2sj.Jis2Sjis(wbuf62);
                string name = System.Text.Encoding.GetEncoding("shift_jis").GetString(name_buf);

                Int16 floor = br.ReadInt16();//建物階数

                uint frm_zno = br.ReadUInt32();//形状対応情報部のレコード番号
                uint frm_zoffset = br.ReadUInt32();//別記属性管理部からのオフセット

                if (frm_zno == recnum)
                {

                    if (ztown1 > 0)
                    {
                    }

                    if (ztown2 > 0)
                    {
                    }

                    if (frm_zoffset != 0xffffffff)
                    {
                        fs.Seek(ptr3 + frm_zoffset, SeekOrigin.Begin);
                        uint ext_cnt = br.ReadUInt32();//別記属性レコード数

                        for (int m = 0; m < ext_cnt; m++)
                        {
                            uint ext_no = br.ReadUInt32();
                            uint ext_code = br.ReadUInt16();
                            char ctype = br.ReadChar();

                            byte rsv = br.ReadByte();
                            int ext_floor = br.ReadInt16();

                            byte[] wfloor_name = new byte[10];
                            wfloor_name = br.ReadBytes(10);//地番
                            byte[] floor_name_buf = jis2sj.Jis2Sjis(wfloor_name);
                            string floor_name = System.Text.Encoding.GetEncoding("shift_jis").GetString(floor_name_buf);

                            byte sep_type = br.ReadByte();
                            byte sep_pos = br.ReadByte();

                            byte[] wext_name = new byte[50];
                            wext_name = br.ReadBytes(50);//地番
                            byte[] ext_name_buf = jis2sj.Jis2Sjis(wext_name);
                            string ext_name = System.Text.Encoding.GetEncoding("shift_jis").GetString(ext_name_buf);

                        }
                    }

                    break;
                }
            }

            fs.Close();
            br.Close();
        }

        private void NumberToXY(string number, ref int x, ref int y)
        {
            int ret = 0;

            string result = number.Replace("０", "0");
            result = result.Replace("１", "1");
            result = result.Replace("２", "2");
            result = result.Replace("３", "3");
            result = result.Replace("４", "4");
            result = result.Replace("５", "5");
            result = result.Replace("６", "6");
            result = result.Replace("７", "7");
            result = result.Replace("８", "8");
            result = result.Replace("９", "9");

            string sx = result.Substring(0, 5);
            string sy = result.Substring(5, 5);

            x = Int32.Parse(sx);
            y = Int32.Parse(sy);

        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            string msg = "";

            int orgx = Int32.Parse(textORGX.Text);//cm
            int orgy = Int32.Parse(textORGY.Text);//cm

            double gx = orgx + (double)(e.X - offset_w) * rate * 100;
            double gy = orgy - (double)(e.Y - offset_h) * rate * 100;

            textZX.Text = gx.ToString();
            textZY.Text = gy.ToString();

            double lx = gx / 100.0;
            double ly = gy / 100.0;

            double keido = 0.0;
            double ido = 0.0;

            MapComLib.Convert.gpconv2(lx, ly, 6, ref keido, ref ido);


            double keido2 = keido / 3600;
            double ido2 = ido / 3600;

            textLon.Text = keido2.ToString("F5");
            textLat.Text = ido2.ToString("F5");


            int x = e.X - offset_w;
            int y = e.Y - offset_h;

            MsgOut("x=" + x + ",y=" + y);


            int wx = 0;
            int wy = 0;
            int mx = 0;
            int my = 0;

            Boolean IsHit = false;

            for (int i = 0; i < mesh.Count; i++)
            {
                if (x >= mesh[i].minx && x <= mesh[i].maxx && y >= mesh[i].miny && y <= mesh[i].maxy)
                {
                    for (int j = 0; j < numberinfo.Count; j++)
                    {
                        if (numberinfo[j].x > mesh[i].minx && numberinfo[j].x < mesh[i].maxx && numberinfo[j].y > mesh[i].miny && numberinfo[j].y < mesh[i].maxy)
                        {

                            msg = mesh[i].minx.ToString() + ", " + mesh[i].maxx.ToString() + ", " + mesh[i].miny.ToString() + ", " + mesh[i].maxy.ToString();

                            textMeshNo.Text = numberinfo[j].number;

                            NumberToXY(numberinfo[j].number, ref mx, ref my);

                            wx = mesh[i].minx;
                            wy = mesh[i].miny;

                            IsHit = true;
                            break;
                        }
                    }
                    break;
                }
            }

            switch (click_mode)
            {
                case 0:
                    break;
                case 1:

                    if (IsHit == true)
                    {
                        int page = Int32.Parse(textPage.Text);
                        int PageSize = Int32.Parse(textPageSize.Text);

                        //int wx = mesh[i].minx;
                        //int wy = mesh[i].miny;

                        if (PageSize == 2)
                        {
                            wy -= msize_h;
                            my--;
                        }

                        //                                int w =Int32.Parse(textMWidth.Text)*PageSize;
                        //                              int h = Int32.Parse(textMHeight.Text)*PageSize;
                        int w = msize_w * PageSize;
                        int h = msize_h * PageSize;

                        AddPage(page, wx, wy, w, h, mx, my, PageSize);

                        LoadData(false);
                    }
                    click_mode = 0;
                    break;
                case 2:

                    if (drawAllPage == true)
                    {

                        var items = listBook.SelectedIndices;

                        foreach (int idx in items)
                        {
                            string filePath = pageinfo[idx];

                            Point get_p = new Point();

                            get_p.X = (int)gx;
                            get_p.Y = (int)gy;

                            int ret = GetPage(get_p, filePath);
                            if (ret > 0)
                            {
                                Form2 f2 = new Form2();
                                f2.book = book[idx];
                                f2.page = ret;
                                f2.filePath = filePath;
                                f2.ShowDialog();
                            }
                        }

                    }
                    else
                    {
                        int idx = listBook.SelectedIndex;
                        //                  if (idx == -1)
                        //                {
                        //              }
                        //            else
                        //          {
                        string filePath = pageinfo[idx];

                        Point get_p = new Point();

                        get_p.X = (int)gx;
                        get_p.Y = (int)gy;

                        int ret = GetPage(get_p, filePath);

                        if (ret > 0)
                        {
                            Form2 f2 = new Form2();
                            f2.book = book[idx];
                            f2.page = ret;
                            f2.filePath = filePath;
                            f2.ShowDialog();
                        }

                        //        }
                    }

                    click_mode = 0;
                    break;
                case 3:
                    SaveCenterPos(gx, gy);
                    break;
            }



//            msg = e.X.ToString() + "-" + e.Y.ToString();
            //MsgOut(msg);
        }


        private void AddPage(int page, int wx, int wy, int w, int h, int mx, int my, int pagesize)
        {

            int idx = listBook.SelectedIndex;

            if (idx == -1) return;

            string filePath = pageinfo[idx];


            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {

                    int zx = (mx - 1) * 75000 + ZMDORGX;//cm
                    int zy = (my - 1)* 50000 + ZMDORGY;//cm
                    int zx2 = zx+ w*100;//cm
                    int zy2 = zy+h*100;//cm

                    double lx = (double)zx / 100.0;
                    double ly = (double)zy / 100.0;

                    double keido = 0.0;
                    double ido = 0.0;

                    MapComLib.Convert.gpconv2(lx, ly, 6, ref keido, ref ido);


                    string line = page + "," + wx + "," + wy + "," + w + "," + h + "," + mx + "," + my + "," + keido * 1000 + "," + ido * 1000 + "," + zx + "," + zy + "," + zx2 + "," + zy2 + ","+ pagesize;

                    writer.WriteLine(line);
                }
            }
            catch (Exception e)
            {
            }


        }

        private int GetPage(Point get_p, string filePath)
        {
            int ret = 0;

//            int idx = listBook.SelectedIndex;
  //          if (idx == -1) return ret;
//            string filePath = pageinfo[idx];

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {

                        string[] param = line.Split(',');


                        if (param.Length >= 10)
                        {
                            int page = Int32.Parse(param[0]);//ページ
                            int wx = Int32.Parse(param[1]);//メッシュ内座標X
                            int wy = Int32.Parse(param[2]);//メッシュ内座標Y
                            int ww = Int32.Parse(param[3]);//幅
                            int wh = Int32.Parse(param[4]);//高さ
                            int mx = Int32.Parse(param[5]);
                            int my = Int32.Parse(param[6]);
                            Double keido = Double.Parse(param[7]);//経度
                            Double ido = Double.Parse(param[8]);//緯度
                            int lx = Int32.Parse(param[9]);//左下正規化座標X
                            int ly = Int32.Parse(param[10]);//左下正規化座標Y
                            int lx2 = Int32.Parse(param[11]);//右上正規化座標X
                            int ly2 = Int32.Parse(param[12]);//右上正規化座標Y
                            int pagesize = Int32.Parse(param[13]);//ページサイズ

                            int x = wx;
                            int y = wy;
                            int w = ww;
                            int h = wh;

                            Point[] p = new Point[4];

                            p[0].X = lx; p[0].Y = ly;
                            p[1].X = lx + w*100; p[1].Y = ly;
                            p[2].X = lx + w*100; p[2].Y = ly + h*100;
                            p[3].X = lx; p[3].Y = ly + h*100;

                            if (get_p.X >= p[0].X && get_p.X <= p[1].X && get_p.Y >= p[0].Y && get_p.Y <= p[2].Y)
                            {
                                ret = page;
                                break;
                            }

                        }
                    }
                }
            }
            catch (Exception e)
            {
            }

            return ret;
        }


        private void DrawPage(Graphics m_g,int idx)
        {
            //int idx = listBook.SelectedIndex;

            //if (idx == -1) return;

            string filePath = pageinfo[idx];
//            SolidBrush opaqueBrush = new SolidBrush(Color.FromArgb(128, 0, 0, 255));

            MsgOut("draw page"+ filePath);

            if (drawAllPage == true)
            {
                DrawPageFile(m_g, filePath, opaqueBrush[idx], bookorg[0].X, bookorg[0].Y);
            }
            else
            {
                DrawPageFile(m_g, filePath, opaqueBrush[idx], bookorg[idx].X, bookorg[idx].Y);
            }


            //DrawGrid();


        }

        private void DrawPageFile(Graphics m_g,string filePath, SolidBrush opaqueBrush,int bookoffset_x, int bookoffset_y)
        {

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {

                        string[] param = line.Split(',');


                        if (param.Length >= 10)
                        {
                            int page = Int32.Parse(param[0]);//ページ
                            int wx = Int32.Parse(param[1]);//メッシュ内座標X
                            int wy = Int32.Parse(param[2]);//メッシュ内座標Y
                            int ww = Int32.Parse(param[3]);//幅(m)
                            int wh = Int32.Parse(param[4]);//高さ(m)
                            int mx = Int32.Parse(param[5]);
                            int my = Int32.Parse(param[6]);
                            Double keido = Double.Parse(param[7]);//経度
                            Double ido = Double.Parse(param[8]);//緯度
                            Double lx = Double.Parse(param[9]);//正規化座標X(cm)
                            Double ly = Double.Parse(param[10]);//正規化座標Y(cm)
                            Double lx2 = Double.Parse(param[11]);//正規化座標X(cm)
                            Double ly2 = Double.Parse(param[12]);//正規化座標Y(cm)
                            int pagesize = Int32.Parse(param[13]);//ページサイズ

                            int x = (int)((double)(lx - bookoffset_x) / (100 * rate)) + offset_w;//
                            int y = (int)((double)(bookoffset_y - ly) / (100 * rate)) + offset_h;//

                            //int x = (int)((double)wx / rate) + offset_w;
                            //int y = (int)((double)wy / rate) + offset_h;
                            //                            int y = (int)((double)wy / rate) + offset_h;
                            int w = (int)((double)ww / rate);
                            int h = (int)((double)wh / rate);

                            Point[] p = new Point[4];

                            p[0].X = x; p[0].Y = y;
                            p[1].X = x + w; p[1].Y = y;
                            p[2].X = x + w; p[2].Y = y - h;
                            p[3].X = x; p[3].Y = y - h;

                            //SolidBrush opaqueBrush = new SolidBrush(Color.FromArgb(128, 0, 0, 255));

                            m_g.FillPolygon(opaqueBrush, p);
                            m_g.DrawPolygon(pe[3], p);

                            Font s_font;
                            int font_size = 24;

                            SolidBrush s_br;//文字用

                            //font_size = (int)(30 / rate);
                            s_br = new SolidBrush(Color.White);
                            FontFamily fontFamily = new FontFamily("ＭＳ Ｐゴシック");
                            s_font = new Font(
                            fontFamily,
                                font_size,
                               FontStyle.Regular,
                               GraphicsUnit.Pixel);

                            m_g.DrawString(page.ToString(), s_font, s_br, p[0].X, p[2].Y);

                            s_br.Dispose();
                            s_font.Dispose();


                        }
                    }
                }
            }
            catch (Exception e)
            {
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            click_mode = 1;
        }
        private void btnMod_Click(object sender, EventArgs e)
        {
            click_mode = 2;
        }


        private void PageToCSV(int idx,string inFilePath, string outFilePath)
        {

            //int idx = listBook.SelectedIndex;

            //if (idx < 0) return;

            using (StreamReader reader = new StreamReader(inFilePath))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {

                    string[] param = line.Split(',');


                    if (param.Length >= 10)
                    {
                        int page = Int32.Parse(param[0]);//ページ
                        int wx = Int32.Parse(param[1]);//メッシュ内座標X
                        int wy = Int32.Parse(param[2]);//メッシュ内座標Y
                        int ww = Int32.Parse(param[3]);//幅
                        int wh = Int32.Parse(param[4]);//高さ
                        int mx = Int32.Parse(param[5]);
                        int my = Int32.Parse(param[6]);
                        Double keido = Double.Parse(param[7]);//経度
                        Double ido = Double.Parse(param[8]);//緯度
                        int lx = Int32.Parse(param[9]);//正規化座標X
                        int ly = Int32.Parse(param[10]);//正規化座標Y
                        int lx2 = Int32.Parse(param[11]);//正規化座標X
                        int ly2 = Int32.Parse(param[12]);//正規化座標Y
                        int pagesize = Int32.Parse(param[13]);//ページサイズ


                        //冊,ページ,枝,左右,図面名,スケール,表示地図種別,左下座標X,左下座標Y,左上座標X,左上座標Y,右上座標X,右上座標Y,右下座標X,左下正規化座標X,左下正規化座標Y,左上正規化座標X,左上正規化座標Y,右上正規化座標X,右上正規化座標Y,右下正規化座標X,右下正規化座標Y

                        //左
                        int booknum = Int32.Parse(book[idx]);
                        int eda = 0;
                        int leftright_flg = 0;
                        int zno = 0;
                        int scale = 1500 * pagesize;
                        int maptype = 11;


                        //左ページ
                        //---------------------------------------------------------------------------------------

                        int ld_x = lx;
                        int ld_y = ly - 50000 * pagesize;

                        double w_lx = (double)ld_x / 100.0;
                        double w_ly = (double)ld_y / 100.0;

                        double w_keido = 0.0;
                        double w_ido = 0.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);

                        double ld_keido = w_keido;
                        double ld_ido = w_ido;
                        //---------------------------------------------------------------------------------------
                        int lu_x = lx;
                        int lu_y = ly;

                        w_lx = (double)lu_x / 100.0;
                        w_ly = (double)lu_y / 100.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);

                        double lu_keido = w_keido;
                        double lu_ido = w_ido;
                        //---------------------------------------------------------------------------------------
                        int ru_x = lx + 75000 * pagesize / 2;
                        int ru_y = ly;

                        w_lx = (double)ru_x / 100.0;
                        w_ly = (double)ru_y / 100.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);
                        double ru_keido = w_keido;
                        double ru_ido = w_ido;
                        //---------------------------------------------------------------------------------------
                        int rd_x = lx + 75000 * pagesize / 2;
                        int rd_y = ly - 50000 * pagesize;

                        w_lx = (double)rd_x / 100.0;
                        w_ly = (double)rd_y / 100.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);
                        double rd_keido = w_keido;
                        double rd_ido = w_ido;



                        string outline = booknum + "," + page + "," + eda + "," + leftright_flg + "," + zno + "," + scale + "," + maptype + ",";
                        outline += (int)(ld_keido * 1000);
                        outline += ",";
                        outline += (int)(ld_ido * 1000);
                        outline += ",";
                        outline += (int)(lu_keido * 1000);
                        outline += ",";
                        outline += (int)(lu_ido * 1000);
                        outline += ",";
                        outline += (int)(ru_keido * 1000);
                        outline += ",";
                        outline += (int)(ru_ido * 1000);
                        outline += ",";
                        outline += (int)(rd_keido * 1000);
                        outline += ",";
                        outline += (int)(rd_ido * 1000);
                        outline += ",";
                        outline += ld_x;
                        outline += ",";
                        outline += ld_y;
                        outline += ",";
                        outline += lu_x;
                        outline += ",";
                        outline += lu_y;
                        outline += ",";
                        outline += ru_x;
                        outline += ",";
                        outline += ru_y;
                        outline += ",";
                        outline += rd_x;
                        outline += ",";
                        outline += rd_y;


                        using (StreamWriter writer = new StreamWriter(outFilePath, true))
                        {
                            writer.WriteLine(outline);
                        }


                        //右ページ
                        //---------------------------------------------------------------------------------------
                        leftright_flg = 1;

                        int ld_x2 = lx + 75000 * pagesize / 2;
                        int ld_y2 = ly - 50000 * pagesize;

                        w_lx = (double)ld_x2 / 100.0;
                        w_ly = (double)ld_y2 / 100.0;

                        w_keido = 0.0;
                        w_ido = 0.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);

                        double ld_keido2 = w_keido;
                        double ld_ido2 = w_ido;
                        //---------------------------------------------------------------------------------------
                        int lu_x2 = lx + 75000 * pagesize / 2;
                        int lu_y2 = ly;

                        w_lx = (double)lu_x2 / 100.0;
                        w_ly = (double)lu_y2 / 100.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);

                        double lu_keido2 = w_keido;
                        double lu_ido2 = w_ido;
                        //---------------------------------------------------------------------------------------
                        int ru_x2 = lx + 75000 * pagesize;
                        int ru_y2 = ly;

                        w_lx = (double)ru_x2 / 100.0;
                        w_ly = (double)ru_y2 / 100.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);
                        double ru_keido2 = w_keido;
                        double ru_ido2 = w_ido;
                        //---------------------------------------------------------------------------------------
                        int rd_x2 = lx + 75000 * pagesize;
                        int rd_y2 = ly - 50000 * pagesize;

                        w_lx = (double)rd_x2 / 100.0;
                        w_ly = (double)rd_y2 / 100.0;

                        MapComLib.Convert.gpconv2(w_lx, w_ly, 6, ref w_keido, ref w_ido);
                        double rd_keido2 = w_keido;
                        double rd_ido2 = w_ido;



                        outline = booknum + "," + page + "," + eda + "," + leftright_flg + "," + zno + "," + scale + "," + maptype + ",";

                        outline += (int)(ld_keido2 * 1000);
                        outline += ",";
                        outline += (int)(ld_ido2 * 1000);
                        outline += ",";
                        outline += (int)(lu_keido2 * 1000);
                        outline += ",";
                        outline += (int)(lu_ido2 * 1000);
                        outline += ",";
                        outline += (int)(ru_keido2 * 1000);
                        outline += ",";
                        outline += (int)(ru_ido2 * 1000);
                        outline += ",";
                        outline += (int)(rd_keido2 * 1000);
                        outline += ",";
                        outline += (int)(rd_ido2 * 1000);
                        outline += ",";
                        outline += ld_x2;
                        outline += ",";
                        outline += ld_y2;
                        outline += ",";
                        outline += lu_x2;
                        outline += ",";
                        outline += lu_y2;
                        outline += ",";
                        outline += ru_x2;
                        outline += ",";
                        outline += ru_y2;
                        outline += ",";
                        outline += rd_x2;
                        outline += ",";
                        outline += rd_y2;

                        using (StreamWriter writer = new StreamWriter(outFilePath, true))
                        {
                            writer.WriteLine(outline);
                        }
                    }
                }
            }
        }

        private void btnOutPut_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < listBook.Items.Count; i++)
            {
                string filePath = pageinfo[i];
                string outFilePath = DATA_PATH + "\\csv\\"+Path.GetFileNameWithoutExtension(filePath)+".csv";

                if (File.Exists(outFilePath) == true)
                {
                    File.Delete(outFilePath);
                }

                PageToCSV(i,filePath, outFilePath);
            }

            //int idx = listBook.SelectedIndex;

            //if (idx == -1) return;

            //string filePath = pageinfo[idx];

            //            string outFilePath = filePath.Replace(".txt", ".csv");
            //string outFilePath = DATA_PATH + "\\csv\\"+Path.GetFileNameWithoutExtension(filePath)+".csv";

        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            IsMouseDown = true;
            start_p.X = e.X;
            start_p.Y = e.Y;
            current_image = new Bitmap(this.pictureBox1.Image);

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            MsgOut("mouseup");

            if (click_mode == 0 && IsMouseDown)
            {
                end_p.X = e.X;
                end_p.Y = e.Y;

                IsMouseDown = false;

                int mx = Int32.Parse(textX.Text);
                int my = Int32.Parse(textY.Text);

                int sx = mx + end_p.X - start_p.X;
                int sy = my + end_p.Y - start_p.Y;

                textX.Text = sx.ToString();
                textY.Text = sy.ToString();

                offset_w = Int32.Parse(textX.Text);
                offset_h = Int32.Parse(textY.Text);
                g.Clear(Color.White);
                CopyImage(offset_w, offset_h);
                int idx = listBook.SelectedIndex;


                if (drawAllPage == true)
                {
                    DrawAllPage();
                }
                else
                {
                    if (idx >= 0)
                    {
                        DrawPage(g, idx);
                    }
                }
                pictureBox1.Image = canvas;
                SetCenterPos();

                //                LoadData();
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (click_mode == 0 && IsMouseDown)
            {
                end_p.X = e.X;
                end_p.Y = e.Y;

                int sx = end_p.X - start_p.X;
                int sy = end_p.Y - start_p.Y;

                g.Clear(Color.White);
                g.DrawImage(current_image, sx, sy);
                //g.DrawImage(bg_canvas, offset_w+sx, offset_h+sy, bg_canvas.Width, bg_canvas.Height);

                pictureBox1.Image = canvas;

                string msg = sx.ToString() + "-" + sy.ToString();
                //MsgOut(msg);
            }
        }


        private void listBook_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listBook.SelectedItems.Count == 0)
            {
                Reload();
                g.Clear(Color.White);
                bg_g.Clear(Color.White);

                pictureBox1.Image = canvas;

            }

            if (listBook.SelectedItems.Count > 1)
            {
                btnSetCenter.Enabled = false;

                var items = listBook.SelectedIndices;

                LoadMultiItems(false);
            }
            else
            {
                btnSetCenter.Enabled = true;
                
                btnAdd.Enabled = true;
                drawAllPage = false;

                LoadData(true);

            }
        }

        private void btnMove_Click(object sender, EventArgs e)
        {
            rate = Double.Parse(textRate.Text);

           int orgx = Int32.Parse(textORGX.Text);//cm
           int orgy = Int32.Parse(textORGY.Text);//cm

            double gx = Int32.Parse(textZX.Text);
            double gy = Int32.Parse(textZY.Text);

            offset_w = pictureBox1.Width/2 - (int)((gx-orgx) / (rate * 100));
            offset_h = pictureBox1.Height/2 - (int)((orgy-gy) / (rate * 100));

            textX.Text = offset_w.ToString();
            textY.Text = offset_h.ToString();

            int idx = listBook.SelectedIndex;

            g.Clear(Color.White);

            if (listBook.SelectedItems.Count > 1)
            {

                var items = listBook.SelectedIndices;

                LoadMultiItems(false);
            }
            else
            {
                btnAdd.Enabled = true;
                drawAllPage = false;

                LoadData(true);

            }

            CopyImage(offset_w, offset_h);
            DrawPage(g, idx);
            pictureBox1.Image = canvas;


            /*
            int idx = listBook.SelectedIndex;
            if (idx == -1) return;

            int mx = -(int)(max_x / rate) / 4;
            int my = -(int)(max_y / rate) / 4;

            textX.Text = mx.ToString();
            textY.Text = my.ToString();

            offset_w = Int32.Parse(textX.Text);
            offset_h = Int32.Parse(textY.Text);

            g.Clear(Color.White);
            CopyImage(offset_w, offset_h);
            DrawPage(g,idx);
            pictureBox1.Image = canvas;
            */
        }


        private void SaveCenterPos(double gx,double gy)
        {

            if (MessageBox.Show("中心位置を保存します", "確認", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            if (drawAllPage == false)
            {

                int idx = listBook.SelectedIndex;

//                double gx = Int32.Parse(textZX.Text);
//                double gy = Int32.Parse(textZY.Text);


                string filePath = DATA_PATH + "\\def\\book.def";
                string tmpPath = DATA_PATH + "\\def\\book.def.tmp";

                try
                {

                    using (StreamWriter writer = new StreamWriter(tmpPath, false))
                    {
                        using (StreamReader reader = new StreamReader(filePath))
                        {
                            int line_idx = 0;
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {

                                if (line_idx == idx)
                                {

                                    string[] param = line.Split(',');
                                    string outline = "";

                                    outline += param[0];
                                    outline += ",";
                                    outline += param[1];
                                    outline += ",";
                                    outline += param[2];
                                    outline += ",";
                                    outline += param[3];
                                    outline += ",";
                                    outline += param[4];
                                    outline += ",";
                                    outline += gx.ToString();
                                    outline += ",";
                                    outline += gy.ToString();

                                    writer.WriteLine(outline);

                                }
                                else
                                {
                                    writer.WriteLine(line);
                                }
                                line_idx++;
                            }
                        }
                    }

                    if (File.Exists(filePath) == true)
                    {
                        File.Delete(filePath);
                    }

                    File.Move(tmpPath, filePath);
                }
                catch (Exception ex)
                {
                    MsgOut(ex.ToString());
                }
            }
            click_mode = 0;
        }

//        private void bntSetCenter_Click(object sender, EventArgs e)
  //      {
    //        if (listBook.Items.Count == 1)
      //      {
        //        click_mode = 3;
          //  }

        //}

        private void btnUp_Click(object sender, EventArgs e)
        {
            double rate = Double.Parse(textRate.Text);

            if (rate > 2)
            {
                rate -= 1;
            }
            textRate.Text = rate.ToString();


            int orgx = Int32.Parse(textORGX.Text);//cm
            int orgy = Int32.Parse(textORGY.Text);//cm

            double gx = Int32.Parse(textCenterX.Text);
            double gy = Int32.Parse(textCenterY.Text);

            offset_w = pictureBox1.Width / 2 - (int)((gx - orgx) / (rate * 100));
            offset_h = pictureBox1.Height / 2 - (int)((orgy - gy) / (rate * 100));

            textX.Text = offset_w.ToString();
            textY.Text = offset_h.ToString();

            int idx = listBook.SelectedIndex;

            g.Clear(Color.White);

            if (listBook.SelectedItems.Count > 1)
            {

                var items = listBook.SelectedIndices;

                LoadMultiItems(false);
                CopyImage(offset_w, offset_h);
                DrawAllPage();
            }
            else
            {
                btnAdd.Enabled = true;
                drawAllPage = false;

                LoadData(false);
                CopyImage(offset_w, offset_h);
                DrawPage(g, idx);

            }

            pictureBox1.Image = canvas;

//            ReLoad();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            double rate = Double.Parse(textRate.Text);

            if (rate <50)
            {
                rate += 1;
            }
            textRate.Text = rate.ToString();
            
            int orgx = Int32.Parse(textORGX.Text);//cm
            int orgy = Int32.Parse(textORGY.Text);//cm

            double gx = Int32.Parse(textCenterX.Text);
            double gy = Int32.Parse(textCenterY.Text);

            offset_w = pictureBox1.Width / 2 - (int)((gx - orgx) / (rate * 100));
            offset_h = pictureBox1.Height / 2 - (int)((orgy - gy) / (rate * 100));

            textX.Text = offset_w.ToString();
            textY.Text = offset_h.ToString();

            int idx = listBook.SelectedIndex;

            g.Clear(Color.White);
            if (listBook.SelectedItems.Count > 1)
            {

                var items = listBook.SelectedIndices;

                LoadMultiItems(false);
                CopyImage(offset_w, offset_h);
                DrawAllPage();
            }
            else
            {
                btnAdd.Enabled = true;
                drawAllPage = false;

                LoadData(false);
                CopyImage(offset_w, offset_h);
                DrawPage(g, idx);

            }
            pictureBox1.Image = canvas;
        }

        private void SetCenterPos()
        {
            int orgx = Int32.Parse(textORGX.Text);//cm
            int orgy = Int32.Parse(textORGY.Text);//cm

            double gx = orgx + (double)(pictureBox1.Width/2 - offset_w) * rate * 100;
            double gy = orgy - (double)(pictureBox1.Height/2 - offset_h) * rate * 100;

            textCenterX.Text = gx.ToString();
            textCenterY.Text = gy.ToString();

        }

        private void btnBookAdd_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.mode = 0;
            f3.ShowDialog();

            Reload();

        }

        private void btnBookMod_Click(object sender, EventArgs e)
        {
            if (listBook.SelectedIndex < 0) return;
            Form3 f3 = new Form3();
            f3.mode = 1;
            f3.idx = listBook.SelectedIndex;
            f3.ShowDialog();

            Reload();

        }

        private void btnBookDel_Click(object sender, EventArgs e)
        {
            if (listBook.SelectedIndex < 0) return;
            Form3 f3 = new Form3();
            f3.mode = 2;
            f3.idx = listBook.SelectedIndex;
            f3.ShowDialog();

            Reload();

        }

        private void btnSetCenter_Click(object sender, EventArgs e)
        {
                 if (listBook.SelectedItems.Count == 1)
                  {
                    click_mode = 3;
              }
        }

        private void btnOutPutMDB_Click(object sender, EventArgs e)
        {

            string MDB_PATH = DATA_PATH+"\\mdb\\" + "FIIM_PAGE.mdb";

            for (int i = 0; i < listBook.Items.Count; i++)
            {
                string filePath = pageinfo[i];
                string outFilePath = DATA_PATH + "\\csv\\" + Path.GetFileNameWithoutExtension(filePath) + ".csv";

                //if (File.Exists(outFilePath) == true)
                //{
                //File.Delete(outFilePath);
                //}

                //PageToCSV(i, filePath, outFilePath);

                bool IsDelete=false;

                if (i == 0)
                {
                    IsDelete = true;
                }

                ImportProc(outFilePath, MDB_PATH, IsDelete);

            }
        }
        private void ImportProc(string src, string dest, bool IsDelete)
        {
            // 接続文字列
            string connectionString = $@"Provider=Microsoft.Jet.OLEDB.4.0;Data Source={dest};";

            try
            {
                // 接続を開く
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();

                    if (IsDelete == true)
                    {
                        string insertQuery = "DELETE FROM ページ検索テーブル";

                        using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
                        {
                            int rowsAffected = command.ExecuteNonQuery();
                            //Console.WriteLine($"{rowsAffected} 行が挿入されました。");
                        }
                    }

                    try
                    {
                        using (StreamReader reader = new StreamReader(src))
                        {
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {
                                string[] param = line.Split(',');

                                string insertQuery = "INSERT INTO ページ検索テーブル (";
                                insertQuery += "冊,ページ,枝,左右,図面名,スケール,表示地図種別,";
                                insertQuery += "左下座標Ｘ,";
                                insertQuery += "左下座標Ｙ,";
                                insertQuery += "左上座標Ｘ,";
                                insertQuery += "左上座標Ｙ,";
                                insertQuery += "右上座標Ｘ,";
                                insertQuery += "右上座標Ｙ,";
                                insertQuery += "右下座標Ｘ,";
                                insertQuery += "右下座標Ｙ,";
                                insertQuery += "左下正規化座標Ｘ,";
                                insertQuery += "左下正規化座標Ｙ,";
                                insertQuery += "左上正規化座標Ｘ,";
                                insertQuery += "左上正規化座標Ｙ,";
                                insertQuery += "右上正規化座標Ｘ,";
                                insertQuery += "右上正規化座標Ｙ,";
                                insertQuery += "右下正規化座標Ｘ,";
                                insertQuery += "右下正規化座標Ｙ";
                                insertQuery += ") VALUES (";
                                insertQuery += Int32.Parse(param[0]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[1]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[2]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[3]);
                                insertQuery += ",";
                                insertQuery += param[4];
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[5]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[6]);
                                insertQuery += ",";

                                insertQuery += Int32.Parse(param[7]);//
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[8]);//
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[9]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[10]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[11]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[12]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[13]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[14]);
                                insertQuery += ",";

                                insertQuery += Int32.Parse(param[15]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[16]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[17]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[18]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[19]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[20]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[21]);
                                insertQuery += ",";
                                insertQuery += Int32.Parse(param[22]);
                                insertQuery += ")";
                                // コマンドを実行
                                using (OleDbCommand command = new OleDbCommand(insertQuery, connection))
                                {
                                    int rowsAffected = command.ExecuteNonQuery();
                                    //Console.WriteLine($"{rowsAffected} 行が挿入されました。");
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.ToString());
                    }
                    connection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("エラー: " + ex.Message);
            }
        }

        private void btnMDBView_Click(object sender, EventArgs e)
        {
            string MDB_PATH = DATA_PATH + "\\mdb\\" + "FIIM_PAGE.mdb";

            FormMDBView mdbview = new FormMDBView();
            mdbview.MDB_PATH = MDB_PATH;

            mdbview.Show();
        }
    }
    public struct Poly
    {
        public Point lt;
        public Point lb;
    }

    public struct Mesh
    {
        public int minx;
        public int maxx;
        public int miny;
        public int maxy;
    }
    public struct NumberInfo
    {
        public string number;
        public int x;
        public int y;
    }
}

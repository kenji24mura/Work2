﻿namespace ReadBC
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoad = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textZMDFile = new System.Windows.Forms.TextBox();
            this.listInfo = new System.Windows.Forms.ListBox();
            this.textRate = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textX = new System.Windows.Forms.TextBox();
            this.textY = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.textPage = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textPageSize = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnOutPut = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.btnMod = new System.Windows.Forms.Button();
            this.listBook = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textZY = new System.Windows.Forms.TextBox();
            this.textZX = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textMeshNo = new System.Windows.Forms.TextBox();
            this.textLat = new System.Windows.Forms.TextBox();
            this.textLon = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnMove = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSetCenter = new System.Windows.Forms.Button();
            this.btnReload = new System.Windows.Forms.Button();
            this.btnAllDraw = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.textBook = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textORGX = new System.Windows.Forms.TextBox();
            this.textORGY = new System.Windows.Forms.TextBox();
            this.btnUp = new System.Windows.Forms.Button();
            this.btnDown = new System.Windows.Forms.Button();
            this.textCenterY = new System.Windows.Forms.TextBox();
            this.textCenterX = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.btnBookDel = new System.Windows.Forms.Button();
            this.btnBookMod = new System.Windows.Forms.Button();
            this.btnBookAdd = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnOutPutMDB = new System.Windows.Forms.Button();
            this.btnMDBView = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLoad
            // 
            this.btnLoad.Location = new System.Drawing.Point(1205, 363);
            this.btnLoad.Margin = new System.Windows.Forms.Padding(4);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(126, 35);
            this.btnLoad.TabIndex = 0;
            this.btnLoad.Text = "LOAD";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Visible = false;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(47, 196);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1128, 707);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseClick);
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // textZMDFile
            // 
            this.textZMDFile.Font = new System.Drawing.Font("Meiryo UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textZMDFile.Location = new System.Drawing.Point(672, 911);
            this.textZMDFile.Margin = new System.Windows.Forms.Padding(4);
            this.textZMDFile.Name = "textZMDFile";
            this.textZMDFile.ReadOnly = true;
            this.textZMDFile.Size = new System.Drawing.Size(502, 21);
            this.textZMDFile.TabIndex = 2;
            // 
            // listInfo
            // 
            this.listInfo.BackColor = System.Drawing.Color.Black;
            this.listInfo.ForeColor = System.Drawing.Color.LightGreen;
            this.listInfo.FormattingEnabled = true;
            this.listInfo.ItemHeight = 15;
            this.listInfo.Location = new System.Drawing.Point(1197, 420);
            this.listInfo.Margin = new System.Windows.Forms.Padding(4);
            this.listInfo.Name = "listInfo";
            this.listInfo.Size = new System.Drawing.Size(306, 169);
            this.listInfo.TabIndex = 4;
            // 
            // textRate
            // 
            this.textRate.Location = new System.Drawing.Point(1277, 50);
            this.textRate.Name = "textRate";
            this.textRate.Size = new System.Drawing.Size(83, 23);
            this.textRate.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(1196, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "RATE";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(54, 939);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(1120, 49);
            this.listBox1.TabIndex = 14;
            // 
            // textX
            // 
            this.textX.Location = new System.Drawing.Point(1279, 207);
            this.textX.Name = "textX";
            this.textX.Size = new System.Drawing.Size(81, 23);
            this.textX.TabIndex = 15;
            // 
            // textY
            // 
            this.textY.Location = new System.Drawing.Point(1379, 204);
            this.textY.Name = "textY";
            this.textY.Size = new System.Drawing.Size(81, 23);
            this.textY.TabIndex = 16;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1196, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 15);
            this.label2.TabIndex = 17;
            this.label2.Text = "START";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(27, 21);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(94, 25);
            this.btnAdd.TabIndex = 18;
            this.btnAdd.Text = "追加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // textPage
            // 
            this.textPage.Location = new System.Drawing.Point(238, 48);
            this.textPage.Name = "textPage";
            this.textPage.Size = new System.Drawing.Size(47, 23);
            this.textPage.TabIndex = 19;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(143, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 20;
            this.label3.Text = "ページ";
            // 
            // textPageSize
            // 
            this.textPageSize.Location = new System.Drawing.Point(238, 76);
            this.textPageSize.Name = "textPageSize";
            this.textPageSize.Size = new System.Drawing.Size(47, 23);
            this.textPageSize.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(143, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 26;
            this.label6.Text = "ページサイズ";
            // 
            // btnOutPut
            // 
            this.btnOutPut.Location = new System.Drawing.Point(726, 155);
            this.btnOutPut.Name = "btnOutPut";
            this.btnOutPut.Size = new System.Drawing.Size(94, 26);
            this.btnOutPut.TabIndex = 27;
            this.btnOutPut.Text = "CSV出力";
            this.btnOutPut.UseVisualStyleBackColor = true;
            this.btnOutPut.Click += new System.EventHandler(this.btnOutPut_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(51, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(19, 15);
            this.label7.TabIndex = 29;
            this.label7.Text = "冊";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(1314, 318);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(88, 19);
            this.checkBox7.TabIndex = 36;
            this.checkBox7.Text = "checkBox7";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(1314, 299);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(88, 19);
            this.checkBox6.TabIndex = 35;
            this.checkBox6.Text = "checkBox6";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(1314, 280);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(88, 19);
            this.checkBox5.TabIndex = 34;
            this.checkBox5.Text = "checkBox5";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(1205, 337);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(88, 19);
            this.checkBox4.TabIndex = 33;
            this.checkBox4.Text = "checkBox4";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(1205, 318);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(88, 19);
            this.checkBox3.TabIndex = 32;
            this.checkBox3.Text = "checkBox3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(1205, 299);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(88, 19);
            this.checkBox2.TabIndex = 31;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(1205, 280);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(88, 19);
            this.checkBox1.TabIndex = 30;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // btnMod
            // 
            this.btnMod.Location = new System.Drawing.Point(399, 86);
            this.btnMod.Name = "btnMod";
            this.btnMod.Size = new System.Drawing.Size(94, 26);
            this.btnMod.TabIndex = 37;
            this.btnMod.Text = "更新";
            this.btnMod.UseVisualStyleBackColor = true;
            this.btnMod.Click += new System.EventHandler(this.btnMod_Click);
            // 
            // listBook
            // 
            this.listBook.FormattingEnabled = true;
            this.listBook.ItemHeight = 15;
            this.listBook.Location = new System.Drawing.Point(89, 4);
            this.listBook.Name = "listBook";
            this.listBook.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listBook.Size = new System.Drawing.Size(440, 64);
            this.listBook.TabIndex = 38;
            this.listBook.SelectedIndexChanged += new System.EventHandler(this.listBook_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textZY);
            this.groupBox1.Controls.Add(this.textZX);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.textMeshNo);
            this.groupBox1.Controls.Add(this.textLat);
            this.groupBox1.Controls.Add(this.textLon);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.btnMove);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(1203, 653);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 305);
            this.groupBox1.TabIndex = 39;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "地点情報";
            // 
            // textZY
            // 
            this.textZY.Location = new System.Drawing.Point(100, 135);
            this.textZY.Name = "textZY";
            this.textZY.Size = new System.Drawing.Size(114, 23);
            this.textZY.TabIndex = 9;
            // 
            // textZX
            // 
            this.textZX.Location = new System.Drawing.Point(100, 106);
            this.textZX.Name = "textZX";
            this.textZX.Size = new System.Drawing.Size(114, 23);
            this.textZX.TabIndex = 8;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 138);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(75, 15);
            this.label10.TabIndex = 7;
            this.label10.Text = "正規化座標Y";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 113);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(75, 15);
            this.label11.TabIndex = 6;
            this.label11.Text = "正規化座標X";
            // 
            // textMeshNo
            // 
            this.textMeshNo.Location = new System.Drawing.Point(18, 244);
            this.textMeshNo.Name = "textMeshNo";
            this.textMeshNo.Size = new System.Drawing.Size(195, 23);
            this.textMeshNo.TabIndex = 5;
            // 
            // textLat
            // 
            this.textLat.Location = new System.Drawing.Point(99, 77);
            this.textLat.Name = "textLat";
            this.textLat.Size = new System.Drawing.Size(114, 23);
            this.textLat.TabIndex = 4;
            // 
            // textLon
            // 
            this.textLon.Location = new System.Drawing.Point(99, 48);
            this.textLon.Name = "textLon";
            this.textLon.Size = new System.Drawing.Size(114, 23);
            this.textLon.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 217);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 15);
            this.label8.TabIndex = 2;
            this.label8.Text = "メッシュ番号";
            // 
            // btnMove
            // 
            this.btnMove.Location = new System.Drawing.Point(100, 164);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(88, 36);
            this.btnMove.TabIndex = 6;
            this.btnMove.Text = "中心移動";
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Visible = false;
            this.btnMove.Click += new System.EventHandler(this.btnMove_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "経度";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "経度";
            // 
            // btnSetCenter
            // 
            this.btnSetCenter.Location = new System.Drawing.Point(872, 4);
            this.btnSetCenter.Name = "btnSetCenter";
            this.btnSetCenter.Size = new System.Drawing.Size(88, 30);
            this.btnSetCenter.TabIndex = 10;
            this.btnSetCenter.Text = "中心設定";
            this.btnSetCenter.UseVisualStyleBackColor = true;
            this.btnSetCenter.Click += new System.EventHandler(this.btnSetCenter_Click);
            // 
            // btnReload
            // 
            this.btnReload.Location = new System.Drawing.Point(1088, 57);
            this.btnReload.Name = "btnReload";
            this.btnReload.Size = new System.Drawing.Size(87, 28);
            this.btnReload.TabIndex = 40;
            this.btnReload.Text = "Reload";
            this.btnReload.UseVisualStyleBackColor = true;
            this.btnReload.Visible = false;
            this.btnReload.Click += new System.EventHandler(this.btnReload_Click);
            // 
            // btnAllDraw
            // 
            this.btnAllDraw.Location = new System.Drawing.Point(1379, 363);
            this.btnAllDraw.Margin = new System.Windows.Forms.Padding(4);
            this.btnAllDraw.Name = "btnAllDraw";
            this.btnAllDraw.Size = new System.Drawing.Size(126, 35);
            this.btnAllDraw.TabIndex = 41;
            this.btnAllDraw.Text = "ALL LOAD";
            this.btnAllDraw.UseVisualStyleBackColor = true;
            this.btnAllDraw.Visible = false;
            this.btnAllDraw.Click += new System.EventHandler(this.btnAllDraw_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(143, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 15);
            this.label9.TabIndex = 42;
            this.label9.Text = "冊";
            // 
            // textBook
            // 
            this.textBook.Location = new System.Drawing.Point(238, 19);
            this.textBook.Name = "textBook";
            this.textBook.Size = new System.Drawing.Size(47, 23);
            this.textBook.TabIndex = 43;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1196, 145);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 15);
            this.label12.TabIndex = 44;
            this.label12.Text = "基準座標X";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1196, 175);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 15);
            this.label13.TabIndex = 45;
            this.label13.Text = "基準座標Y";
            // 
            // textORGX
            // 
            this.textORGX.Location = new System.Drawing.Point(1277, 141);
            this.textORGX.Name = "textORGX";
            this.textORGX.Size = new System.Drawing.Size(176, 23);
            this.textORGX.TabIndex = 46;
            // 
            // textORGY
            // 
            this.textORGY.Location = new System.Drawing.Point(1277, 175);
            this.textORGY.Name = "textORGY";
            this.textORGY.Size = new System.Drawing.Size(176, 23);
            this.textORGY.TabIndex = 47;
            // 
            // btnUp
            // 
            this.btnUp.Location = new System.Drawing.Point(1370, 52);
            this.btnUp.Name = "btnUp";
            this.btnUp.Size = new System.Drawing.Size(57, 25);
            this.btnUp.TabIndex = 48;
            this.btnUp.Text = "▲";
            this.btnUp.UseVisualStyleBackColor = true;
            this.btnUp.Click += new System.EventHandler(this.btnUp_Click);
            // 
            // btnDown
            // 
            this.btnDown.Location = new System.Drawing.Point(1433, 50);
            this.btnDown.Name = "btnDown";
            this.btnDown.Size = new System.Drawing.Size(57, 25);
            this.btnDown.TabIndex = 49;
            this.btnDown.Text = "▼";
            this.btnDown.UseVisualStyleBackColor = true;
            this.btnDown.Click += new System.EventHandler(this.btnDown_Click);
            // 
            // textCenterY
            // 
            this.textCenterY.Location = new System.Drawing.Point(1277, 108);
            this.textCenterY.Name = "textCenterY";
            this.textCenterY.Size = new System.Drawing.Size(114, 23);
            this.textCenterY.TabIndex = 53;
            // 
            // textCenterX
            // 
            this.textCenterX.Location = new System.Drawing.Point(1277, 79);
            this.textCenterX.Name = "textCenterX";
            this.textCenterX.Size = new System.Drawing.Size(114, 23);
            this.textCenterX.TabIndex = 52;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(1196, 111);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(63, 15);
            this.label14.TabIndex = 51;
            this.label14.Text = "中心座標Y";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(1196, 86);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(63, 15);
            this.label15.TabIndex = 50;
            this.label15.Text = "中心座標X";
            // 
            // btnBookDel
            // 
            this.btnBookDel.Location = new System.Drawing.Point(726, 4);
            this.btnBookDel.Name = "btnBookDel";
            this.btnBookDel.Size = new System.Drawing.Size(85, 30);
            this.btnBookDel.TabIndex = 56;
            this.btnBookDel.Text = "冊削除";
            this.btnBookDel.UseVisualStyleBackColor = true;
            this.btnBookDel.Click += new System.EventHandler(this.btnBookDel_Click);
            // 
            // btnBookMod
            // 
            this.btnBookMod.Location = new System.Drawing.Point(635, 4);
            this.btnBookMod.Name = "btnBookMod";
            this.btnBookMod.Size = new System.Drawing.Size(85, 30);
            this.btnBookMod.TabIndex = 55;
            this.btnBookMod.Text = "冊更新";
            this.btnBookMod.UseVisualStyleBackColor = true;
            this.btnBookMod.Click += new System.EventHandler(this.btnBookMod_Click);
            // 
            // btnBookAdd
            // 
            this.btnBookAdd.Location = new System.Drawing.Point(544, 4);
            this.btnBookAdd.Name = "btnBookAdd";
            this.btnBookAdd.Size = new System.Drawing.Size(85, 30);
            this.btnBookAdd.TabIndex = 54;
            this.btnBookAdd.Text = "冊追加";
            this.btnBookAdd.UseVisualStyleBackColor = true;
            this.btnBookAdd.Click += new System.EventHandler(this.btnBookAdd_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textBook);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.textPageSize);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.textPage);
            this.groupBox2.Controls.Add(this.btnAdd);
            this.groupBox2.Location = new System.Drawing.Point(47, 79);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(305, 110);
            this.groupBox2.TabIndex = 57;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // btnOutPutMDB
            // 
            this.btnOutPutMDB.Location = new System.Drawing.Point(826, 155);
            this.btnOutPutMDB.Name = "btnOutPutMDB";
            this.btnOutPutMDB.Size = new System.Drawing.Size(94, 26);
            this.btnOutPutMDB.TabIndex = 58;
            this.btnOutPutMDB.Text = "MDB出力";
            this.btnOutPutMDB.UseVisualStyleBackColor = true;
            this.btnOutPutMDB.Click += new System.EventHandler(this.btnOutPutMDB_Click);
            // 
            // btnMDBView
            // 
            this.btnMDBView.Location = new System.Drawing.Point(935, 152);
            this.btnMDBView.Name = "btnMDBView";
            this.btnMDBView.Size = new System.Drawing.Size(129, 26);
            this.btnMDBView.TabIndex = 59;
            this.btnMDBView.Text = "MDB表示";
            this.btnMDBView.UseVisualStyleBackColor = true;
            this.btnMDBView.Click += new System.EventHandler(this.btnMDBView_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1529, 1000);
            this.Controls.Add(this.btnMDBView);
            this.Controls.Add(this.btnOutPutMDB);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnSetCenter);
            this.Controls.Add(this.btnBookDel);
            this.Controls.Add(this.btnBookMod);
            this.Controls.Add(this.btnBookAdd);
            this.Controls.Add(this.textCenterY);
            this.Controls.Add(this.textCenterX);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.btnDown);
            this.Controls.Add(this.btnUp);
            this.Controls.Add(this.textORGY);
            this.Controls.Add(this.textORGX);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.btnAllDraw);
            this.Controls.Add(this.btnReload);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBook);
            this.Controls.Add(this.btnMod);
            this.Controls.Add(this.checkBox7);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.checkBox5);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnOutPut);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textY);
            this.Controls.Add(this.textX);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textRate);
            this.Controls.Add(this.listInfo);
            this.Controls.Add(this.textZMDFile);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnLoad);
            this.Font = new System.Drawing.Font("Meiryo UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "MeshTool";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textZMDFile;
        private System.Windows.Forms.ListBox listInfo;
        private System.Windows.Forms.TextBox textRate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textX;
        private System.Windows.Forms.TextBox textY;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox textPage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textPageSize;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnOutPut;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button btnMod;
        private System.Windows.Forms.ListBox listBook;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textMeshNo;
        private System.Windows.Forms.TextBox textLat;
        private System.Windows.Forms.TextBox textLon;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btnReload;
        private System.Windows.Forms.Button btnAllDraw;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBook;
        private System.Windows.Forms.TextBox textZY;
        private System.Windows.Forms.TextBox textZX;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textORGX;
        private System.Windows.Forms.TextBox textORGY;
        private System.Windows.Forms.Button btnSetCenter;
        private System.Windows.Forms.Button btnUp;
        private System.Windows.Forms.Button btnDown;
        private System.Windows.Forms.TextBox textCenterY;
        private System.Windows.Forms.TextBox textCenterX;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnBookDel;
        private System.Windows.Forms.Button btnBookMod;
        private System.Windows.Forms.Button btnBookAdd;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnOutPutMDB;
        private System.Windows.Forms.Button btnMDBView;
    }
}


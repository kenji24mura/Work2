﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadBC
{
    public partial class Form3 : Form
    {
        public String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];

        public int mode;//0:add 1:mod 2:del
        public int idx;

        public Form1 f1;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            switch (mode)
            {
                case 0:
                    btnMod.Enabled = false;
                    btnDel.Enabled = false;
                    break;
                case 1:
                    btnAdd.Enabled = false;
                    btnDel.Enabled = false;
                    LoadList(idx);
                    break;
                case 2:
                    btnAdd.Enabled = false;
                    btnMod.Enabled = false;
                    LoadList(idx);
                    break;
            }
        }

        private void LoadList(int idx)
        {
            string filePath = DATA_PATH + "\\def\\book.def";

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    int lcnt = 0;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (lcnt == idx)
                        {
                            string[] param = line.Split(',');

                            textBookId.Text = param[0];
                            textBookName.Text = param[1];
                            textMapPath.Text = param[2];
                            textORGX.Text = param[3];
                            textORGY.Text = param[4];
                            textCenterX.Text = param[5];
                            textCenterY.Text = param[6];
                            break;
                        }


                        lcnt++;
                    }
                }
            }
            catch (Exception e)
            {
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("追加しますか?", "確認", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }

            string filePath = DATA_PATH + "\\def\\book.def";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    //using (StreamReader reader = new StreamReader(filePath))
                    //{
                                string outline = "";

                                outline += textBookId.Text;
                                outline += ",";
                                outline += textBookName.Text;
                                outline += ",";
                                outline += textMapPath.Text;
                                outline += ",";
                                outline += textORGX.Text;
                                outline += ",";
                                outline += textORGY.Text;
                                outline += ",";
                                outline += textCenterX.Text;
                                outline += ",";
                                outline += textCenterY.Text;

                                writer.WriteLine(outline);
                    //}
                }
            }
            catch (Exception ex)
            {
            }

            Close();

        }

        private void btnMod_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("更新しますか?", "確認", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            string filePath = DATA_PATH + "\\def\\book.def";
            string tmpPath = DATA_PATH + "\\def\\book.def.tmp";

            try
            {
                using (StreamWriter writer = new StreamWriter(tmpPath, false))
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        int line_idx = 0;
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {

                            if (line_idx == idx)
                            {
                                string outline = "";

                                outline += textBookId.Text;
                                outline += ",";
                                outline += textBookName.Text;
                                outline += ",";
                                outline += textMapPath.Text;
                                outline += ",";
                                outline += textORGX.Text;
                                outline += ",";
                                outline += textORGY.Text;
                                outline += ",";
                                outline += textCenterX.Text;
                                outline += ",";
                                outline += textCenterY.Text;

                                writer.WriteLine(outline);
                            }
                            else
                            {
                                writer.WriteLine(line);
                            }
                            line_idx++;
                        }
                    }
                }

                if (File.Exists(filePath) == true)
                {
                    File.Delete(filePath);
                }

                File.Move(tmpPath, filePath);
            }
            catch (Exception ex)
            {
            }
            Close();
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("削除しますか?", "確認", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }
            string filePath = DATA_PATH + "\\def\\book.def";
            string tmpPath = DATA_PATH + "\\def\\book.def.tmp";

            try
            {
                using (StreamWriter writer = new StreamWriter(tmpPath, false))
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        int line_idx = 0;
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {

                            if (line_idx == idx)
                            {
                            }
                            else
                            {
                                writer.WriteLine(line);
                            }
                            line_idx++;
                        }
                    }
                }

                if (File.Exists(filePath) == true)
                {
                    File.Delete(filePath);
                }

                File.Move(tmpPath, filePath);
            }
            catch (Exception ex)
            {
            }
            Close();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // OpenFileDialogオブジェクトの生成
            OpenFileDialog od = new OpenFileDialog();
            od.Title = "ファイルを開く";  //ダイアログ名
            od.InitialDirectory = DATA_PATH;  //初期フォルダ
            od.FileName = "";  //初期選択ファイル名
            od.Filter = "すべてのファイル(*.*)|*.*";  //選択できる拡張子
            od.FilterIndex = 1;  //初期の拡張子

            // ダイアログを表示する
            DialogResult result = od.ShowDialog();


            // 選択後の判定
            if (result == DialogResult.OK)
            {
                //「開く」ボタンクリック時の処理
                textMapPath.Text = od.FileName;  //これで選択したファイルパスを取得できる
            }
            else if (result == DialogResult.Cancel)
            {
                //「キャンセル」ボタンクリック時の処理
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using ZMDCom;

namespace ReadBC
{
    public partial class Form2 : Form
    {
        public string filePath;
        public string book;
        public int page;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

            textPage.Text = page.ToString();
            textBook.Text = book.ToString();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeletePage(page, filePath);
        }

        private void DeletePage(int m_page,string m_filePath)
        {

            if (MessageBox.Show("削除しますか？", "削除確認", MessageBoxButtons.OKCancel) == DialogResult.Cancel)
            {
                return;
            }


            string tmpFilePath = m_filePath+".tmp";

            try
            {

                using (StreamWriter writer = new StreamWriter(tmpFilePath,false))
                {
                    try
                    {
                        using (StreamReader reader = new StreamReader(m_filePath))
                        {
                            string line;
                            while ((line = reader.ReadLine()) != null)
                            {

                                string[] param = line.Split(',');


                                if (param.Length >= 10)
                                {
                                    int page = Int32.Parse(param[0]);//ページ
                                    int wx = Int32.Parse(param[1]);//メッシュ内座標X
                                    int wy = Int32.Parse(param[2]);//メッシュ内座標Y
                                    int ww = Int32.Parse(param[3]);//幅
                                    int wh = Int32.Parse(param[4]);//高さ
                                    int mx = Int32.Parse(param[5]);
                                    int my = Int32.Parse(param[6]);
                                    Double keido = Double.Parse(param[7]);//経度
                                    Double ido = Double.Parse(param[8]);//緯度
                                    int lx = Int32.Parse(param[9]);//正規化座標X
                                    int ly = Int32.Parse(param[10]);//正規化座標Y
                                    int lx2 = Int32.Parse(param[11]);//正規化座標X
                                    int ly2 = Int32.Parse(param[12]);//正規化座標Y
                                    int pagesize = Int32.Parse(param[13]);//ページサイズ

                                    if (page != m_page)
                                    {
                                        writer.WriteLine(line);
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception e)
                    {

                    }

                }

                File.Delete(m_filePath);
                File.Move(tmpFilePath, m_filePath);

            }
            catch (Exception ex)
            {
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadBC
{
    public partial class FormMDBView : Form
    {
        //string db = @"C:\D_DRV\ページ作成\data\mdb\FIIM_PAGE.mdb";

        public string MDB_PATH = "";

        public FormMDBView()
        {
            InitializeComponent();
        }

        private void FormMDBView_Load(object sender, EventArgs e)
        {
            ReadMDB();
        }
        public void ReadMDB()
        {
            //String db = MDB_PATH;

//            string msg = "Import開始";
  //          Invoke(new UpdateMessage(MsgOut), msg);

            try
            {
                OleDbConnection conn = new OleDbConnection();
                OleDbCommand comm = new OleDbCommand();

                conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + MDB_PATH; // MDB名など

                // 接続します。
                conn.Open();

                // SELECT文を設定します。
                comm.CommandText = "SELECT * FROM ページ検索テーブル";
                comm.Connection = conn;
                OleDbDataReader reader = comm.ExecuteReader();

                int reccnt = 0;

                // 結果を表示します。
                while (reader.Read())
                {

                    string book = reader["冊"].ToString();
                    string page = reader["ページ"].ToString();
                    string tree = reader["枝"].ToString();
                    string leftright = reader["左右"].ToString();
                    string scale = reader["スケール"].ToString();
                    string maptype = reader["表示地図種別"].ToString();


                    //単位はcm
                    Double ld_lon = Double.Parse(reader["左下座標Ｘ"].ToString());
                    Double ld_lat = Double.Parse(reader["左下座標Ｙ"].ToString());

                    Double lu_lon = Double.Parse(reader["左上座標Ｘ"].ToString());
                    Double lu_lat = Double.Parse(reader["左上座標Ｙ"].ToString());
                    
                    Double rd_lon = Double.Parse(reader["右上座標Ｘ"].ToString());
                    Double rd_lat = Double.Parse(reader["右上座標Ｙ"].ToString());
                    
                    Double ru_lon = Double.Parse(reader["右下座標Ｘ"].ToString());
                    Double ru_lat = Double.Parse(reader["右下座標Ｙ"].ToString());


                    Double ld_x = Double.Parse(reader["左下正規化座標Ｘ"].ToString());
                    Double ld_y = Double.Parse(reader["左下正規化座標Ｙ"].ToString());

                    Double lu_x = Double.Parse(reader["左上正規化座標Ｘ"].ToString());
                    Double lu_y = Double.Parse(reader["左上正規化座標Ｙ"].ToString());

                    Double rd_x = Double.Parse(reader["右下正規化座標Ｘ"].ToString());
                    Double rd_y = Double.Parse(reader["右下正規化座標Ｙ"].ToString());

                    Double ru_x = Double.Parse(reader["右上正規化座標Ｘ"].ToString());
                    Double ru_y = Double.Parse(reader["右上正規化座標Ｙ"].ToString());

                    listBox1.Items.Add(book + "," + page + "," + tree + "," + leftright);

                }
                conn.Close();
//                msg = "Import終了";
  //              Invoke(new UpdateMessage(MsgOut), msg);
            }
            catch (Exception ex)
            {
    //            Invoke(new UpdateMessage(MsgOut), ex.ToString());
            }
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TargetSearch
{
    public partial class Form1 : Form
    {
        public static String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];
        string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= " + DATA_PATH + "\\MDB\\" + "FIIM_TARGET.mdb";
        string KANA = "*アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヲ";


        private int sel_kind2;

        List<DispList> dispLists = new List<DispList>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            SearchKind1();

            for(int i = 0; i < KANA.Length; i++)
            {
                comboBox3.Items.Add(KANA[i]);
            }
        }

        private void SearchKind1()
        {
            OleDbConnection dbcon = new OleDbConnection(CON_STR);

            OleDbCommand cmd = dbcon.CreateCommand();
            dbcon.Open();

            string query = "SELECT * FROM 目標物分類テーブル WHERE 目標物分類=0";

            List<ItemSet> src = new List<ItemSet>();

            OleDbCommand command = new OleDbCommand(query, dbcon);
            OleDbDataReader reader = command.ExecuteReader();


                while (reader.Read())
                {
                    string kind1 = reader["目標物大分類"].ToString();
                    string kind2 = reader["目標物分類"].ToString();
                    string name = reader["名称"].ToString();

                    src.Add(new ItemSet(Int32.Parse(kind1), name));/// 1つでItem１つ分となる

//                comboBox1.Items.Add(name);
                }
            // ComboBoxに表示と値をセット
            comboBox1.DataSource = src;
            comboBox1.DisplayMember = "ItemDisp";
            comboBox1.ValueMember = "ItemValue";
            dbcon.Close();

        }
        private void SearchKind2(int kind1)
        {
            OleDbConnection dbcon = new OleDbConnection(CON_STR);

            OleDbCommand cmd = dbcon.CreateCommand();
            dbcon.Open();

            string query = "SELECT * FROM 目標物分類テーブル WHERE 目標物大分類="+kind1+ " AND 目標物分類>0";

            List<ItemSet> src = new List<ItemSet>();

            OleDbCommand command = new OleDbCommand(query, dbcon);
            OleDbDataReader reader = command.ExecuteReader();


            while (reader.Read())
            {
                //string kind1 = reader["目標物大分類"].ToString();
                string kind2 = reader["目標物分類"].ToString();
                string name = reader["名称"].ToString();

                src.Add(new ItemSet(Int32.Parse(kind2), name));/// 1つでItem１つ分となる

                //                comboBox1.Items.Add(name);
            }
            // ComboBoxに表示と値をセット
            comboBox2.DataSource = src;
            comboBox2.DisplayMember = "ItemDisp";
            comboBox2.ValueMember = "ItemValue";
            dbcon.Close();

        }

        private void SearchTarget(int kind2)
        {
            OleDbConnection dbcon = new OleDbConnection(CON_STR);

            OleDbCommand cmd = dbcon.CreateCommand();
            dbcon.Open();

            string query = "SELECT * FROM 目標物テーブル WHERE 種別="+kind2;

            if (comboBox3.SelectedIndex > 0)
            {
                query += " AND かな Like'" + comboBox3.SelectedItem.ToString() + "%'";
            }
            query += " ORDER BY かな";

            List<ItemSet> src = new List<ItemSet>();

            OleDbCommand command = new OleDbCommand(query, dbcon);
            OleDbDataReader reader = command.ExecuteReader();


            while (reader.Read())
            {
                string kind = reader["種別"].ToString();
                string target = reader["目標物"].ToString();
                string name = reader["名称"].ToString();
                string lx = reader["基準座標Ｘ"].ToString();
                string ly = reader["基準座標Ｙ"].ToString();

                src.Add(new ItemSet(Int32.Parse(target), name));/// 1つでItem１つ分となる

//                listBox1.Items.Add(name);
            }
            //listBox1.Items.Clear(); 

            listBox1.DataSource = src;
            listBox1.DisplayMember = "ItemDisp";
            listBox1.ValueMember = "ItemValue";

            dbcon.Close();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // labelに現在コンボ選択の内容を表示
            ItemSet tmp = ((ItemSet)comboBox1.SelectedItem);//表示名はキャストして取りだす
//            labelDisplay.Text = tmp.ItemDisp;
     
            
            string kind1 = tmp.ItemValue.ToString();//値はそのまま取りだせる
            //comboBox2.Items.Clear();
            SearchKind2(Int32.Parse(kind1));
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            // labelに現在コンボ選択の内容を表示
            ItemSet tmp = ((ItemSet)comboBox2.SelectedItem);//表示名はキャストして取りだす
                                                            //            labelDisplay.Text = tmp.ItemDisp;


            string kind2 = tmp.ItemValue.ToString();//値はそのまま取りだせる
            //listBox1.Items.Clear();
            sel_kind2 = Int32.Parse(kind2);
            SearchTarget(Int32.Parse(kind2));

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ItemSet tmp = ((ItemSet)listBox1.SelectedItem);//表示名はキャストして取りだす
            string str_target = tmp.ItemValue.ToString();//値はそのまま取りだせる
            ItemSet tmp2 = ((ItemSet)comboBox2.SelectedItem);//表示名はキャストして取りだす
            string str_kind2 = tmp2.ItemValue.ToString();//値はそのまま取りだせる

            int kind2 = Int32.Parse(str_kind2);
            int target = Int32.Parse(str_target);


            GetTargetInfo(kind2,target);
        }
        private void GetTargetInfo(int kind2,int target)
        {
            OleDbConnection dbcon = new OleDbConnection(CON_STR);

            OleDbCommand cmd = dbcon.CreateCommand();
            dbcon.Open();

            string query = "SELECT * FROM 目標物テーブル WHERE 目標物=" +target + " AND 種別 = " + kind2;

            OleDbCommand command = new OleDbCommand(query, dbcon);
            OleDbDataReader reader = command.ExecuteReader();


            while (reader.Read())
            {
                string kind = reader["種別"].ToString();
                string name = reader["名称"].ToString();
                string lx = reader["基準座標Ｘ"].ToString();
                string ly = reader["基準座標Ｙ"].ToString();

                textBox1.Text = lx + "," + ly;
            }
            dbcon.Close();
        }


        public void SearchTarget(int kind2,Point start,Point end)
        {
            DispList dispList = new DispList();

            OleDbConnection dbcon = new OleDbConnection(CON_STR);

            OleDbCommand cmd = dbcon.CreateCommand();
            dbcon.Open();

            int x0=start.X;
            int x1=end.X;
            int y0=start.Y;
            int y1 = end.Y;

            string query = "SELECT * FROM 目標物テーブル WHERE 種別=" + kind2 + " AND ";
            query += "( 基準座標Ｘ BETWEEN "+ x0 + " AND "+x1+")";
            query += " AND ";
            query += "( 基準座標Ｙ BETWEEN " + y0 + " AND " + y1+")";


      //      List<ItemSet> src = new List<ItemSet>();

            OleDbCommand command = new OleDbCommand(query, dbcon);
            OleDbDataReader reader = command.ExecuteReader();


            while (reader.Read())
            {
                DispList dl = new DispList();


                string kind = reader["種別"].ToString();
                string target = reader["目標物"].ToString();
                string name = reader["名称"].ToString();
                string lx = reader["基準座標Ｘ"].ToString();
                string ly = reader["基準座標Ｙ"].ToString();

                dl.kind = int.Parse(kind);
                dl.target = int.Parse(target);
                dl.name = name;
                dl.lx = int.Parse(lx);
                dl.ly = int.Parse(ly);

                dispLists.Add(dl);
            }
            dbcon.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            SearchTarget(sel_kind2);
        }

        private void btnMapDisp_Click(object sender, EventArgs e)
        {
            int w = 1;

            ItemSet tmp1 = ((ItemSet)comboBox1.SelectedItem);//表示名はキャストして取りだす
            string str_kind1 = tmp1.ItemValue.ToString();//値はそのまま取りだせる
            ItemSet tmp2 = ((ItemSet)comboBox2.SelectedItem);//表示名はキャストして取りだす
            string str_kind2 = tmp2.ItemValue.ToString();//値はそのまま取りだせる


            string[] param = textBox1.Text.Split(',');

            Point start = new Point();
            Point end = new Point();

            if (param.Length > 0)
            {

                int kind1 = Int32.Parse(str_kind1);
                int kind2 = Int32.Parse(str_kind2);

                start.X = Int32.Parse(param[0])-w/2;
                start.Y = Int32.Parse(param[1])-w/2;
                end.X = Int32.Parse(param[0]) + w / 2;
                end.Y = Int32.Parse(param[1]) + w / 2;

                SearchTarget(kind2,start,end);
            }


        }
    }
    public class ItemSet
    {
        // DisplayMemberとValueMemberにはプロパティで指定する仕組み
        public String ItemDisp { get; set; }
        public int ItemValue { get; set; }

        // プロパティをコンストラクタでセット
        public ItemSet(int v, String s)
        {
            ItemDisp = s;
            ItemValue = v;
        }
    }
    public class DispList
    {
        public int kind;
        public int target;
        public string name;
        public int lx;
        public int ly;
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form2 : Form
    {
        [DllImport("KERNEL32.DLL")]
        public static extern uint GetPrivateProfileString(string lpAppName,
            string lpKeyName, string lpDefault,
            StringBuilder lpReturnedString, uint nSize,
            string lpFileName);
        [DllImport("KERNEL32.DLL")]
        public static extern uint WritePrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpString,
            string lpFileName);

        public string MiddleConfigFile;
        public Form2()
        {
            InitializeComponent();

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {

            try
            {
                string newNumber = textBox1.Text;
                WritePrivateProfileString(
                    "SYSTEM",                      // セクション名
                    "車両番号",                          // キー名 
                    newNumber,                             // 格納先
                    MiddleConfigFile);                   // iniファイル名
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Close();
        }



        private void Form2_Load(object sender, EventArgs e)
        {
            TopMost = true;

            textBox1.Text = GetCarNumber();
            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

        }
        public String GetCarNumber()
        {
            //MsgOut("車両番号取得");
            string Num = "";

            //string MiddleConfigFile = NaviApp + "IICMW\\etc\\CMV_CCTL_CTRL.INI";


            StringBuilder sb = new StringBuilder(1024);

            try
            {
                GetPrivateProfileString(
                    "SYSTEM",                      // セクション名
                    "車両番号",                          // キー名    
                    "",                             // 値が取得できなかった場合に返される初期値
                    sb,                             // 格納先
                    Convert.ToUInt32(sb.Capacity),  // 格納先のキャパ
                    MiddleConfigFile);                   // iniファイル名
                Num = sb.ToString();
            }
            catch (Exception ex)
            {
                // MsgOut(ex.Message);
                MessageBox.Show(ex.Message);
            }

            return Num;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox1.Text += ((Button)sender).Text;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;
            if (str.Length > 1)
            {
                textBox1.Text = str.Substring(0, str.Length - 1);
            }

        }

        private void button12_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }
    }
}

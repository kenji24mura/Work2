﻿namespace MainteTool
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listView1 = new System.Windows.Forms.ListView();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textAutoUpdateIntval = new System.Windows.Forms.TextBox();
            this.checkAutoUpdate = new System.Windows.Forms.CheckBox();
            this.labelDate = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.timerAutoUpdate = new System.Windows.Forms.Timer(this.components);
            this.checkLogOut = new System.Windows.Forms.CheckBox();
            this.textLogComment = new System.Windows.Forms.TextBox();
            this.checkLimit = new System.Windows.Forms.CheckBox();
            this.textLimit = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.listView1.Location = new System.Drawing.Point(12, 70);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1127, 287);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(1021, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 30);
            this.button1.TabIndex = 3;
            this.button1.Text = "更新";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(961, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "sec";
            // 
            // textAutoUpdateIntval
            // 
            this.textAutoUpdateIntval.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textAutoUpdateIntval.Location = new System.Drawing.Point(907, 30);
            this.textAutoUpdateIntval.Name = "textAutoUpdateIntval";
            this.textAutoUpdateIntval.Size = new System.Drawing.Size(38, 24);
            this.textAutoUpdateIntval.TabIndex = 14;
            this.textAutoUpdateIntval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // checkAutoUpdate
            // 
            this.checkAutoUpdate.AutoSize = true;
            this.checkAutoUpdate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkAutoUpdate.Location = new System.Drawing.Point(819, 32);
            this.checkAutoUpdate.Name = "checkAutoUpdate";
            this.checkAutoUpdate.Size = new System.Drawing.Size(79, 21);
            this.checkAutoUpdate.TabIndex = 13;
            this.checkAutoUpdate.Text = "自動更新";
            this.checkAutoUpdate.UseVisualStyleBackColor = true;
            this.checkAutoUpdate.CheckedChanged += new System.EventHandler(this.checkAutoUpdate_CheckedChanged);
            // 
            // labelDate
            // 
            this.labelDate.BackColor = System.Drawing.Color.Black;
            this.labelDate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelDate.ForeColor = System.Drawing.Color.LawnGreen;
            this.labelDate.Location = new System.Drawing.Point(12, 21);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(210, 29);
            this.labelDate.TabIndex = 20;
            this.labelDate.Text = "label4";
            this.labelDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnClose.Location = new System.Drawing.Point(12, 406);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(130, 41);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // timerAutoUpdate
            // 
            this.timerAutoUpdate.Tick += new System.EventHandler(this.timerAutoUpdate_Tick);
            // 
            // checkLogOut
            // 
            this.checkLogOut.AutoSize = true;
            this.checkLogOut.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkLogOut.Location = new System.Drawing.Point(159, 417);
            this.checkLogOut.Name = "checkLogOut";
            this.checkLogOut.Size = new System.Drawing.Size(77, 21);
            this.checkLogOut.TabIndex = 22;
            this.checkLogOut.Text = "LogOut";
            this.checkLogOut.UseVisualStyleBackColor = true;
            // 
            // textLogComment
            // 
            this.textLogComment.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textLogComment.Location = new System.Drawing.Point(242, 415);
            this.textLogComment.Name = "textLogComment";
            this.textLogComment.Size = new System.Drawing.Size(897, 24);
            this.textLogComment.TabIndex = 23;
            this.textLogComment.Text = "ログコメント";
            // 
            // checkLimit
            // 
            this.checkLimit.AutoSize = true;
            this.checkLimit.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkLimit.Location = new System.Drawing.Point(12, 372);
            this.checkLimit.Name = "checkLimit";
            this.checkLimit.Size = new System.Drawing.Size(77, 21);
            this.checkLimit.TabIndex = 24;
            this.checkLimit.Text = "No.限定";
            this.checkLimit.UseVisualStyleBackColor = true;
            // 
            // textLimit
            // 
            this.textLimit.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textLimit.Location = new System.Drawing.Point(95, 371);
            this.textLimit.Name = "textLimit";
            this.textLimit.Size = new System.Drawing.Size(100, 24);
            this.textLimit.TabIndex = 25;
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 453);
            this.Controls.Add(this.textLimit);
            this.Controls.Add(this.checkLimit);
            this.Controls.Add(this.textLogComment);
            this.Controls.Add(this.checkLogOut);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textAutoUpdateIntval);
            this.Controls.Add(this.checkAutoUpdate);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form6";
            this.Text = "プロセス管理テーブル";
            this.Load += new System.EventHandler(this.Form6_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textAutoUpdateIntval;
        private System.Windows.Forms.CheckBox checkAutoUpdate;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Timer timerAutoUpdate;
        private System.Windows.Forms.CheckBox checkLogOut;
        private System.Windows.Forms.TextBox textLogComment;
        private System.Windows.Forms.CheckBox checkLimit;
        private System.Windows.Forms.TextBox textLimit;
    }
}
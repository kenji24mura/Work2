﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class MsgForm : Form
    {
        public string disp_message;
        public MsgForm()
        {
            InitializeComponent();
        }

        private void MsgForm_Load(object sender, EventArgs e)
        {
            TopMost = true;
            labelMsg.Text = disp_message;

            timer1.Enabled = true;
            timer1.Interval = 10000;

            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            Close();
        }
    }
}

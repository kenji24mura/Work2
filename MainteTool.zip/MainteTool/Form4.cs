﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form4 : Form
    {

        public String AUTO_UPDATE_INTVAL = System.Configuration.ConfigurationManager.AppSettings["AUTO_UPDATE_INTVAL"];

        private ColumnHeader[] columnData = new ColumnHeader[20];

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

            TopMost = true;


            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Sorting = SortOrder.Ascending;
            listView1.View = View.Details;


            // 列（コラム）ヘッダの作成
            columnData[0] = new ColumnHeader();
            columnData[1] = new ColumnHeader();
            columnData[2] = new ColumnHeader();
            columnData[3] = new ColumnHeader();
            columnData[4] = new ColumnHeader();
            columnData[5] = new ColumnHeader();
            columnData[6] = new ColumnHeader();
            columnData[7] = new ColumnHeader();
            columnData[8] = new ColumnHeader();
            columnData[9] = new ColumnHeader();
            columnData[10] = new ColumnHeader();


            columnData[0].Text = "名称";
            columnData[0].Width = 250;
            columnData[1].Text = "説明";
            columnData[1].Width = 0;
            columnData[2].Text = "I/F種類";
            columnData[2].Width = 100;
            columnData[3].Text = "最大速度";
            columnData[3].Width = 0;
            columnData[4].Text = "macアドレス";
            columnData[4].Width = 0;
            columnData[5].Text = "送信byte数";
            columnData[5].Width = 0;
            columnData[6].Text = "受信byte数";
            columnData[6].Width = 0;
            columnData[7].Text = "IPアドレス(IPv6)";
            columnData[7].Width = 0;
            columnData[8].Text = "IPアドレス(IPv4)";
            columnData[8].Width = 150;
            columnData[9].Text = "サブネットマスク(IPv4)";
            columnData[9].Width = 150;
            columnData[10].Text = "デフォルトゲートウェイ(IPv4)";
            columnData[10].Width = 150;

            ColumnHeader[] colHeaderRegValue =
              { this.columnData[0],
                this.columnData[1],
                this.columnData[2],
                this.columnData[3],
                this.columnData[4],
                this.columnData[5],
                this.columnData[6],
                this.columnData[7],
                this.columnData[8],
                this.columnData[9],
                this.columnData[10] };
            listView1.Columns.AddRange(colHeaderRegValue);


            UpdateInfo();

            checkAutoUpdate.Checked = false;

            textAutoUpdateIntval.Text = AUTO_UPDATE_INTVAL;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            UpdateInfo();
        }
        private void UpdateInfo()
        {
            DateTime dt = DateTime.Now;
            labelDate.Text = dt.ToString("yyyy/MM/dd HH:mm:ss");

            listView1.Items.Clear();

            NetworkInterface[] nicList = NetworkInterface.GetAllNetworkInterfaces();

            foreach (NetworkInterface nic in nicList)
            {
                IPInterfaceProperties ipInfo = nic.GetIPProperties();

                string IPAddress1="";
                string IPAddress2="";
                string NetMask="";
                string DefaultGW="";

                if (ipInfo.UnicastAddresses.Count > 0)
                {
                    //IPAddress1 = ipInfo.UnicastAddresses[0].Address.ToString();
                    //if (ipInfo.UnicastAddresses.Count > 1)
                    //{
                    //    IPAddress2 = ipInfo.UnicastAddresses[1].Address.ToString();
                    //}else
                    //{
                    //    IPAddress2 = "none";
                    //}
                    for (int j = 0; j < ipInfo.UnicastAddresses.Count; j++)
                    {
                        if (ipInfo.UnicastAddresses[j].Address.AddressFamily == AddressFamily.InterNetworkV6)
                        {
                            IPAddress1 = ipInfo.UnicastAddresses[j].Address.ToString();
                        }
                        else
                        {
                            if (ipInfo.UnicastAddresses[j].Address.AddressFamily == AddressFamily.InterNetwork)
                            {
                                IPAddress2 = ipInfo.UnicastAddresses[j].Address.ToString();
                                NetMask = ipInfo.UnicastAddresses[j].IPv4Mask.ToString();
                            }
                        }
                    }

                }
                else
                {
                    IPAddress1 = "none";
                    IPAddress2 = "none";
                }
                GatewayIPAddressInformationCollection addresses = ipInfo.GatewayAddresses;
                if (addresses.Count > 0)
                {
                    for (int j = 0; j < addresses.Count; j++)
                    {
                        if (addresses[j].Address.AddressFamily == AddressFamily.InterNetwork)
                        {
                            DefaultGW = addresses[j].Address.ToString();
                        }
                    }
                }

                string[] item1 = {nic.Name,
                    nic.Description,
                    nic.NetworkInterfaceType.ToString(),
                    (nic.Speed / 1000000).ToString()+"Mbs",
                    nic.GetPhysicalAddress().ToString() ,
                    nic.GetIPv4Statistics().BytesSent.ToString(),
                    nic.GetIPv4Statistics().BytesReceived.ToString(),
                    IPAddress1,
                    IPAddress2,
                    NetMask,
                    DefaultGW};

                listView1.Items.Add(new ListViewItem(item1));


            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void checkAutoUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timerAutoUpdate.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timerAutoUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timerAutoUpdate.Enabled = false;
                }
            }
            else
            {
                timerAutoUpdate.Enabled = false;
            }
        }

        private void timerAutoUpdate_Tick(object sender, EventArgs e)
        {
            timerAutoUpdate.Enabled = false;
            UpdateInfo();

            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timerAutoUpdate.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timerAutoUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timerAutoUpdate.Enabled = false;
                }
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {

            listView1.Focus();
            // 選択項目があるかどうかを確認する
            if (listView1.SelectedItems.Count == 0)
            {
                // 選択項目がないので処理をせず抜ける
                return;
            }

            string[] items = new string[11];

            ListViewItem itemx = listView1.SelectedItems[0];

            items[0] = itemx.Text;
            //// 選択項目を取得する

            for (int j = 1; j < listView1.Columns.Count; j++)
            {
                items[j] = itemx.SubItems[j].Text;
            }

            Hide();

            Form10 f10 = new Form10();

            f10.m_name = items[0];
            f10.m_address = items[8];
            f10.m_netmask = items[9];
            f10.m_gateway = items[10];


            f10.ShowDialog();
            Show();
        }
    }
}

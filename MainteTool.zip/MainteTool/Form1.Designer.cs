﻿namespace MainteTool
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnReboot = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.btnSwipeOn = new System.Windows.Forms.Button();
            this.btnSwipeOff = new System.Windows.Forms.Button();
            this.btnErrorReportON = new System.Windows.Forms.Button();
            this.btnErrorReportOFF = new System.Windows.Forms.Button();
            this.bAntiSpyON = new System.Windows.Forms.Button();
            this.bAntiSpyOFF = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.labelServer = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.btnHCopy = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.textAutoUpdateIntval = new System.Windows.Forms.TextBox();
            this.checkAutoUpdate = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btnBat9 = new System.Windows.Forms.Button();
            this.btnBat7 = new System.Windows.Forms.Button();
            this.btnBat8 = new System.Windows.Forms.Button();
            this.btnBat6 = new System.Windows.Forms.Button();
            this.btnBat4 = new System.Windows.Forms.Button();
            this.btnBat5 = new System.Windows.Forms.Button();
            this.btnBat3 = new System.Windows.Forms.Button();
            this.btnBat1 = new System.Windows.Forms.Button();
            this.btnBat2 = new System.Windows.Forms.Button();
            this.btnBat0 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnCatTbl = new System.Windows.Forms.Button();
            this.btnUpdate2 = new System.Windows.Forms.Button();
            this.textMode = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.btnGPS = new System.Windows.Forms.Button();
            this.btnExplore2 = new System.Windows.Forms.Button();
            this.btnExpolore = new System.Windows.Forms.Button();
            this.btnCmd = new System.Windows.Forms.Button();
            this.btnNetWork = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.numCLS = new System.Windows.Forms.Button();
            this.numBS = new System.Windows.Forms.Button();
            this.num0 = new System.Windows.Forms.Button();
            this.num9 = new System.Windows.Forms.Button();
            this.num8 = new System.Windows.Forms.Button();
            this.num7 = new System.Windows.Forms.Button();
            this.num6 = new System.Windows.Forms.Button();
            this.num5 = new System.Windows.Forms.Button();
            this.num4 = new System.Windows.Forms.Button();
            this.num3 = new System.Windows.Forms.Button();
            this.num2 = new System.Windows.Forms.Button();
            this.num1 = new System.Windows.Forms.Button();
            this.textPwd3 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.textPwd2 = new System.Windows.Forms.TextBox();
            this.textPwd1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnLogView = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnReboot
            // 
            this.btnReboot.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnReboot.Location = new System.Drawing.Point(476, 436);
            this.btnReboot.Name = "btnReboot";
            this.btnReboot.Size = new System.Drawing.Size(154, 43);
            this.btnReboot.TabIndex = 4;
            this.btnReboot.Text = "再起動";
            this.btnReboot.UseVisualStyleBackColor = true;
            this.btnReboot.Click += new System.EventHandler(this.btnReboot_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(21, 469);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(614, 52);
            this.listBox1.TabIndex = 6;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnClose.Location = new System.Drawing.Point(483, 528);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(147, 40);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Font = new System.Drawing.Font("Meiryo UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(648, 522);
            this.tabControl1.TabIndex = 36;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.Controls.Add(this.textBox3);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.btnSwipeOn);
            this.tabPage1.Controls.Add(this.btnSwipeOff);
            this.tabPage1.Controls.Add(this.btnReboot);
            this.tabPage1.Controls.Add(this.btnErrorReportON);
            this.tabPage1.Controls.Add(this.btnErrorReportOFF);
            this.tabPage1.Controls.Add(this.bAntiSpyON);
            this.tabPage1.Controls.Add(this.bAntiSpyOFF);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.labelServer);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.checkBox1);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.btnHCopy);
            this.tabPage1.Controls.Add(this.btnUpdate);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Font = new System.Drawing.Font("Meiryo UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(640, 495);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Page1";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox3.Location = new System.Drawing.Point(102, 70);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(141, 23);
            this.textBox3.TabIndex = 59;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label8.Location = new System.Drawing.Point(20, 73);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(76, 16);
            this.label8.TabIndex = 58;
            this.label8.Text = "車両名称";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button6.Location = new System.Drawing.Point(15, 436);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(151, 43);
            this.button6.TabIndex = 57;
            this.button6.Text = "アプリ終了";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click_1);
            // 
            // btnSwipeOn
            // 
            this.btnSwipeOn.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSwipeOn.Location = new System.Drawing.Point(478, 310);
            this.btnSwipeOn.Name = "btnSwipeOn";
            this.btnSwipeOn.Size = new System.Drawing.Size(150, 41);
            this.btnSwipeOn.TabIndex = 56;
            this.btnSwipeOn.Text = "スワイプ動作有効";
            this.btnSwipeOn.UseVisualStyleBackColor = true;
            this.btnSwipeOn.Click += new System.EventHandler(this.btnSwipeOn_Click_1);
            // 
            // btnSwipeOff
            // 
            this.btnSwipeOff.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnSwipeOff.Location = new System.Drawing.Point(325, 310);
            this.btnSwipeOff.Name = "btnSwipeOff";
            this.btnSwipeOff.Size = new System.Drawing.Size(150, 41);
            this.btnSwipeOff.TabIndex = 55;
            this.btnSwipeOff.Text = "スワイプ動作無効";
            this.btnSwipeOff.UseVisualStyleBackColor = true;
            this.btnSwipeOff.Click += new System.EventHandler(this.btnSwipeOff_Click_1);
            // 
            // btnErrorReportON
            // 
            this.btnErrorReportON.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnErrorReportON.Location = new System.Drawing.Point(478, 268);
            this.btnErrorReportON.Name = "btnErrorReportON";
            this.btnErrorReportON.Size = new System.Drawing.Size(150, 41);
            this.btnErrorReportON.TabIndex = 54;
            this.btnErrorReportON.Text = "エラーレポート有効";
            this.btnErrorReportON.UseVisualStyleBackColor = true;
            this.btnErrorReportON.Click += new System.EventHandler(this.btnErrorReportON_Click_1);
            // 
            // btnErrorReportOFF
            // 
            this.btnErrorReportOFF.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnErrorReportOFF.Location = new System.Drawing.Point(325, 268);
            this.btnErrorReportOFF.Name = "btnErrorReportOFF";
            this.btnErrorReportOFF.Size = new System.Drawing.Size(150, 41);
            this.btnErrorReportOFF.TabIndex = 53;
            this.btnErrorReportOFF.Text = "エラーレポート無効";
            this.btnErrorReportOFF.UseVisualStyleBackColor = true;
            this.btnErrorReportOFF.Click += new System.EventHandler(this.btnErrorReportOFF_Click_1);
            // 
            // bAntiSpyON
            // 
            this.bAntiSpyON.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.bAntiSpyON.Location = new System.Drawing.Point(168, 358);
            this.bAntiSpyON.Name = "bAntiSpyON";
            this.bAntiSpyON.Size = new System.Drawing.Size(150, 41);
            this.bAntiSpyON.TabIndex = 52;
            this.bAntiSpyON.Text = "アンチスパイウェア有効";
            this.bAntiSpyON.UseVisualStyleBackColor = true;
            this.bAntiSpyON.Click += new System.EventHandler(this.bAntiSpyON_Click_1);
            // 
            // bAntiSpyOFF
            // 
            this.bAntiSpyOFF.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.bAntiSpyOFF.Location = new System.Drawing.Point(15, 358);
            this.bAntiSpyOFF.Name = "bAntiSpyOFF";
            this.bAntiSpyOFF.Size = new System.Drawing.Size(150, 41);
            this.bAntiSpyOFF.TabIndex = 51;
            this.bAntiSpyOFF.Text = "アンチスパイウェア無効";
            this.bAntiSpyOFF.UseVisualStyleBackColor = true;
            this.bAntiSpyOFF.Click += new System.EventHandler(this.bAntiSpyOFF_Click_1);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button4.Location = new System.Drawing.Point(167, 311);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(150, 41);
            this.button4.TabIndex = 50;
            this.button4.Text = "右ボタン有効化";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button3.Location = new System.Drawing.Point(15, 311);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(150, 41);
            this.button3.TabIndex = 49;
            this.button3.Text = "右ボタン無効化";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(167, 268);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 41);
            this.button2.TabIndex = 48;
            this.button2.Text = "Windowsキー有効化";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(15, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 41);
            this.button1.TabIndex = 47;
            this.button1.Text = "Windowsキー無効化";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button5.Location = new System.Drawing.Point(488, 18);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(119, 71);
            this.button5.TabIndex = 46;
            this.button5.Text = "ログ";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_1);
            // 
            // labelServer
            // 
            this.labelServer.BackColor = System.Drawing.SystemColors.Control;
            this.labelServer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.labelServer.Font = new System.Drawing.Font("Meiryo UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelServer.Location = new System.Drawing.Point(238, 203);
            this.labelServer.Name = "labelServer";
            this.labelServer.Size = new System.Drawing.Size(279, 22);
            this.labelServer.TabIndex = 42;
            this.labelServer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(238, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 41;
            this.label2.Text = "ファイル名";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.checkBox1.Location = new System.Drawing.Point(238, 179);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(88, 21);
            this.checkBox1.TabIndex = 40;
            this.checkBox1.Text = "アップロード";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(305, 149);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(166, 24);
            this.textBox2.TabIndex = 39;
            this.textBox2.Text = "COPY";
            // 
            // btnHCopy
            // 
            this.btnHCopy.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnHCopy.Location = new System.Drawing.Point(13, 149);
            this.btnHCopy.Name = "btnHCopy";
            this.btnHCopy.Size = new System.Drawing.Size(131, 76);
            this.btnHCopy.TabIndex = 38;
            this.btnHCopy.Text = "画面コピー";
            this.btnHCopy.UseVisualStyleBackColor = true;
            this.btnHCopy.Click += new System.EventHandler(this.btnHCopy_Click_1);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnUpdate.Location = new System.Drawing.Point(241, 20);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(111, 42);
            this.btnUpdate.TabIndex = 37;
            this.btnUpdate.Text = "更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click_1);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox1.Location = new System.Drawing.Point(102, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(124, 23);
            this.textBox1.TabIndex = 36;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(20, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 16);
            this.label1.TabIndex = 35;
            this.label1.Text = "車両番号";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightGray;
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.textAutoUpdateIntval);
            this.tabPage2.Controls.Add(this.checkAutoUpdate);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.btnBat9);
            this.tabPage2.Controls.Add(this.btnBat7);
            this.tabPage2.Controls.Add(this.btnBat8);
            this.tabPage2.Controls.Add(this.btnBat6);
            this.tabPage2.Controls.Add(this.btnBat4);
            this.tabPage2.Controls.Add(this.btnBat5);
            this.tabPage2.Controls.Add(this.btnBat3);
            this.tabPage2.Controls.Add(this.btnBat1);
            this.tabPage2.Controls.Add(this.btnBat2);
            this.tabPage2.Controls.Add(this.btnBat0);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.btnCatTbl);
            this.tabPage2.Controls.Add(this.btnUpdate2);
            this.tabPage2.Controls.Add(this.textMode);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.button8);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.btnGPS);
            this.tabPage2.Controls.Add(this.btnExplore2);
            this.tabPage2.Controls.Add(this.btnExpolore);
            this.tabPage2.Controls.Add(this.btnCmd);
            this.tabPage2.Controls.Add(this.btnNetWork);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(640, 495);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Page2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label7.Location = new System.Drawing.Point(169, 378);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 17);
            this.label7.TabIndex = 65;
            this.label7.Text = "sec";
            // 
            // textAutoUpdateIntval
            // 
            this.textAutoUpdateIntval.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textAutoUpdateIntval.Location = new System.Drawing.Point(115, 375);
            this.textAutoUpdateIntval.Name = "textAutoUpdateIntval";
            this.textAutoUpdateIntval.Size = new System.Drawing.Size(38, 24);
            this.textAutoUpdateIntval.TabIndex = 64;
            this.textAutoUpdateIntval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // checkAutoUpdate
            // 
            this.checkAutoUpdate.AutoSize = true;
            this.checkAutoUpdate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkAutoUpdate.Location = new System.Drawing.Point(27, 377);
            this.checkAutoUpdate.Name = "checkAutoUpdate";
            this.checkAutoUpdate.Size = new System.Drawing.Size(79, 21);
            this.checkAutoUpdate.TabIndex = 63;
            this.checkAutoUpdate.Text = "自動更新";
            this.checkAutoUpdate.UseVisualStyleBackColor = true;
            this.checkAutoUpdate.CheckedChanged += new System.EventHandler(this.checkAutoUpdate_CheckedChanged);
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Gray;
            this.label6.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label6.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.label6.Location = new System.Drawing.Point(142, 287);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(184, 20);
            this.label6.TabIndex = 62;
            this.label6.Text = "label6";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(22, 286);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(104, 16);
            this.label5.TabIndex = 61;
            this.label5.Text = "バッテリー状態";
            // 
            // btnBat9
            // 
            this.btnBat9.BackColor = System.Drawing.Color.Gray;
            this.btnBat9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat9.Location = new System.Drawing.Point(295, 340);
            this.btnBat9.Name = "btnBat9";
            this.btnBat9.Size = new System.Drawing.Size(31, 31);
            this.btnBat9.TabIndex = 60;
            this.btnBat9.UseVisualStyleBackColor = false;
            // 
            // btnBat7
            // 
            this.btnBat7.BackColor = System.Drawing.Color.Gray;
            this.btnBat7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat7.Location = new System.Drawing.Point(235, 340);
            this.btnBat7.Name = "btnBat7";
            this.btnBat7.Size = new System.Drawing.Size(31, 31);
            this.btnBat7.TabIndex = 59;
            this.btnBat7.UseVisualStyleBackColor = false;
            // 
            // btnBat8
            // 
            this.btnBat8.BackColor = System.Drawing.Color.Gray;
            this.btnBat8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat8.Location = new System.Drawing.Point(265, 340);
            this.btnBat8.Name = "btnBat8";
            this.btnBat8.Size = new System.Drawing.Size(31, 31);
            this.btnBat8.TabIndex = 58;
            this.btnBat8.UseVisualStyleBackColor = false;
            // 
            // btnBat6
            // 
            this.btnBat6.BackColor = System.Drawing.Color.Gray;
            this.btnBat6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat6.Location = new System.Drawing.Point(205, 340);
            this.btnBat6.Name = "btnBat6";
            this.btnBat6.Size = new System.Drawing.Size(31, 31);
            this.btnBat6.TabIndex = 57;
            this.btnBat6.UseVisualStyleBackColor = false;
            // 
            // btnBat4
            // 
            this.btnBat4.BackColor = System.Drawing.Color.Gray;
            this.btnBat4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat4.Location = new System.Drawing.Point(145, 340);
            this.btnBat4.Name = "btnBat4";
            this.btnBat4.Size = new System.Drawing.Size(31, 31);
            this.btnBat4.TabIndex = 56;
            this.btnBat4.UseVisualStyleBackColor = false;
            // 
            // btnBat5
            // 
            this.btnBat5.BackColor = System.Drawing.Color.Gray;
            this.btnBat5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat5.Location = new System.Drawing.Point(175, 340);
            this.btnBat5.Name = "btnBat5";
            this.btnBat5.Size = new System.Drawing.Size(31, 31);
            this.btnBat5.TabIndex = 55;
            this.btnBat5.UseVisualStyleBackColor = false;
            // 
            // btnBat3
            // 
            this.btnBat3.BackColor = System.Drawing.Color.Gray;
            this.btnBat3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat3.Location = new System.Drawing.Point(115, 340);
            this.btnBat3.Name = "btnBat3";
            this.btnBat3.Size = new System.Drawing.Size(31, 31);
            this.btnBat3.TabIndex = 54;
            this.btnBat3.UseVisualStyleBackColor = false;
            // 
            // btnBat1
            // 
            this.btnBat1.BackColor = System.Drawing.Color.Gray;
            this.btnBat1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat1.Location = new System.Drawing.Point(55, 340);
            this.btnBat1.Name = "btnBat1";
            this.btnBat1.Size = new System.Drawing.Size(31, 31);
            this.btnBat1.TabIndex = 53;
            this.btnBat1.UseVisualStyleBackColor = false;
            // 
            // btnBat2
            // 
            this.btnBat2.BackColor = System.Drawing.Color.Gray;
            this.btnBat2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat2.Location = new System.Drawing.Point(85, 340);
            this.btnBat2.Name = "btnBat2";
            this.btnBat2.Size = new System.Drawing.Size(31, 31);
            this.btnBat2.TabIndex = 52;
            this.btnBat2.UseVisualStyleBackColor = false;
            // 
            // btnBat0
            // 
            this.btnBat0.BackColor = System.Drawing.Color.Gray;
            this.btnBat0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBat0.Location = new System.Drawing.Point(25, 340);
            this.btnBat0.Name = "btnBat0";
            this.btnBat0.Size = new System.Drawing.Size(31, 31);
            this.btnBat0.TabIndex = 51;
            this.btnBat0.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Gray;
            this.label4.ForeColor = System.Drawing.Color.LawnGreen;
            this.label4.Location = new System.Drawing.Point(24, 317);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(302, 20);
            this.label4.TabIndex = 50;
            this.label4.Text = "label4";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnCatTbl
            // 
            this.btnCatTbl.Font = new System.Drawing.Font("Meiryo UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCatTbl.Location = new System.Drawing.Point(475, 295);
            this.btnCatTbl.Name = "btnCatTbl";
            this.btnCatTbl.Size = new System.Drawing.Size(148, 43);
            this.btnCatTbl.TabIndex = 49;
            this.btnCatTbl.Text = "車両テーブル";
            this.btnCatTbl.UseVisualStyleBackColor = true;
            this.btnCatTbl.Click += new System.EventHandler(this.btnCatTbl_Click);
            // 
            // btnUpdate2
            // 
            this.btnUpdate2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnUpdate2.Location = new System.Drawing.Point(243, 18);
            this.btnUpdate2.Name = "btnUpdate2";
            this.btnUpdate2.Size = new System.Drawing.Size(111, 42);
            this.btnUpdate2.TabIndex = 48;
            this.btnUpdate2.Text = "更新";
            this.btnUpdate2.UseVisualStyleBackColor = true;
            this.btnUpdate2.Click += new System.EventHandler(this.btnUpdate2_Click);
            // 
            // textMode
            // 
            this.textMode.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textMode.Location = new System.Drawing.Point(104, 28);
            this.textMode.Name = "textMode";
            this.textMode.ReadOnly = true;
            this.textMode.Size = new System.Drawing.Size(124, 23);
            this.textMode.TabIndex = 47;
            this.textMode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(22, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 46;
            this.label3.Text = "運用モード";
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Meiryo UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button8.Location = new System.Drawing.Point(475, 164);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(148, 43);
            this.button8.TabIndex = 42;
            this.button8.Text = "サーバプロセステーブル";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click_1);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button7.Location = new System.Drawing.Point(475, 17);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(148, 43);
            this.button7.TabIndex = 41;
            this.button7.Text = "接続情報";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // btnGPS
            // 
            this.btnGPS.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnGPS.Location = new System.Drawing.Point(475, 246);
            this.btnGPS.Name = "btnGPS";
            this.btnGPS.Size = new System.Drawing.Size(148, 43);
            this.btnGPS.TabIndex = 40;
            this.btnGPS.Text = "GPS";
            this.btnGPS.UseVisualStyleBackColor = true;
            this.btnGPS.Click += new System.EventHandler(this.btnGPS_Click);
            // 
            // btnExplore2
            // 
            this.btnExplore2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnExplore2.Location = new System.Drawing.Point(172, 139);
            this.btnExplore2.Name = "btnExplore2";
            this.btnExplore2.Size = new System.Drawing.Size(148, 43);
            this.btnExplore2.TabIndex = 39;
            this.btnExplore2.Text = "エクスプローラ(DATA)";
            this.btnExplore2.UseVisualStyleBackColor = true;
            this.btnExplore2.Click += new System.EventHandler(this.btnExplore2_Click_1);
            // 
            // btnExpolore
            // 
            this.btnExpolore.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnExpolore.Location = new System.Drawing.Point(18, 139);
            this.btnExpolore.Name = "btnExpolore";
            this.btnExpolore.Size = new System.Drawing.Size(148, 43);
            this.btnExpolore.TabIndex = 38;
            this.btnExpolore.Text = "エクスプローラ(APP)";
            this.btnExpolore.UseVisualStyleBackColor = true;
            this.btnExpolore.Click += new System.EventHandler(this.btnExpolore_Click_1);
            // 
            // btnCmd
            // 
            this.btnCmd.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnCmd.Location = new System.Drawing.Point(19, 213);
            this.btnCmd.Name = "btnCmd";
            this.btnCmd.Size = new System.Drawing.Size(148, 43);
            this.btnCmd.TabIndex = 37;
            this.btnCmd.Text = "コマンド";
            this.btnCmd.UseVisualStyleBackColor = true;
            this.btnCmd.Click += new System.EventHandler(this.btnCmd_Click_1);
            // 
            // btnNetWork
            // 
            this.btnNetWork.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnNetWork.Location = new System.Drawing.Point(475, 115);
            this.btnNetWork.Name = "btnNetWork";
            this.btnNetWork.Size = new System.Drawing.Size(148, 43);
            this.btnNetWork.TabIndex = 36;
            this.btnNetWork.Text = "ネットワーク情報";
            this.btnNetWork.UseVisualStyleBackColor = true;
            this.btnNetWork.Click += new System.EventHandler(this.btnNetWork_Click_1);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.LightGray;
            this.tabPage3.Controls.Add(this.numCLS);
            this.tabPage3.Controls.Add(this.numBS);
            this.tabPage3.Controls.Add(this.num0);
            this.tabPage3.Controls.Add(this.num9);
            this.tabPage3.Controls.Add(this.num8);
            this.tabPage3.Controls.Add(this.num7);
            this.tabPage3.Controls.Add(this.num6);
            this.tabPage3.Controls.Add(this.num5);
            this.tabPage3.Controls.Add(this.num4);
            this.tabPage3.Controls.Add(this.num3);
            this.tabPage3.Controls.Add(this.num2);
            this.tabPage3.Controls.Add(this.num1);
            this.tabPage3.Controls.Add(this.textPwd3);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.textPwd2);
            this.tabPage3.Controls.Add(this.textPwd1);
            this.tabPage3.Controls.Add(this.label10);
            this.tabPage3.Controls.Add(this.textBox4);
            this.tabPage3.Controls.Add(this.label9);
            this.tabPage3.Controls.Add(this.btnLogView);
            this.tabPage3.Location = new System.Drawing.Point(4, 23);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(640, 495);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Page3";
            // 
            // numCLS
            // 
            this.numCLS.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.numCLS.Location = new System.Drawing.Point(495, 241);
            this.numCLS.Name = "numCLS";
            this.numCLS.Size = new System.Drawing.Size(49, 46);
            this.numCLS.TabIndex = 81;
            this.numCLS.Text = "CLS";
            this.numCLS.UseVisualStyleBackColor = true;
            this.numCLS.Click += new System.EventHandler(this.NumFunc);
            // 
            // numBS
            // 
            this.numBS.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.numBS.Location = new System.Drawing.Point(440, 241);
            this.numBS.Name = "numBS";
            this.numBS.Size = new System.Drawing.Size(49, 46);
            this.numBS.TabIndex = 80;
            this.numBS.Text = "BS";
            this.numBS.UseVisualStyleBackColor = true;
            this.numBS.Click += new System.EventHandler(this.NumFunc);
            // 
            // num0
            // 
            this.num0.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num0.Location = new System.Drawing.Point(385, 241);
            this.num0.Name = "num0";
            this.num0.Size = new System.Drawing.Size(49, 46);
            this.num0.TabIndex = 79;
            this.num0.Text = "0";
            this.num0.UseVisualStyleBackColor = true;
            this.num0.Click += new System.EventHandler(this.NumFunc);
            // 
            // num9
            // 
            this.num9.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num9.Location = new System.Drawing.Point(495, 186);
            this.num9.Name = "num9";
            this.num9.Size = new System.Drawing.Size(49, 46);
            this.num9.TabIndex = 78;
            this.num9.Text = "9";
            this.num9.UseVisualStyleBackColor = true;
            this.num9.Click += new System.EventHandler(this.NumFunc);
            // 
            // num8
            // 
            this.num8.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num8.Location = new System.Drawing.Point(440, 186);
            this.num8.Name = "num8";
            this.num8.Size = new System.Drawing.Size(49, 46);
            this.num8.TabIndex = 77;
            this.num8.Text = "8";
            this.num8.UseVisualStyleBackColor = true;
            this.num8.Click += new System.EventHandler(this.NumFunc);
            // 
            // num7
            // 
            this.num7.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num7.Location = new System.Drawing.Point(385, 186);
            this.num7.Name = "num7";
            this.num7.Size = new System.Drawing.Size(49, 46);
            this.num7.TabIndex = 76;
            this.num7.Text = "7";
            this.num7.UseVisualStyleBackColor = true;
            this.num7.Click += new System.EventHandler(this.NumFunc);
            // 
            // num6
            // 
            this.num6.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num6.Location = new System.Drawing.Point(495, 134);
            this.num6.Name = "num6";
            this.num6.Size = new System.Drawing.Size(49, 46);
            this.num6.TabIndex = 75;
            this.num6.Text = "6";
            this.num6.UseVisualStyleBackColor = true;
            this.num6.Click += new System.EventHandler(this.NumFunc);
            // 
            // num5
            // 
            this.num5.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num5.Location = new System.Drawing.Point(440, 134);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(49, 46);
            this.num5.TabIndex = 74;
            this.num5.Text = "5";
            this.num5.UseVisualStyleBackColor = true;
            this.num5.Click += new System.EventHandler(this.NumFunc);
            // 
            // num4
            // 
            this.num4.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num4.Location = new System.Drawing.Point(385, 134);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(49, 46);
            this.num4.TabIndex = 73;
            this.num4.Text = "4";
            this.num4.UseVisualStyleBackColor = true;
            this.num4.Click += new System.EventHandler(this.NumFunc);
            // 
            // num3
            // 
            this.num3.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num3.Location = new System.Drawing.Point(495, 82);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(49, 46);
            this.num3.TabIndex = 72;
            this.num3.Text = "3";
            this.num3.UseVisualStyleBackColor = true;
            this.num3.Click += new System.EventHandler(this.NumFunc);
            // 
            // num2
            // 
            this.num2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num2.Location = new System.Drawing.Point(440, 82);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(49, 46);
            this.num2.TabIndex = 71;
            this.num2.Text = "2";
            this.num2.UseVisualStyleBackColor = true;
            this.num2.Click += new System.EventHandler(this.NumFunc);
            // 
            // num1
            // 
            this.num1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num1.Location = new System.Drawing.Point(385, 82);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(49, 46);
            this.num1.TabIndex = 70;
            this.num1.Text = "1";
            this.num1.UseVisualStyleBackColor = true;
            this.num1.Click += new System.EventHandler(this.NumFunc);
            // 
            // textPwd3
            // 
            this.textPwd3.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textPwd3.Location = new System.Drawing.Point(175, 177);
            this.textPwd3.Name = "textPwd3";
            this.textPwd3.PasswordChar = '*';
            this.textPwd3.Size = new System.Drawing.Size(179, 24);
            this.textPwd3.TabIndex = 69;
            this.textPwd3.Enter += new System.EventHandler(this.textPwd3_Enter);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label13.Location = new System.Drawing.Point(13, 180);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(144, 16);
            this.label13.TabIndex = 68;
            this.label13.Text = "新パスワード（確認）";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label12.Location = new System.Drawing.Point(13, 149);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 16);
            this.label12.TabIndex = 67;
            this.label12.Text = "新パスワード";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label11.Location = new System.Drawing.Point(13, 119);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 16);
            this.label11.TabIndex = 66;
            this.label11.Text = "旧パスワード";
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.button9.Location = new System.Drawing.Point(16, 222);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(111, 42);
            this.button9.TabIndex = 65;
            this.button9.Text = "更新";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // textPwd2
            // 
            this.textPwd2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textPwd2.Location = new System.Drawing.Point(175, 146);
            this.textPwd2.Name = "textPwd2";
            this.textPwd2.PasswordChar = '*';
            this.textPwd2.Size = new System.Drawing.Size(179, 24);
            this.textPwd2.TabIndex = 64;
            this.textPwd2.Enter += new System.EventHandler(this.textPwd2_Enter);
            // 
            // textPwd1
            // 
            this.textPwd1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textPwd1.Location = new System.Drawing.Point(175, 116);
            this.textPwd1.Name = "textPwd1";
            this.textPwd1.PasswordChar = '*';
            this.textPwd1.Size = new System.Drawing.Size(179, 24);
            this.textPwd1.TabIndex = 63;
            this.textPwd1.Enter += new System.EventHandler(this.textPwd1_Enter);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label10.Location = new System.Drawing.Point(13, 79);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(127, 16);
            this.label10.TabIndex = 62;
            this.label10.Text = "ログインパスワード";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textBox4.Location = new System.Drawing.Point(148, 31);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(196, 23);
            this.textBox4.TabIndex = 61;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS UI Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label9.Location = new System.Drawing.Point(13, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 16);
            this.label9.TabIndex = 60;
            this.label9.Text = "アプリバージョン";
            // 
            // btnLogView
            // 
            this.btnLogView.Font = new System.Drawing.Font("Meiryo UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnLogView.Location = new System.Drawing.Point(16, 435);
            this.btnLogView.Name = "btnLogView";
            this.btnLogView.Size = new System.Drawing.Size(183, 43);
            this.btnLogView.TabIndex = 50;
            this.btnLogView.Text = "ログビューワ";
            this.btnLogView.UseVisualStyleBackColor = true;
            this.btnLogView.Click += new System.EventHandler(this.btnLogView_Click);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 571);
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.listBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.Text = "メンテナンスツール";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnReboot;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnSwipeOn;
        private System.Windows.Forms.Button btnSwipeOff;
        private System.Windows.Forms.Button btnErrorReportON;
        private System.Windows.Forms.Button btnErrorReportOFF;
        private System.Windows.Forms.Button bAntiSpyON;
        private System.Windows.Forms.Button bAntiSpyOFF;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label labelServer;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnHCopy;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button btnGPS;
        private System.Windows.Forms.Button btnExplore2;
        private System.Windows.Forms.Button btnExpolore;
        private System.Windows.Forms.Button btnCmd;
        private System.Windows.Forms.Button btnNetWork;
        private System.Windows.Forms.Button btnUpdate2;
        private System.Windows.Forms.TextBox textMode;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCatTbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnBat9;
        private System.Windows.Forms.Button btnBat7;
        private System.Windows.Forms.Button btnBat8;
        private System.Windows.Forms.Button btnBat6;
        private System.Windows.Forms.Button btnBat4;
        private System.Windows.Forms.Button btnBat5;
        private System.Windows.Forms.Button btnBat3;
        private System.Windows.Forms.Button btnBat1;
        private System.Windows.Forms.Button btnBat2;
        private System.Windows.Forms.Button btnBat0;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnLogView;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textAutoUpdateIntval;
        private System.Windows.Forms.CheckBox checkAutoUpdate;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textPwd2;
        private System.Windows.Forms.TextBox textPwd1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox textPwd3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button numCLS;
        private System.Windows.Forms.Button numBS;
        private System.Windows.Forms.Button num0;
        private System.Windows.Forms.Button num9;
        private System.Windows.Forms.Button num8;
        private System.Windows.Forms.Button num7;
        private System.Windows.Forms.Button num6;
        private System.Windows.Forms.Button num5;
        private System.Windows.Forms.Button num4;
        private System.Windows.Forms.Button num3;
        private System.Windows.Forms.Button num2;
        private System.Windows.Forms.Button num1;
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    static class Program
    {
        public static String AUTOLOGIN = System.Configuration.ConfigurationManager.AppSettings["AUTOLOGIN"];

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if(AUTOLOGIN == "true")
            {
                Application.Run(new Form1());
            }
            else
            {
                Application.Run(new LoginForm());
            }
        }
    }
}

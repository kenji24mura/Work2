﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class LoginForm : Form
    {
        public String FTP_USER = System.Configuration.ConfigurationManager.AppSettings["FTP_USER"];

        string init_password = "07E1CD7DCA89A1678042477183B7AC3F";//119
        public LoginForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string result = GetMD5HashString(textBox2.Text);

            if (result == GetKey())
            {
                Form1 f1 = new Form1();
                f1.Show();
                Hide();
            }
            else
            {
                label1.Text = "パスワードを入力して下さい。";
            }

        }
        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
                Left = (Screen.GetBounds(this).Width - Width) / 2;
                Top = (Screen.GetBounds(this).Height - Height) / 2;

            string pwdkey = GetKey();

            if (pwdkey == null){
                SetKey(init_password);
            }else
            {
                if(pwdkey.Length == 0)
                {
                    SetKey(init_password);
                }
            }
        }
        private void NumFunc(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if(b.Text == "BS")
            {
                if(textBox2.Text.Length > 0)
                {
                    string str = textBox2.Text.Substring(0, textBox2.Text.Length - 1);
                    textBox2.Text = str;
                }
            }
            else
            {
                if (b.Text == "CLS")
                {
                    textBox2.Text = "";
                }
                else
                {
                    textBox2.Text += b.Text;

                }

            }

        }
        public static string GetMD5HashString(string text)
        {
            // 文字列をバイト型配列に変換する
            byte[] data = Encoding.UTF8.GetBytes(text);

            // MD5ハッシュアルゴリズム生成
            var algorithm = new MD5CryptoServiceProvider();

            // ハッシュ値を計算する
            byte[] bs = algorithm.ComputeHash(data);

            // リソースを解放する
            algorithm.Clear();

            // バイト型配列を16進数文字列に変換
            var result = new StringBuilder();
            foreach (byte b in bs)
            {
                result.Append(b.ToString("X2"));
            }
            return result.ToString();
        }


        private string GetKey()
        {
            string keystr = @"Software\Fujitsu\CCL\" + FTP_USER;

            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.CurrentUser.OpenSubKey(keystr);
                if (regkey == null) return "";

                string dw = (string)regkey.GetValue("pid");

                //閉じる
                regkey.Close();

                return dw;
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        private int SetKey(string val)
        {
            string keystr = @"Software\Fujitsu\CCL\" + FTP_USER;

            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.CurrentUser.CreateSubKey(keystr);
                if (regkey == null) return -1;

                regkey.SetValue("pid", val);

                //閉じる
                regkey.Close();

                return 0;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form1 : Form
    {
        public delegate bool EnumWindowsDelegate(IntPtr hWnd, IntPtr lparam);

        [DllImport("KERNEL32.DLL")]
        public static extern uint
          GetPrivateProfileString(string lpAppName,
          string lpKeyName, string lpDefault,
          StringBuilder lpReturnedString, uint nSize,
          string lpFileName);
        [DllImport("user32.dll")]
        static extern bool PostMessage(IntPtr hWnd, uint Msg, int wParam, int lParam);
        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public extern static bool EnumWindows(EnumWindowsDelegate lpEnumFunc, IntPtr lparam);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int GetWindowText(IntPtr hWnd,
            StringBuilder lpString, int nMaxCount);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int GetWindowTextLength(IntPtr hWnd);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(
            IntPtr hWnd, out int lpdwProcessId);

        [DllImport("user32.dll", EntryPoint = "ShowWindow")]
        public static extern int ShowWindow(Int32 hWnd, int nCmdShow);

        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool SetWindowPos(IntPtr hWnd,
            int hWndInsertAfter, int x, int y, int cx, int cy, int uFlags);

        private const int SWP_NOSIZE = 0x0001;
        private const int SWP_NOMOVE = 0x0002;
        private const int SWP_SHOWWINDOW = 0x0040;
        private const int HWND_TOPMOST = -1;
        private const int HWND_NOTOPMOST = -2;


        public const int TASKBAR_HIDE = 0;
        public const int TASKBAR_SHOW = 5;

        [DllImport("user32.dll", EntryPoint = "FindWindow")]
        public static extern Int32 FindWindow(String lpClassName, String lpWindowName);


        const int WM_CLOSE = 0x0010;
        const int WM_QUIT = 0x0012;


        public String NaviApp = System.Configuration.ConfigurationManager.AppSettings["NAVI_APP"];
        public String NaviData = System.Configuration.ConfigurationManager.AppSettings["NAVI_DATA"];
        public String NaviTool = System.Configuration.ConfigurationManager.AppSettings["NAVI_TOOL"];
        public String FTP_SERVER = System.Configuration.ConfigurationManager.AppSettings["FTP_SERVER"];
        public String FTP_SERVER2 = System.Configuration.ConfigurationManager.AppSettings["FTP_SERVER2"];
        public String FTP_USER = System.Configuration.ConfigurationManager.AppSettings["FTP_USER"];
        public String FTP_PASSWD = System.Configuration.ConfigurationManager.AppSettings["FTP_PASSWD"];
        public String SERVER_DIR = System.Configuration.ConfigurationManager.AppSettings["SERVER_DIR"];
        public String LOCAL_DIR = System.Configuration.ConfigurationManager.AppSettings["LOCAL_DIR"];

        public String AUTO_UPDATE_INTVAL = System.Configuration.ConfigurationManager.AppSettings["AUTO_UPDATE_INTVAL"];

        // 2020/12/25 Add Start 監視プロセス追加対応 TECS）高橋
        /// <summary>
        /// クローズ対象のプロセス
        /// </summary>
        public static string CLOSE_PROCESS = System.Configuration.ConfigurationManager.AppSettings["CLOSE_PROCESS"];
        // 2020/12/25 Add End

        public static string Key_ActivateWindowsKey = @"SYSTEM\CurrentControlSet\Control\Keyboard Layout";
        public static string Key_ActivateRightButton = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer";

        public static string Key_WindowsDefender = @"SOFTWARE\Policies\Microsoft\Windows Defender";
        public static string Key_ErrorReport = @"Software\Microsoft\Windows\Windows Error Reporting";

        public static string Key_Swipe = @"SOFTWARE\Policies\Microsoft\Windows\EdgeUI";

//"AllowEdgeSwipe"=dword:00000000

        string MiddleConfigFile;
        string ACTIVE_SERVER;

        RegistryClass rc = new RegistryClass();

        TextBox textObj;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textObj = textPwd1;

            MiddleConfigFile = NaviApp + "IICMW\\etc\\CMV_CCTL_CTRL.INI";

            checkBox1.Checked = true;
            textBox1.Text = GetCarNumber();
            textBox2.Text = "COPY"+GetCarNumber()+"_";

            try
            {
                textBox3.Text = GetCarName(Int32.Parse(textBox1.Text));

            } catch(Exception ex){

            }

            textMode.Text = GetMode();

            UpdateButtons();

            timer2.Enabled = true;
            timer2.Interval = 5000;

            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

            UpdatePowerStatus();

            timer3.Enabled = true;
            timer3.Interval = 10000;

            checkAutoUpdate.Checked = false;

            textAutoUpdateIntval.Text = AUTO_UPDATE_INTVAL;


            //
            textBox4.Text = GetAppVersion();

        }

        void UpdatePowerStatus()
        {
            int val;
            Button[] b = new Button[10];

            b[0] = btnBat0;
            b[1] = btnBat1;
            b[2] = btnBat2;
            b[3] = btnBat3;
            b[4] = btnBat4;
            b[5] = btnBat5;
            b[6] = btnBat6;
            b[7] = btnBat7;
            b[8] = btnBat8;
            b[9] = btnBat9;


            PowerLineStatus pls = SystemInformation.PowerStatus.PowerLineStatus;
            switch (pls)
            {
                case PowerLineStatus.Offline:
                    label6.Text = "オフライン";
                    label6.BackColor = Color.Red;
                    break;
                case PowerLineStatus.Online:
                    label6.Text = "オンライン";
                    label6.BackColor = Color.Green;
                    break;
                case PowerLineStatus.Unknown:
                    label6.BackColor = Color.Gray;
                    label6.Text = "不明";
                    break;
            }

            //バッテリー残量（割合）
            float blp = SystemInformation.PowerStatus.BatteryLifePercent;
            label4.Text ="バッテリー残量:"+ (blp * 100).ToString()+"%";

            val = (int)(blp * 100)/10;

            for(int i = 0; i < 10; i++)
            {
                if(i < val)
                {
                    b[i].BackColor = Color.Orange;
                }else
                {
                    b[i].BackColor = Color.Gray;
                }

            }


            //バッテリー残量（時間）
            int blr = SystemInformation.PowerStatus.BatteryLifeRemaining;
            if (-1 < blr)
            {
                label4.Text += "(残り時間 :";
                label4.Text += (blr/60).ToString();
                label4.Text += "分)";

            }
            else
           {
                label4.Text += "(残り時間 不明)";
            }

        }

        //--------------------------------------------------------------------
        //ボタン状態更新
        //--------------------------------------------------------------------
        public void UpdateButtons()
        {
            if (rc.GetActivateWindowsKey() == true)
            {
                button1.Enabled = false;
                button2.Enabled = true;
            }
            else
            {
                button1.Enabled = true;
                button2.Enabled = false;
            }
            if (rc.GetActivateRightButton() == true)
            {
                button3.Enabled = false;
                button4.Enabled = true;
            }
            else
            {
                button3.Enabled = true;
                button4.Enabled = false;
            }

            if (rc.GetAntiSpyOFF() == true)
            {
                bAntiSpyOFF.Enabled = false;
                bAntiSpyON.Enabled = true;
            }
            else
            {
                bAntiSpyOFF.Enabled = true;
                bAntiSpyON.Enabled = false;
            }

            if (rc.GetErrorReportOFF() == true)
            {
                btnErrorReportOFF.Enabled = false;
                btnErrorReportON.Enabled = true;
            }
            else
            {
                btnErrorReportOFF.Enabled = true;
                btnErrorReportON.Enabled = false;
            }
            //スワイプ有効・無効
            if (rc.GetSwipwOFF() == true)
            {
                btnSwipeOff.Enabled = false;
                btnSwipeOn.Enabled = true;
            }
            else
            {
                btnSwipeOff.Enabled = true;
                btnSwipeOn.Enabled = false;
            }
        }
        //--------------------------------------------------------------------
        //シャットダウン処理
        //--------------------------------------------------------------------
        private void ShutDownProc()
        {
            System.Diagnostics.Process p;

            MsgOut("アプリ終了");
            string MiddleApp = NaviApp + "IICMW\\bin\\CMW_SHUTDOWN.exe";

            EnumWindows(new EnumWindowsDelegate(EnumWindowCallBack), this.Handle);

            p = System.Diagnostics.Process.Start(MiddleApp);

            MsgOut("再起動実行");
            System.Diagnostics.ProcessStartInfo psi =
                new System.Diagnostics.ProcessStartInfo();
            psi.FileName = "shutdown.exe";
            //コマンドラインを指定
            psi.Arguments = "/r /t 0";
            //ウィンドウを表示しないようにする
            psi.UseShellExecute = false;
            psi.CreateNoWindow = true;
            
            //起動
            p = System.Diagnostics.Process.Start(psi);

            Close();
        }

        //--------------------------------------------------------------------
        //メッセージ出力
        //--------------------------------------------------------------------
        public void MsgOut(String msg)
        {
            DateTime dt = DateTime.Now;
            listBox1.Items.Add(dt.ToString() + "," + msg);

        }
        //--------------------------------------------------------------------
        //車両番号取得
        //--------------------------------------------------------------------
        public String GetCarNumber()
        {
            MsgOut("車両番号取得");
            string Num = "";

            StringBuilder sb = new StringBuilder(1024);
            GetPrivateProfileString(
                "SYSTEM",                               // セクション名
                "車両番号",                             // キー名    
                "",                                     // 値が取得できなかった場合に返される初期値
                sb,                                     // 格納先
                Convert.ToUInt32(sb.Capacity),          // 格納先のキャパ
                MiddleConfigFile);                      // iniファイル名

            try
            {
                Num = sb.ToString();
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }

            return Num;

        }

        //--------------------------------------------------------------------
        //車両名称取得
        //--------------------------------------------------------------------
        public String GetCarName(int CarNumber)
        {
            string CarName="";

            string CarMst = NaviData + "IICCL\\data\\code\\A\\AVM_車両ファイル.txt";

            string line = "";

            try
            {
                System.IO.StreamReader file =
                    new System.IO.StreamReader(CarMst, System.Text.Encoding.GetEncoding("shift_jis"));

                while ((line = file.ReadLine()) != null)
                {
                    string[] stArrayData = line.Split(',');

                    if (stArrayData.Length > 3)
                    {
                        if(CarNumber == Int32.Parse(stArrayData[0]))
                        {
                            CarName = stArrayData[2];
                        }
                    }
                }
                file.Close();
            }
            catch (Exception ex)
            {

            }

            return CarName;
        }

        //--------------------------------------------------------------------
        //アプリバージョン取得
        //--------------------------------------------------------------------
        public String GetAppVersion()
        {
            string AppVersion = "";

            string VersionFile = NaviApp + "IICCL\\bin\\version.txt";

            string line = "";

            try
            {
                System.IO.StreamReader file =
                    new System.IO.StreamReader(VersionFile, System.Text.Encoding.GetEncoding("shift_jis"));

                if ((line = file.ReadLine()) != null)
                {
                            AppVersion = line;
                }
                file.Close();
            }
            catch (Exception ex)
            {

            }

            return AppVersion;
        }

        //--------------------------------------------------------------------
        //運用モード取得
        //--------------------------------------------------------------------
        public String GetMode()
        {
            MsgOut("運用モード取得");
            string Num = "";

            StringBuilder sb = new StringBuilder(1024);
            GetPrivateProfileString(
                "SYSTEM",                               // セクション名
                "運用モード",                             // キー名    
                "0",                                     // 値が取得できなかった場合に返される初期値
                sb,                                     // 格納先
                Convert.ToUInt32(sb.Capacity),          // 格納先のキャパ
                MiddleConfigFile);                      // iniファイル名

            try
            {
                Num = sb.ToString();
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }

            return Num;

        }
        //--------------------------------------------------------------------
        //ウインドウコールバック
        //--------------------------------------------------------------------
        private static bool EnumWindowCallBack(IntPtr hWnd, IntPtr lparam)
        {
            int textLen = GetWindowTextLength(hWnd);

            //ウィンドウのタイトルを取得する
            StringBuilder tsb = new StringBuilder(textLen + 1);

            GetWindowText(hWnd, tsb, tsb.Capacity);

            int processId;

            GetWindowThreadProcessId(hWnd, out processId);

            Process hProcess = Process.GetProcessById(processId);

            //
            //特定プロセスに通知
            //

            try
            {
                // 2020/12/25 Mod Start 監視プロセス追加対応 TECS）高橋
                //if (hProcess.ProcessName == "CCL_TCTL" || hProcess.ProcessName == "MyPing" || hProcess.ProcessName == "PSCTL" || hProcess.ProcessName == "PowerCtrl2" || hProcess.ProcessName == "NoTaskBar3")
                //{
                //    PostMessage(hWnd, WM_CLOSE, 0, 1);
                //}
                //if (hProcess.ProcessName == "CCL_AddrService" || hProcess.ProcessName == "CCL_NETMON_CL" || hProcess.ProcessName == "CCL_UPDATEDATA" || hProcess.ProcessName == "CCL_UPDATEAPP")
                //{
                //    PostMessage(hWnd, WM_CLOSE, 0, 1);
                //}

                // クローズ通知送信先プロセス
                string[] closeProcess = CLOSE_PROCESS.Split(',');
                if (closeProcess.Contains(hProcess.ProcessName))
                {
                    PostMessage(hWnd, WM_CLOSE, 0, 1);
                }
                // 2020/12/25 Mod End

                // 強制終了通知送信先プロセス
                if (hProcess.ProcessName == "NoTaskBar3")
                {
                    PostMessage(hWnd, WM_QUIT, 0, 1);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            return true;
        }

        //--------------------------------------------------------------------
        //pingチェック
        //--------------------------------------------------------------------
        public int PingCheck()
        {
            int ret = 0;
            MsgOut("ping 実行:" + FTP_SERVER);
            if (SendPing(FTP_SERVER) == true)
            {
                MsgOut("ping 正常" + FTP_SERVER);
                ACTIVE_SERVER = FTP_SERVER;
                labelServer.Text = ACTIVE_SERVER;
            }
            else
            {
                MsgOut("ping 異常" + FTP_SERVER);

                if (SendPing(FTP_SERVER2) == true)
                {
                    MsgOut("ping 正常" + FTP_SERVER2);
                    ACTIVE_SERVER = FTP_SERVER2;
                    labelServer.Text = ACTIVE_SERVER;
                }
                else
                {
                    MsgOut("ping 異常" + FTP_SERVER2);
                    labelServer.Text = "リモートサーバはアクセスできません";
                    ret = -1;
                }
            }
            return ret;
        }


        //--------------------------------------------------------------------
        //タスクバー表示
        //--------------------------------------------------------------------
        private void ShowTaskBar()
        {
            MsgOut("タスクバー表示");
            Int32 hWnd = FindWindow("Shell_TrayWnd", null);
            if (hWnd != 0)
            {
                //タスクバーの表示
                ShowWindow(hWnd, TASKBAR_SHOW);

                //// タスクバーを常に表示
                //      APPBARDATA pData = new APPBARDATA();
                //      pData.cbSize = Marshal.SizeOf(pData);
                //      pData.hWnd = (IntPtr)hWnd;
                //      pData.lParam = (int)ABMsg.ABM_NEW;//REMOVEにするとオートハイドになる
                //タスクバーにメッセージ送信
                //      SHAppBarMessage(ABMsg.ABM_SETSTATE, ref pData);

                //}
            }
        }

        //--------------------------------------------------------------------
        //デスクトップキャプチャー
        //--------------------------------------------------------------------
        private void DesktopCapture()
        {
            DateTime dt = DateTime.Now;
            string sdate = dt.ToString("yyyyMMddHHmmss");

            string SaveFileName = textBox2.Text + sdate + ".png";
            string SaveFilePath = NaviData + LOCAL_DIR + SaveFileName;


            //キャプチャタイマーの停止
            timer1.Enabled = false;

            //Bitmapの作成
            Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width,
                Screen.PrimaryScreen.Bounds.Height);
            //Graphicsの作成
            Graphics g = Graphics.FromImage(bmp);
            //画面全体をコピーする
            g.CopyFromScreen(new Point(0, 0), new Point(0, 0), bmp.Size);

            Image wkImg;
            wkImg = new Bitmap(bmp);

            // PNGで保存 
//            bmp.Save(SaveFilePath, System.Drawing.Imaging.ImageFormat.Png);
            wkImg.Save(SaveFilePath, System.Drawing.Imaging.ImageFormat.Png);
            // BMPで保存 
            //            bmp.Save(SaveFileName + ".bmp", System.Drawing.Imaging.ImageFormat.Bmp);
            //            // JPGで保存 
            //            bmp.Save(SaveFileName + ".jpg", System.Drawing.Imaging.ImageFormat.Jpeg);
            // TIFFで保存 
            //            bmp.Save(SaveFileName + ".tiff", System.Drawing.Imaging.ImageFormat.Tiff);

            //解放
            g.Dispose();


            Show();
            MsgOut("画面をキャプチャーしました");

            if (checkBox1.Checked == true)
            {

                if (PingCheck() == 0)
                {
                    PutFile(FTP_USER, FTP_PASSWD, "ftp://" + ACTIVE_SERVER + SERVER_DIR + "/" + SaveFileName, SaveFilePath);
                    MsgOut("画面をアップロードしました");
                }
                else
                {
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "画面のアップロードに失敗しました";
                    mf.ShowDialog();

                }

                System.IO.File.Delete(SaveFilePath);
            }
        }

        //--------------------------------------------------------------------
        //ファイルアップロード
        //--------------------------------------------------------------------
        public void PutFile(String username, String password, String serverUrl, String localFile)
        {

            try
            {
                //WebClientオブジェクトを作成
                System.Net.WebClient wc = new System.Net.WebClient();
                //ログインユーザー名とパスワードを指定
                wc.Credentials = new System.Net.NetworkCredential(username, password);
                //FTPサーバーにファイルをアップロードする
                wc.UploadFile(serverUrl, localFile);
                //解放する
                wc.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //--------------------------------------------------------------------
        //タイマーセクション
        //--------------------------------------------------------------------
        private void timer1_Tick(object sender, EventArgs e)
        {
            DesktopCapture();
            Show();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            IntPtr handle = Process.GetCurrentProcess().MainWindowHandle;

            SetWindowPos(handle, HWND_TOPMOST, 0, 0, 0, 0,
                SWP_NOSIZE | SWP_NOMOVE);

        }
        //--------------------------------------------------------------------
        //PING 監視
        //--------------------------------------------------------------------
        public Boolean SendPing(String host)
        {
            Boolean result = false;

            try
            {
                //Pingオブジェクトの作成
                System.Net.NetworkInformation.Ping p =
                    new System.Net.NetworkInformation.Ping();
                System.Net.NetworkInformation.PingReply reply = p.Send(host);

                //結果を取得
                if (reply.Status == System.Net.NetworkInformation.IPStatus.Success)
                {
                    result = true;
                }
                else
                {
                }
                p.Dispose();
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
                result = false;
            }
            return result;
        }


        //--------------------------------------------------------------------
        //PAGE1
        //--------------------------------------------------------------------

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.MiddleConfigFile = MiddleConfigFile;
            Hide();
            f2.ShowDialog();
            Show();
            textBox1.Text = GetCarNumber();

            textBox3.Text = GetCarName(Int32.Parse(textBox1.Text));

        }


        private void button5_Click_1(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            Hide();
            f3.NaviApp = NaviApp;
            f3.NaviData = NaviData;
            f3.CarNumber = GetCarNumber();

            f3.FTP_SERVER = FTP_SERVER;
            f3.FTP_SERVER2 = FTP_SERVER2;
            f3.FTP_USER = FTP_USER;
            f3.FTP_PASSWD = FTP_PASSWD;
            f3.SERVER_DIR = SERVER_DIR;
            f3.LOCAL_DIR = LOCAL_DIR;

            f3.ShowDialog();
            Show();
        }

        private void btnHCopy_Click_1(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer1.Interval = 3000;
            Hide();
        }



        private void button1_Click_1(object sender, EventArgs e)
        {
        rc.ActivateWindowsKey(false);
        UpdateButtons();
    }

    private void button2_Click_1(object sender, EventArgs e)
        {
            rc.ActivateWindowsKey(true);
            UpdateButtons();

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            rc.ActivateRightButton(false);
            UpdateButtons();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            rc.ActivateRightButton(true);
            UpdateButtons();
        }

        private void bAntiSpyOFF_Click_1(object sender, EventArgs e)
        {
            rc.SetAntiSpyOFF(true);
            UpdateButtons();
        }

        private void bAntiSpyON_Click_1(object sender, EventArgs e)
        {
            rc.SetAntiSpyOFF(false);
            UpdateButtons();
        }

        private void btnErrorReportOFF_Click_1(object sender, EventArgs e)
        {
            rc.SetErrorReportOFF(true);
            UpdateButtons();
        }

        private void btnErrorReportON_Click_1(object sender, EventArgs e)
        {
            rc.SetErrorReportOFF(false);
            UpdateButtons();
        }

        private void btnSwipeOff_Click_1(object sender, EventArgs e)
        {
            rc.SetSwipwOFF(true);
            UpdateButtons();
        }

        private void btnSwipeOn_Click_1(object sender, EventArgs e)
        {
            rc.SetSwipwOFF(false);
            UpdateButtons();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            string MiddleApp = NaviApp + "IICMW\\bin\\CMW_SHUTDOWN.exe";

            EnumWindows(new EnumWindowsDelegate(EnumWindowCallBack), this.Handle);


            System.Diagnostics.Process p =
                    System.Diagnostics.Process.Start(MiddleApp);

            ShowTaskBar();
        }
        //--------------------------------------------------------------------
        //閉じる
        //--------------------------------------------------------------------
        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
//            Close();
        }

        //--------------------------------------------------------------------
        //再起動
        //--------------------------------------------------------------------
        private void btnReboot_Click(object sender, EventArgs e)
        {
            ShutDownProc();
        }



        //--------------------------------------------------------------------
        //PAGE2
        //--------------------------------------------------------------------

        private void btnExpolore_Click_1(object sender, EventArgs e)
        {
            Process.Start(NaviApp);
        }

        private void btnExplore2_Click_1(object sender, EventArgs e)
        {
            Process.Start(NaviData);
        }

        private void btnCmd_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process p =
                System.Diagnostics.Process.Start("cmd.exe");
        }

        private void btnGPS_Click(object sender, EventArgs e)
        {
            Form8 f8 = new Form8();
            f8.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.Show();
        }

        private void btnNetWork_Click_1(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            Hide();
            f4.ShowDialog();
            Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
        }
        private void btnUpdate2_Click(object sender, EventArgs e)
        {
            Form7 f7 = new Form7();
            f7.ShowDialog();

            textMode.Text = GetMode();
        }

        private void btnCatTbl_Click(object sender, EventArgs e)
        {
            Form9 f9 = new Form9();
            f9.ShowDialog();
        }

        //--------------------------------------------------------------------
        //PAGE3
        //--------------------------------------------------------------------
        private void btnLogView_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process p;

            try
            {
                MsgOut("ログビューワ起動");
                string ViewApp = NaviTool + "LogView3.exe";
                p = System.Diagnostics.Process.Start(ViewApp);
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }
            Close();
        }

        private void btnLogView2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process p;

            try
            {
                MsgOut("ログビューワ起動");
                string ViewApp = NaviTool + "LogView2_forTABLET.exe";
                p = System.Diagnostics.Process.Start(ViewApp);
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }
            Close();
        }

        private void checkAutoUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timer3.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timer3.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timer3.Enabled = false;
                }
            }
            else
            {
                timer3.Enabled = false;
            }
        }
        private void timer3_Tick(object sender, EventArgs e)
        {

            timer3.Enabled = false;

            UpdatePowerStatus();

            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timer3.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timer3.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timer3.Enabled = false;
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string result = GetMD5HashString(textPwd1.Text);

            if (result != GetKey())
            {
                MessageBox.Show("旧パスワードが違います");
            }
            else
            {
                if (textPwd2.Text.Length < 3)
                {
                    MessageBox.Show("新パスワードは3文字以上入力してください");
                }
                else
                {
                    if (textPwd2.Text != textPwd3.Text)
                    {
                        MessageBox.Show("新パスワードと確認用パスワードが違います");
                    }else
                    {
                        SetKey(GetMD5HashString(textPwd2.Text));
                    }
                }
            }
        }
        public static string GetMD5HashString(string text)
        {
            // 文字列をバイト型配列に変換する
            byte[] data = Encoding.UTF8.GetBytes(text);

            // MD5ハッシュアルゴリズム生成
            var algorithm = new MD5CryptoServiceProvider();

            // ハッシュ値を計算する
            byte[] bs = algorithm.ComputeHash(data);

            // リソースを解放する
            algorithm.Clear();

            // バイト型配列を16進数文字列に変換
            var result = new StringBuilder();
            foreach (byte b in bs)
            {
                result.Append(b.ToString("X2"));
            }
            return result.ToString();
        }

        private string GetKey()
        {
            string keystr = @"Software\Fujitsu\CCL\" + FTP_USER;

            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.CurrentUser.OpenSubKey(keystr);
                if (regkey == null) return "";

                string dw = (string)regkey.GetValue("pid");

                //閉じる
                regkey.Close();

                return dw;
            }
            catch (Exception ex)
            {
                return "";
            }
        }
        private int SetKey(string val)
        {
            string keystr = @"Software\Fujitsu\CCL\" + FTP_USER;

            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.CurrentUser.CreateSubKey(keystr);
                if (regkey == null) return -1;

                regkey.SetValue("pid", val);

                //閉じる
                regkey.Close();

                return 0;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }

        private void textPwd1_Enter(object sender, EventArgs e)
        {
            textObj = textPwd1;
        }

        private void textPwd2_Enter(object sender, EventArgs e)
        {
            textObj = textPwd2;
        }

        private void textPwd3_Enter(object sender, EventArgs e)
        {
            textObj = textPwd3;
        }
        private void NumFunc(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (b.Text == "BS")
            {
                if (textObj.Text.Length > 0)
                {
                    string str = textObj.Text.Substring(0, textObj.Text.Length - 1);
                    textObj.Text = str;
                }
            }
            else
            {
                if (b.Text == "CLS")
                {
                    textObj.Text = "";
                }
                else
                {
                    textObj.Text += b.Text;

                }

            }

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form7 : Form
    {
        [DllImport("KERNEL32.DLL")]
        public static extern uint
          GetPrivateProfileString(string lpAppName,
          string lpKeyName, string lpDefault,
          StringBuilder lpReturnedString, uint nSize,
          string lpFileName);
        [DllImport("KERNEL32.DLL")]
        public static extern uint WritePrivateProfileString(
            string lpAppName,
            string lpKeyName,
            string lpString,
            string lpFileName);

        public String NaviApp = System.Configuration.ConfigurationManager.AppSettings["NAVI_APP"];
        public String NaviData = System.Configuration.ConfigurationManager.AppSettings["NAVI_DATA"];

        string MiddleConfigFile;
        int Mode;

        public Form7()
        {
            InitializeComponent();
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            MiddleConfigFile = NaviApp + "IICMW\\etc\\CMV_CCTL_CTRL.INI";

            TopMost = true;

            Mode = GetMode();

            if(Mode == 0)
            {
                button1.BackColor = Color.Orange;
                button2.BackColor = Color.LightGray;

            }
            else
            {
                button2.BackColor = Color.Orange;
                button1.BackColor = Color.LightGray;
            }
            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

        }

        //--------------------------------------------------------------------
        //運用モード取得
        //--------------------------------------------------------------------
        public int GetMode()
        {
            string Num = "";

            StringBuilder sb = new StringBuilder(1024);
            GetPrivateProfileString(
                "SYSTEM",                               // セクション名
                "運用モード",                             // キー名    
                "0",                                     // 値が取得できなかった場合に返される初期値
                sb,                                     // 格納先
                Convert.ToUInt32(sb.Capacity),          // 格納先のキャパ
                MiddleConfigFile);                      // iniファイル名

            try
            {
                Num = sb.ToString();
            }
            catch (Exception ex)
            {
                Num = "0";
            }

            return Int32.Parse(Num);

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            try
            {
                string newNumber = Mode.ToString();
                WritePrivateProfileString(
                    "SYSTEM",                      // セクション名
                    "運用モード",                          // キー名 
                    newNumber,                             // 格納先
                    MiddleConfigFile);                   // iniファイル名
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Mode = 0;
            button1.BackColor = Color.Orange;
            button2.BackColor = Color.LightGray;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mode = 1;
            button2.BackColor = Color.Orange;
            button1.BackColor = Color.LightGray;
        }
    }
}

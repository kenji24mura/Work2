﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    class RegistryClass
    {
        public static string Key_ActivateWindowsKey = @"SYSTEM\CurrentControlSet\Control\Keyboard Layout";
        public static string Key_ActivateRightButton = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer";

        public static string Key_WindowsDefender = @"SOFTWARE\Policies\Microsoft\Windows Defender";
        public static string Key_ErrorReport = @"Software\Microsoft\Windows\Windows Error Reporting";

        public static string Key_Swipe = @"SOFTWARE\Policies\Microsoft\Windows\EdgeUI";

        //--------------------------------------------------------------------
        //レジストリキー取得（ウインドウズキー無効）
        //--------------------------------------------------------------------
        public bool GetActivateWindowsKey()
        {
            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.LocalMachine.OpenSubKey(Key_ActivateWindowsKey);
                if (regkey == null) return false;

                //byte[] bs = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x5b, 0xe0, 0x00, 0x00, 0x5c, 0xe0, 0x00, 0x00, 0x00, 0x00 };
                byte[] bytes = (byte[])regkey.GetValue("Scancode Map","");

                //閉じる
                regkey.Close();

                if (bytes.Length >= 24)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GetActivateWindowsKey"+ex.Message);
                return false;
            }

        }
        //--------------------------------------------------------------------
        //レジストリキー取得（右ボタン無効）
        //--------------------------------------------------------------------

        public bool GetActivateRightButton()
        {
            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Key_ActivateRightButton);
                if (regkey == null) return false;

                int dw = (int)regkey.GetValue("NoViewContextMenu",-1);

                //閉じる
                regkey.Close();

                if (dw == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GetActivateRightButton"+ex.Message);
                return false;
            }

        }

        //--------------------------------------------------------------------
        //レジストリキー取得(アンチスパイウェア無効）
        //--------------------------------------------------------------------
        public bool GetAntiSpyOFF()
        {
            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.LocalMachine.OpenSubKey(Key_WindowsDefender);
                if (regkey == null) return false;

                int dw = (int)regkey.GetValue("DisableAntiSpyware",-1);

                //閉じる
                regkey.Close();

                if (dw == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GetAntiSpyOFF"+ex.Message);
                return false;
            }
        }

        //--------------------------------------------------------------------
        //レジストリキー取得(エラーレポート無効）
        //--------------------------------------------------------------------
        public bool GetErrorReportOFF()
        {
            try
            {
                Microsoft.Win32.RegistryKey regkey =
        Microsoft.Win32.Registry.CurrentUser.OpenSubKey(Key_ErrorReport);
                if (regkey == null) return false;

                int dw = (int)regkey.GetValue("ForceQueue");

                //閉じる
                regkey.Close();

                if (dw == 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GetErrorReportOFF"+ex.Message);
                return false;
            }
        }
        //--------------------------------------------------------------------
        //レジストリ更新（ウインドウズキー無効）
        //--------------------------------------------------------------------
       public void ActivateWindowsKey(Boolean mode)
        {

            try
            {
                if (mode == true)
                {
                    //キーとそのツリーを根こそぎ削除
                    Microsoft.Win32.Registry.LocalMachine.DeleteSubKeyTree(Key_ActivateWindowsKey);
                }
                else
                {
                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.LocalMachine.CreateSubKey(Key_ActivateWindowsKey);

                    //バイト配列を書き込む（REG_BINARYで書き込まれる）
                    byte[] bs = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x5b, 0xe0, 0x00, 0x00, 0x5c, 0xe0, 0x00, 0x00, 0x00, 0x00 };
                    regkey.SetValue("Scancode Map", bs);

                    //閉じる
                    regkey.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //--------------------------------------------------------------------
        //レジストリ更新（右ボタン無効）
        //--------------------------------------------------------------------

        public void ActivateRightButton(Boolean mode)
        {
            try
            {
                if (mode == true)
                {
                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Key_ActivateRightButton);

                    int dw = 0;
                    regkey.SetValue("NoViewContextMenu", dw);

                    //閉じる
                    regkey.Close();

                }
                else
                {
                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Key_ActivateRightButton);

                    int dw = 1;
                    regkey.SetValue("NoViewContextMenu", dw);

                    //閉じる
                    regkey.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        //--------------------------------------------------------------------
        //レジストリキー更新（アンチスパイウェア無効）
        //--------------------------------------------------------------------
        public void SetAntiSpyOFF(Boolean mode)
        {
            try
            {
                if (mode == true)
                {
                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.LocalMachine.CreateSubKey(Key_WindowsDefender);

                    int dw = 1;
                    regkey.SetValue("DisableAntiSpyware", dw);

                    //閉じる
                    regkey.Close();

                }
                else
                {
                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.LocalMachine.CreateSubKey(Key_WindowsDefender);

                    int dw = 0;
                    regkey.SetValue("DisableAntiSpyware", dw);

                    //閉じる
                    regkey.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //--------------------------------------------------------------------
        //レジストリキー更新(エラーレポート）
        //--------------------------------------------------------------------
        public void SetErrorReportOFF(Boolean mode)
        {
            try
            {
                if (mode == true)
                {

                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Key_ErrorReport);

                    int dw = 1;
                    regkey.SetValue("ForceQueue", dw);

                    //閉じる
                    regkey.Close();

                }
                else
                {
                    Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.CurrentUser.CreateSubKey(Key_ErrorReport);

                    int dw = 0;
                    regkey.SetValue("ForceQueue", dw);

                    //閉じる
                    regkey.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //--------------------------------------------------------------------
        //レジストリキー取得(スワイプ無効）
        //--------------------------------------------------------------------
        public bool GetSwipwOFF()
        {
            try
            {
                Microsoft.Win32.RegistryKey regkey =
            Microsoft.Win32.Registry.LocalMachine.CreateSubKey(Key_Swipe);
                if (regkey == null) return false;

                int dw = (int)regkey.GetValue("AllowEdgeSwipe",-1);

                //閉じる
                regkey.Close();

                if (dw == 0)
                {
                    //キーがあれば
                    return true;
                }
                else
                {//キーがなければ
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GetSwipwOFF" + ex.Message);
                return false;
            }
        }
        //--------------------------------------------------------------------
        //レジストリキー更新(スワイプ無効）
        //--------------------------------------------------------------------
        public void SetSwipwOFF(Boolean mode)
        {
            try
            {
                //「スワイプを無効化する」
                if (mode == true)
                {

                    Microsoft.Win32.RegistryKey regkey =
             Microsoft.Win32.Registry.LocalMachine.CreateSubKey(Key_Swipe);

                    int dw = 0;
                    regkey.SetValue("AllowEdgeSwipe", dw);

                    //閉じる
                    regkey.Close();
                }
                else
                //「スワイプを有効化する」
                {
                    Microsoft.Win32.RegistryKey regkey =
             Microsoft.Win32.Registry.LocalMachine.CreateSubKey(Key_Swipe);

                    //削除する
                    regkey.DeleteValue("AllowEdgeSwipe");

                    //閉じる
                    regkey.Close();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

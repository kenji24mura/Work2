﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form6 : Form
    {
        public String AUTO_UPDATE_INTVAL = System.Configuration.ConfigurationManager.AppSettings["AUTO_UPDATE_INTVAL"];
        public String LOGPATH = System.Configuration.ConfigurationManager.AppSettings["LOGPATH"];

        string Share_Momory_Name = "TIIC_CARCTL";
        private MemoryMappedFile m_Mmf = null;
        private MemoryMappedViewAccessor m_Accessor = null;

        private ColumnHeader[] columnData = new ColumnHeader[20];

        Log lg = new Log();

        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {
            lg.LOGFNAME = LOGPATH + "MainteTool.Process.log";
            lg.loglimit = 1000000;
            lg.logmax = 10;

            TopMost = true;
            // ListViewコントロールのプロパティを設定
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Sorting = SortOrder.None;
            listView1.View = View.Details;


            // 列（コラム）ヘッダの作成
            columnData[0] = new ColumnHeader();
            columnData[1] = new ColumnHeader();
            columnData[2] = new ColumnHeader();
            columnData[3] = new ColumnHeader();
            columnData[4] = new ColumnHeader();
            columnData[5] = new ColumnHeader();
            columnData[6] = new ColumnHeader();
            columnData[7] = new ColumnHeader();
            columnData[8] = new ColumnHeader();
            columnData[9] = new ColumnHeader();//2018.05.09

            columnData[0].Text = "No.";
            columnData[0].Width = 100;
            columnData[1].Text = "プロセスID(LTE)";
            columnData[1].Width = 120;
            columnData[2].Text = "プロセスID(無線LAN)";
            columnData[2].Width = 120;
            columnData[3].Text = "プロセス名";
            columnData[3].Width = 100;
            columnData[4].Text = "起動時間";
            columnData[4].Width = 100;

            columnData[5].Text = "更新時間";
            columnData[5].Width = 100;
            columnData[6].Text = "接続状態(LTE)";
            columnData[6].Width = 120;
            columnData[7].Text = "接続状態(無線LAN)";
            columnData[7].Width = 120;
            columnData[8].Text = "メッセージキュー識別子";
            columnData[8].Width = 150;
            columnData[9].Text = "リザーブ";
            columnData[9].Width = 50;

            ColumnHeader[] colHeaderRegValue =
              { this.columnData[0],
                this.columnData[1],
                this.columnData[2],
                this.columnData[3],
                this.columnData[4],
                this.columnData[5],
                this.columnData[6],
                this.columnData[7],
                this.columnData[8],
                this.columnData[9]};
            listView1.Columns.AddRange(colHeaderRegValue);

            checkAutoUpdate.Checked = false;

            textAutoUpdateIntval.Text = AUTO_UPDATE_INTVAL;

            UpdateInfo();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateInfo();
        }

        private void UpdateInfo()
        {
            DateTime dt = DateTime.Now;
            labelDate.Text = dt.ToString("yyyy/MM/dd HH:mm:ss");

            listView1.Items.Clear();

            ChkSharedMemory(Share_Momory_Name);
        }
        //
        //指定した共有メモリの指定位置の値を取得
        //
        public void ChkSharedMemory(string ShMemName)
        {
            try
            {
                m_Mmf = MemoryMappedFile.CreateOrOpen(ShMemName, 30000);
                m_Accessor = m_Mmf.CreateViewAccessor();

                int offset = 0;

                ulong pidlte;          // プロセスID(LTE)
                ulong pidwrls;     // プロセスID(無線LAN)
                byte[] name = new byte[32];      // プロセス名
                byte[] starttime = new byte[14]; // 起動時間
                byte[] updatetime = new byte[14];    // 更新時間
                byte[] statlt = new byte[1];        // 接続状態(LTE)
                byte[] statwrls = new byte[1];   // 接続状態(無線LAN)
                byte[] queid = new byte[64];     // メッセージキュー識別子
                byte[] rsv = new byte[10];            // リザーブ


                int CarMax = 1000;

                offset = 0;


                if (checkLogOut.Checked == true)
                {
                    string msg = "接続情報 " + textLogComment.Text;
                    lg.LogOut(msg);

                    msg = "◆◆インデックス,プロセスID(LTE),プロセスID(無線LAN),プロセス名,起動時間,更新時間,接続状態(LTE),接続状態(無線LAN),メッセージキュー識別子,リザーブ◆◆";
                    lg.LogOut(msg);
                }

                for (int i = 0; i < CarMax; i++)
                {

                    //long pidlte;          // プロセスID(LTE)
                    pidlte = m_Accessor.ReadUInt64(offset); offset += 8;
                    //long pidwrls;     // プロセスID(無線LAN)
                    pidwrls = m_Accessor.ReadUInt64(offset); offset += 8;
                    //byte[] name = new byte[32];      // プロセス名
                    m_Accessor.ReadArray<byte>(offset, name, 0, name.Length); offset += 32;
                    //byte[] starttime = new byte[14]; // 起動時間
                    m_Accessor.ReadArray<byte>(offset, starttime, 0, starttime.Length); offset += 14;
                    //byte[] updatetime = new byte[14];    // 更新時間
                    m_Accessor.ReadArray<byte>(offset, updatetime, 0, updatetime.Length); offset += 14;
                    //byte statlt;        // 接続状態(LTE)
                    m_Accessor.ReadArray<byte>(offset, statlt, 0, statlt.Length); offset += 1;
                    //byte statwrls;   // 接続状態(無線LAN)
                    m_Accessor.ReadArray<byte>(offset, statwrls, 0, statwrls.Length); offset += 1;
                    //byte[] queid = new byte[64];     // メッセージキュー識別子
                    m_Accessor.ReadArray<byte>(offset, queid, 0, queid.Length); offset += 64;
                    //byte[] rsv = new byte[3];            // リザーブ
                    m_Accessor.ReadArray<byte>(offset, rsv, 0, rsv.Length); offset += 10;

                    string Name = System.Text.Encoding.ASCII.GetString(name);
                    string Starttime = System.Text.Encoding.ASCII.GetString(starttime);
                    string Updatetime = System.Text.Encoding.ASCII.GetString(updatetime);

                    string Statlt = "";
                    string Statwrls = "";

                    switch (statlt[0])
                    {
                        case 0:
                            Statlt = "未起動（停止）";
                            break;
                        case 1:
                            Statlt = "起動中";
                            break;
                        case 2:
                            Statlt = "起動済み（実行中）";
                            break;
                    }
                    switch (statwrls[0])
                    {
                        case 0:
                            Statwrls = "未起動（停止）";
                            break;
                        case 1:
                            Statwrls = "起動中";
                            break;
                        case 2:
                            Statwrls = "起動済み（実行中）";
                            break;
                    }

                    string Queid = System.Text.Encoding.ASCII.GetString(queid);
                    string Rsv = System.Text.Encoding.ASCII.GetString(rsv);

                    string[] item1 = { i.ToString("D4"),pidlte.ToString(),
                    pidwrls.ToString(),
                    Name,
                    Starttime,
                    Updatetime,
                       Statlt,
                Statwrls,
                    Queid,
                    Rsv };

                    //シーケンシャル番号限定
                    if (checkLimit.Checked == true)
                    {
                        int limit = Int32.Parse(textLimit.Text);

                        if (limit == i)
                        {
                            listView1.Items.Add(new ListViewItem(item1));
                        }
                    }
                    else
                    {
                        listView1.Items.Add(new ListViewItem(item1));
                    }



                    if (checkLogOut.Checked == true && (pidlte>0 || pidwrls> 0))
                    {
                        string msg = i.ToString()+",";
                        for (int j = 0; j < item1.Length; j++)
                        {
                            msg += item1[j];
                            msg += ",";
                        }
                        lg.LogOut(msg);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void checkAutoUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timerAutoUpdate.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timerAutoUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timerAutoUpdate.Enabled = false;
                }
            }
            else
            {
                timerAutoUpdate.Enabled = false;
            }
        }

        private void timerAutoUpdate_Tick(object sender, EventArgs e)
        {
            timerAutoUpdate.Enabled = false;
            UpdateInfo();

            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timerAutoUpdate.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timerAutoUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timerAutoUpdate.Enabled = false;
                }
            }
        }
    }
}

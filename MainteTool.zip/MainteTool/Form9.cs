﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form9 : Form
    {

        private MemoryMappedFile m_Mmf = null;
        private MemoryMappedViewAccessor m_Accessor = null;

        private ColumnHeader[] columnData = new ColumnHeader[20];

        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            TopMost = true;

            // ListViewコントロールのプロパティを設定
            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Sorting = SortOrder.Ascending;
            listView1.View = View.Details;


            // 列（コラム）ヘッダの作成
            columnData[0] = new ColumnHeader();
            columnData[1] = new ColumnHeader();
            columnData[2] = new ColumnHeader();
            columnData[3] = new ColumnHeader();
            columnData[4] = new ColumnHeader();
            columnData[5] = new ColumnHeader();
            columnData[6] = new ColumnHeader();
            columnData[7] = new ColumnHeader();
            columnData[8] = new ColumnHeader();
            columnData[9] = new ColumnHeader();
            columnData[10] = new ColumnHeader();
            columnData[11] = new ColumnHeader();
            columnData[12] = new ColumnHeader();

            columnData[0].Text = "車両番号";
            columnData[0].Width = 100;
            columnData[1].Text = "名称";
            columnData[1].Width = 100;
            columnData[2].Text = "AVM";
            columnData[2].Width = 50;
            columnData[3].Text = "車種";
            columnData[3].Width = 50;

            columnData[4].Text = "経度";
            columnData[4].Width = 100;
            columnData[5].Text = "緯度";
            columnData[5].Width = 100;
            columnData[6].Text = "方位";
            columnData[6].Width = 50;
            columnData[7].Text = "動態";
            columnData[7].Width = 50;


            columnData[8].Text = "部署水利予約状況";
            columnData[8].Width = 100;
            columnData[9].Text = "コード";
            columnData[9].Width = 120;
            columnData[10].Text = "部署位置予約状況";
            columnData[10].Width = 100;
            columnData[11].Text = "緯度";
            columnData[11].Width = 100;
            columnData[12].Text = "経度";
            columnData[12].Width = 100;

            ColumnHeader[] colHeaderRegValue =
              { this.columnData[0],
                this.columnData[1],
                this.columnData[2],
                this.columnData[3],
                this.columnData[4],
                this.columnData[5],
                this.columnData[6],
                this.columnData[7],
                this.columnData[8],
                this.columnData[9],
                this.columnData[10],
                this.columnData[11],
                this.columnData[12]};
            listView1.Columns.AddRange(colHeaderRegValue);

            listView1.Items.Clear();

            ChkSharedMemory("MEMORY_OTHERCARS_INFO");


        }

        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();

            ChkSharedMemory("MEMORY_OTHERCARS_INFO");

        }
        //
        //指定した共有メモリの指定位置の値を取得
        //
        public void ChkSharedMemory(string ShMemName)
        {
            m_Mmf = MemoryMappedFile.CreateOrOpen(ShMemName, 30000);
            m_Accessor = m_Mmf.CreateViewAccessor();

            int offset = 0;

            byte[] buf = new byte[116];
            byte[] name = new byte[16];

            string listMsg;

            int CarMax;

            CarMax = m_Accessor.ReadInt32(offset);

            long CarNo;//                           4                               車両コード
            byte[] Name = new byte[16];//                               16                              車両名称
            byte[] TYpe = new byte[1];//                                                Type                                1                               AVMタイプ（車両タイプ）									
            byte[] Kind = new byte[1];//                                1                               車種コード
            byte[] StationCode = new byte[2];//                             2                               署所コード
            byte[] CenterCode = new byte[2]; //                              2                               本部コード
            byte[] Reserve1 = new byte[2];//                                2                               予備
            int Lantitude1;//                             4                               緯度
            int Longitude1;//                             4                               経度
            byte[] Direction = new byte[1];//                             1                               方位
            byte[] Reserve2 = new byte[3];//                                3                               予備
            byte[] Status = new byte[2];//                                2                               動態
            byte[] LastUpdateDateTime = new byte[14];//                                14                              最終更新日時
            byte[] CaseID = new byte[24];//                                24                              事案識別子
            byte[] ReservedStatus1 = new byte[1];//                             1                                 部署水利予約状況
            byte[] Code = new byte[19];//                              19                              水利コード＋残り空白
            byte[] ReservedStatus2 = new byte[1];//                             1                                 部署位置予約状況
            byte[] Reserve3 = new byte[3];//                                3                                 予約領域
            int Lantitude2;//                             4                                 緯度
            int Longitude2;//                             4                                 経度
            byte[] RequestFlag = new byte[1];//                             1                               要求中フラグ
            byte[] Reserve4 = new byte[3];//                             3                               予備

            offset += 4;

            for (int i = 0; i < CarMax; i++)
            {
                //long CarNo;//                           4                               車両コード
                CarNo = m_Accessor.ReadInt32(offset); offset += 4;
                //byte[] Name = new byte[16];//                               16                              車両名称
                m_Accessor.ReadArray<byte>(offset, Name, 0, Name.Length); offset += 16;
                //byte TYpe;//                                                Type                                1                               AVMタイプ（車両タイプ）									
                m_Accessor.ReadArray<byte>(offset, TYpe, 0, TYpe.Length); offset += 1;
                //byte Kind;//                                1                               車種コード
                m_Accessor.ReadArray<byte>(offset, Kind, 0, Kind.Length); offset += 1;
                //byte[] StationCode = new byte[2];//                             2                               署所コード
                m_Accessor.ReadArray<byte>(offset, StationCode, 0, StationCode.Length); offset += 2;
                //byte[] CenterCode = new byte[2]; //                              2                               本部コード
                m_Accessor.ReadArray<byte>(offset, CenterCode, 0, CenterCode.Length); offset += 2;
                //byte[] Reserve1 = new byte[2];//                                2                               予備
                m_Accessor.ReadArray<byte>(offset, Reserve1, 0, Reserve1.Length); offset += 2;
                //int Lantitude1;//                             4                               緯度
                Lantitude1 = m_Accessor.ReadInt32(offset); offset += 4;
                //int Longitude1;//                             4                               経度
                Longitude1 = m_Accessor.ReadInt32(offset); offset += 4;
                //byte Direction;//                             1                               方位
                m_Accessor.ReadArray<byte>(offset, Direction, 0, Direction.Length); offset += 1;
                //byte[] Reserve2 = new byte[3];//                                3                               予備
                m_Accessor.ReadArray<byte>(offset, Reserve1, 0, Reserve1.Length); offset += 3;
                //byte[] Status = new byte[2];//                                2                               動態
                m_Accessor.ReadArray<byte>(offset, Status, 0, Status.Length); offset += 2;
                //byte[] LastUpdateDateTime = new byte[14];//                                14                              最終更新日時
                m_Accessor.ReadArray<byte>(offset, LastUpdateDateTime, 0, LastUpdateDateTime.Length); offset += 14;
                //byte[] CaseID = new byte[24];//                                24                              事案識別子
                m_Accessor.ReadArray<byte>(offset, CaseID, 0, CaseID.Length); offset += 24;
                //byte[] ReservedStatus1 = new byte[1];//                             1                                 部署水利予約状況
                m_Accessor.ReadArray<byte>(offset, ReservedStatus1, 0, ReservedStatus1.Length); offset += 1;
                //byte[] Code = new byte[19];//                              19                              水利コード＋残り空白
                m_Accessor.ReadArray<byte>(offset, Code, 0, Code.Length); offset += 19;
                //byte ReservedStatus;//                             1                                 部署位置予約状況
                m_Accessor.ReadArray<byte>(offset, ReservedStatus2, 0, ReservedStatus2.Length); offset += 1;
                //byte[] Reserve3 = new byte[3];//                                3                                 予約領域
                m_Accessor.ReadArray<byte>(offset, Reserve3, 0, Reserve3.Length); offset += 3;
                //int Lantitude2;//                             4                                 緯度
                Lantitude2 = m_Accessor.ReadInt32(offset); offset += 4;
                //int Longitude2;//                             4                                 経度
                Longitude2 = m_Accessor.ReadInt32(offset); offset += 4;


                for (int m = 0; m < Name.Length; m++)
                {
                    if (Name[m] == 0x00)
                    {
                        Name[m] = 0x20;
                    };
                }

                string strName;
                strName = System.Text.Encoding.GetEncoding(932).GetString(Name);

                //ASCII エンコード
                for (int j = 0; j < Code.Length; j++)
                {
                    if (Code[j] == 0x00)
                    {
                        Code[j] = 0x20;
                    };
                }

                string textCode = System.Text.Encoding.ASCII.GetString(Code);
                if (textCode.Length < 1)
                {
                    textCode = " ";
                }

                //動態
                string textStatus = System.Text.Encoding.ASCII.GetString(Status);

                string[] item1 = { CarNo.ToString("d4"),
                    strName,
                    TYpe[0].ToString("x2"),
                    Kind[0].ToString("x2"),
                    Lantitude1.ToString("d10"),
                    Longitude1.ToString("d10"),
                    Direction[0].ToString("x2"),
                       textStatus,
                ReservedStatus1[0].ToString("x2"),
                    textCode,
                    ReservedStatus2[0].ToString("x2"),
                    Lantitude2.ToString("d10"),
                    Longitude2.ToString("d10")};

                listView1.Items.Add(new ListViewItem(item1));

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

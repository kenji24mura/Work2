﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form10 : Form
    {
        public String NAVI_APP = System.Configuration.ConfigurationManager.AppSettings["NAVI_APP"];
        public String NAVI_TOOL = System.Configuration.ConfigurationManager.AppSettings["NAVI_TOOL"];
        public String NAVI_DATA = System.Configuration.ConfigurationManager.AppSettings["NAVI_DATA"];
        public String CMD_NAME = System.Configuration.ConfigurationManager.AppSettings["CMD_NAME"];


        public string m_name;
        public string m_address;
        public string m_netmask;
        public string m_gateway;

        public TextBox current;

        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            textBox1.Text = m_name;
            textBox2.Text = m_address;
            textBox3.Text = m_netmask;
            textBox4.Text = m_gateway;

            button1.Text = "1";
            button2.Text = "2";
            button3.Text = "3";
            button4.Text = "4";
            button5.Text = "5";
            button6.Text = "6";
            button7.Text = "7";
            button8.Text = "8";
            button9.Text = "9";
            button10.Text = "0";
            button11.Text = ".";
            button12.Text = "CLS";

            current = textBox2;
        }
        private void UpdateAddress(string name, string address, string netmask, string gateway)
        {
            string cmdpath = NAVI_TOOL + CMD_NAME;
            string param = "\"" + name + "\" " + address + " " + netmask + " " + gateway;

            Process p = Process.Start(cmdpath, param);
            p.WaitForExit();              // プロセスの終了を待つ
            int iExitCode = p.ExitCode;   // 終了コード

            //netsh interface ip set address "ローカル エリア接続 3" static 172.16.1.101 255.255.255.0
        }
        public void SetData(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (b.Text != "CLS")
            {
                current.Text += b.Text;
            }
            else
            {
                current.Text = "";
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            UpdateAddress(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

﻿namespace MainteTool
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listView1 = new System.Windows.Forms.ListView();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkAutoUpdate = new System.Windows.Forms.CheckBox();
            this.timerAutoUpdate = new System.Windows.Forms.Timer(this.components);
            this.textAutoUpdateIntval = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkFilter = new System.Windows.Forms.CheckBox();
            this.textFilter = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.checkFilter2 = new System.Windows.Forms.CheckBox();
            this.textFilter2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.checkLogOut = new System.Windows.Forms.CheckBox();
            this.textLogComment = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.listView1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.listView1.ForeColor = System.Drawing.Color.Black;
            this.listView1.Location = new System.Drawing.Point(4, 65);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(818, 335);
            this.listView1.TabIndex = 6;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnClose.Location = new System.Drawing.Point(4, 522);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(130, 41);
            this.btnClose.TabIndex = 5;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.Location = new System.Drawing.Point(1113, -49);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(130, 39);
            this.btnUpdate.TabIndex = 4;
            this.btnUpdate.Text = "更新";
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(692, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(130, 39);
            this.button1.TabIndex = 7;
            this.button1.Text = "更新";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkBox1.Location = new System.Drawing.Point(531, 533);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(122, 21);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "establish only";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkBox2.Location = new System.Drawing.Point(692, 533);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(90, 21);
            this.checkBox2.TabIndex = 9;
            this.checkBox2.Text = "ipv4 only";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkAutoUpdate
            // 
            this.checkAutoUpdate.AutoSize = true;
            this.checkAutoUpdate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkAutoUpdate.Location = new System.Drawing.Point(513, 23);
            this.checkAutoUpdate.Name = "checkAutoUpdate";
            this.checkAutoUpdate.Size = new System.Drawing.Size(79, 21);
            this.checkAutoUpdate.TabIndex = 10;
            this.checkAutoUpdate.Text = "自動更新";
            this.checkAutoUpdate.UseVisualStyleBackColor = true;
            this.checkAutoUpdate.CheckedChanged += new System.EventHandler(this.checkAutoUpdate_CheckedChanged);
            // 
            // timerAutoUpdate
            // 
            this.timerAutoUpdate.Tick += new System.EventHandler(this.timerAutoUpdate_Tick);
            // 
            // textAutoUpdateIntval
            // 
            this.textAutoUpdateIntval.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textAutoUpdateIntval.Location = new System.Drawing.Point(601, 21);
            this.textAutoUpdateIntval.Name = "textAutoUpdateIntval";
            this.textAutoUpdateIntval.Size = new System.Drawing.Size(38, 24);
            this.textAutoUpdateIntval.TabIndex = 11;
            this.textAutoUpdateIntval.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(655, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "sec";
            // 
            // checkFilter
            // 
            this.checkFilter.AutoSize = true;
            this.checkFilter.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkFilter.Location = new System.Drawing.Point(16, 421);
            this.checkFilter.Name = "checkFilter";
            this.checkFilter.Size = new System.Drawing.Size(109, 21);
            this.checkFilter.TabIndex = 13;
            this.checkFilter.Text = "ポートフィルター";
            this.checkFilter.UseVisualStyleBackColor = true;
            // 
            // textFilter
            // 
            this.textFilter.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textFilter.Location = new System.Drawing.Point(145, 421);
            this.textFilter.Name = "textFilter";
            this.textFilter.Size = new System.Drawing.Size(367, 24);
            this.textFilter.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(529, 421);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(244, 18);
            this.label2.TabIndex = 15;
            this.label2.Text = "指定例) 123;234";
            // 
            // checkFilter2
            // 
            this.checkFilter2.AutoSize = true;
            this.checkFilter2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkFilter2.Location = new System.Drawing.Point(16, 453);
            this.checkFilter2.Name = "checkFilter2";
            this.checkFilter2.Size = new System.Drawing.Size(93, 21);
            this.checkFilter2.TabIndex = 16;
            this.checkFilter2.Text = "IPフィルター";
            this.checkFilter2.UseVisualStyleBackColor = true;
            // 
            // textFilter2
            // 
            this.textFilter2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.textFilter2.Location = new System.Drawing.Point(145, 453);
            this.textFilter2.Name = "textFilter2";
            this.textFilter2.Size = new System.Drawing.Size(367, 24);
            this.textFilter2.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(528, 453);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(244, 18);
            this.label3.TabIndex = 18;
            this.label3.Text = "指定例) 0.0.0.0;127.0.0.1";
            // 
            // labelDate
            // 
            this.labelDate.BackColor = System.Drawing.Color.Black;
            this.labelDate.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.labelDate.ForeColor = System.Drawing.Color.LawnGreen;
            this.labelDate.Location = new System.Drawing.Point(13, 11);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(210, 29);
            this.labelDate.TabIndex = 19;
            this.labelDate.Text = "label4";
            this.labelDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkLogOut
            // 
            this.checkLogOut.AutoSize = true;
            this.checkLogOut.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.checkLogOut.Location = new System.Drawing.Point(16, 486);
            this.checkLogOut.Name = "checkLogOut";
            this.checkLogOut.Size = new System.Drawing.Size(77, 21);
            this.checkLogOut.TabIndex = 20;
            this.checkLogOut.Text = "LogOut";
            this.checkLogOut.UseVisualStyleBackColor = true;
            // 
            // textLogComment
            // 
            this.textLogComment.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textLogComment.Location = new System.Drawing.Point(145, 483);
            this.textLogComment.Name = "textLogComment";
            this.textLogComment.Size = new System.Drawing.Size(677, 24);
            this.textLogComment.TabIndex = 21;
            this.textLogComment.Text = "ログコメント";
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(834, 575);
            this.Controls.Add(this.textLogComment);
            this.Controls.Add(this.checkLogOut);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textFilter2);
            this.Controls.Add(this.checkFilter2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textFilter);
            this.Controls.Add(this.checkFilter);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textAutoUpdateIntval);
            this.Controls.Add(this.checkAutoUpdate);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnUpdate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form5";
            this.Text = "接続情報";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkAutoUpdate;
        private System.Windows.Forms.Timer timerAutoUpdate;
        private System.Windows.Forms.TextBox textAutoUpdateIntval;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkFilter;
        private System.Windows.Forms.TextBox textFilter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkFilter2;
        private System.Windows.Forms.TextBox textFilter2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelDate;
        private System.Windows.Forms.CheckBox checkLogOut;
        private System.Windows.Forms.TextBox textLogComment;
    }
}
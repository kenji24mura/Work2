﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Compression;
using System.IO;

namespace MainteTool
{
    public partial class Form3 : Form
    {
        public string NaviApp;
        public string NaviData;
        public string Log1;
        public string Zip1;
        public string Log2;
        public string Zip2;
        public string FTP_SERVER;
        public string FTP_SERVER2;
        public string FTP_USER;
        public string FTP_PASSWD;
        public string SERVER_DIR;
        public string LOCAL_DIR;
        public string CarNumber;

        string ACTIVE_SERVER="";

        private DateTime limitDate;

        private int LogCount = 0;
        string workdir1;
        string workdir2;


        public Form3()
        {
            InitializeComponent();
        }
        private void Form3_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
            radioButton3.Checked = true;

            Form3 f3 = new Form3();
            f3.NaviApp = NaviApp;
            f3.NaviData = NaviData;
            Log1 = @"IICCL\data\log";
            Log2 = @"IICMW\log";

            textBox1.Text = NaviData + Log1;
            textBox2.Text = NaviData + Log2;
            textBox3.Text = "Log"+CarNumber + "_";

            labelFolder.Text = "d:\\";

            labelServer.Enabled = true;
            labelFolder.Enabled = false;

            btnFolder.Enabled = false;

            comboBox1.Items.Add("1");
            comboBox1.Items.Add("5");
            comboBox1.Items.Add("10");
            comboBox1.Items.Add("24");
            comboBox1.Items.Add("50");
            comboBox1.Items.Add("100");
            comboBox1.SelectedIndex = 0;

            workdir1 = NaviData + @"IICCL\data\logWk";
            workdir2 = NaviData + @"IICMW\logWk";

            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

            TopMost = true;
            PingCheck();
//            labelServer.Text = ACTIVE_SERVER;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void CreateZip(string indir,string outfile)
        {
            try
            {
                //                ZipFile.CreateFromDirectory(indir, outfile);
                //対象ディレクトリをアーカイブに含める 2018.02.25
                //
                ZipFile.CreateFromDirectory(indir, outfile,CompressionLevel.Optimal,true);
            }
            catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
            }
        }

        private void btnLog1_Click(object sender, EventArgs e)
        {

            DateTime dt = DateTime.Now;

            string sdate = dt.ToString("yyyyMMddHHmmss");
            Zip1 = textBox3.Text + @"IICCL" + sdate + ".zip";

            string indir = NaviData + Log1;
            string outfile = NaviData + LOCAL_DIR + Zip1;

            if (radioButton3.Checked == true)
            {

                btnLog1.Enabled = false;
                CreateZip(indir, outfile);
                btnLog1.Enabled = true;
            }else
            {
                //時間指定
                DateTime dtNow = DateTime.Now;
                int limitval = Int32.Parse(comboBox1.SelectedItem.ToString());
                limitDate = dtNow.AddHours(-limitval);

                ////作業ディレクトリの作成
                if (Directory.Exists(workdir1))
                {
                    Directory.Delete(workdir1,true);
                }
                else
                {
                    Directory.CreateDirectory(workdir1);
                }

                LogCount = 0;
                GetLog(indir, workdir1);
                if (LogCount > 0)
                {
                    btnLog1.Enabled = false;
                    CreateZip(workdir1, outfile);
                    btnLog1.Enabled = true;
                }else
                {
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "対象のログはありません。";
                    mf.ShowDialog();

                    return;
                }
            }


            if (radioButton1.Checked == true)
            {

                if (PingCheck() == 0)
                {
                    PutFile(FTP_USER, FTP_PASSWD, "ftp://" + ACTIVE_SERVER + SERVER_DIR + "/" + Zip1, outfile);


                    MsgForm mf = new MsgForm();
                    mf.disp_message = "ログをアップロードしました。";
                    mf.ShowDialog();
                }else
                {
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "ログのアップロードに失敗しました。";
                    mf.ShowDialog();
                }
                System.IO.File.Delete(outfile);
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                        System.IO.File.Copy(outfile, labelFolder.Text + "\\" + Zip1, true);
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "ログをコピーしました。";
                    mf.ShowDialog();
                }
            }

        }
        private void btnLog2_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;

            string sdate = dt.ToString("yyyyMMddHHmmss");
            Zip2 = textBox3.Text + @"IICMW" + sdate + ".zip";

            string indir = NaviData + Log2;
            string outfile = NaviData + LOCAL_DIR + Zip2;

            if (radioButton3.Checked == true)
            {
                btnLog2.Enabled = false;
                CreateZip(indir, outfile);
                btnLog2.Enabled = true;
            }
            else
            {
                //時間指定
                DateTime dtNow = DateTime.Now;
                int limitval = Int32.Parse(comboBox1.SelectedItem.ToString());
                limitDate = dtNow.AddHours(-limitval);

                ////作業ディレクトリの作成
                if (Directory.Exists(workdir2))
                {
                    Directory.Delete(workdir2, true);
                }
                else
                {
                    Directory.CreateDirectory(workdir2);
                }

                LogCount = 0;

                GetLog(indir, workdir2);

                if (LogCount > 0)
                {
                    btnLog1.Enabled = false;
                    CreateZip(workdir2, outfile);
                    btnLog1.Enabled = true;
                }else
                {
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "対象のログはありません。";
                    mf.ShowDialog();
                    return;
                }
            }

            if (radioButton1.Checked == true)
            {
                if (PingCheck() == 0)
                {
                    PutFile(FTP_USER, FTP_PASSWD, "ftp://" + ACTIVE_SERVER + SERVER_DIR + "/" + Zip2, outfile);


                    MsgForm mf = new MsgForm();
                    mf.disp_message = "ログをアップロードしました。";
                    mf.ShowDialog();
                }
                else
                {
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "ログのアップロードに失敗しました。";
                    mf.ShowDialog();
                }
                System.IO.File.Delete(outfile);
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    System.IO.File.Copy(outfile, labelFolder.Text + "\\" + Zip2, true);
                    MsgForm mf = new MsgForm();
                    mf.disp_message = "ログをコピーしました。";
                    mf.ShowDialog();
                }
            }

        }
        //--------------------------------------------------------------------
        //ログ収集
        //--------------------------------------------------------------------
        public void GetLog(string sDir,string workdir)
        {
            ////作業ディレクトリの作成
            if (Directory.Exists(workdir))
            {
                Directory.Delete(workdir, true);
            }
            else
            {
                Directory.CreateDirectory(workdir);
            }


            foreach (string f in Directory.GetFiles(sDir))
            {
                CheckLog(f, sDir, workdir);
            }
            DirSearch(sDir, sDir, workdir);
        }

        //--------------------------------------------------------------------
        //再帰的にサーチ
        //--------------------------------------------------------------------
        void DirSearch(string sDir,string logpath, string workdir)
        {
            try
            {
                foreach (string d in Directory.GetDirectories(sDir))
                {
                    foreach (string f in Directory.GetFiles(d))
                    {
                        CheckLog(f, logpath, workdir);
                    }
                    DirSearch(d, logpath, workdir);
                }
            }
            catch (System.Exception ex)
            {

            }
        }

        //--------------------------------------------------------------------
        //指定時間ログコピー
        //--------------------------------------------------------------------
        private void CheckLog(string f,string logpath,string workdir)
        {
            DateTime dtCreate = System.IO.File.GetLastWriteTime(f);

            if (dtCreate > limitDate)
            {
                string dir;

                string workpath = f.Replace(logpath, workdir);

                dir = Path.GetDirectoryName(workpath);
                if (Directory.Exists(dir))
                {
                }
                else
                {
                    Directory.CreateDirectory(dir);
                }

                System.IO.File.Copy(f, workpath);
                LogCount++;

            }
        }

        //--------------------------------------------------------------------
        //pingチェック
        //--------------------------------------------------------------------
        public int PingCheck()
        {
            int ret = 0;
//            MsgOut("ping 実行:" + FTP_SERVER);
            if (SendPing(FTP_SERVER) == true)
            {
  //              MsgOut("ping 正常" + FTP_SERVER);
                ACTIVE_SERVER = FTP_SERVER;
                labelServer.Text = ACTIVE_SERVER;
            }
            else
            {
    //            MsgOut("ping 異常" + FTP_SERVER);

                if (SendPing(FTP_SERVER2) == true)
                {
      //              MsgOut("ping 正常" + FTP_SERVER2);
                    ACTIVE_SERVER = FTP_SERVER2;
                    labelServer.Text = ACTIVE_SERVER;
                }
                else
                {
        //            MsgOut("ping 異常" + FTP_SERVER2);
                    ret = -1;
                    labelServer.Text = "リモートサーバはアクセスできません";
                }
            }
            return ret;
        }

        //--------------------------------------------------------------------
        //PING 監視
        //--------------------------------------------------------------------
        public Boolean SendPing(String host)
        {
            Boolean result = false;

            try
            {
                //Pingオブジェクトの作成
                System.Net.NetworkInformation.Ping p =
                    new System.Net.NetworkInformation.Ping();
                System.Net.NetworkInformation.PingReply reply = p.Send(host);

                //結果を取得
                if (reply.Status == System.Net.NetworkInformation.IPStatus.Success)
                {
                    result = true;
                }
                else
                {
                }
                p.Dispose();
            }
            catch (Exception ex)
            {
                result = false;
            }
            return result;
        }

        //--------------------------------------------------------------------
        //FTP Upload
        //--------------------------------------------------------------------

        public void PutFile(String username, String password, String serverUrl, String localFile)
        {

            try
            {
                //WebClientオブジェクトを作成
                System.Net.WebClient wc = new System.Net.WebClient();
                //ログインユーザー名とパスワードを指定
                wc.Credentials = new System.Net.NetworkCredential(username, password);
                //FTPサーバーにファイルをアップロードする
                wc.UploadFile(serverUrl, localFile);
                //解放する
                wc.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //FolderBrowserDialogクラスのインスタンスを作成
            FolderBrowserDialog fbd = new FolderBrowserDialog();

            //上部に表示する説明テキストを指定する
            fbd.Description = "フォルダを指定してください。";
            //ルートフォルダを指定する
            //デフォルトでDesktop
            fbd.RootFolder = Environment.SpecialFolder.Desktop;
            //最初に選択するフォルダを指定する
            //RootFolder以下にあるフォルダである必要がある
            fbd.SelectedPath = labelFolder.Text;
            //ユーザーが新しいフォルダを作成できるようにする
            //デフォルトでTrue
            fbd.ShowNewFolderButton = true;

            //ダイアログを表示する
            if (fbd.ShowDialog(this) == DialogResult.OK)
            {
                //選択されたフォルダを表示する
                labelFolder.Text = fbd.SelectedPath;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            labelServer.Enabled = true;
            labelFolder.Enabled = false;
            btnFolder.Enabled = false;
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            labelServer.Enabled = false;
            labelFolder.Enabled = true;
            btnFolder.Enabled = true;
        }

    }
}

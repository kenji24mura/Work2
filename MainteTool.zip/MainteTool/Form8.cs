﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form8 : Form
    {
        string[] ComTable = { "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "COM10" };


        public String NaviApp = System.Configuration.ConfigurationManager.AppSettings["NAVI_APP"];
        public String NaviData = System.Configuration.ConfigurationManager.AppSettings["NAVI_DATA"];
        public String NaviTool = System.Configuration.ConfigurationManager.AppSettings["NAVI_TOOL"];
        public String LOGPATH = System.Configuration.ConfigurationManager.AppSettings["LOGPATH"];
        public String UDP_HOST = System.Configuration.ConfigurationManager.AppSettings["UDP_HOST"];
        public String UDP_PORT = System.Configuration.ConfigurationManager.AppSettings["UDP_PORT"];

        Encoding sjisEnc = Encoding.GetEncoding("Shift_JIS");
        StreamWriter writer;

        Boolean IsStart=false;

        Boolean IsUdpContinue;
        System.Net.Sockets.UdpClient objSck2;

//デリゲートメソッド
        private delegate void DelSetText(string str);


        public Form8()
        {
            InitializeComponent();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            TopMost = true;
            Encoding sjisEnc = Encoding.GetEncoding("Shift_JIS");

            for (int i = 0; i < ComTable.Length; i++)
            {
                comboBox1.Items.Add(ComTable[i]);

            }
            btnStop.Enabled = false;
            btnStop2.Enabled = false;
            comboBox1.SelectedIndex = 0;

            textUDPHOST.Text = UDP_HOST;
            textUDPPORT.Text = UDP_PORT;
            Width = 1000;
            Height = 700;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;

            string logpath = LOGPATH + "\\" + dt.ToString("yyyyMMddhhmmss") + "_NMEA.txt";

            serialPort1.BaudRate = 9600;
            serialPort1.PortName = comboBox1.SelectedItem.ToString();

            try
            {
                serialPort1.Open();
                MsgOut("OPEN");
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }
            writer =
              new StreamWriter(logpath, true, sjisEnc);
            btnStart.Enabled = false;
            btnStop.Enabled = true;

            IsStart = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                serialPort1.Close();
                MsgOut("CLOSE");
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }
            writer.Close();
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void serialPort1_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            SerialPort port = (SerialPort)sender;
            byte[] buf = new byte[1024];
            int len = port.Read(buf, 0, 1024);
            string s = Encoding.GetEncoding("Shift_JIS").GetString(buf, 0, len);

            MsgOut(s);
            string[] cols = s.Split(',');

            for(int i=0; i < cols.Length; i++)
            {
                if (cols[i].IndexOf("$GPRMC") >= 0)
                {
                    if(cols.Length > (i + 6))
                    {
                        listBox3.Items.Clear();
                        listBox3.Items.Add(cols[i]);
                        string JST = "";
                        string UTC = "";

                        if (cols[i + 1].Length >= 8)
                        {

                            string str = cols[i + 1];
                            UTC = str.Substring(0, 2) + ":" + str.Substring(2, 2) + ":" + str.Substring(4, 2) + "." + Int32.Parse(str.Substring(7)).ToString("D3");
                            try
                            {
                                DateTime utc_input = System.DateTime.ParseExact(UTC, "HH:mm:ss.fff",
                                      System.Globalization.DateTimeFormatInfo.InvariantInfo,
                                      System.Globalization.DateTimeStyles.NoCurrentDateDefault);
                                TimeZoneInfo jstZoneInfo = System.TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time");

                                DateTime jst = System.TimeZoneInfo.ConvertTimeFromUtc(utc_input, jstZoneInfo);
                                JST = jst.ToString("HH:mm:ss fff");
                            }
                            catch (Exception ex)
                            {
                         //       MsgOut(UTC+","+ex.ToString());
                            }
                        }

                        listBox3.Items.Add("UTC時刻:" + UTC);
                        listBox3.Items.Add("JST時刻:" + JST);
                        listBox3.Items.Add("ステータス:"+cols[i + 2]);
                        listBox3.Items.Add("緯度:"+cols[i + 4]+cols[i + 3]);
                        listBox3.Items.Add("経度:"+cols[i + 6]+cols[i + 5]);
                    }
                    break;
                }
            }
            
            //$GPRMC,085120.307,A,3541.1493,N,13945.3994,E,000.0,240.3,181211,,,A*6A
            //ステータス。V = 警告、A = 有効

            SaveLog(s);
        }
        public void MsgOut(string msg)
        {
            DateTime dt = DateTime.Now;
            listBox1.Items.Add(dt.ToString() + "," + msg);
            int max = listBox1.Items.Count;
            if(max > 1000)
            {
                listBox1.Items.Clear();
            }else
            {
                listBox1.TopIndex = max-1;
            }

        }
        public void MsgOut2(string msg)
        {
            DateTime dt = DateTime.Now;
            listBox2.Items.Add(dt.ToString() + "," + msg);
            int max = listBox2.Items.Count;
            if (max > 1000)
            {
                listBox2.Items.Clear();
            }else
            {
                listBox2.TopIndex = max-1;
            }
        }
        public void SaveLog(string msg)
        {
            writer.Write(msg);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if(IsStart == true)
            {
                try
                {
                    serialPort1.Close();
                    MsgOut("CLOSE");
                }
                catch (Exception ex)
                {
                    MsgOut(ex.Message);
                }
                writer.Close();
            }
            Close();
        }
        //--------------------------------------------------------------------
        //UDP受信開始
        //--------------------------------------------------------------------

        private void GetUDPInfo()
        {

            if (SendPing(UDP_HOST) == true)
            {
                IsUdpContinue = true;

                MsgOut2("車載端末への接続用UDP生成");

                try
                {

                    // NTPサーバへの接続用UDP生成
                    System.Net.IPEndPoint ipAny =
                        new System.Net.IPEndPoint(System.Net.IPAddress.Any, Int32.Parse(UDP_PORT));
                    objSck2 = new System.Net.Sockets.UdpClient(ipAny);

                    MsgOut2("UDP/IP受信コールバック設定");
                    // UDP/IP受信コールバック設定(System.AsyncCallback)
                    objSck2.BeginReceive(ReceiveCallback2, objSck2);


                }
                catch (Exception e)
                {
                    IsUdpContinue = false;
                    btnStart2.Enabled = true;
                    btnStop2.Enabled = false;
                }
            }
            else
            {
                IsUdpContinue = false;
                btnStart2.Enabled = true;
                btnStop2.Enabled = false;
            }
        }
        private void StopUDPInfo()
        {
            if(IsUdpContinue == true)
            {
                objSck2.Close();
                objSck2 = null;
                MsgOut2("車載端末への接続用UDP CLOSE");

                IsUdpContinue = false;
            }

        }
        //--------------------------------------------------------------------
        //PING 監視
        //--------------------------------------------------------------------
        public Boolean SendPing(String host)
        {
            Boolean result = false;

            try
            {
                //Pingオブジェクトの作成
                System.Net.NetworkInformation.Ping p =
                    new System.Net.NetworkInformation.Ping();
                System.Net.NetworkInformation.PingReply reply = p.Send(host);

                //結果を取得
                if (reply.Status == System.Net.NetworkInformation.IPStatus.Success)
                {
                    result = true;
                }
                else
                {
                }
                p.Dispose();
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
                result = false;
            }
            return result;
        }


        //--------------------------------------------------------------------
        //UDP受信コールバック
        //--------------------------------------------------------------------
        public void ReceiveCallback2(IAsyncResult ar)
        {
            System.Net.Sockets.UdpClient udp =
                (System.Net.Sockets.UdpClient)ar.AsyncState;

            //非同期受信を終了する
            System.Net.IPEndPoint remoteEP = null;
            byte[] rcvBytes;
            try
            {
                rcvBytes = udp.EndReceive(ar, ref remoteEP);
            }
            catch (System.Net.Sockets.SocketException ex)
            {
                return;
            }
            catch (ObjectDisposedException ex)
            {
                return;
            }

            //データを文字列に変換する
            string rcvMsg = System.Text.Encoding.UTF8.GetString(rcvBytes);

            Invoke(new DelSetText(SetResponse), rcvMsg);

            if (IsUdpContinue == true)
            {
                //再びデータ受信を開始する
                udp.BeginReceive(ReceiveCallback2, udp);
            }
        }

        //--------------------------------------------------------------------
        //UDP受信完了
        //--------------------------------------------------------------------
        public void SetResponse(String str)
        {
            MsgOut2(str);

            string[] wstr = new string[20];

            int start, idx;

            idx = str.IndexOf("$GNRMC,");

            if (idx >= 0)
            {
                int k = 0;
                start = idx;

                //
                //RMCセンテンスを分解する
                //
                while (k < 10)
                {
                    idx = str.IndexOf(",", start);
                    if (idx > 0)
                    {
                        wstr[k] = str.Substring(start, idx - start);
                        start = idx + 1;
                        k++;
                    }
                }
            }
        }

        private void btnStart2_Click(object sender, EventArgs e)
        {
            GetUDPInfo();
            btnStart2.Enabled = false;
            btnStop2.Enabled = true;
        }

        private void btnStop2_Click(object sender, EventArgs e)
        {
            StopUDPInfo();
            btnStart2.Enabled = true;
            btnStop2.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str= "085120.0";
            string JST = "";

//            if (cols[i + 1].Length > 8)
//            {
                string UTC = str.Substring(0, 2) + ":" + str.Substring(2, 2) + ":"+str.Substring(4, 2) + "." + Int32.Parse(str.Substring(7)).ToString("D3");
                try
                {
                    DateTime utc_input = System.DateTime.ParseExact(UTC, "HH:mm:ss.fff",
                          System.Globalization.DateTimeFormatInfo.InvariantInfo,
                          System.Globalization.DateTimeStyles.NoCurrentDateDefault);
                    TimeZoneInfo jstZoneInfo = System.TimeZoneInfo.FindSystemTimeZoneById("Tokyo Standard Time");

                    DateTime jst = System.TimeZoneInfo.ConvertTimeFromUtc(utc_input, jstZoneInfo);
                    JST = jst.ToString("HH:mm:ss fff");
                }
                catch (Exception ex)
                {

                }
            //}
        }
    }
}

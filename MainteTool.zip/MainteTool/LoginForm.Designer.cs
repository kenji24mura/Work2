﻿namespace MainteTool
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.num1 = new System.Windows.Forms.Button();
            this.num2 = new System.Windows.Forms.Button();
            this.num3 = new System.Windows.Forms.Button();
            this.num6 = new System.Windows.Forms.Button();
            this.num5 = new System.Windows.Forms.Button();
            this.num4 = new System.Windows.Forms.Button();
            this.num9 = new System.Windows.Forms.Button();
            this.num8 = new System.Windows.Forms.Button();
            this.num7 = new System.Windows.Forms.Button();
            this.num0 = new System.Windows.Forms.Button();
            this.numBS = new System.Windows.Forms.Button();
            this.numCLS = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(36, 317);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 46);
            this.button1.TabIndex = 0;
            this.button1.Text = "ログイン";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.button2.Location = new System.Drawing.Point(365, 317);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 46);
            this.button2.TabIndex = 1;
            this.button2.Text = "閉じる";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.textBox2.Location = new System.Drawing.Point(28, 51);
            this.textBox2.Name = "textBox2";
            this.textBox2.PasswordChar = '*';
            this.textBox2.Size = new System.Drawing.Size(179, 24);
            this.textBox2.TabIndex = 40;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.groupBox1.Location = new System.Drawing.Point(36, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(247, 115);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "ログインパスワード";
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.Lime;
            this.label1.Location = new System.Drawing.Point(33, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(444, 26);
            this.label1.TabIndex = 42;
            // 
            // num1
            // 
            this.num1.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num1.Location = new System.Drawing.Point(318, 38);
            this.num1.Name = "num1";
            this.num1.Size = new System.Drawing.Size(49, 46);
            this.num1.TabIndex = 43;
            this.num1.Text = "1";
            this.num1.UseVisualStyleBackColor = true;
            this.num1.Click += new System.EventHandler(this.NumFunc);
            // 
            // num2
            // 
            this.num2.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num2.Location = new System.Drawing.Point(373, 38);
            this.num2.Name = "num2";
            this.num2.Size = new System.Drawing.Size(49, 46);
            this.num2.TabIndex = 44;
            this.num2.Text = "2";
            this.num2.UseVisualStyleBackColor = true;
            this.num2.Click += new System.EventHandler(this.NumFunc);
            // 
            // num3
            // 
            this.num3.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num3.Location = new System.Drawing.Point(428, 38);
            this.num3.Name = "num3";
            this.num3.Size = new System.Drawing.Size(49, 46);
            this.num3.TabIndex = 45;
            this.num3.Text = "3";
            this.num3.UseVisualStyleBackColor = true;
            this.num3.Click += new System.EventHandler(this.NumFunc);
            // 
            // num6
            // 
            this.num6.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num6.Location = new System.Drawing.Point(428, 90);
            this.num6.Name = "num6";
            this.num6.Size = new System.Drawing.Size(49, 46);
            this.num6.TabIndex = 48;
            this.num6.Text = "6";
            this.num6.UseVisualStyleBackColor = true;
            this.num6.Click += new System.EventHandler(this.NumFunc);
            // 
            // num5
            // 
            this.num5.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num5.Location = new System.Drawing.Point(373, 90);
            this.num5.Name = "num5";
            this.num5.Size = new System.Drawing.Size(49, 46);
            this.num5.TabIndex = 47;
            this.num5.Text = "5";
            this.num5.UseVisualStyleBackColor = true;
            this.num5.Click += new System.EventHandler(this.NumFunc);
            // 
            // num4
            // 
            this.num4.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num4.Location = new System.Drawing.Point(318, 90);
            this.num4.Name = "num4";
            this.num4.Size = new System.Drawing.Size(49, 46);
            this.num4.TabIndex = 46;
            this.num4.Text = "4";
            this.num4.UseVisualStyleBackColor = true;
            this.num4.Click += new System.EventHandler(this.NumFunc);
            // 
            // num9
            // 
            this.num9.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num9.Location = new System.Drawing.Point(428, 142);
            this.num9.Name = "num9";
            this.num9.Size = new System.Drawing.Size(49, 46);
            this.num9.TabIndex = 51;
            this.num9.Text = "9";
            this.num9.UseVisualStyleBackColor = true;
            this.num9.Click += new System.EventHandler(this.NumFunc);
            // 
            // num8
            // 
            this.num8.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num8.Location = new System.Drawing.Point(373, 142);
            this.num8.Name = "num8";
            this.num8.Size = new System.Drawing.Size(49, 46);
            this.num8.TabIndex = 50;
            this.num8.Text = "8";
            this.num8.UseVisualStyleBackColor = true;
            this.num8.Click += new System.EventHandler(this.NumFunc);
            // 
            // num7
            // 
            this.num7.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num7.Location = new System.Drawing.Point(318, 142);
            this.num7.Name = "num7";
            this.num7.Size = new System.Drawing.Size(49, 46);
            this.num7.TabIndex = 49;
            this.num7.Text = "7";
            this.num7.UseVisualStyleBackColor = true;
            this.num7.Click += new System.EventHandler(this.NumFunc);
            // 
            // num0
            // 
            this.num0.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.num0.Location = new System.Drawing.Point(318, 197);
            this.num0.Name = "num0";
            this.num0.Size = new System.Drawing.Size(49, 46);
            this.num0.TabIndex = 52;
            this.num0.Text = "0";
            this.num0.UseVisualStyleBackColor = true;
            this.num0.Click += new System.EventHandler(this.NumFunc);
            // 
            // numBS
            // 
            this.numBS.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.numBS.Location = new System.Drawing.Point(373, 197);
            this.numBS.Name = "numBS";
            this.numBS.Size = new System.Drawing.Size(49, 46);
            this.numBS.TabIndex = 53;
            this.numBS.Text = "BS";
            this.numBS.UseVisualStyleBackColor = true;
            this.numBS.Click += new System.EventHandler(this.NumFunc);
            // 
            // numCLS
            // 
            this.numCLS.Font = new System.Drawing.Font("Meiryo UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.numCLS.Location = new System.Drawing.Point(428, 197);
            this.numCLS.Name = "numCLS";
            this.numCLS.Size = new System.Drawing.Size(49, 46);
            this.numCLS.TabIndex = 54;
            this.numCLS.Text = "CLS";
            this.numCLS.UseVisualStyleBackColor = true;
            this.numCLS.Click += new System.EventHandler(this.NumFunc);
            // 
            // LoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(480, 375);
            this.ControlBox = false;
            this.Controls.Add(this.numCLS);
            this.Controls.Add(this.numBS);
            this.Controls.Add(this.num0);
            this.Controls.Add(this.num9);
            this.Controls.Add(this.num8);
            this.Controls.Add(this.num7);
            this.Controls.Add(this.num6);
            this.Controls.Add(this.num5);
            this.Controls.Add(this.num4);
            this.Controls.Add(this.num3);
            this.Controls.Add(this.num2);
            this.Controls.Add(this.num1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.MaximizeBox = false;
            this.Name = "LoginForm";
            this.Load += new System.EventHandler(this.LoginForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button num1;
        private System.Windows.Forms.Button num2;
        private System.Windows.Forms.Button num3;
        private System.Windows.Forms.Button num6;
        private System.Windows.Forms.Button num5;
        private System.Windows.Forms.Button num4;
        private System.Windows.Forms.Button num9;
        private System.Windows.Forms.Button num8;
        private System.Windows.Forms.Button num7;
        private System.Windows.Forms.Button num0;
        private System.Windows.Forms.Button numBS;
        private System.Windows.Forms.Button numCLS;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MainteTool
{
    public partial class Form5 : Form
    {

        public String AUTO_UPDATE_INTVAL = System.Configuration.ConfigurationManager.AppSettings["AUTO_UPDATE_INTVAL"];
        public String PORT_FILTER = System.Configuration.ConfigurationManager.AppSettings["PORT_FILTER"];
        public String IP_FILTER = System.Configuration.ConfigurationManager.AppSettings["IP_FILTER"];
        public String NaviApp = System.Configuration.ConfigurationManager.AppSettings["NAVI_APP"];
        public String NaviData = System.Configuration.ConfigurationManager.AppSettings["NAVI_DATA"];
        public String LOGPATH = System.Configuration.ConfigurationManager.AppSettings["LOGPATH"];

        private ColumnHeader[] columnData = new ColumnHeader[20];
        Log lg = new Log();

        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

            lg.LOGFNAME = LOGPATH + "MainteTool.Network.log";
            lg.loglimit = 1000000;
            lg.logmax = 10;

            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

            TopMost = true;

            textFilter.Text = PORT_FILTER;
            textFilter2.Text = IP_FILTER;
            textAutoUpdateIntval.Text = AUTO_UPDATE_INTVAL;

            listView1.FullRowSelect = true;
            listView1.GridLines = true;
            listView1.Sorting = SortOrder.Ascending;
            listView1.View = View.Details;


            // 列（コラム）ヘッダの作成
            columnData[0] = new ColumnHeader();
            columnData[1] = new ColumnHeader();
            columnData[2] = new ColumnHeader();
            columnData[3] = new ColumnHeader();
            columnData[4] = new ColumnHeader();
            columnData[5] = new ColumnHeader();

            //            プロトコル\tローカルアドレス\t外部アドレス\t状態

            columnData[0].Text = "プロトコル";
            columnData[0].Width = 100;
            columnData[1].Text = "ローカルアドレス";
            columnData[1].Width = 150;
            columnData[2].Text = "ポート";
            columnData[2].Width = 80;
            columnData[3].Text = "外部アドレス";
            columnData[3].Width = 150;
            columnData[4].Text = "ポート";
            columnData[4].Width = 80;
            columnData[5].Text = "状態";
            columnData[5].Width = 200;

            ColumnHeader[] colHeaderRegValue =
              { this.columnData[0],
                this.columnData[1],
                this.columnData[2],
                this.columnData[3],
                this.columnData[4],
                this.columnData[5] };
            listView1.Columns.AddRange(colHeaderRegValue);

            checkBox1.Checked = true;
            checkBox2.Checked = true;

            checkAutoUpdate.Checked = false;

            textAutoUpdateIntval.Text = AUTO_UPDATE_INTVAL;

            UpdateInfo();

            DateTime dt = DateTime.Now;
            labelDate.Text = dt.ToString("yyyy/MM/dd HH:mm:ss");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateInfo();
        }

        private void UpdateInfo()
        {
            DateTime dt = DateTime.Now;
            labelDate.Text = dt.ToString("yyyy/MM/dd HH:mm:ss");

            listView1.Items.Clear();

            Boolean IsDisp1 = false;
            Boolean IsDisp2 = false;
            Boolean IsDisp3 = false;
            Boolean IsDisp4 = false;

            var ip = System.Net.NetworkInformation.IPGlobalProperties.GetIPGlobalProperties();

            if (checkLogOut.Checked == true)
            {
                string msg = "接続情報 "+textLogComment.Text;
                lg.LogOut(msg);

                msg = "◆◆プロトコル,ローカルアドレス,外部アドレス,状態◆◆";
                lg.LogOut(msg);
            }

            foreach (var tcp in ip.GetActiveTcpConnections())
            {

                string state = tcp.State.ToString();

                int port1;
                int port2;
                string IP1;
                string IP2;

                string[] item1 = {"TCP",
                    tcp.LocalEndPoint.Address.ToString(),
                    tcp.LocalEndPoint.Port.ToString()   ,
                    tcp.RemoteEndPoint.Address.ToString(),
                    tcp.RemoteEndPoint.Port.ToString(),
                    tcp.State.ToString()};


                port1 = tcp.LocalEndPoint.Port;
                port2 = tcp.RemoteEndPoint.Port;
                IP1 = tcp.LocalEndPoint.Address.ToString();
                IP2 = tcp.RemoteEndPoint.Address.ToString();

                if (checkBox1.Checked == true)
                {
                    if (state.IndexOf("Established") == 0)
                    {
                        IsDisp1 = true;
                    }else
                    {
                        IsDisp1 = false;
                    }
                }else
                {
                    IsDisp1 = true;
                }

                if (checkBox2.Checked == true)
                {
                    if (tcp.LocalEndPoint.Address.ToString().IndexOf("::") == 0)
                    {
                        IsDisp2 = false;
                    }
                    else
                    {
                        IsDisp2 = true;
                    }
                }
                else
                {
                    IsDisp2 = true;
                }

                if (checkFilter.Checked == true && textFilter.Text.Length > 0)
                {
                    IsDisp3 = false;
                    try
                    {
                        string strFilter = textFilter.Text;

                        string[] col = strFilter.Split(';');

                        for (int i = 0; i < col.Length; i++)
                        {
                            string portval;
                            portval = col[i];
                            if (port1 == Int32.Parse(portval) || port2 == Int32.Parse(portval))
                            {
                                IsDisp3 = true;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }


                }else
                {
                    IsDisp3 = true;
                }

                if (checkFilter2.Checked == true && textFilter2.Text.Length > 0)
                {
                    IsDisp4 = false;
                    try
                    {
                        string strFilter2 = textFilter2.Text;

                        string[] col = strFilter2.Split(';');

                        for (int i = 0; i < col.Length; i++)
                        {
                            string portval;
                            portval = col[i];
                            if (IP1.IndexOf(portval) == 0 || IP2.IndexOf(portval) == 0)
                            {
                                IsDisp4 = true;
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
                else
                {
                    IsDisp4 = true;
                }

                if (IsDisp1 == true && IsDisp2 == true && IsDisp3== true && IsDisp4 == true)
                {
                    listView1.Items.Add(new ListViewItem(item1));

                    if (checkLogOut.Checked == true)
                    {
                        string msg="";
                        for(int i = 0; i < item1.Length; i++)
                        {
                            msg += item1[i];
                            msg += ",";
                        }
                        lg.LogOut(msg);
                    }

                }

            }

            //NetworkInterface[] nicList = NetworkInterface.GetAllNetworkInterfaces();

            //foreach (NetworkInterface nic in nicList)
            //{
            //    IPInterfaceProperties ipInfo = nic.GetIPProperties();

            //    string IPAddress1 = "";
            //    string IPAddress2 = "";

            //    if (ipInfo.UnicastAddresses.Count > 0)
            //    {
            //        IPAddress1 = ipInfo.UnicastAddresses[0].Address.ToString();
            //        if (ipInfo.UnicastAddresses.Count > 1)
            //        {
            //            IPAddress2 = ipInfo.UnicastAddresses[1].Address.ToString();
            //        }
            //        else
            //        {
            //            IPAddress2 = "none";
            //        }
            //    }
            //    else
            //    {
            //        IPAddress1 = "none";
            //        IPAddress2 = "none";
            //    }

            //    string[] item1 = {nic.Name,
            //        nic.Description,
            //        nic.NetworkInterfaceType.ToString(),
            //        (nic.Speed / 1000000).ToString()+"Mbs",
            //        nic.GetPhysicalAddress().ToString() ,
            //        nic.GetIPv4Statistics().BytesSent.ToString(),
            //        nic.GetIPv4Statistics().BytesReceived.ToString(),
            //        IPAddress1,
            //        IPAddress2};

            //    listView1.Items.Add(new ListViewItem(item1));


            //}


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            timerAutoUpdate.Enabled = false;
            Close();

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            UpdateInfo();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            UpdateInfo();
        }

        private void timerAutoUpdate_Tick(object sender, EventArgs e)
        {
            timerAutoUpdate.Enabled = false;
            UpdateInfo();

            if(checkAutoUpdate.Checked == true)
            {
                try
                {
                    timerAutoUpdate.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timerAutoUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timerAutoUpdate.Enabled = false;
                }
            }
        }

        private void checkAutoUpdate_CheckedChanged(object sender, EventArgs e)
        {
            if (checkAutoUpdate.Checked == true)
            {
                try
                {
                    timerAutoUpdate.Interval = Int32.Parse(textAutoUpdateIntval.Text) * 1000;
                    timerAutoUpdate.Enabled = true;
                }
                catch (Exception ex)
                {
                    checkAutoUpdate.Checked = false;
                    timerAutoUpdate.Enabled = false;
                }
            }
            else
            {
                timerAutoUpdate.Enabled = false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GDITool
{
    public partial class Form1 : Form
    {
        static string DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];
        static string TIMER_INTVAL = System.Configuration.ConfigurationManager.AppSettings["TIMER_INTVAL"];
        static string PROC_NAME = System.Configuration.ConfigurationManager.AppSettings["PROC_NAME"];

        [DllImport("user32.dll")]
        private static extern uint GetGuiResources(IntPtr hProcess, uint uiFlags);

        // uiFlags: 0 = GDI オブジェクト数, 1 = USER オブジェクト数
        private const uint GR_GDIOBJECTS = 0;
        private const uint GR_USEROBJECTS = 1;


        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            timer1.Interval = Int32.Parse(TIMER_INTVAL);
            textProcess.Text = PROC_NAME;

            btnStop.Enabled = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            timer1.Enabled = true;
            btnStart.Enabled = false;
            btnStop.Enabled = true;
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            btnStart.Enabled = true;
            btnStop.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            CheckGDI();
        }

        private void CheckGDI()
        {
            try
            {
                System.Diagnostics.Process[] ps =
        System.Diagnostics.Process.GetProcessesByName(textProcess.Text);

                if (ps == null || ps.Length == 0)
                {
                    MsgOut("該当プロセス無");
                }
                else
                {
                    Process proc = ps[0];

                    uint gdiCount = GetGuiResources(proc.Handle, GR_GDIOBJECTS);
                    uint userCount = GetGuiResources(proc.Handle, GR_USEROBJECTS);

                    string msg = "【"+ proc.ProcessName+"】" +" GDI:" +gdiCount.ToString() + "," + "USER:"+userCount.ToString();
                    MsgOut(msg);
                }
            }
            catch (Exception ex)
            {
                MsgOut("エラー: " + ex.Message);
            }

        }
        private void MsgOut(string msg)
        {
            DateTime dt= DateTime.Now;
            listBox1.Items.Add(dt+","+msg);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UDPCtrl
{
    public partial class Form1 : Form
    {

        //string remoteHost; // 送信先のIPアドレス
        //int remotePort; // 送信先のポート番号
        //int localPort; // 送信先のポート番号

        UdpClient udpClient;
        IPEndPoint remoteEndPoint;

        delegate void SetText(string text);


        UdpClient udp;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "127.0.0.1";
            textBox2.Text = "12000";
            textBox3.Text = "test";
            textBox4.Text = "12001";
        }

        private void MsgOut(string msg)
        {
            DateTime dt = DateTime.Now;
            listBox1.Items.Add(dt.ToString() + "," + msg);
        }
        private void button3_Click(object sender, EventArgs e)
        {
            string remoteHost = textBox1.Text;
            int remotePort = Int32.Parse(textBox2.Text);
            string message = textBox3.Text;

            SendUDP(remoteHost, remotePort,message);
        }

        private void SendUDP(string remoteHost, int remotePort,string message)
        {


            MsgOut("UDP 接続");
            udp = new UdpClient();

            MsgOut("UDP 送信["+message+"]");
            byte[] data = Encoding.UTF8.GetBytes(message);
            udp.Send(data, data.Length, remoteHost, remotePort);

            MsgOut("UDP 切断");
            udp.Close();
            udp.Dispose();

        }
        private void StartReceiver()
        {
            while (true)
            {
                byte[] receivedData = udpClient.Receive(ref remoteEndPoint);
                string receivedMessage = Encoding.UTF8.GetString(receivedData);

                string text = "UDP 受信[ " + receivedMessage + "][" + remoteEndPoint.Address + "]";
                Invoke(new SetText(MsgOut), text);


                if (receivedMessage.IndexOf("への応答") < 0)
                {
                    string remoteHost = remoteEndPoint.Address.ToString();
                    int remotePort = Int32.Parse(textBox2.Text);
                    string message = receivedMessage + "への応答";

                    SendUDP(remoteHost, remotePort, message);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int localPort = Int32.Parse(textBox4.Text);

            MsgOut("UDP 開始");
            udpClient = new UdpClient(localPort);
            remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);

            Task.Run(() => StartReceiver()); // 非同期で受信を開始

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MsgOut("UDP 終了");
            udpClient.Close();
            udpClient.Dispose();

        }
    }
}

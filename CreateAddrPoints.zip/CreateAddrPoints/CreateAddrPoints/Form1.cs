﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace CreateAddrPoints
{
    public partial class Form1 : Form
    {



        string CONN_STRING = "User ID=WEBGIS; Password=WEBGIS; Data Source=172.20.10.10:1521/fire.osaka";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DeleteDB();
                        GetDB();
            //GetDB_test();
        }

        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }

        public void GetDB()
        {
            int cnt = 0;
            string sqlStr = "select * from TBDSC360A";


            int kind;//種別
            int target;    //目標物
            String name;    //名称
            String kana;//かな
            string kana1;                    //かな１
                                             //電話番号
                                             //ELコード
            int prif;                                 //都道府県
            int city;                                 //市町村
            int town1;                                 //大字
            int town2;                                 //丁目
                                                       //仮小字街区
            String number;                                 //街区名称
                                                           //連番
            int maptype = 11;                                               //表示地図種別
            int lon = 0;                                               //地図座標Ｘ
            int lat = 0;                                               //地図座標Ｙ
            int zx = -39334100;                                               //基準座標Ｘ
            int zy = -155628200;                                               //基準座標Ｙ
                                                                            //変換レベル
                                                                            //更新区分
                                                                            //配信フラグ
                                                                            //更新日付
                                                                            //登録者
                                                                            //更新者
                                                                            //タウン種別１
                                                                            //タウン種別２
                                                                            //タウン種別３
            String addrName;                                                               //住所名称
                                                                                           //フィールド1
                                                                                           //備考
                                                                                           //代表区分
            int pointflg;                                                               //地点決定可否
            int infoflg;                                                               //詳細情報可否
                                                                                       //消防分類
                                                                                       //消防コード
            int symdispflg;                                               //シンボル表示有無

            try
            {
                string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= ";
                string MDB = "c:\\D_DRV\\FIIM_TARGET.mdb";

                OleDbConnection dbcon = new OleDbConnection(CON_STR + MDB);
                dbcon.Open();



                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {


                                String CITY_CD = reader["CITY_CD"].ToString();
                                String TOWN_CD = reader["TOWN_CD"].ToString();
                                String TYOME_CD = reader["TYOME_CD"].ToString();
                                String BANTI = reader["BANTI"].ToString();
                                String GOU = reader["GOU"].ToString();

                                String ZAHYO_X = reader["ZAHYO_X"].ToString();
                                String ZAHYO_Y = reader["ZAHYO_Y"].ToString();

                                cnt++;

                                kind = 1;
                                target = cnt;
                                name = "住所";
                                kana = "ｼﾞｭｳｼｮ";
                                prif = 72;
                                city = Int32.Parse(CITY_CD);
                                town1 = Int32.Parse(TOWN_CD);
                                town2 = Int32.Parse(TYOME_CD);
                                number = BANTI+"-"+GOU;

                                lon = 0;
                                lat = 0;

                                Double lx = Double.Parse(ZAHYO_X);
                                Double ly = Double.Parse(ZAHYO_Y);


                                int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;

                                MapCom.Convert cs = new MapCom.Convert();
                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);

                                lon = (int)(m_keido * 1000);
                                lat = (int)(m_ido * 1000);

                                zx = (int)(lx / 1000.0);
                                zy = (int)(ly / 1000.0);


                                addrName = "大阪府";
                                pointflg = 1;
                                infoflg = 1;
                                symdispflg = 1;

                                string updateQuery = "INSERT INTO 目標物テーブル ";
                                updateQuery += "(";
                                updateQuery += "種別";
                                updateQuery += ",";
                                updateQuery += "目標物";
                                updateQuery += ",";
                                updateQuery += "名称";
                                updateQuery += ",";
                                updateQuery += "かな";
                                updateQuery += ",";
                                updateQuery += "都道府県";
                                updateQuery += ",";
                                updateQuery += "市町村";
                                updateQuery += ",";
                                updateQuery += "大字";
                                updateQuery += ",";
                                updateQuery += "丁目";
                                updateQuery += ",";
                                updateQuery += "街区名称";
                                updateQuery += ",";
                                updateQuery += "表示地図種別";
                                updateQuery += ",";
                                updateQuery += "地図座標Ｘ";
                                updateQuery += ",";
                                updateQuery += "地図座標Ｙ";
                                updateQuery += ",";
                                updateQuery += "基準座標Ｘ";
                                updateQuery += ",";
                                updateQuery += "基準座標Ｙ";
                                updateQuery += ",";
                                updateQuery += "住所名称";
                                updateQuery += ",";
                                updateQuery += "地点決定可否";
                                updateQuery += ",";
                                updateQuery += "詳細情報可否";
                                updateQuery += ",";
                                updateQuery += "シンボル表示有無";

                                updateQuery += ") VALUES (";

                                updateQuery += kind.ToString();
                                updateQuery += ",";
                                updateQuery += target.ToString();
                                updateQuery += ",";
                                updateQuery += "'";
                                updateQuery += name;
                                updateQuery += "'";
                                updateQuery += ",";
                                updateQuery += "'";
                                updateQuery += kana;
                                updateQuery += "'";
                                updateQuery += ",";
                                updateQuery += prif.ToString();
                                updateQuery += ",";
                                updateQuery += city.ToString();
                                updateQuery += ",";
                                updateQuery += town1.ToString();
                                updateQuery += ",";
                                updateQuery += town2.ToString();
                                updateQuery += ",";
                                updateQuery += "'";
                                updateQuery += number;
                                updateQuery += "'";
                                updateQuery += ",";
                                updateQuery += maptype.ToString();
                                updateQuery += ",";
                                updateQuery += lon.ToString();
                                updateQuery += ",";
                                updateQuery += lat.ToString();
                                updateQuery += ",";
                                updateQuery += zx.ToString();
                                updateQuery += ",";
                                updateQuery += zy.ToString();
                                updateQuery += ",";
                                updateQuery += "'";
                                updateQuery += addrName;
                                updateQuery += "'";
                                updateQuery += ",";
                                updateQuery += pointflg.ToString();
                                updateQuery += ",";
                                updateQuery += infoflg.ToString();
                                updateQuery += ",";
                                updateQuery += symdispflg.ToString();

                                updateQuery += ")";



                                /*

                                string updateQuery = "INSERT INTO 目標物テーブル ";
                                updateQuery += "種別";
                                updateQuery += ",";
                                updateQuery += "目標物";

                                updateQuery += ") VALUES (";

                                updateQuery += "1";
                                updateQuery += ",";
                                updateQuery += "100";


                                updateQuery += ")";
                                */

                                /*種別,目標物,名称,かな,地図座標Ｘ,地図座標Ｙ
                                 * 
                                 */

                                UpdateDB(dbcon, updateQuery);


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();
                    //コネクションを破棄する
                    conn.Dispose();
                }

                dbcon.Close();

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }
        public void DeleteDB()
        {
            try
            {
                string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= ";
                string MDB = "c:\\D_DRV\\FIIM_TARGET.mdb";

                OleDbConnection dbcon = new OleDbConnection(CON_STR + MDB);
                dbcon.Open();

                string updateQuery = "DELETE FROM 目標物テーブル WHERE 種別=1";

                MsgOut(updateQuery);
                using (OleDbCommand command = new OleDbCommand(updateQuery, dbcon))
                {
                    int rowsAffected = command.ExecuteNonQuery();
                }

                dbcon.Close();

            }
            catch (Exception ex)
            {
                MsgOut(ex.ToString());
            }
        }

        public void GetDB_test()
        {
            int ret = 0;
            //string sqlStr = "select * from TBDSC360A";

            try
            {
                string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= ";
                string MDB = "c:\\D_DRV\\FIIM_TARGET.mdb";

                OleDbConnection dbcon = new OleDbConnection(CON_STR + MDB);
                dbcon.Open();

                int kind;//種別
                int target;    //目標物
                String name;    //名称
                String kana;//かな
                string kana1;                    //かな１
                                                 //電話番号
                                                 //ELコード
                int prif;                                 //都道府県
                int city;                                 //市町村
                int town1;                                 //大字
                int town2;                                 //丁目
                                                           //仮小字街区
                String number;                                 //街区名称
                                                               //連番
                int maptype=11;                                               //表示地図種別
                int lon=0;                                               //地図座標Ｘ
                int lat=0;                                               //地図座標Ｙ
                int zx= -38947;                                               //基準座標Ｘ
                int zy= -128780;                                               //基準座標Ｙ
                                                                               //変換レベル
                                                                               //更新区分
                                                                               //配信フラグ
                                                                               //更新日付
                                                                               //登録者
                                                                               //更新者
                                                                               //タウン種別１
                                                                               //タウン種別２
                                                                               //タウン種別３
                String addrName;                                                               //住所名称
                                                                                               //フィールド1
                                                                                               //備考
                                                                                               //代表区分
                int pointflg;                                                               //地点決定可否
                int infoflg;                                                               //詳細情報可否
                                                                               //消防分類
                                                                               //消防コード
                int symdispflg;                                               //シンボル表示有無

                kind = 1;
                target = 2;
                name = "住所";
                kana = "ｼﾞｭｳｼｮ";
                prif = 72;
                city = 1;
                town1 = 11;
                town2 = 12;
                number = "11-11";
                addrName = "大阪府";
                pointflg = 1;
                infoflg = 1;
                symdispflg = 1;

                string updateQuery = "INSERT INTO 目標物テーブル ";
                updateQuery += "(";
                updateQuery += "種別";
                updateQuery += ",";
                updateQuery += "目標物";
                updateQuery += ",";
                updateQuery += "名称";
                updateQuery += ",";
                updateQuery += "かな";
                updateQuery += ",";
                updateQuery += "都道府県";
                updateQuery += ",";
                updateQuery += "市町村";
                updateQuery += ",";
                updateQuery += "大字";
                updateQuery += ",";
                updateQuery += "丁目";
                updateQuery += ",";
                updateQuery += "街区名称";
                updateQuery += ",";
                updateQuery += "表示地図種別";
                updateQuery += ",";
                updateQuery += "地図座標Ｘ";
                updateQuery += ",";
                updateQuery += "地図座標Ｙ";
                updateQuery += ",";
                updateQuery += "基準座標Ｘ";
                updateQuery += ",";
                updateQuery += "基準座標Ｙ";
                updateQuery += ",";
                updateQuery += "住所名称";
                updateQuery += ",";
                updateQuery += "地点決定可否";
                updateQuery += ",";
                updateQuery += "詳細情報可否";
                updateQuery += ",";
                updateQuery += "シンボル表示有無";

                updateQuery += ") VALUES (";
                
                updateQuery += kind.ToString();
                updateQuery += ",";
                updateQuery += target.ToString();
                updateQuery += ",";
                updateQuery += "'";
                updateQuery += name;
                updateQuery += "'";
                updateQuery += ",";
                updateQuery += "'";
                updateQuery += kana;
                updateQuery += "'";
                updateQuery += ",";
                updateQuery += prif.ToString();
                updateQuery += ",";
                updateQuery += city.ToString();
                updateQuery += ",";
                updateQuery += town1.ToString();
                updateQuery += ",";
                updateQuery += town2.ToString();
                updateQuery += ",";
                updateQuery += "'";
                updateQuery += number;
                updateQuery += "'";
                updateQuery += ",";
                updateQuery += maptype.ToString();
                updateQuery += ",";
                updateQuery += lon.ToString();
                updateQuery += ",";
                updateQuery += lat.ToString();
                updateQuery += ",";
                updateQuery += zx.ToString();
                updateQuery += ",";
                updateQuery += zy.ToString();
                updateQuery += ",";
                updateQuery += "'";
                updateQuery += addrName;
                updateQuery += "'";
                updateQuery += ",";
                updateQuery += pointflg.ToString();
                updateQuery += ",";
                updateQuery += infoflg.ToString();
                updateQuery += ",";
                updateQuery += symdispflg.ToString();

                updateQuery += ")";

                UpdateDB(dbcon, updateQuery);



                dbcon.Close();

            }
            catch (Exception ex)
            {
                MsgOut(ex.ToString());
            }
        }


        private void UpdateDB(OleDbConnection dbcon, string updateQuery)
        {
            try
            {
                MsgOut(updateQuery);
                // コマンドを実行
                using (OleDbCommand command = new OleDbCommand(updateQuery, dbcon))
                {
                    int rowsAffected = command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MsgOut(ex.ToString());
            }
        }

    }

}

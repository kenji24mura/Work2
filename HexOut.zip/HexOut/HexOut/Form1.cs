﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HexOut
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textSelectFile.Text = "";
        }

        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }
        private void MsgOut2(string msg)
        {
            listBox2.Items.Add(msg);
        }

        private void HexOutPut(string filename)
        {
            try
            {

                FileInfo file = new FileInfo(filename);
                long size = file.Length;

                textFileSize.Text = size.ToString();

                FileStream fs = new FileStream(filename, FileMode.Open);
                BinaryReader br = new BinaryReader(fs);

                int file_length = (int)fs.Length;
                int read_len = 0;
                bool IsEOF = false;
                string line = "";
                int col_cnt = 0;
                int line_cnt = 0;

                string head = "          ";
                for (int i = 0; i < 16; i++)
                {
                    head += i.ToString("X2");
                    head += " ";

                }
                MsgOut(head);
                head = "---------------------------------------------------------";
                MsgOut(head);

                while (IsEOF == false)
                {
                    if (read_len < file_length)
                    {
                        byte b = br.ReadByte();

                        read_len++;
                        if (col_cnt < 15)
                        {

                            if (col_cnt == 0)
                            {
                                line += (line_cnt * 16).ToString("X8");
                                line += "  ";
                            }


                            line += b.ToString("X2");
                            line += " ";
                            col_cnt++;
                        }
                        else
                        {
                            line += b.ToString("X2");
                            MsgOut(line);
                            line_cnt++;
                            line = "";
                            col_cnt = 0;

                        }
                    }
                    else
                    {
                        IsEOF = true;
                    }

                }
                if (line.Length > 0)
                {
                    MsgOut(line);
                }

                fs.Close();
                br.Close();



            }
            catch (Exception ex)
            {
                MsgOut2(ex.Message);
            }

        }

        private void btnHexOut_Click(object sender, EventArgs e)
        {
            string filename = textSelectFile.Text;
            HexOutPut(filename);

        }

        private void btnBrowser_Click(object sender, EventArgs e)
        {
            // OpenFileDialogオブジェクトの生成
            OpenFileDialog od = new OpenFileDialog();
            od.Title = "ファイルを開く";  //ダイアログ名
            od.InitialDirectory = @"C:\";  //初期フォルダ
            od.FileName = @"sample.txt";  //初期選択ファイル名
            od.Filter = "すべてのファイル(*.*)|*.*";  //選択できる拡張子
            od.FilterIndex = 1;  //初期の拡張子

            // ダイアログを表示する
            DialogResult result = od.ShowDialog();


            // 選択後の判定
            if (result == DialogResult.OK)
            {
                //「開く」ボタンクリック時の処理
                textSelectFile.Text = od.FileName;  //これで選択したファイルパスを取得できる
            }
            else if (result == DialogResult.Cancel)
            {
                //「キャンセル」ボタンクリック時の処理
            }
        }



        private void SaveFile(string fileName)
        {
            try
            {
                DateTime dt = DateTime.Now;
                using (StreamWriter sw = new StreamWriter(fileName, false, Encoding.UTF8))
                {
                    for (int i = 0; i < listBox1.Items.Count; i++)
                    {
                        sw.WriteLine(listBox1.Items[i].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                MsgOut2(ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void 開くOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // OpenFileDialogオブジェクトの生成
            OpenFileDialog od = new OpenFileDialog();
            od.Title = "ファイルを開く";  //ダイアログ名


            if (textSelectFile.Text.Length > 0)
            {
                od.InitialDirectory = Path.GetDirectoryName(textSelectFile.Text);  //初期フォルダ
            }

            od.FileName = @"sample.txt";  //初期選択ファイル名
            od.Filter = "すべてのファイル(*.*)|*.*";  //選択できる拡張子
            od.FilterIndex = 1;  //初期の拡張子

            // ダイアログを表示する
            DialogResult result = od.ShowDialog();


            // 選択後の判定
            if (result == DialogResult.OK)
            {
                //「開く」ボタンクリック時の処理
                textSelectFile.Text = od.FileName;  //これで選択したファイルパスを取得できる

                listBox1.Items.Clear();

                HexOutPut(textSelectFile.Text);
            }
            else if (result == DialogResult.Cancel)
            {
                //「キャンセル」ボタンクリック時の処理
            }
        }

        private void 保存SToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();

            sfd.FileName = Path.GetFileNameWithoutExtension(textSelectFile.Text) + ".txt";

            if (textSelectFile.Text.Length > 0)
            {
                sfd.InitialDirectory = Path.GetDirectoryName(textSelectFile.Text);
            }

            sfd.Filter = "すべてのファイル(*.*)|*.*";
            sfd.FilterIndex = 2;
            sfd.Title = "保存先のファイルを選択してください";
            sfd.RestoreDirectory = true;
            sfd.OverwritePrompt = true;
            sfd.CheckPathExists = true;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                SaveFile(sfd.FileName);
            }

        }

        private void btnFirstLine_Click(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = 0;
        }

        private void btnLastLine_Click(object sender, EventArgs e)
        {
            listBox1.SelectedIndex = listBox1.Items.Count - 1;
        }

        /*

        private void 印刷PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += new PrintPageEventHandler(pd_PrintPage);

            PrintDialog pdlg = new PrintDialog();
            pdlg.Document = pd;
            if (pdlg.ShowDialog() == DialogResult.OK)
            {
                pd.Print();
            }
        }
        private void pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            Font font = new Font("ＭＳ ゴシック", 10.5f);
            Brush brush = new SolidBrush(Color.Black);

            int px = 0;
            int py = 0;

            int linecnt = 0;
            int pagemax = listBox1.Items.Count / 100;
            int pagecnt = 0;

            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                string line = listBox1.Items[i].ToString();

                px = 10;
                py += 11;
                e.Graphics.DrawString(line, font, brush, new PointF(px, py));

                linecnt++;
                if (linecnt > 100)
                {
                    pagecnt++;
                    if (pagecnt > pagemax)
                    {
                        e.HasMorePages=false;
                    }
                    else
                    {
                        e.HasMorePages = true;
                    }

                }
            }
        }
        */
    }
}
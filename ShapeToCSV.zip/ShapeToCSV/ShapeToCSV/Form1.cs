﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;

namespace ShapeToCSV
{
    public partial class Form1 : Form
    {

        List<string> shp = new List<string>();
        List<string> dbf = new List<string>();
        List<LAY_INFO> lay_info = new List<LAY_INFO>();

        int limitCnt = 0;
        int DispLimitCnt = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textLayDefFile.Text = @"D:\\大阪データ移行プロジェクト\\data\\csv\maplay.csv";
            textShapeFile.Text = @"D:\大阪データ移行プロジェクト\shape\data\shapefiles\地図背景用作図_ポイント.shp";
            textDBFFile.Text = @"D:\大阪データ移行プロジェクト\shape\data\shapefiles\地図背景用作図_ポイント.dbf";
            textCSVFile.Text = @"D:\大阪データ移行プロジェクト\shape\data\shapefiles\地図背景用作図_ポイント.csv";
            checkOutputLimit.Checked = true;

            textLimitCount.Text = "100";
            textDispLimit.Text = "1000";

        }
        private void MsgOut(string msg)
        {
            DateTime dateTime = DateTime.Now;
            listBox1.Items.Add(dateTime+","+msg);
        }
        public int ConvertInt(uint val)
        {
            int result = 0;

            result = (int)(
    ((val & 0xff000000) >> 24) |
    ((val & 0x00ff0000) >> 8) |
    ((val & 0x0000ff00) << 8) |
    ((val & 0x000000ff) << 24)
    );

            return result;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            shp.Clear();
            dbf.Clear();
            lay_info.Clear();

            listBox1.Items.Clear();
            listBox2.Items.Clear();

            string lay_fname = textLayDefFile.Text;
            string shp_fname = textShapeFile.Text;
            string dbf_fname = textDBFFile.Text;
            string csv_fname = textCSVFile.Text;

            limitCnt = Int32.Parse(textLimitCount.Text);

            ConvertShape(lay_fname, shp_fname, dbf_fname, csv_fname);

        }


        private void ConvertShape(string lay_fname,string shp_fname,string dbf_fname,string csv_fname)
        {
            MsgOut("変換処理開始");
            load_info(lay_fname);

            ParseShp(shp_fname);
            ParseDbf(dbf_fname);

            try
            {
                //UTF8 BOM付き
                Encoding utf8_encoding = Encoding.GetEncoding("utf-8");
                StreamWriter sw = new StreamWriter(csv_fname, false, utf8_encoding);


                string title = "izahyo_x,izahyo_y,mlStyle,L_NO,L_TYPE,SYMBOL,TEXT,TEXT_SIZE,DATA_ANGLE,TY_FLG,フォント,文字色(ラベル文字色RGBA-ラベル背景色RGBA),作成者,作成日時,編集者,編集日時";
                //MsgOut(title);

                sw.WriteLine(title);

                for (int i = 0; i < shp.Count; i++)
                {
                    //izahyo_x
                    //izahyo_y
                    //mlStyle
                    //L_NO
                    //L_TYPE
                    //SYMBOL
                    //TEXT
                    //TEXT_SIZE
                    //DATA_ANGLE
                    //TY_FLG
                    //フォント
                    //文字色(ラベル文字色RGBA - ラベル背景色RGBA)
                    //作成者
                    //作成日時
                    //編集者
                    //編集日時

                    //MsgOut((i+1).ToString()+":"+shp[i] + "," + dbf[i]);
                    sw.WriteLine(shp[i] + "," + dbf[i]);

                    if (checkOutputLimit.Checked == false)
                    {
                        if(i%100 == 0)
                        {
                            MsgOut((i + 1).ToString() + "件出力");
                        }

                    }
                    else
                    {
                        MsgOut((i + 1).ToString() + "件出力");
                    }
                }

                sw.Close();
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }
            MsgOut("変換処理終了");

        }
        public void ParseShp(string fname)
        {
            double Xmin = 0;
            double Ymin = 0;
            double Xmax = 0;
            double Ymax = 0;
            double Zmin = 0;
            double Zmax = 0;
            double Mmin = 0;
            double Mmax = 0;


            //ファイルヘッダ処理
            FileStream fs = new FileStream(fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            int fcode = br.ReadInt32();
            fcode = ConvertInt((uint)fcode);

            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用

            int flen = br.ReadInt32();
            flen = ConvertInt((uint)flen);

            int version = br.ReadInt32();

            int shapetype = br.ReadInt32();

            Xmin = br.ReadDouble();
            Ymin = br.ReadDouble();
            Xmax = br.ReadDouble();
            Ymax = br.ReadDouble();
            Zmin = br.ReadDouble();
            Zmax = br.ReadDouble();
            Mmin = br.ReadDouble();
            Mmax = br.ReadDouble();

            bool IsEOF = false;


            int line_cnt = 0;
            int poly_cnt = 0;
            int symbol_cnt = 0;

            int cnt = 0;

            //レコードヘッダ
            while (!IsEOF)
            {
                try
                {
                    long cur = fs.Seek(0, SeekOrigin.Current);
                    //MsgOut("カレントポイント:" + cur.ToString());

                    if (cur >= flen * 2)
                    {
                        IsEOF = true;
                    }
                    else
                    {

                        int recnum = br.ReadInt32();
                        recnum = ConvertInt((uint)recnum);

                        int reclen = br.ReadInt32();
                        reclen = ConvertInt((uint)reclen);

                        byte[] buf = new byte[reclen * 2];
                        buf = br.ReadBytes(reclen * 2);
                        //                        byte[] buf = new byte[reclen];
                        //                        buf = br.ReadBytes(reclen);

                        int offset = 0;
                        int type = BitConverter.ToInt32(buf, offset);
                        offset += 4;

                        double[] Box = new double[4];

                        int NumParts = 0;
                        int NumPoint = 0;

                        double dx;
                        double dy;

                        switch (type)
                        {
                            case 0:// Null Shape
                                break;
                            case 1: //Point

                                Point ps = new Point();
                                dx = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                dy = BitConverter.ToDouble(buf, offset);
                                offset += 8;


                                //MsgOut(recnum + ","+dx+ "," + dy);

                                shp.Add(dx + "," + dy);

                                break;
                            case 3: //PolyLine


                                Box[0] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[1] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[2] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[3] = BitConverter.ToDouble(buf, offset);
                                offset += 8;

                                NumParts = BitConverter.ToInt32(buf, offset);
                                offset += 4;

                                int NumPoints = BitConverter.ToInt32(buf, offset);
                                offset += 4;

                                for (int i = 0; i < NumParts; i++)
                                {
                                    int Parts = BitConverter.ToInt32(buf, offset);
                                    offset += 4;
                                }

                                Point[] p = new Point[NumPoints];
                                for (int i = 0; i < NumPoints; i++)
                                {
                                    dx = BitConverter.ToDouble(buf, offset);
                                    offset += 8;
                                    dy = BitConverter.ToDouble(buf, offset);
                                    offset += 8;

                                }

                                break;
                            case 5: //Polygon

                                /*
                                if (checkPolygon.Checked == false) break;
                                */
                                Box[0] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[1] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[2] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[3] = BitConverter.ToDouble(buf, offset);
                                offset += 8;

                                NumParts = BitConverter.ToInt32(buf, offset);
                                offset += 4;


                                NumPoints = BitConverter.ToInt32(buf, offset);
                                offset += 4;

                                for (int i = 0; i < NumParts; i++)
                                {
                                    int Parts = BitConverter.ToInt32(buf, offset);
                                    offset += 4;
                                }

                                Point[] pl = new Point[NumPoints];
                                for (int i = 0; i < NumPoints; i++)
                                {
                                    dx = BitConverter.ToDouble(buf, offset);
                                    offset += 8;
                                    dy = BitConverter.ToDouble(buf, offset);
                                    offset += 8;

                                }

                                break;
                            case 8: //MultiPoint
                                break;
                            case 11: //PointZ
                                break;
                            case 13: //PolyLineZ
                                break;
                            case 15: //PolygonZ
                                break;
                            case 18: //MultiPointZ
                                break;
                            case 21: //PointM
                                break;
                            case 23: //PolyLineM
                                break;
                            case 25: //PolygonM
                                break;
                            case 28: //MultiPointM
                                break;
                            case 31: //MultiPatch
                                break;
                            default:
                                break;
                        }
                    }

                }
                catch (Exception ex)
                {
                    IsEOF = true;
                }
                cnt++;

                if (checkOutputLimit.Checked == true)
                {
                    if (cnt >= limitCnt) break;
                }


            }

            fs.Close();
            br.Close();

        }
        public void ParseShx(string fname)
        {
            double Xmin = 0;
            double Ymin = 0;
            double Xmax = 0;
            double Ymax = 0;
            double Zmin = 0;
            double Zmax = 0;
            double Mmin = 0;
            double Mmax = 0;


            //ファイルヘッダ処理
            FileStream fs = new FileStream(fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            int fcode = br.ReadInt32();
            fcode = ConvertInt((uint)fcode);

            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用

            int flen = br.ReadInt32();
            flen = ConvertInt((uint)flen);// flenはワード(2byte)単位

            int version = br.ReadInt32();

            int shapetype = br.ReadInt32();

            Xmin = br.ReadDouble();
            Ymin = br.ReadDouble();
            Xmax = br.ReadDouble();
            Ymax = br.ReadDouble();
            Zmin = br.ReadDouble();
            Zmax = br.ReadDouble();
            Mmin = br.ReadDouble();
            Mmax = br.ReadDouble();

            //------- レコード部 ----------------
            bool IsEOF = false;
            int cnt = 0;

            while (!IsEOF)
            {
                try
                {
                    long cur = fs.Seek(0, SeekOrigin.Current);

                    if (cur >= flen * 2)
                    {
                        IsEOF = true;
                    }
                    else
                    {
                        cnt++;

                        int offset = br.ReadInt32();
                        offset = ConvertInt((uint)offset);

                        int cont_len = br.ReadInt32();
                        cont_len = ConvertInt((uint)cont_len);

                    }
                }
                catch (Exception ex)
                {
                    IsEOF = true;
                }

            }


            fs.Close();
            br.Close();
        }
        public void ParseDbf(string fname)
        {
            string str_encoding = "shift-jis";

            FileStream fs = new FileStream(fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            //--ヘッダ処理----------------------------------------------------------------

            int reccnt = 0;
            int headsize = 0;
            int recsize = 0;
            int filelds_cnt = 0;

            byte hb;
            hb = br.ReadByte();
            int offset = 1;

            byte[] strbuf = new byte[3];

            strbuf = br.ReadBytes(3);
            offset += 3;

            short yy = (short)strbuf[0];
            short mm = (short)strbuf[1];
            short dd = (short)strbuf[2];

            byte[] int32buf = new byte[4];

            int32buf = br.ReadBytes(4);
            reccnt = BitConverter.ToInt32(int32buf, 0);

            offset += 4;

            byte[] int16buf = new byte[2];
            int16buf = br.ReadBytes(2);
            headsize = BitConverter.ToInt16(int16buf, 0);

            int16buf = br.ReadBytes(2);
            recsize = BitConverter.ToInt16(int16buf, 0);

            byte[] wb = new byte[20];
            wb = br.ReadBytes(20);

            filelds_cnt = headsize / 32 - 1;

            string[] s_fileld_name = new string[filelds_cnt];
            string[] s_fileld_type = new string[filelds_cnt];
            short[] filels_len = new short[filelds_cnt];
            short[] filels_len2 = new short[filelds_cnt];

            for (int i = 0; i < filelds_cnt; i++)
            {
                byte[] filelds = new byte[32];

                filelds = br.ReadBytes(32);

                byte[] fileld_name = new byte[11];
                byte[] fileld_type = new byte[1];
                byte[] fileld_rsv = new byte[4];
                byte[] fileld_len = new byte[1];
                byte[] fileld_len2 = new byte[1];
                byte[] fileld_rsv2 = new byte[14];

                int f_offset = 0;

                Array.Copy(filelds, f_offset, fileld_name, 0, 11);
                f_offset += 11;

                s_fileld_name[i] = System.Text.Encoding.GetEncoding(str_encoding).GetString(fileld_name);

                Array.Copy(filelds, f_offset, fileld_type, 0, 1);
                f_offset += 1;
                s_fileld_type[i] = System.Text.Encoding.GetEncoding(str_encoding).GetString(fileld_type);


                Array.Copy(filelds, f_offset, fileld_rsv, 0, 4);
                f_offset += 4;

                Array.Copy(filelds, f_offset, fileld_len, 0, 1);
                f_offset += 1;
                filels_len[i] = fileld_len[0];

                Array.Copy(filelds, f_offset, fileld_len2, 0, 1);
                f_offset += 1;
                filels_len2[i] = fileld_len2[0];

                Array.Copy(filelds, f_offset, fileld_rsv2, 0, 14);
                f_offset += 14;

                s_fileld_name[i] = s_fileld_name[i].TrimEnd('\0');

            }

            byte End_OF_Header;
            End_OF_Header = br.ReadByte();//OD

            /* [フィールドタイプ]
            C:(Character)任意のOEMコードページ文字
            D:(Date)年月日をあらわす数字および文字（内部表現は8桁のYYYYMMDD形式）
            F:(Floating point binary numeric)- . 0 1 2 3 4 5 6 7 8 9
            N:(Binary codeddecimal numeric)- . 0 1 2 3 4 5 6 7 8 9
            L:(Logical)? Y y N n T t F f（初期値設定しない場合は? になる）
            M:(Memo)任意のOEMコードページ文字(内部表現は10桁の.DBTブロック番号）
            */

            //--レコード数分繰り返し----------------------------------------------------------------

            for (int i = 0; i < reccnt; i++)
            {

                byte[] recbuf = new byte[recsize];
                recbuf = br.ReadBytes(recsize);


                int fi_offset = 1;

                string list = "";

                string[] value = new string[filelds_cnt];

                for (int j = 0; j < filelds_cnt; j++)
                {
                    byte[] wrkbuf = new byte[filels_len[j]];
                    Array.Copy(recbuf, fi_offset, wrkbuf, 0, filels_len[j]);

                    value[j] = Encoding.GetEncoding(str_encoding).GetString(wrkbuf);
                    value[j] = value[j].TrimEnd();

                    fi_offset += filels_len[j];
                }
                /*
0:フィールド名:TEXT,フィールドタイプ:C,フィールド長:254
1:フィールド名:作成者,フィールドタイプ:C,フィールド長:254
2:フィールド名:作成日時,フィールドタイプ:C,フィールド長:23
3:フィールド名:編集者,フィールドタイプ:C,フィールド長:254
4:フィールド名:編集日時,フィールドタイプ:C,フィールド長:23
5:フィールド名:TEST,フィールドタイプ:C,フィールド長:254
6:フィールド名:UTMポイン,フィールドタイプ:C,フィールド長:254
7:フィールド名:コメント,フィールドタイプ:C,フィールド長:254
8:フィールド名:mlStyle,フィールドタイプ:N,フィールド長:9
9:フィールド名:L_NO,フィールドタイプ:C,フィールド長:254
10:フィールド名:L_TYPE,フィールドタイプ:C,フィールド長:254
11:フィールド名:SYMBOL,フィールドタイプ:C,フィールド長:254
12:フィールド名:TEXT_SIZE,フィールドタイプ:C,フィールド長:254
13:フィールド名:DATA_ANGLE,フィールドタイプ:C,フィールド長:254
14:フィールド名:MLSTYLE,フィールドタイプ:C,フィールド長:254
15:フィールド名:TY_FLG,フィールドタイプ:C,フィールド長:254
16:フィールド名:角度,フィールドタイプ:N,フィールド長:9
17:フィールド名:文字サイズ,フィールドタイプ:N,フィールド長:9

                izahyo_x,izahyo_y,mlStyle,L_NO,L_TYPE,SYMBOL,TEXT,TEXT_SIZE,DATA_ANGLE,TY_FLG,フォント,文字色(ラベル文字色RGBA-ラベル背景色RGBA),作成者,作成日時,編集者,編集日時
                */


                list = GetFieldValue(s_fileld_name, value,"mlStyle");//mlStyle
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "L_NO"); ;//L_NO
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "L_TYPE");//L_TYPE
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "SYMBOL");//SYMBOL
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "TEXT");//TEXT
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "TEXT_SIZE");//TEXT_SIZE
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "DATA_ANGLE");//DATA_ANGLE
                list += ",";
                list += GetFieldValue(s_fileld_name, value, "TY_FLG");//TY_FLG
                list += ",";

                int mlStyle = 0;
                int ty_flg = 0;
                try
                {
                    mlStyle = Int32.Parse(GetFieldValue(s_fileld_name, value, "mlStyle"));
                    ty_flg = Int32.Parse(GetFieldValue(s_fileld_name, value, "TY_FLG"));

                }
                catch (Exception ex)
                {

                }
                string style = GetMstyle(mlStyle);
                string[] style_param= style.Split(',');

                list += "'";


                if(ty_flg == 0)
                {
                    list += style_param[8];//フォント
                }
                else
                {
                    list += "@";
                    list += style_param[8];//フォント

                }


                list += "'";
                list += ",";

                list += "'";
                list += "{ \"Brush\":{ \"Style\":\"Solid\",\"Colour\":{ \"RGBA\":[";
                list += RGBCSV(style_param[4]);//ラベル文字色
                list += "]},\"BackgroundColour\":{ \"RGBA\":[";
                list += RGBCSV(style_param[5]);//ラベル背景色
                list += "]} } }";
                list += "'";

                list += ",";

                list += GetFieldValue(s_fileld_name, value, "作成者");//作成者
                list += ",";

                list += GetFieldValue(s_fileld_name, value, "作成日時");//作成日時
                list += ",";

                list += GetFieldValue(s_fileld_name, value, "編集者");//編集者
                list += ",";

                list += GetFieldValue(s_fileld_name, value, "編集日時");//編集日時
                list += ",";

                dbf.Add(list);

                if (checkOutputLimit.Checked == true)
                {
                    if (i >= limitCnt) break;
                }

            }

            fs.Close();
            br.Close();

        }

        private int GetFieldIdx(string[] s_fileld_name,string field)
        {
            int idx = -1;
            for (int j = 0; j < s_fileld_name.Length; j++)
            {
                if (s_fileld_name[j].IndexOf(field) == 0)
                {
                    idx = j;
                    break;
                }
            }
            if (idx < 0)
            {
                MsgOut("インデックス検索エラー!!");
            }
            return idx;
        }
        private string GetFieldValue(string[] s_fileld_name, string[] value,string field)
        {
            string retValue = "";
            int idx = -1;
            for (int j = 0; j < s_fileld_name.Length; j++)
            {
                if (s_fileld_name[j].IndexOf(field) == 0)
                {
                    retValue=value[j];
                    idx = j;
                    break;
                }
            }
            if (idx<0)
            {
                MsgOut("インデックス検索エラー!!");
            }
            return retValue;
        }

        public string RGBCSV(string argb)
        {
            string ret = "";

            //0xff000000

            if (argb.Length >= 10)
            {
                int a = Convert.ToInt32(argb.Substring(2, 2),16);

                //20250203
                if (a == 255)
                {
                   a = 0;
                }

                int r = Convert.ToInt32(argb.Substring(4, 2),16);
                int g = Convert.ToInt32(argb.Substring(6, 2), 16);
                int b = Convert.ToInt32(argb.Substring(8, 2), 16);
                ret = r.ToString() + "," + g.ToString() + "," + b.ToString() + "," + a.ToString();
            }
            return ret;
        }
        public String GetMstyle(int mlStyle)
        {
            string ret = "";

            LAY_INFO result = lay_info.Find(s => s.mlstyle == mlStyle);

            if(result == null)
            {
                ret += ",";
                ret += ",";
                ret += ",";
                ret += ",";
                ret += ",";
                ret += ",";
                ret += ",";
                ret += ",";
                ret += ",";
            }
            else
            {
                ret = result.mlstyle.ToString();
                ret += ",";
                ret += result.name;
                ret += ",";
                ret += result.lay_no;
                ret += ",";
                ret += result.pen_width;
                ret += ",";
                ret += result.pen;
                ret += ",";
                ret += result.brush;
                ret += ",";
                ret += result.symbol_scale;
                ret += ",";
                ret += result.defined;
                ret += ",";
                ret += result.font;
                ret += ",";
                ret += result.font_size;
            }


            return ret;
        }
        public void load_info(string fname)
        {
            StreamReader sr = new StreamReader(fname);


            int lcnt = 0;

            Boolean IsEOF = false;

            while (IsEOF == false)
            {
                string line = sr.ReadLine();
                if (line == null)
                {
                    IsEOF = true;
                }
                else
                {
                    if (lcnt == 0)
                    {
                    }
                    else
                    {
                        string[] param = line.Split(new char[] { ',' });
                        if (param.Length >=9 )
                        {
                            lay_info.Add(new LAY_INFO { mlstyle = Int32.Parse(param[0]), name=param[1],lay_no = param[2], pen_width = param[3], pen = param[4], brush = param[5], symbol_scale = param[6], defined = param[7], font = param[8], font_size = param[9] });
                        }
                    }
                    lcnt++;
                }
            }
            sr.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            DispLimitCnt = Int32.Parse(textDispLimit.Text);
            int incnt = 0;
            string csv_fname = textCSVFile.Text;

            try
            {
                StreamReader sr = new StreamReader(csv_fname);
                Boolean IsEOF = false;
                while (IsEOF == false)
                {
                    string line = sr.ReadLine();
                    if(line == null)
                    {
                        IsEOF = true;
                    }
                    else
                    {
                        incnt++;
                        listBox2.Items.Add(incnt.ToString()+":"+line);

                        if (incnt >= DispLimitCnt)
                        {
                            IsEOF = true;
                        }
                    }


                }

            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }
        }
    }
    class LAY_INFO
    {
        //mstyle 
        public int mlstyle { get; set; }
        //名称  //
        public string name { get; set; }
        //レイヤ種別
        public string lay_no { get; set; }
        //線太
        public string pen_width { get; set; }
        //ペン
        public string pen { get; set; }
        //ブラシ
        public string brush { get; set; }
        //SYMBOL_SCALE
        public string symbol_scale { get; set; }
        //DEFINED
        public string defined { get; set; }
        //フォント
        public string font { get; set; }
        //文字サイズ
        public string font_size { get; set; }
    }
}

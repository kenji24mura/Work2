﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CreateReportLayer
{
    public partial class Form1 : Form
    {
        public static String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];
        public static String TIMER_INTVAL = System.Configuration.ConfigurationManager.AppSettings["TIMER_INTVAL"];
        public static String SQLSERVER_CONN_STRING = System.Configuration.ConfigurationManager.AppSettings["SQLSERVER_CONN_STRING"];
        public static String ORACLE_CONN_STRING = System.Configuration.ConfigurationManager.AppSettings["ORACLE_CONN_STRING"];


        string LAY_NO = "n@8-1";

        int SYMBOL_NO = 1000;
        int INFO_TYPE = 8;
        int LAY_TYPE = 3;

        string TABLE_NAME = "TBWG0002";


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void MsgOut(string msg)
        {
            DateTime dt = DateTime.Now;
            listBox1.Items.Add(dt+","+msg);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DelData(LAY_NO,SYMBOL_NO,TABLE_NAME);
            ConnServer(SQLSERVER_CONN_STRING);
        }


        private void ConnServer(string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT TDKD010.* , TDKD020.zahyo_no as TDKD020_zahyo_no,TDKD020.zahyo_x as TDKD020_zahyo_x, TDKD020.zahyo_y as TDKD020_zahyo_y  FROM TDKD010 ";
                    query += " left join TDKD020 on TDKD010.tou_syosyo_cd = TDKD020.tou_syosyo_cd and TDKD010.tou_year = TDKD020.tou_year and TDKD010.tou_no = TDKD020.tou_no ";
                    //query += " WHERE TDKD010.tou_date>'2024/04/01 00:00:00'";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            string bk_tou_syosyo_cd = "";
                            string bk_tou_year = "";
                            string bk_tou_no = "";

                            string line = "";
                            int rec_cnt = 1;


                            OracleConnection conn = new OracleConnection();

                            conn.ConnectionString = ORACLE_CONN_STRING;
                            conn.Open();

                            while (reader.Read())
                            {
                                string tou_syosyo_cd = reader["tou_syosyo_cd"].ToString();
                                string tou_year = reader["tou_year"].ToString();
                                string tou_no = reader["tou_no"].ToString();
                                string sdate = reader["sdate"].ToString();
                                string edate = reader["edate"].ToString();
                                string stime = reader["stime"].ToString();
                                string etime = reader["etime"].ToString();
                                string zahyo_x = reader["zahyo_x"].ToString();
                                string zahyo_y = reader["zahyo_y"].ToString();
                                string zahyo_x1 = reader["zahyo_x1"].ToString();
                                string zahyo_y1 = reader["zahyo_y1"].ToString();
                                string zahyo_x2 = reader["zahyo_x2"].ToString();
                                string zahyo_y2 = reader["zahyo_y2"].ToString();
                                string zahyo_x3 = reader["zahyo_x3"].ToString();
                                string zahyo_y3 = reader["zahyo_y3"].ToString();
                                string zahyo_x4 = reader["zahyo_x4"].ToString();
                                string zahyo_y4 = reader["zahyo_y4"].ToString();
                                string zahyo_x5 = reader["zahyo_x5"].ToString();
                                string zahyo_y5 = reader["zahyo_y5"].ToString();
                                string zahyo_x6 = reader["zahyo_x6"].ToString();
                                string zahyo_y6 = reader["zahyo_y6"].ToString();
                                string zahyo_x7 = reader["zahyo_x7"].ToString();
                                string zahyo_y7 = reader["zahyo_y7"].ToString();
                                string zahyo_x8 = reader["zahyo_x8"].ToString();
                                string zahyo_y8 = reader["zahyo_y8"].ToString();
                                string zahyo_x9 = reader["zahyo_x9"].ToString();
                                string zahyo_y9 = reader["zahyo_y9"].ToString();
                                string zahyo_x10 = reader["zahyo_x10"].ToString();
                                string zahyo_y10 = reader["zahyo_y10"].ToString();

                                //string TDKD020_zahyo_no = reader["TDKD020_zahyo_no"].ToString();
                                string TDKD020_zahyo_x = reader["TDKD020_zahyo_x"].ToString();
                                string TDKD020_zahyo_y = reader["TDKD020_zahyo_y"].ToString();

                                if (tou_syosyo_cd.Equals(bk_tou_syosyo_cd) == true && tou_year.Equals(bk_tou_year) == true && tou_no.Equals(bk_tou_no) == true)
                                {
                                    //継続レコード

                                    //line += ",";
                                    //line += TDKD020_zahyo_no;
                                    line += ",";
                                    line += TDKD020_zahyo_x;
                                    line += ",";
                                    line += TDKD020_zahyo_y;


                                }
                                else
                                {

                                    if (line.Length > 0)
                                    {
                                        MsgOut(line);
                                        DBEntry(conn,line, rec_cnt);
                                        rec_cnt++;


                                    }

                                    line = "";

                                    line = tou_syosyo_cd;
                                    line += ",";
                                    line = tou_year;
                                    line += ",";
                                    line = tou_no;
                                    line += ",";
                                    line += sdate;
                                    line += ",";
                                    line += edate;
                                    line += ",";
                                    line += stime;
                                    line += ",";
                                    line += etime;
                                    line += ",";
                                    line += zahyo_x;
                                    line += ",";
                                    line += zahyo_y;
                                    line += ",";
                                    line += zahyo_x1;
                                    line += ",";
                                    line += zahyo_y1;
                                    line += ",";
                                    line += zahyo_x2;
                                    line += ",";
                                    line += zahyo_y2;
                                    line += ",";
                                    line += zahyo_x3;
                                    line += ",";
                                    line += zahyo_y3;
                                    line += ",";
                                    line += zahyo_x4;
                                    line += ",";
                                    line += zahyo_y4;
                                    line += ",";
                                    line += zahyo_x5;
                                    line += ",";
                                    line += zahyo_y5;
                                    line += ",";
                                    line += zahyo_x6;
                                    line += ",";
                                    line += zahyo_y6;
                                    line += ",";
                                    line += zahyo_x7;
                                    line += ",";
                                    line += zahyo_y7;
                                    line += ",";
                                    line += zahyo_x8;
                                    line += ",";
                                    line += zahyo_y8;
                                    line += ",";
                                    line += zahyo_x9;
                                    line += ",";
                                    line += zahyo_y9;
                                    line += ",";
                                    line += zahyo_x10;
                                    line += ",";
                                    line += zahyo_y10;

                                    //line += ",";
                                    //line += TDKD020_zahyo_no;
                                    line += ",";
                                    line += TDKD020_zahyo_x;
                                    line += ",";
                                    line += TDKD020_zahyo_y;

                                    bk_tou_syosyo_cd = tou_syosyo_cd;
                                    bk_tou_year = tou_year;
                                    bk_tou_no = tou_no;
                                }

                            }
                            if (line.Length > 0)
                            {
                                MsgOut(line);
                            }

                            conn.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MsgOut("エラー: " + ex.Message);
                }
            }
        }
        private void DBEntry(OracleConnection conn,string line,int cnt)
        {
            DateTime dt = DateTime.Now;

            string[] param = line.Split(',');

            string tablename = TABLE_NAME;

            string lay_no = LAY_NO;
            string item_no;

            int symbol_no = SYMBOL_NO;
            int info_type = INFO_TYPE;
            int lay_type = LAY_TYPE;

            item_no = info_type.ToString("D2");
            item_no += symbol_no.ToString("D4");
            item_no += cnt.ToString("D6");

            string info_summery;


            info_summery = "";

            info_summery += "{";
            info_summery += "\"受付日\":";
            info_summery += "\"";
            info_summery += "\"";
            info_summery += ",\"連番\":";
            info_summery += "\"";
            info_summery += "\"";
            info_summery += ",\"処理区分\":";
            info_summery += "\"";
            info_summery += "\"";

            info_summery += ",\"備考\":";

            info_summery += "\"";
            info_summery += "開始日:";
            info_summery += param[3];
            info_summery += ",終了日:";
            info_summery += param[4];
            info_summery += "\"";

            info_summery += "}";

            MapCom.Convert cs = new MapCom.Convert();

            double lx = 0.0;
            double ly = 0.0;

            try
            {
                lx = Double.Parse(param[5]);
                ly = Double.Parse(param[6]);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }


            int kijyunkei = 6;
            double m_keido = 0.0;
            double m_ido = 0.0;
            long m_keido_w = 0;
            long m_ido_w = 0;

            //正規化座標(m)→経緯度（日本）(秒）
            cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
            //日本測地系（ミリ秒）→世界測地系（ミリ秒）
            cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

//            double zahyo_x = Double.Parse(param[5]);
//            double zahyo_y = Double.Parse(param[6]);

            double zahyo_x = (double)m_keido_w / (3600 * 1000);
            double zahyo_y = (double)m_ido_w / (3600 * 1000);



            string strinfo1 = "";
            string strinfo2 = "";
            string strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            String update_date = dt.ToString();
            String item_no2 = "";

            int start = 7;
            int pcnt = (param.Length - 7) / 2;

            int zahyo_cnt = 0;

            for (int i = 0; i < pcnt; i++)
            {
                if (param[start + i * 2].Length > 0 && param[start + i * 2 + 1].Length > 0)
                {
                    MsgOut(param[start + i * 2] + "," + param[start + i * 2 + 1]);
                    zahyo_cnt++;
                }
            }

            ZPOINT[] zp = new ZPOINT[zahyo_cnt];
            int k = 0;

            for (int i = 0; i < pcnt; i++)
            {
                if (param[start + i * 2].Length > 0 && param[start + i * 2 + 1].Length > 0)
                {
                    zp[k] = new ZPOINT();


                    lx = 0.0;
                    ly = 0.0;

                    try
                    {
                        lx = Double.Parse(param[start + i * 2]);
                        ly = Double.Parse(param[start + i * 2 + 1]);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex);
                    }


                    kijyunkei = 6;
                    m_keido = 0.0;
                    m_ido = 0.0;
                    m_keido_w = 0;
                    m_ido_w = 0;

                    //正規化座標(m)→経緯度（日本）(秒）
                    cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                    //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                    cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);

                    zp[k].zahyo_x = (double)m_keido_w / (3600 * 1000);
                    zp[k].zahyo_y = (double)m_ido_w / (3600 * 1000);


                    k++;
                }
            }

            AddPolygonData(conn, tablename, lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, ref zp, update_date, item_no2);

        }
        private void AddPolygonData(OracleConnection conn, String tablename, String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, ref ZPOINT[] zp, string update_date, String item_no2)
        {

            string msg;

            string arraydata = "ARRAY_POINT(";

            int maxcnt = zp.Length;

            for (int i = 0; i < maxcnt; i++)
            {
                if (i > 0)
                {
                    arraydata += ",";
                }
                arraydata += "POINT(";
                arraydata += zp[i].zahyo_x;
                arraydata += ",";
                arraydata += zp[i].zahyo_y;
                arraydata += ")";
            }

            arraydata += ")";

            try
            {


                //プレースホルダでバインドする
                string sql = "insert into  " + tablename;
                sql += "(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,zahyo_cnt,zahyo_array,update_date,item_no2)";
                sql += " VALUES(:lay_no,:item_no,:info_type,:info_summery,:lay_type,:symbol_no,:zahyo_x,:zahyo_y,:strinfo1,:strinfo2,:strinfo3,:str_zahyo_x,:str_zahyo_y,:zahyo_cnt,";
                sql += arraydata;
                sql += ",:update_date,:item_no2)";

                msg = sql;
                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        using (OracleCommand cmd = new OracleCommand(sql, conn))
                        {
                            cmd.BindByName = true;


                            cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                lay_no, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":item_no", OracleDbType.Varchar2,
                                item_no, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":info_type", OracleDbType.Int32,
                                info_type, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":info_summery", OracleDbType.Varchar2,
                                info_summery, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":lay_type", OracleDbType.Varchar2,
                                lay_type, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Varchar2,
                                symbol_no, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":zahyo_x", OracleDbType.Double,
                                zahyo_x, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":zahyo_y", OracleDbType.Double,
                                zahyo_y, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":strinfo1", OracleDbType.Varchar2,
                                strinfo1, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":strinfo2", OracleDbType.Varchar2,
                                strinfo2, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":strinfo3", OracleDbType.Varchar2,
                                strinfo3, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":str_zahyo_x", OracleDbType.Double,
                                str_zahyo_x, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":str_zahyo_y", OracleDbType.Double,
                                str_zahyo_y, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":zahyo_cnt", OracleDbType.Int32,
                                zahyo_cnt, ParameterDirection.Input));

                            DateTime dt = DateTime.Parse(update_date);

                            cmd.Parameters.Add(new OracleParameter(":update_date", OracleDbType.Date,
                                    dt, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":item_no2", OracleDbType.Varchar2,
                                item_no2, ParameterDirection.Input));

                            cmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        MsgOut(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MsgOut(ex.Message);
            }

        }
        private void DelData(String layerID, int symbol_no,string tablename)
        {
            string msg;

            try
            {
                //プレースホルダでバインドする
                string sql = "delete from  "+tablename+" Where lay_no=:lay_no AND symbol_no=:symbol_no";

                using (OracleConnection conn = new OracleConnection())
                {
                    conn.ConnectionString = ORACLE_CONN_STRING;
                    conn.Open();
                    using (OracleTransaction transaction = conn.BeginTransaction())
                    {
                        try
                        {
                            using (OracleCommand cmd = new OracleCommand(sql, conn))
                            {
                                cmd.BindByName = true;


                                cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                    layerID, ParameterDirection.Input));
                                cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Int32,
                                    symbol_no, ParameterDirection.Input));

                                cmd.ExecuteNonQuery();

                                transaction.Commit();
                                msg = "Delete Commit! [" + layerID + "]";
                                MsgOut(msg);
                            }
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            msg = ex.ToString();
                            MsgOut(msg);
                        }
                    }
                    conn.Close();
                    conn.Dispose();
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }
        }


    }
    public class ZPOINT
    {
        public double zahyo_x;
        public double zahyo_y;
    }
}

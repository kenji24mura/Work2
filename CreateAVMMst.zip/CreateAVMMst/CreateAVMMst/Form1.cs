﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CreateAVMMst
{
    public partial class Form1 : Form
    {

        static string CONN_STRING_WEBGIS = System.Configuration.ConfigurationManager.AppSettings["CONN_STRING_WEBGIS"];
        static string CONN_STRING_DAMS = System.Configuration.ConfigurationManager.AppSettings["CONN_STRING_DAMS"];
        static string CONN_STRING_KEIBO = System.Configuration.ConfigurationManager.AppSettings["CONN_STRING_KEIBO"];
        static string CONN_STRING_DAMS_T = System.Configuration.ConfigurationManager.AppSettings["CONN_STRING_DAMS_T"];
        public static String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];

        string CON_STR = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source= ";
        string DB1 = "c:\\D_DRV\\FIIM_TARGET.mdb";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            ReadDB_TBJS0100();
        }


        private void ReadDB_TBJS0100()
        {
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(200, 0, 0, 0);

            string result = (dt - sp1).ToString("yyyy/MM/dd HH:mm:ss");
            string sqlStr = "select * from TBJS0100 WHERE MAKE_KBN <> 'D'";

            int cnt = 0;

            try
            {

                OleDbConnection dbcon = new OleDbConnection(CON_STR + DB1);

                OleDbCommand cmd = dbcon.CreateCommand();
                dbcon.Open();


                //using (OracleConnection gis_conn = new OracleConnection())
                //{
                //  gis_conn.ConnectionString = CONN_STRING_WEBGIS;
                // gis_conn.Open();
                //コネクションを生成する
                using (OracleConnection conn = new OracleConnection())
                {
                    //コネクションを取得する
                    conn.ConnectionString = CONN_STRING_KEIBO;
                    conn.Open();

                    //コマンドを生成する
                    using (OracleCommand command = new OracleCommand(sqlStr))
                    {
                        command.Connection = conn;
                        command.CommandType = CommandType.Text;

                        //コマンドを実行する
                        using (OracleDataReader reader = command.ExecuteReader())
                        {
                            //検索結果が存在する間ループする
                            while (reader.Read())
                            {
                                String SUIRI_CD = reader["SUIRI_CD"].ToString();
                                String SUIRI_SBT = reader["SUIRI_SBT"].ToString();
                                String SYMBOL_SBT = reader["SYMBOL_SBT"].ToString();
                                String SHIYO_KAHI = reader["SHIYO_KAHI"].ToString();
                                String HAIKAN_KOKEI = reader["HAIKAN_KOKEI"].ToString();
                                String MOJI = reader["MOJI"].ToString();
                                String IZAHYO_X = reader["IZAHYO_X"].ToString();
                                String IZAHYO_Y = reader["IZAHYO_Y"].ToString();
                                String FUKA = reader["FUKA"].ToString();


                                MsgOut(SUIRI_CD);


                                MapCom.Convert cs = new MapCom.Convert();

                                double lx = 0.0;
                                double ly = 0.0;
                                try
                                {
                                    lx = Double.Parse(IZAHYO_X);
                                    ly = Double.Parse(IZAHYO_Y);
                                }
                                catch (Exception ex)
                                {
                                }

                                int kijyunkei = 6;
                                double m_keido = 0.0;
                                double m_ido = 0.0;
                                long m_keido_w = 0;
                                long m_ido_w = 0;

                                //正規化座標(m)→経緯度（日本）(秒）
                                cs.gpconv2(lx / 1000.0, ly / 1000.0, kijyunkei, ref m_keido, ref m_ido);
                                //日本測地系（ミリ秒）→世界測地系（ミリ秒）
                                cs.ConvJ2W((long)(m_keido * 1000), (long)(m_ido * 1000), ref m_keido_w, ref m_ido_w);


                                //string updateQuery = "UPDATE 目標物テーブル SET 名称 = '" + NewName + "' WHERE 種別 =" + kind + " AND 目標物=" + target;

                                //UpdateDB(dbcon, updateQuery);


                            }
                        }
                    }

                    //コネクションを切断する
                    conn.Close();

                    //コネクションを破棄する
                    conn.Dispose();
                }

                dbcon.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }

        private void UpdateDB(OleDbConnection dbcon, string updateQuery)
        {
            try
            {
                // コマンドを実行
                using (OleDbCommand command = new OleDbCommand(updateQuery, dbcon))
                {
                    int rowsAffected = command.ExecuteNonQuery();
                    MsgOut($"{rowsAffected} 行が更新されました。");
                }
            }
            catch (Exception ex)
            {
                MsgOut("エラーが発生しました: " + ex.Message);
            }
        }

        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }


    }
}

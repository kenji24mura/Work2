﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
//using static System.Net.Mime.MediaTypeNames;

namespace ImageResizeCMD
{
    internal class Program
    {
        static void Main(string[] args)
        {
            if (args.Length < 4)
            {
                Console.WriteLine("args error");
                return;
            }
            else
            {
                string sourceFile = args[0];
                string destinationFile = args[1];
                int width = Int32.Parse(args[2]);
                int height = Int32.Parse(args[3]);

                System.Drawing.Imaging.ImageFormat imageFormat = ImageFormat.Png;

                ResizeImageWhileMaintainingAspectRatio(sourceFile, destinationFile, imageFormat, width, height);
            }
        }
        // <summary>
        /// 画像ファイルのサイズを変更します
        /// </summary>
        /// <param name="sourceFile">サイズ変更する画像ファイル</param>
        /// <param name="destinationFile">サイズ変更した画像ファイル</param>
        /// <param name="imageFormat">画像ファイル形式</param>
        /// <param name="width">変更する幅</param>
        /// <param name="height">変更する高さ</param>
        public static void ResizeImageWhileMaintainingAspectRatio(string sourceFile,
            string destinationFile,
            System.Drawing.Imaging.ImageFormat imageFormat,
            int width,
            int height)
        {
            // サイズ変更する画像ファイルを開く
            using (Image image = Image.FromFile(sourceFile))
            {
                // 変更倍率を取得する
                float scale = Math.Min((float)width / (float)image.Width, (float)height / (float)image.Height);

                // サイズ変更した画像を作成する
                using (Bitmap bitmap = new Bitmap(width, height))
                using (Graphics graphics = Graphics.FromImage(bitmap))
                {
                    // 変更サイズを取得する
                    int widthToScale = (int)(image.Width * scale);
                    int heightToScale = (int)(image.Height * scale);

                    // 背景色を塗る
                    //SolidBrush solidBrush = new SolidBrush(Color.Black);
                    //graphics.FillRectangle(solidBrush, new RectangleF(0, 0, width, height));

                    // サイズ変更した画像に、左上を起点に変更する画像を描画する
                    graphics.DrawImage(image, 0, 0, widthToScale, heightToScale);

                    // サイズ変更した画像を保存する
                    bitmap.Save(destinationFile, imageFormat);
                }
            }
        }

    }
}

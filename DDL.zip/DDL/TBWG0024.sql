-- TBWG0024
--* RestoreFromTempTable
create table TBWG0024 (
  PRIF NUMBER(10, 0) not null
  , CITY NUMBER(10, 0) not null
  , TOWN1 NUMBER(10, 0) not null
  , TOWN2 NUMBER(10, 0) not null
  , ZX NUMBER(13, 0)
  , ZY NUMBER(13, 0)
  , LON NUMBER(13, 10)
  , LAT NUMBER(13, 10)
  , NAME VARCHAR2(100) not null
  , KANA VARCHAR2(100)
  , UPDATE_DATE DATE
  , constraint TBWG0024_PKC primary key (PRIF,CITY,TOWN1,TOWN2,NAME)
) ;
comment on table TBWG0024 is '�n�ԃe�[�u��';
comment on column TBWG0024.PRIF is '�s���{��';
comment on column TBWG0024.CITY is '�s����';
comment on column TBWG0024.TOWN1 is '����';
comment on column TBWG0024.TOWN2 is '����';
comment on column TBWG0024.ZX is 'X���W';
comment on column TBWG0024.ZY is 'Y���W';
comment on column TBWG0024.LON is '�o�x';
comment on column TBWG0024.LAT is '�ܓx';
comment on column TBWG0024.NAME is '����';
comment on column TBWG0024.KANA is '�J�i';
comment on column TBWG0024.UPDATE_DATE is '�X�V����';
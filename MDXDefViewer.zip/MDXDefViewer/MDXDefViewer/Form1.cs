﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace MDXDefViewer
{
    public partial class Form1 : Form
    {
        DataGridViewColumn[] viewColumn = new DataGridViewColumn[30];

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.AllowUserToAddRows = false;

//            textDispDef.Text = @"C:\D_DRV\表示定義\25000";
  //          textCtrl.Text = @"C:\D_DRV\管理ファイル\図式分類定義";
    //        textSymbolPath.Text = @"C:\D_DRV\表示定義\symbol\mdx_bmp";
            textDispDef.Text = "";
            textCtrl.Text = "";
            textSymbolPath.Text = "";

            string Dir1 = textDispDef.Text;
            string Dir2 = textCtrl.Text;

            /*
            string[] fiAlls1 = Directory.GetFiles(Dir1);
            foreach (string f in fiAlls1)
            {
                comboBox1.Items.Add(f);
            }

            string[] fiAlls2 = Directory.GetFiles(Dir2);
            foreach (string f in fiAlls2)
            {
                comboBox2.Items.Add(f);
            }
            */

            if (Directory.Exists(Dir1) == true)
            {
                InitComboBox(comboBox1, Dir1);
            }

            if(Directory.Exists(Dir2) == true)
            {
                InitComboBox(comboBox2, Dir2);
            }

            for (int i = 0; i < 30; i++)
            {
                viewColumn[i] = new DataGridViewColumn();
            }
        }

        private void InitComboBox(System.Windows.Forms.ComboBox cb, string Dir)
        {
            cb.Items.Clear();
            cb.Text = "";
            string[] fiAlls = Directory.GetFiles(Dir);
            foreach (string f in fiAlls)
            {
                cb.Items.Add(f);
            }
            if (cb.Items.Count > 0)
            {
                cb.SelectedIndex = 0;
            }
        }

        /*
        private void button1_Click(object sender, EventArgs e)
        {
            string FileName1 = @"C:\\D_DRV\25000_lsd.csv";
            string FileName2 = @"C:\\D_DRV\25000_fcd.csv";

            LoadCSV(FileName1, FileName2);
        }
        */
        public void LoadCSV(string FileName1, string FileName2)
        {
            dataGridView1.Columns.Clear();
            for (int i = 0; i < 30; i++)
            {
                viewColumn[i] = new DataGridViewColumn();
            }

            try
            {
                StreamReader sr = new StreamReader(
                        FileName1, Encoding.GetEncoding("UTF-8"));

                int col = 0;

                while (sr.Peek() > -1)
                {

                    string line = sr.ReadLine();
                    string[] param = line.Split(',');

                    //Console.WriteLine(line);

                    string name = "";


                    if (col == 0)
                    {
                        for (int i = 0; i < param.Length; i++)
                        {
                            if (i == 0 && param[0].IndexOf("図式分類コード") == 0)
                            {
                                DataGridViewColumn n_viewColumn = new DataGridViewColumn();

                                n_viewColumn.Name = "name";                         //列の名前
                                n_viewColumn.HeaderText = "名称";                   //ヘッダーに表示される名称
                                n_viewColumn.CellTemplate = new DataGridViewTextBoxCell();  //セルのタイプ
                                n_viewColumn.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                                dataGridView1.Columns.Add(n_viewColumn);
                            }
                            viewColumn[i].Name = param[i];                         //列の名前
                            viewColumn[i].HeaderText = param[i];                   //ヘッダーに表示される名称
                            viewColumn[i].CellTemplate = new DataGridViewTextBoxCell();  //セルのタイプ
                            dataGridView1.Columns.Add(viewColumn[i]);

                        }
                        if (FileName1.IndexOf("_spd.csv") > 0)
                        {
                            DataGridViewImageColumn n_viewColumn = new DataGridViewImageColumn();

                            n_viewColumn.Name = "image";                         //列の名前
                            n_viewColumn.HeaderText = "アイコン";                   //ヘッダーに表示される名称
                            n_viewColumn.CellTemplate = new DataGridViewImageCell();  //セルのタイプ
                            n_viewColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
                            dataGridView1.Columns.Add(n_viewColumn);
                        }
                    }
                    else
                    {

                        if (FileName1.IndexOf("_spd.csv") > 0)
                        {
                            var view_param = new object[param.Length + 1];
                            string image_path = textSymbolPath.Text + "\\" + param[1] + ".bmp";

                            Image image = Image.FromFile(image_path);

                            view_param[0] = param[0];
                            view_param[1] = param[1];
                            view_param[2] = image;

                            dataGridView1.Rows.Add(view_param);
                        }
                        else
                        {
                            name = GetObjectName(FileName2, param[0]);

                            string[] view_param = new string[param.Length + 1];

                            //Console.WriteLine(dataGridView1.Columns[0].HeaderCell.Value);

                            int j = 0;
                            if (dataGridView1.Columns[1].HeaderCell.Value.ToString().IndexOf("図式分類コード") == 0)
                            {
                                view_param[j] = name;
                                j++;
                            }
                            for (int i = 0; i < param.Length; i++)
                            {
                                view_param[j] = param[i].ToString();
                                j++;


                            }
                            dataGridView1.Rows.Add(view_param);
                        }
                    }
                    col++;
                }
                sr.Close();

                SetColor();

            }
            catch (Exception ex)
            {
                //MsgOut(ex.Message);
            }

        }

        private void SetColor()
        {

            int r_idx = -1;
            int g_idx = -1;
            int b_idx = -1;

            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                string value = dataGridView1.Columns[i].HeaderCell.Value.ToString();

                if (value.IndexOf("[要素１]色（Ｒ）") == 0)
                {
                    r_idx = i;
                }
                if (value.IndexOf("[要素１]色（Ｇ）") == 0)
                {
                    g_idx = i;
                }
                if (value.IndexOf("[要素１]色（Ｂ）") == 0)
                {
                    b_idx = i;
                }
                if (value.IndexOf("[塗り]色（Ｒ）") == 0)
                {
                    r_idx = i;
                }
                if (value.IndexOf("[塗り]色（Ｇ）") == 0)
                {
                    g_idx = i;
                }
                if (value.IndexOf("[塗り]色（Ｂ）") == 0)
                {
                    b_idx = i;
                }
                if (value.IndexOf("[注記]色（Ｒ）") == 0)
                {
                    r_idx = i;
                }
                if (value.IndexOf("[注記]色（Ｇ）") == 0)
                {
                    g_idx = i;
                }
                if (value.IndexOf("[注記]色（Ｂ）") == 0)
                {
                    b_idx = i;
                }
                //                Console.WriteLine(dataGridView1.Columns[i].HeaderCell.Value.ToString());
            }

            if ((r_idx >= 0) && (g_idx >= 0) && (b_idx >= 0))
            {
                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    Color cr;

                    int r_val = 0;
                    int g_val = 0;
                    int b_val = 0;

                    for (int j = 0; j < dataGridView1.Rows[i].Cells.Count; j++)
                    {
                        string value = dataGridView1[j, i].Value.ToString();
                        if (value.Length > 0 && j == r_idx)
                        {
                            r_val = Int32.Parse(value);
                        }
                        if (value.Length > 0 && j == g_idx)
                        {
                            g_val = Int32.Parse(value);
                        }
                        if (value.Length > 0 && j == b_idx)
                        {
                            b_val = Int32.Parse(value);
                        }
                        //                    Console.WriteLine(dataGridView1[j, i].Value);
                    }
                    cr = Color.FromArgb(255, r_val, g_val, b_val);

                    dataGridView1[r_idx, i].Style.BackColor = cr;
                    dataGridView1[g_idx, i].Style.BackColor = cr;
                    dataGridView1[b_idx, i].Style.BackColor = cr;

                }
            }


        }

        public String GetObjectName(string FileName, string ObjID)
        {
            string ret = "";

            try
            {
                StreamReader sr = new StreamReader(
                        FileName, Encoding.GetEncoding("UTF-8"));

                int linecnt = 0;
                while (sr.Peek() > -1)
                {

                    string line = sr.ReadLine();

                    if (linecnt > 0)
                    {
                        string[] param = line.Split(',');

                        if (param[1] == ObjID)
                        {
                            ret = param[2];
                        }
                    }

                    linecnt++;
                }
                sr.Close();

            }
            catch (Exception ex)
            {
                //MsgOut(ex.Message);
            }


            return ret;
        }

        private void btnLaodCsv_Click(object sender, EventArgs e)
        {
            string FileName1 = comboBox1.Text;
            string FileName2 = comboBox2.Text;

            LoadCSV(FileName1, FileName2);

        }

        private void btnDispDef_Click(object sender, EventArgs e)
        {
            SelectDir(textDispDef.Text, textDispDef, comboBox1);
        }

        private void btnSymbol_Click(object sender, EventArgs e)
        {
            SelectDir(textSymbolPath.Text, textSymbolPath);
        }

        private void btnCtrl_Click(object sender, EventArgs e)
        {
            SelectDir(textCtrl.Text, textCtrl, comboBox2);
        }

        private void SelectDir(string SelectedPath, System.Windows.Forms.TextBox tb)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();

            // 初期選択フォルダーが設定できる①
            dialog.SelectedPath = SelectedPath;

            // ダイアログに表示する説明文を設定できる②
            dialog.Description = "フォルダ選択";

            // 新しくフォルダを作成を許可する②
            dialog.ShowNewFolderButton = false;

            // ダイアログを表示する。
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                // 選択されたフォルダを取得する
                tb.Text = dialog.SelectedPath;
            }
            else
            {
                // キャンセルの場合は何もしない
            }
        }
        private void SelectDir(string SelectedPath, System.Windows.Forms.TextBox tb, System.Windows.Forms.ComboBox cb)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();

            // 初期選択フォルダーが設定できる①
            dialog.SelectedPath = SelectedPath;

            // ダイアログに表示する説明文を設定できる②
            dialog.Description = "フォルダ選択";

            // 新しくフォルダを作成を許可する②
            dialog.ShowNewFolderButton = false;

            // ダイアログを表示する。
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                // 選択されたフォルダを取得する
                tb.Text = dialog.SelectedPath;
                InitComboBox(cb, tb.Text);

            }
            else
            {
                // キャンセルの場合は何もしない
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if(dataGridView1.Columns.Count==0) return;

            try
            {
                string srcfname = comboBox1.Text;
                string wkfname = srcfname + ".wk";

                DateTime dt = DateTime.Now;
                using (StreamWriter sw = new StreamWriter(wkfname, false, Encoding.UTF8))
                {

                    string line = "";
                    int start = 0;
                    int end = 0;

                    if (comboBox1.Text.IndexOf("_spd.csv") > 0)
                    {
                        start = 0;
                        end = -1;
                    }
                    else
                    {
                        start = 1;
                        end = 0;
                    }

                    for (int i = start; i < dataGridView1.Columns.Count + end; i++)
                    {
                        string value = dataGridView1.Columns[i].HeaderCell.Value.ToString();
                        if (i > start)
                        {
                            line += ",";
                        }
                        line += value;


                    }
                    Console.WriteLine(line);
                    sw.WriteLine(line);
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        line = "";
                        for (int j = start; j < dataGridView1.Rows[i].Cells.Count + end; j++)
                        {
                            string value = dataGridView1[j, i].Value.ToString();
                            if (j > start)
                            {
                                line += ",";
                            }
                            line += value;
                        }
                        Console.WriteLine(line);
                        sw.WriteLine(line);
                    }

                }

                if (MessageBox.Show("保存しますか?","保存確認",MessageBoxButtons.OKCancel) == DialogResult.OK)
                {
                    DateTime dateTime = DateTime.Now;

                    string dir = Path.GetDirectoryName(srcfname)+"\\back";
                    string fname = Path.GetFileNameWithoutExtension(srcfname);
                    string ext = Path.GetExtension(srcfname);

                    if (Directory.Exists(dir))
                    {
                    }
                    else
                    {
                        Directory.CreateDirectory(dir);
                    }

                    string backupfile = dir+"\\"+fname+"."+dt.ToString("yyyyMMdd-HHmmss")+ext;

                    File.Copy(srcfname, backupfile, true);
                    File.Copy(wkfname, srcfname, true);
                    File.Delete(wkfname);

                    //InitComboBox(comboBox1, textDispDef.Text);
                    string FileName1 = comboBox1.Text;
                    string FileName2 = comboBox2.Text;

                    LoadCSV(FileName1, FileName2);


                }

            }
            catch (Exception ex)
            {
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void リリースNToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Formversion fv = new Formversion();
            fv.ShowDialog();
        }
    }
}

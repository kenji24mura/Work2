﻿namespace CreateShape
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.textCsvFile = new System.Windows.Forms.TextBox();
            this.textShapeDir = new System.Windows.Forms.TextBox();
            this.textDefFile = new System.Windows.Forms.TextBox();
            this.btnSymbol = new System.Windows.Forms.Button();
            this.btnLine = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textShapeFileName = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.comboCSVEncode = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboShapeEncode = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textCsvFile
            // 
            this.textCsvFile.Location = new System.Drawing.Point(167, 31);
            this.textCsvFile.Margin = new System.Windows.Forms.Padding(4);
            this.textCsvFile.Name = "textCsvFile";
            this.textCsvFile.Size = new System.Drawing.Size(353, 23);
            this.textCsvFile.TabIndex = 1;
            // 
            // textShapeDir
            // 
            this.textShapeDir.Location = new System.Drawing.Point(167, 106);
            this.textShapeDir.Margin = new System.Windows.Forms.Padding(4);
            this.textShapeDir.Name = "textShapeDir";
            this.textShapeDir.Size = new System.Drawing.Size(353, 23);
            this.textShapeDir.TabIndex = 2;
            // 
            // textDefFile
            // 
            this.textDefFile.Location = new System.Drawing.Point(167, 62);
            this.textDefFile.Margin = new System.Windows.Forms.Padding(4);
            this.textDefFile.Name = "textDefFile";
            this.textDefFile.Size = new System.Drawing.Size(353, 23);
            this.textDefFile.TabIndex = 3;
            // 
            // btnSymbol
            // 
            this.btnSymbol.Location = new System.Drawing.Point(45, 328);
            this.btnSymbol.Name = "btnSymbol";
            this.btnSymbol.Size = new System.Drawing.Size(98, 29);
            this.btnSymbol.TabIndex = 4;
            this.btnSymbol.Text = "SYMBOL";
            this.btnSymbol.UseVisualStyleBackColor = true;
            this.btnSymbol.Click += new System.EventHandler(this.btnSymbol_Click);
            // 
            // btnLine
            // 
            this.btnLine.Location = new System.Drawing.Point(173, 328);
            this.btnLine.Name = "btnLine";
            this.btnLine.Size = new System.Drawing.Size(98, 29);
            this.btnLine.TabIndex = 5;
            this.btnLine.Text = "LINE";
            this.btnLine.UseVisualStyleBackColor = true;
            this.btnLine.Click += new System.EventHandler(this.btnLine_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 15);
            this.label1.TabIndex = 6;
            this.label1.Text = "CSVファイル";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(31, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 7;
            this.label2.Text = "Shape出力先";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 15);
            this.label3.TabIndex = 8;
            this.label3.Text = "Defファイル";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "Shapeファイル名";
            // 
            // textShapeFileName
            // 
            this.textShapeFileName.Location = new System.Drawing.Point(167, 141);
            this.textShapeFileName.Margin = new System.Windows.Forms.Padding(4);
            this.textShapeFileName.Name = "textShapeFileName";
            this.textShapeFileName.Size = new System.Drawing.Size(104, 23);
            this.textShapeFileName.TabIndex = 10;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(36, 197);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(811, 94);
            this.listBox1.TabIndex = 11;
            // 
            // comboCSVEncode
            // 
            this.comboCSVEncode.FormattingEnabled = true;
            this.comboCSVEncode.Location = new System.Drawing.Point(730, 64);
            this.comboCSVEncode.Name = "comboCSVEncode";
            this.comboCSVEncode.Size = new System.Drawing.Size(117, 23);
            this.comboCSVEncode.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(730, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 15);
            this.label5.TabIndex = 13;
            this.label5.Text = "CSV Encode";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(730, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 15);
            this.label6.TabIndex = 14;
            this.label6.Text = "Shape Encode";
            // 
            // comboShapeEncode
            // 
            this.comboShapeEncode.FormattingEnabled = true;
            this.comboShapeEncode.Location = new System.Drawing.Point(730, 133);
            this.comboShapeEncode.Name = "comboShapeEncode";
            this.comboShapeEncode.Size = new System.Drawing.Size(117, 23);
            this.comboShapeEncode.TabIndex = 15;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(541, 31);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 22);
            this.button1.TabIndex = 16;
            this.button1.Text = "参照";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(541, 65);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(73, 22);
            this.button2.TabIndex = 17;
            this.button2.Text = "参照";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(541, 107);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(73, 22);
            this.button3.TabIndex = 18;
            this.button3.Text = "参照";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 386);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboShapeEncode);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboCSVEncode);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textShapeFileName);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnLine);
            this.Controls.Add(this.btnSymbol);
            this.Controls.Add(this.textDefFile);
            this.Controls.Add(this.textShapeDir);
            this.Controls.Add(this.textCsvFile);
            this.Font = new System.Drawing.Font("Meiryo UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "CreateShape";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textCsvFile;
        private System.Windows.Forms.TextBox textShapeDir;
        private System.Windows.Forms.TextBox textDefFile;
        private System.Windows.Forms.Button btnSymbol;
        private System.Windows.Forms.Button btnLine;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textShapeFileName;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ComboBox comboCSVEncode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboShapeEncode;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}


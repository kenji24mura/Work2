﻿/* 
 * CreateShape
 * CSVをsahpeに変換する
 * 
 * 
 * 初版:20241116 K.Nishimura
 * 
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Microsoft.VisualBasic.FileIO;
using System.Security.Cryptography;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace CreateShape
{
    public partial class Form1 : Form
    {
        public string DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];

        string shp_filename = "";
        string shx_filename = "";
        string dbf_filename = "";
        string def_filename = "";
        string csv_filename = "";


        List<POINT_DATA> points = new List<POINT_DATA>();
        List<FIELD_DATA> fields = new List<FIELD_DATA>();
        List<LINE_DATA> lines = new List<LINE_DATA>();


        private void Form1_Load(object sender, EventArgs e)
        {
            textCsvFile.Text = "C:\\D_DRV\\shape\\data\\csv\\sample.csv";
            textDefFile.Text = "C:\\D_DRV\\shape\\data\\def\\sample.def";

            textShapeDir.Text = DATA_PATH + "\\shape\\";
            textShapeFileName.Text = "sample";

            comboCSVEncode.Items.Add("shift-jis");
            comboCSVEncode.Items.Add("utf-8");
            comboCSVEncode.SelectedIndex = 0;

            comboShapeEncode.Items.Add("shift-jis");
            comboShapeEncode.Items.Add("utf-8");
            comboShapeEncode.SelectedIndex = 0;
        }

        public Form1()
        {
            InitializeComponent();
        }

        public void MsgOut(string msg)
        {
            DateTime dateTime = DateTime.Now;

            listBox1.Items.Add(dateTime+","+msg);
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
        }
        //---------------------
        //
        //---------------------

        public int ConvertInt(uint val)
        {
            int result = 0;

            result = (int)(
    ((val & 0xff000000) >> 24) |
    ((val & 0x00ff0000) >> 8) |
    ((val & 0x0000ff00) << 8) |
    ((val & 0x000000ff) << 24)
    );

            return result;

        }

        public void OutPutShp(int shape_type)
        {
            BinaryWriter bw = new BinaryWriter(new FileStream(shp_filename, FileMode.Create));

            //--- ヘッダ処理

            int data_cnt;

            int fcode = 9994;
            int rsv1 = 0;
            int rsv2 = 0;
            int rsv3 = 0;
            int rsv4 = 0;
            int rsv5 = 0;

            int file_len = 0;

            int version = 1000;
            Double Xmin = Double.MaxValue;
            Double Ymin = Double.MaxValue;
            Double Xmax = Double.MinValue;
            Double Ymax = Double.MinValue;
            Double Zmin = 0;
            Double Zmax = 0;
            Double Mmin = 0;
            Double Mmax = 0;


            if (shape_type == 1)
            {
                //POINT
                data_cnt = points.Count;
                file_len = (100 + (8 + 20) * data_cnt) / 2;//ワード単位[ ヘッダ:100 byte レコードヘッダ:8 レコード:shape type[4]+X[8]+Y[8] 

                bw.Write(ConvertInt((uint)fcode));
                bw.Write(ConvertInt((uint)rsv1));
                bw.Write(ConvertInt((uint)rsv2));
                bw.Write(ConvertInt((uint)rsv3));
                bw.Write(ConvertInt((uint)rsv4));
                bw.Write(ConvertInt((uint)rsv5));
                bw.Write(ConvertInt((uint)file_len));

                bw.Write(version);
                bw.Write(shape_type);

                foreach (var point_data in points)
                {

                    Double X = point_data.X;
                    Double Y = point_data.Y;

                    if (Xmin > X)
                    {
                        Xmin = X;
                    }
                    if (Ymin > Y)
                    {
                        Ymin = Y;
                    }
                    if (Xmax < X)
                    {
                        Xmax = X;
                    }
                    if (Ymax < Y)
                    {
                        Ymax = Y;
                    }

                }

                bw.Write(Xmin);
                bw.Write(Ymin);
                bw.Write(Xmax);
                bw.Write(Ymax);
                bw.Write(Zmin);
                bw.Write(Zmax);
                bw.Write(Mmin);
                bw.Write(Mmax);

                //--- レコード処理

                int rec_num = 0;

                foreach (var point_data in points)
                {

                    int rec_len = 4 + 8 + 8;//byte単位 レコードヘッダ:8 レコード:shape type[4]+X[8]+Y[8]

                    Double X = point_data.X;
                    Double Y = point_data.Y;

                    bw.Write(ConvertInt((uint)(rec_num + 1)));
                    bw.Write(ConvertInt((uint)(rec_len / 2)));

                    bw.Write(shape_type);
                    bw.Write(X);
                    bw.Write(Y);

                    rec_num++;
                }

            }
            else
            {
                //LINE
                data_cnt = lines.Count;

                int lines_len = 0;

                foreach (var lines_data in lines)
                {
                    int parts = 1;
                    int points = lines_data.lpoints.Count;

                    int rec_len = 8 + 4 + 32 + 4 + 4 + parts * 4 + points * 16;//レコードヘッダ[8]+shapetype[4]+Box[32]+parts[4]+points[4]+ parts * 4 + points * 16

                    lines_len += rec_len;
                }

                file_len = (100 + lines_len) / 2;//ワード単位

                bw.Write(ConvertInt((uint)fcode));
                bw.Write(ConvertInt((uint)rsv1));
                bw.Write(ConvertInt((uint)rsv2));
                bw.Write(ConvertInt((uint)rsv3));
                bw.Write(ConvertInt((uint)rsv4));
                bw.Write(ConvertInt((uint)rsv5));
                bw.Write(ConvertInt((uint)file_len));

                bw.Write(version);
                bw.Write(shape_type);

                foreach (var lines_data in lines)
                {
                    foreach (var lpoints in lines_data.lpoints)
                    {
                        Double X = lpoints.X;
                        Double Y = lpoints.Y;

                        if (Xmin > X)
                        {
                            Xmin = X;
                        }
                        if (Ymin > Y)
                        {
                            Ymin = Y;
                        }
                        if (Xmax < X)
                        {
                            Xmax = X;
                        }
                        if (Ymax < Y)
                        {
                            Ymax = Y;
                        }
                    }

                }

                bw.Write(Xmin);
                bw.Write(Ymin);
                bw.Write(Xmax);
                bw.Write(Ymax);
                bw.Write(Zmin);
                bw.Write(Zmax);
                bw.Write(Mmin);
                bw.Write(Mmax);

                //--- レコード処理
                int rec_num = 0;
                foreach (var lines_data in lines)
                {
                    int parts = 1;
                    int points = lines_data.lpoints.Count;

                    int rec_len = 4 + 32 + 4 + 4 + parts * 4 + points * 16;//byte単位 //shapetype[4]+Box[32]+parts[4]+points[4]+ parts * 4 + points * 16

                    bw.Write(ConvertInt((uint)(rec_num + 1)));
                    bw.Write(ConvertInt((uint)(rec_len / 2)));


                    bw.Write(shape_type);

                    bw.Write(Xmin);
                    bw.Write(Ymin);
                    bw.Write(Xmax);
                    bw.Write(Ymax);
                    bw.Write(parts);
                    bw.Write(points);

                    int idx = 0;
                    bw.Write(idx);

                    foreach (var lpoints in lines_data.lpoints)
                    {
                        Double X = lpoints.X;
                        Double Y = lpoints.Y;

                        bw.Write(X);
                        bw.Write(Y);
                    }
                    rec_num++;
                }

            }

            bw.Close();
        }
        public void OutPutShx(int shape_type)
        {
            BinaryWriter bw = new BinaryWriter(new FileStream(shx_filename, FileMode.Create));
            //--- ヘッダ処理

            int data_cnt;

            int fcode = 9994;
            int rsv1 = 0;
            int rsv2 = 0;
            int rsv3 = 0;
            int rsv4 = 0;
            int rsv5 = 0;
            int file_len = 0;
            int version = 1000;

            Double Xmin = Double.MaxValue;
            Double Ymin = Double.MaxValue;
            Double Xmax = Double.MinValue;
            Double Ymax = Double.MinValue;
            Double Zmin = 0;
            Double Zmax = 0;
            Double Mmin = 0;
            Double Mmax = 0;

            if (shape_type == 1)
            {
                //POINT
                data_cnt = points.Count;
                file_len = (100 + 8 * data_cnt) / 2;//ワード単位

                foreach (var point_data in points)
                {

                    Double X = point_data.X;
                    Double Y = point_data.Y;

                    if (Xmin > X)
                    {
                        Xmin = X;
                    }
                    if (Ymin > Y)
                    {
                        Ymin = Y;
                    }
                    if (Xmax < X)
                    {
                        Xmax = X;
                    }
                    if (Ymax < Y)
                    {
                        Ymax = Y;
                    }

                }
                bw.Write(ConvertInt((uint)fcode));
                bw.Write(ConvertInt((uint)rsv1));
                bw.Write(ConvertInt((uint)rsv2));
                bw.Write(ConvertInt((uint)rsv3));
                bw.Write(ConvertInt((uint)rsv4));
                bw.Write(ConvertInt((uint)rsv5));
                bw.Write(ConvertInt((uint)file_len));

                bw.Write(version);
                bw.Write(shape_type);

                bw.Write(Xmin);
                bw.Write(Ymin);
                bw.Write(Xmax);
                bw.Write(Ymax);
                bw.Write(Zmin);
                bw.Write(Zmax);
                bw.Write(Mmin);
                bw.Write(Mmax);

                //--- レコード処理

                int rec_num = 0;

                foreach (var point_data in points)
                {
                    int offset = 50 + ((8 + 20) / 2) * rec_num;//ワード単位
                    int rec_len = 4 + 8 + 8;

                    bw.Write(ConvertInt((uint)offset));
                    bw.Write(ConvertInt((uint)(rec_len / 2)));

                    rec_num++;
                }
            }
            else
            {
                //LINE
                data_cnt = lines.Count;
                file_len = (100 + 8 * data_cnt) / 2;//ワード単位

                bw.Write(ConvertInt((uint)fcode));
                bw.Write(ConvertInt((uint)rsv1));
                bw.Write(ConvertInt((uint)rsv2));
                bw.Write(ConvertInt((uint)rsv3));
                bw.Write(ConvertInt((uint)rsv4));
                bw.Write(ConvertInt((uint)rsv5));
                bw.Write(ConvertInt((uint)file_len));

                bw.Write(version);
                bw.Write(shape_type);

                foreach (var lines_data in lines)
                {
                    foreach (var lpoints in lines_data.lpoints)
                    {
                        Double X = lpoints.X;
                        Double Y = lpoints.Y;

                        if (Xmin > X)
                        {
                            Xmin = X;
                        }
                        if (Ymin > Y)
                        {
                            Ymin = Y;
                        }
                        if (Xmax < X)
                        {
                            Xmax = X;
                        }
                        if (Ymax < Y)
                        {
                            Ymax = Y;
                        }
                    }

                }

                bw.Write(Xmin);
                bw.Write(Ymin);
                bw.Write(Xmax);
                bw.Write(Ymax);
                bw.Write(Zmin);
                bw.Write(Zmax);
                bw.Write(Mmin);
                bw.Write(Mmax);

                //オフセットを計算して設定する
                int offset = 50;

                foreach (var lines_data in lines)
                {

                    int parts = 1;
                    int points = lines_data.lpoints.Count;

                    int rec_len = 4 + 32 + 4 + 4 + parts * 4 + points * 16;//byte単位 //shapetype[4]+Box[32]+parts[4]+points[4]+ parts * 4 + points * 16

                    bw.Write(ConvertInt((uint)offset));
                    bw.Write(ConvertInt((uint)(rec_len / 2)));

                    offset += (8 + rec_len) / 2;//ワード単位

                }

            }

            bw.Close();
        }
        public void OutPutDbf(int shape_type)
        {
            DateTime dateTime = DateTime.Now;
            string str_encoding = comboShapeEncode.Text;

            File.Delete(dbf_filename);

            BinaryWriter bw = new BinaryWriter(new FileStream(dbf_filename, FileMode.Create));

            //フィールド情報
            int filelds_cnt = fields.Count;

            //----- header start


            int rec_num = points.Count;

            if (shape_type == 1)
            {
                rec_num = points.Count;
            }
            else
            {
                rec_num = lines.Count;
            }

//            short header_size = (short)(32 + 32 * filelds_cnt);
            short header_size = (short)(32 + 32 * filelds_cnt+1);
            short rec_size = 0;

            byte h_head = 0x03;
            byte[] h_date = new byte[3];
            byte[] rsv = new byte[20];

            byte end_of_head = 0x0d;
            h_date[0] = (byte)dateTime.Year;
            h_date[1] = (byte)dateTime.Month;
            h_date[2] = (byte)dateTime.Day;

            foreach (var field in fields)
            {
                rec_size += field.Field_len;
            }
            rec_size++;


            bw.Write(h_head);
            bw.Write(h_date);
            bw.Write(rec_num);
            bw.Write(header_size);
            bw.Write(rec_size);
            bw.Write(rsv);


            //--- field start
            foreach (var field in fields)
            {
                byte[] fileld_name = new byte[11];
                byte[] fileld_type = new byte[1];
                byte[] fileld_rsv = new byte[4];
                byte[] fileld_len = new byte[1];
                byte[] fileld_len2 = new byte[1];
                byte[] fileld_rsv2 = new byte[14];


                byte[] byteArray1 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(field.Field_name);
                Array.Copy(byteArray1, 0, fileld_name, 0, byteArray1.Length);

                byte[] byteArray2 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(field.Field_type);
                Array.Copy(byteArray2, 0, fileld_type, 0, byteArray2.Length);

                fileld_len[0] = (byte)field.Field_len;
                fileld_len2[0] = (byte)field.Field_len2;

                bw.Write(fileld_name);
                bw.Write(fileld_type);
                bw.Write(fileld_rsv);
                bw.Write(fileld_len);
                bw.Write(fileld_len2);
                bw.Write(fileld_rsv2);

            }
            //--- field end

            bw.Write(end_of_head);

            //----- header end

            if (shape_type == 1)
            {
                foreach (var point_data in points)
                {
                    string info1 = point_data.info1;
                    string info2 = point_data.info2;
                    string info3 = point_data.info3;
                    string info4 = point_data.info4;
                    string info5 = point_data.info5;
                    string info6 = point_data.info6;

                    byte[] b_info1 = new byte[20];
                    byte[] b_info2 = new byte[20];
                    byte[] b_info3 = new byte[20];
                    byte[] b_info4 = new byte[100];
                    byte[] b_info5 = new byte[20];
                    byte[] b_info6 = new byte[20];

                    byte[] byteArray1 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info1);
                    Array.Copy(byteArray1, 0, b_info1, 0, byteArray1.Length);
                    byte[] byteArray2 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info2);
                    Array.Copy(byteArray2, 0, b_info2, 0, byteArray2.Length);
                    byte[] byteArray3 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info3);
                    Array.Copy(byteArray3, 0, b_info3, 0, byteArray3.Length);
                    byte[] byteArray4 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info4);
                    Array.Copy(byteArray4, 0, b_info4, 0, byteArray4.Length);
                    byte[] byteArray5 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info5);
                    Array.Copy(byteArray5, 0, b_info5, 0, byteArray5.Length);
                    byte[] byteArray6 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info6);
                    Array.Copy(byteArray6, 0, b_info6, 0, byteArray6.Length);

                    byte update_flg = 0x20;

                    bw.Write(update_flg);
                    bw.Write(b_info1);
                    bw.Write(b_info2);
                    bw.Write(b_info3);
                    bw.Write(b_info4);
                    bw.Write(b_info5);
                    bw.Write(b_info6);

                }

            }
            else
            {
                foreach (var lines_data in lines)
                {
                    string info1 = lines_data.info1;
                    string info2 = lines_data.info2;
                    string info3 = lines_data.info3;
                    string info4 = lines_data.info4;
                    string info5 = lines_data.info5;
                    string info6 = lines_data.info6;

                    byte[] b_info1 = new byte[20];
                    byte[] b_info2 = new byte[20];
                    byte[] b_info3 = new byte[20];
                    byte[] b_info4 = new byte[100];
                    byte[] b_info5 = new byte[20];
                    byte[] b_info6 = new byte[20];

                    byte[] byteArray1 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info1);
                    Array.Copy(byteArray1, 0, b_info1, 0, byteArray1.Length);
                    byte[] byteArray2 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info2);
                    Array.Copy(byteArray2, 0, b_info2, 0, byteArray2.Length);
                    byte[] byteArray3 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info3);
                    Array.Copy(byteArray3, 0, b_info3, 0, byteArray3.Length);
                    byte[] byteArray4 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info4);
                    Array.Copy(byteArray4, 0, b_info4, 0, byteArray4.Length);
                    byte[] byteArray5 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info5);
                    Array.Copy(byteArray5, 0, b_info5, 0, byteArray5.Length);
                    byte[] byteArray6 = System.Text.Encoding.GetEncoding(str_encoding).GetBytes(info6);
                    Array.Copy(byteArray6, 0, b_info6, 0, byteArray6.Length);

                    byte update_flg = 0x20;//削除フラグ　[0x20:通常 0x2A:削除]

                    bw.Write(update_flg);
                    bw.Write(b_info1);
                    bw.Write(b_info2);
                    bw.Write(b_info3);
                    bw.Write(b_info4);
                    bw.Write(b_info5);
                    bw.Write(b_info6);

                }

            }
            //終端に　0x1A を出力
            byte end_of_file = 0x1a;
            bw.Write(end_of_file);

            bw.Close();
        }

        public void ReadData(int shape_type)
        {
            points.Clear();
            lines.Clear();

            string str_encoding = comboCSVEncode.Text;

            try
            {
                using (TextFieldParser parser = new TextFieldParser(csv_filename, Encoding.GetEncoding(str_encoding)))
                {
                    //カンマ区切りのcsv形式にする
                    parser.TextFieldType = FieldType.Delimited;
                    parser.Delimiters = new string[] { "," };

                    int PointCnt = 0;
                    int LineCnt = 0;

                    //最後まで繰り返す
                    while (!parser.EndOfData)
                    {
                        parser.HasFieldsEnclosedInQuotes = true;

                        parser.TrimWhiteSpace = false;

                        //フィールド作成
                        string[] param = parser.ReadFields();

                        string REMBAN = param[0];
                        string P_REMBAN = param[1];
                        string L_NO = param[2];
                        string L_TYPE = param[3];
                        string COUNT = param[4];
                        string rsv1 = param[5];
                        string ZAHYO = param[6];
                        string rsv2 = param[7];
                        string RECT_LT_X = param[8];
                        string RECT_LT_Y = param[9];
                        string RECT_RB_X = param[10];
                        string RECT_RB_Y = param[11];
                        string SYMBOL = param[12];
                        string rsv3 = param[13];
                        string TEXT = param[14];
                        string rsv4 = param[15];
                        string TEXT_SIZE = param[16];
                        string DATA_ANGLE = param[17];
                        string TY_FLG = param[18];
                        string rsv5 = param[19];
                        string K_NO = param[20];
                        string rsv6 = param[21];
                        string rsv7 = param[22];
                        string SYO_CD = param[23];
                        string rsv8 = param[24];
                        string rsv9 = param[25];
                        string USER_ID = param[26];
                        string rsv10 = param[27];
                        string U_KB = param[28];
                        string rsv11 = param[29];
                        string T_DATE = param[30];

                        if (shape_type == 1)
                        {
                            //文字
                            if (L_TYPE.IndexOf("2") == 0)
                            {
                                if (TEXT.Length > 0)
                                {
                                    string[] ZAHYO_PARAM = ZAHYO.Split(new char[] { ',' });

                                    Double ZX = Double.Parse(ZAHYO_PARAM[0])/1000;
                                    Double ZY = Double.Parse(ZAHYO_PARAM[1])/1000;

                                    points.Add(new POINT_DATA { X = ZX, Y = ZY, info1 = L_NO, info2 = L_TYPE, info3 = SYMBOL, info4 = TEXT, info5 = TEXT_SIZE, info6 = DATA_ANGLE });
                                    PointCnt++;
                                }
                            }
                            if (L_TYPE.IndexOf("3") == 0)
                            {
                                string[] ZAHYO_PARAM = ZAHYO.Split(new char[] { ',' });

                                Double ZX = Double.Parse(ZAHYO_PARAM[0]) / 1000;
                                Double ZY = Double.Parse(ZAHYO_PARAM[1]) / 1000;

                                points.Add(new POINT_DATA { X = ZX, Y = ZY, info1 = L_NO, info2 = L_TYPE, info3 = SYMBOL, info4 = TEXT, info5 = TEXT_SIZE, info6 = DATA_ANGLE });
                                PointCnt++;
                            }
                        }
                        else
                        {
                            if (L_TYPE.IndexOf("0") == 0)
                            {
                                //POLY LINE
                                string[] ZAHYO_PARAM = ZAHYO.Split(new char[] { ',' });

                                List<POINT> lp = new List<POINT>();

                                for (int j = 0; j < ZAHYO_PARAM.Length / 2; j++)
                                {
                                    POINT p = new POINT();

                                    p.X = Double.Parse(ZAHYO_PARAM[j * 2])/1000;
                                    p.Y = Double.Parse(ZAHYO_PARAM[j * 2 + 1]) / 1000;
                                    lp.Add(p);
                                }

                                lines.Add(new LINE_DATA { lpoints = lp, info1 = L_NO, info2 = L_TYPE, info3 = SYMBOL, info4 = TEXT, info5 = TEXT_SIZE, info6 = DATA_ANGLE });
                                LineCnt++;                            
                            }

                        }

                    }

                    MsgOut("PointCnt=" + PointCnt);
                    MsgOut("LineCnt=" + LineCnt);
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void LoadDef(int shape_type)
        {
            fields.Clear();

            try
            {
                StreamReader sr = new StreamReader(def_filename, Encoding.UTF8);

                string line = sr.ReadLine();


                while (line != null)
                {
                    if (line.Substring(0, 1).IndexOf("#") == 0)
                    {
                        //コメント行
                    }
                    else
                    {
                        string[] param = line.Split(new char[] { ',' });

                        short len = Int16.Parse(param[2]);
                        short len2 = Int16.Parse(param[3]);

                        fields.Add(new FIELD_DATA { Field_name = param[0], Field_type = param[1], Field_len = len, Field_len2 = len2 });

                    }
                    line = sr.ReadLine();
                }
                sr.Close();
            }
            catch (Exception ex)
            {
            }
        }

        private void btnSymbol_Click(object sender, EventArgs e)
        {
            int shape_type;
            shape_type = 1;

                MsgOut("POINT 出力開始");

            shp_filename = textShapeDir.Text + textShapeFileName.Text+"_point.shp";
            shx_filename = textShapeDir.Text + textShapeFileName.Text + "_point.shx";
            dbf_filename = textShapeDir.Text + textShapeFileName.Text + "_point.dbf";
            def_filename = textDefFile.Text;
            csv_filename = textCsvFile.Text;

            LoadDef(shape_type);

            ReadData(shape_type);

            MsgOut("shp 出力");
            OutPutShp(shape_type);
            MsgOut("shx 出力");
            OutPutShx(shape_type);
            MsgOut("dbf 出力");
            OutPutDbf(shape_type);

            MsgOut("POINT 出力終了");

        }

        private void btnLine_Click(object sender, EventArgs e)
        {
            int shape_type;
            shape_type = 3;

            MsgOut("LINE 出力開始");

            shp_filename = textShapeDir.Text + textShapeFileName.Text + "_line.shp";
            shx_filename = textShapeDir.Text + textShapeFileName.Text + "_line.shx";
            dbf_filename = textShapeDir.Text + textShapeFileName.Text + "_line.dbf";
            def_filename = textDefFile.Text;
            csv_filename = textCsvFile.Text;

            LoadDef(shape_type);

            ReadData(shape_type);

            MsgOut("shp 出力");
            OutPutShp(shape_type);
            MsgOut("shx 出力");
            OutPutShx(shape_type);
            MsgOut("dbf 出力");
            OutPutDbf(shape_type);

            MsgOut("LINE 出力終了");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofDialog = new OpenFileDialog();

            // デフォルトのフォルダを指定する
            ofDialog.InitialDirectory = DATA_PATH;
            ofDialog.Filter = "CSVファイル(*.csv)|*.csv|すべてのファイル(*.*)|*.*";

            //ダイアログのタイトルを指定する
            ofDialog.Title = "CSV選択";

            //ダイアログを表示する
            if (ofDialog.ShowDialog() == DialogResult.OK)
            {
                textCsvFile.Text = ofDialog.FileName;
                textShapeFileName.Text = Path.GetFileNameWithoutExtension(textCsvFile.Text);
            }
            else
            {
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofDialog = new OpenFileDialog();

            // デフォルトのフォルダを指定する
            ofDialog.InitialDirectory = DATA_PATH;
            ofDialog.Filter = "DEFファイル(*.def)|*.def|すべてのファイル(*.*)|*.*";

            //ダイアログのタイトルを指定する
            ofDialog.Title = "DEF選択";

            //ダイアログを表示する
            if (ofDialog.ShowDialog() == DialogResult.OK)
            {
                textDefFile.Text = ofDialog.FileName;
            }
            else
            {
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dialog = new FolderBrowserDialog();

            // 初期選択フォルダーが設定できる①
            dialog.SelectedPath = DATA_PATH;

            // ダイアログに表示する説明文を設定できる②
            dialog.Description = "shape フォルダ選択";

            // 新しくフォルダを作成を許可する②
            dialog.ShowNewFolderButton = false;

            // ダイアログを表示する。
            DialogResult result = dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                // 選択されたフォルダを取得する
                textShapeDir.Text = dialog.SelectedPath;

            }
            else
            {
                // キャンセルの場合は何もしない
            }
        }
    }
}
class POINT_DATA
{
    public Double X { get; set; }
    public Double Y { get; set; }
    public string info1 { get; set; }
    public string info2 { get; set; }
    public string info3 { get; set; }
    public string info4 { get; set; }
    public string info5 { get; set; }
    public string info6 { get; set; }
}
class LINE_DATA
{
    public List<POINT> lpoints { get; set; }
    public string info1 { get; set; }
    public string info2 { get; set; }
    public string info3 { get; set; }
    public string info4 { get; set; }
    public string info5 { get; set; }
    public string info6 { get; set; }
}
class POINT
{
    public Double X { get; set; }
    public Double Y { get; set; }
}
class FIELD_DATA
{
    public string Field_name { get; set; }
    public string Field_type { get; set; }
    public short Field_len { get; set; }
    public short Field_len2 { get; set; }
}

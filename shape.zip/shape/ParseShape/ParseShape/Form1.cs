﻿/* 
 * ParseShape
 * sahpeをParseする
 * 
 * 
 * 初版:20241116 K.Nishimura
 * 
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ParseShape
{
    public partial class Form1 : Form
    {
        public string DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textFileName.Text = "";
            string path = DATA_PATH;
            textDirectoryName.Text = path;

            LoadList(path);

            comboShapeEncode.Items.Add("shift-jis");
            comboShapeEncode.Items.Add("utf-8");
            comboShapeEncode.SelectedIndex = 0;


        }

        public int ConvertInt(uint val)
        {
            int result = 0;

            result = (int)(
    ((val & 0xff000000) >> 24) |
    ((val & 0x00ff0000) >> 8) |
    ((val & 0x0000ff00) << 8) |
    ((val & 0x000000ff) << 24)
    );

            return result;

        }
        private void MsgOut(string msg,ListBox lb)
        {
            lb.Items.Add(msg);
        }

        private void LoadList(string path)
        {
            listBox1.Items.Clear();
            // ディレクトリ直下のすべてのファイル一覧を取得する
            string[] fiAlls = Directory.GetFiles(path);
            foreach (string f in fiAlls)
            {
                listBox1.Items.Add(f);
            }
        }


        public void ParseShp(string fname,ListBox lb)
        {
            double Xmin = 0;
            double Ymin = 0;
            double Xmax = 0;
            double Ymax = 0;
            double Zmin = 0;
            double Zmax = 0;
            double Mmin = 0;
            double Mmax = 0;


            //ファイルヘッダ処理
            FileStream fs = new FileStream(fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            int fcode = br.ReadInt32();
            fcode = ConvertInt((uint)fcode);

            MsgOut("ファイルコード:" + fcode.ToString(),lb);

            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用

            int flen = br.ReadInt32();
            flen = ConvertInt((uint)flen);

            MsgOut("ファイル長:" + flen.ToString(), lb);

            int version = br.ReadInt32();

            MsgOut("バージョン:" + version.ToString(), lb);

            int shapetype = br.ReadInt32();

            MsgOut("シェープタイプ:" + shapetype.ToString(), lb);

            Xmin = br.ReadDouble();
            Ymin = br.ReadDouble();
            Xmax = br.ReadDouble();
            Ymax = br.ReadDouble();
            Zmin = br.ReadDouble();
            Zmax = br.ReadDouble();
            Mmin = br.ReadDouble();
            Mmax = br.ReadDouble();

            MsgOut("Xmin:" + Xmin.ToString(), lb);
            MsgOut("Ymin:" + Ymin.ToString(), lb);
            MsgOut("Xmax:" + Xmax.ToString(), lb);
            MsgOut("Ymax:" + Ymax.ToString(), lb);
            MsgOut("Zmin:" + Zmin.ToString(), lb);
            MsgOut("Mmin:" + Mmin.ToString(), lb);
            MsgOut("Mmax:" + Mmax.ToString(), lb);

            bool IsEOF = false;


            int line_cnt = 0;
            int poly_cnt = 0;
            int symbol_cnt = 0;


            //レコードヘッダ
            while (!IsEOF)
            {
                try
                {
                    long cur = fs.Seek(0, SeekOrigin.Current);
                    //MsgOut("カレントポイント:" + cur.ToString());

                    if (cur >= flen * 2)
                    {
                        MsgOut("ファイル終端です", lb);
                        IsEOF = true;
                    }
                    else
                    {

                        int recnum = br.ReadInt32();
                        recnum = ConvertInt((uint)recnum);

                        MsgOut("レコード番号:"+ recnum, lb);
                            
                        int reclen = br.ReadInt32();
                        reclen = ConvertInt((uint)reclen);

                        MsgOut("コンテンツ長:" + reclen, lb);


                        byte[] buf = new byte[reclen * 2];
                        buf = br.ReadBytes(reclen * 2);
//                        byte[] buf = new byte[reclen];
//                        buf = br.ReadBytes(reclen);

                        int offset = 0;
                        int type = BitConverter.ToInt32(buf, offset);
                        offset += 4;

                        double[] Box = new double[4];

                        int NumParts = 0;
                        int NumPoint = 0;

                        double dx;
                        double dy;

                        MsgOut("★シェープタイプ:" + type.ToString(), lb);
                        switch (type)
                        {
                            case 0:// Null Shape
                                break;
                            case 1: //Point

                                Point ps = new Point();
                                dx = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                dy = BitConverter.ToDouble(buf, offset);
                                offset += 8;


                                MsgOut("dx=" + dx + ",dy=" + dy, lb);

                                break;
                            case 3: //PolyLine


                                Box[0] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[1] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[2] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[3] = BitConverter.ToDouble(buf, offset);
                                offset += 8;

                                NumParts = BitConverter.ToInt32(buf, offset);
                                offset += 4;
                                MsgOut("NumParts:" + NumParts.ToString(), lb);


                                int NumPoints = BitConverter.ToInt32(buf, offset);
                                offset += 4;
                                MsgOut("NumPoints:" + NumPoints.ToString(), lb);

                                for (int i = 0; i < NumParts; i++)
                                {
                                    int Parts = BitConverter.ToInt32(buf, offset);
                                    offset += 4;
                                }

                                Point[] p = new Point[NumPoints];
                                for (int i = 0; i < NumPoints; i++)
                                {
                                    dx = BitConverter.ToDouble(buf, offset);
                                    offset += 8;
                                    dy = BitConverter.ToDouble(buf, offset);
                                    offset += 8;
                                    MsgOut("dx=" + dx + ",dy=" + dy, lb);

                                }

                                break;
                            case 5: //Polygon

                                /*
                                if (checkPolygon.Checked == false) break;
                                */
                                Box[0] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[1] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[2] = BitConverter.ToDouble(buf, offset);
                                offset += 8;
                                Box[3] = BitConverter.ToDouble(buf, offset);
                                offset += 8;

                                NumParts = BitConverter.ToInt32(buf, offset);
                                offset += 4;
                                MsgOut("NumParts:" + NumParts.ToString(), lb);


                                NumPoints = BitConverter.ToInt32(buf, offset);
                                offset += 4;
                                MsgOut("NumPoints:" + NumPoints.ToString(), lb);

                                for (int i = 0; i < NumParts; i++)
                                {
                                    int Parts = BitConverter.ToInt32(buf, offset);
                                    offset += 4;
                                }

                                Point[] pl = new Point[NumPoints];
                                for (int i = 0; i < NumPoints; i++)
                                {
                                    dx = BitConverter.ToDouble(buf, offset);
                                    offset += 8;
                                    dy = BitConverter.ToDouble(buf, offset);
                                    offset += 8;
                                    MsgOut("dx=" + dx + ",dy=" + dy, lb);

                                }

                                break;
                            case 8: //MultiPoint
                                break;
                            case 11: //PointZ
                                break;
                            case 13: //PolyLineZ
                                break;
                            case 15: //PolygonZ
                                break;
                            case 18: //MultiPointZ
                                break;
                            case 21: //PointM
                                break;
                            case 23: //PolyLineM
                                break;
                            case 25: //PolygonM
                                break;
                            case 28: //MultiPointM
                                break;
                            case 31: //MultiPatch
                                break;
                            default:
                                break;
                        }
                    }

                }
                catch (Exception ex)
                {
                    IsEOF = true;
                }

            }

            fs.Close();
            br.Close();

        }
        public void ParseShx(string fname,ListBox lb)
        {
            double Xmin = 0;
            double Ymin = 0;
            double Xmax = 0;
            double Ymax = 0;
            double Zmin = 0;
            double Zmax = 0;
            double Mmin = 0;
            double Mmax = 0;


            //ファイルヘッダ処理
            FileStream fs = new FileStream(fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            int fcode = br.ReadInt32();
            fcode = ConvertInt((uint)fcode);

            MsgOut("ファイルコード:" + fcode.ToString(), lb);

            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用
            br.ReadInt32();//未使用

            int flen = br.ReadInt32();
            flen = ConvertInt((uint)flen);// flenはワード(2byte)単位

            MsgOut("ファイル長:" + flen.ToString(), lb);

            int version = br.ReadInt32();

            MsgOut("バージョン:" + version.ToString(), lb);

            int shapetype = br.ReadInt32();

            MsgOut("シェープタイプ:" + shapetype.ToString(), lb);

            Xmin = br.ReadDouble();
            Ymin = br.ReadDouble();
            Xmax = br.ReadDouble();
            Ymax = br.ReadDouble();
            Zmin = br.ReadDouble();
            Zmax = br.ReadDouble();
            Mmin = br.ReadDouble();
            Mmax = br.ReadDouble();

            MsgOut("Xmin:" + Xmin.ToString(), lb);
            MsgOut("Ymin:" + Ymin.ToString(), lb);
            MsgOut("Xmax:" + Xmax.ToString(), lb);
            MsgOut("Ymax:" + Ymax.ToString(), lb);
            MsgOut("Zmin:" + Zmin.ToString(), lb);
            MsgOut("Mmin:" + Mmin.ToString(), lb);
            MsgOut("Mmax:" + Mmax.ToString(), lb);


            //------- レコード部 ----------------
            bool IsEOF = false;
            int cnt = 0;

            while (!IsEOF)
            {
                try
                {
                    long cur = fs.Seek(0, SeekOrigin.Current);

                    if (cur >= flen * 2)
                    {
                        MsgOut("ファイル終端です", lb);
                        IsEOF = true;
                    }
                    else
                    {
                        cnt++;

                        MsgOut("レコード番号:" + cnt, lb);

                        int offset = br.ReadInt32();
                        offset = ConvertInt((uint)offset);

                        MsgOut("オフセット:" + offset, lb);

                        int cont_len = br.ReadInt32();
                        cont_len = ConvertInt((uint)cont_len);

                        MsgOut("コンテンツ長:" + cont_len, lb);
                    }
                }
                catch (Exception ex)
                {
                    IsEOF = true;
                }

            }


            fs.Close();
            br.Close();
        }
        public void ParseDbf(string fname,ListBox lb)
        {
            string str_encoding = comboShapeEncode.Text;

            FileStream fs = new FileStream(fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            //--ヘッダ処理----------------------------------------------------------------

            int reccnt = 0;
            int headsize = 0;
            int recsize = 0;
            int filelds_cnt = 0;

            byte hb;
            hb = br.ReadByte();
            int offset = 1;

            byte[] strbuf = new byte[3];

            strbuf = br.ReadBytes(3);
            offset += 3;

            short yy = (short)strbuf[0];
            short mm = (short)strbuf[1];
            short dd = (short)strbuf[2];

            MsgOut("更新日:" + yy + "/" + mm + "/" + dd, lb);

            byte[] int32buf = new byte[4];

            int32buf = br.ReadBytes(4);
            reccnt = BitConverter.ToInt32(int32buf, 0);
            MsgOut("レコード数:" + reccnt.ToString(), lb);

            offset += 4;

            byte[] int16buf = new byte[2];
            int16buf = br.ReadBytes(2);
            headsize = BitConverter.ToInt16(int16buf, 0);
            MsgOut("headsize:" + headsize.ToString(), lb);

            int16buf = br.ReadBytes(2);
            recsize = BitConverter.ToInt16(int16buf, 0);
            MsgOut("recsize:" + recsize.ToString(), lb);

            byte[] wb = new byte[20];
            wb = br.ReadBytes(20);

            filelds_cnt = headsize / 32 -1;

            string[] s_fileld_name = new string[filelds_cnt];
            string[] s_fileld_type = new string[filelds_cnt];
            short[] filels_len = new short[filelds_cnt];
            short[] filels_len2 = new short[filelds_cnt];

            for (int i = 0; i < filelds_cnt; i++)
            {
                byte[] filelds = new byte[32];

                filelds = br.ReadBytes(32);

                byte[] fileld_name = new byte[11];
                byte[] fileld_type = new byte[1];
                byte[] fileld_rsv = new byte[4];
                byte[] fileld_len = new byte[1];
                byte[] fileld_len2 = new byte[1];
                byte[] fileld_rsv2 = new byte[14];

                int f_offset = 0;

                Array.Copy(filelds, f_offset, fileld_name, 0, 11);
                f_offset += 11;

                s_fileld_name[i] = System.Text.Encoding.GetEncoding(str_encoding).GetString(fileld_name);

                Array.Copy(filelds, f_offset, fileld_type, 0, 1);
                f_offset += 1;
                s_fileld_type[i] = System.Text.Encoding.GetEncoding(str_encoding).GetString(fileld_type);


                Array.Copy(filelds, f_offset, fileld_rsv, 0, 4);
                f_offset += 4;

                Array.Copy(filelds, f_offset, fileld_len, 0, 1);
                f_offset += 1;
                filels_len[i] = fileld_len[0];

                Array.Copy(filelds, f_offset, fileld_len2, 0, 1);
                f_offset += 1;
                filels_len2[i] = fileld_len2[0];

                Array.Copy(filelds, f_offset, fileld_rsv2, 0, 14);
                f_offset += 14;

                s_fileld_name[i] = s_fileld_name[i].TrimEnd('\0');
                MsgOut("フィールド名:" + s_fileld_name[i]+ ",フィールドタイプ:" + s_fileld_type[i]+ ",フィールド長:" + filels_len[i], lb);

            }

            byte End_OF_Header;
            End_OF_Header = br.ReadByte();//OD

            /* [フィールドタイプ]
            C:(Character)任意のOEMコードページ文字
            D:(Date)年月日をあらわす数字および文字（内部表現は8桁のYYYYMMDD形式）
            F:(Floating point binary numeric)- . 0 1 2 3 4 5 6 7 8 9
            N:(Binary codeddecimal numeric)- . 0 1 2 3 4 5 6 7 8 9
            L:(Logical)? Y y N n T t F f（初期値設定しない場合は? になる）
            M:(Memo)任意のOEMコードページ文字(内部表現は10桁の.DBTブロック番号）
            */

            //--レコード数分繰り返し----------------------------------------------------------------

            for (int i = 0; i < reccnt; i++)
            {
                byte[] recbuf = new byte[recsize];
                recbuf = br.ReadBytes(recsize);


                MsgOut("レコード番号:" + (i+1), lb);

                int fi_offset = 1;

                for (int j = 0;j< filelds_cnt; j++)
                {
                    byte[] wrkbuf = new byte[filels_len[j]];
                    Array.Copy(recbuf, fi_offset, wrkbuf, 0, filels_len[j]);

                    string value = Encoding.GetEncoding(str_encoding).GetString(wrkbuf);
                    MsgOut(s_fileld_name[j] + ":" + value,lb);

                    fi_offset += filels_len[j];
                }

            }


            fs.Close();
            br.Close();

        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = listBox1.SelectedIndex;

            textFileName.Text = listBox1.Items[idx].ToString();
        }


        private void btnParse_Click(object sender, EventArgs e)
        {
            string fname = textFileName.Text;

            string ext = Path.GetExtension(fname);

            if (ext.IndexOf(".shp") == 0)
            {
                listShp.Items.Clear();
                ParseShp(fname,listShp);
            }
            if (ext.IndexOf(".shx") == 0)
            {
                listShx.Items.Clear();
                ParseShx(fname,listShx);
            }
            if (ext.IndexOf(".dbf") == 0)
            {
                listDbf.Items.Clear();
                ParseDbf(fname,listDbf);
            }

        }

        private void btnSelectDir_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbDialog = new FolderBrowserDialog();

            // ダイアログの説明文を指定する
            fbDialog.Description = "ダイアログの説明文";

            // デフォルトのフォルダを指定する
            fbDialog.SelectedPath = textDirectoryName.Text;

            // 「新しいフォルダーの作成する」ボタンを表示する
            fbDialog.ShowNewFolderButton = true;

            //フォルダを選択するダイアログを表示する
            if (fbDialog.ShowDialog() == DialogResult.OK)
            {
                textDirectoryName.Text = fbDialog.SelectedPath;

                LoadList(textDirectoryName.Text);
            }
            else
            {
                Console.WriteLine("キャンセルされました");
            }
        }
        private void SaveToFile(ListBox lb,string SaveFileName)
        {
            DateTime dt = DateTime.Now;
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.FileName = dt.ToString("yyyyMMddhhMMss")+"_"+SaveFileName;
            sfd.InitialDirectory = DATA_PATH;
            sfd.Filter = "テキストファイル(*.txt)|*.txt|すべてのファイル(*.*)|*.*";
            sfd.FilterIndex = 2;
            sfd.Title = "保存先のファイルを選択してください";
            sfd.RestoreDirectory = true;
            sfd.OverwritePrompt = true;
            sfd.CheckPathExists = true;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    StreamWriter sw = new StreamWriter(sfd.FileName);

                    for(int i =0;i<lb.Items.Count; i++)
                    {

                        string line = lb.Items[i].ToString();
                        sw.WriteLine(line);
                    }

                    sw.Close();
                }
                catch (Exception ex)
                {

                }
                Console.WriteLine(sfd.FileName);
            }
        }

        private void btnSaveShp_Click(object sender, EventArgs e)
        {
            string SaveFileName = "shp.txt";
            SaveToFile(listShp,SaveFileName);
        }

        private void btnSaveShx_Click(object sender, EventArgs e)
        {
            string SaveFileName = "shx.txt";
            SaveToFile(listShx,SaveFileName);
        }

        private void btnSaveDbf_Click(object sender, EventArgs e)
        {
            string SaveFileName = "dbf.txt";
            SaveToFile(listDbf,SaveFileName);
        }
    }
}

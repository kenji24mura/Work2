﻿
namespace ParseShape
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnParse = new System.Windows.Forms.Button();
            this.textFileName = new System.Windows.Forms.TextBox();
            this.listShp = new System.Windows.Forms.ListBox();
            this.btnSelectDir = new System.Windows.Forms.Button();
            this.textDirectoryName = new System.Windows.Forms.TextBox();
            this.comboShapeEncode = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.listShx = new System.Windows.Forms.ListBox();
            this.listDbf = new System.Windows.Forms.ListBox();
            this.btnSaveShp = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnSaveShx = new System.Windows.Forms.Button();
            this.btnSaveDbf = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(34, 89);
            this.listBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(853, 199);
            this.listBox1.TabIndex = 0;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btnParse
            // 
            this.btnParse.Location = new System.Drawing.Point(728, 310);
            this.btnParse.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnParse.Name = "btnParse";
            this.btnParse.Size = new System.Drawing.Size(159, 63);
            this.btnParse.TabIndex = 1;
            this.btnParse.Text = "Parse";
            this.btnParse.UseVisualStyleBackColor = true;
            this.btnParse.Click += new System.EventHandler(this.btnParse_Click);
            // 
            // textFileName
            // 
            this.textFileName.Location = new System.Drawing.Point(34, 310);
            this.textFileName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textFileName.Name = "textFileName";
            this.textFileName.Size = new System.Drawing.Size(550, 23);
            this.textFileName.TabIndex = 2;
            // 
            // listShp
            // 
            this.listShp.FormattingEnabled = true;
            this.listShp.ItemHeight = 15;
            this.listShp.Location = new System.Drawing.Point(35, 427);
            this.listShp.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listShp.Name = "listShp";
            this.listShp.Size = new System.Drawing.Size(354, 274);
            this.listShp.TabIndex = 3;
            // 
            // btnSelectDir
            // 
            this.btnSelectDir.Location = new System.Drawing.Point(34, 36);
            this.btnSelectDir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSelectDir.Name = "btnSelectDir";
            this.btnSelectDir.Size = new System.Drawing.Size(78, 36);
            this.btnSelectDir.TabIndex = 4;
            this.btnSelectDir.Text = "選択";
            this.btnSelectDir.UseVisualStyleBackColor = true;
            this.btnSelectDir.Click += new System.EventHandler(this.btnSelectDir_Click);
            // 
            // textDirectoryName
            // 
            this.textDirectoryName.Location = new System.Drawing.Point(129, 44);
            this.textDirectoryName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textDirectoryName.Name = "textDirectoryName";
            this.textDirectoryName.Size = new System.Drawing.Size(677, 23);
            this.textDirectoryName.TabIndex = 5;
            // 
            // comboShapeEncode
            // 
            this.comboShapeEncode.FormattingEnabled = true;
            this.comboShapeEncode.Location = new System.Drawing.Point(35, 369);
            this.comboShapeEncode.Name = "comboShapeEncode";
            this.comboShapeEncode.Size = new System.Drawing.Size(117, 23);
            this.comboShapeEncode.TabIndex = 17;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(35, 342);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 15);
            this.label6.TabIndex = 16;
            this.label6.Text = "Shape Encode";
            // 
            // listShx
            // 
            this.listShx.FormattingEnabled = true;
            this.listShx.ItemHeight = 15;
            this.listShx.Location = new System.Drawing.Point(418, 429);
            this.listShx.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listShx.Name = "listShx";
            this.listShx.Size = new System.Drawing.Size(354, 274);
            this.listShx.TabIndex = 18;
            // 
            // listDbf
            // 
            this.listDbf.FormattingEnabled = true;
            this.listDbf.ItemHeight = 15;
            this.listDbf.Location = new System.Drawing.Point(795, 427);
            this.listDbf.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listDbf.Name = "listDbf";
            this.listDbf.Size = new System.Drawing.Size(354, 274);
            this.listDbf.TabIndex = 19;
            // 
            // btnSaveShp
            // 
            this.btnSaveShp.Location = new System.Drawing.Point(298, 708);
            this.btnSaveShp.Name = "btnSaveShp";
            this.btnSaveShp.Size = new System.Drawing.Size(91, 33);
            this.btnSaveShp.TabIndex = 20;
            this.btnSaveShp.Text = "SAVE";
            this.btnSaveShp.UseVisualStyleBackColor = true;
            this.btnSaveShp.Click += new System.EventHandler(this.btnSaveShp_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 408);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "shp";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(415, 408);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 15);
            this.label2.TabIndex = 22;
            this.label2.Text = "shx";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(792, 408);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(25, 15);
            this.label3.TabIndex = 23;
            this.label3.Text = "dbf";
            // 
            // btnSaveShx
            // 
            this.btnSaveShx.Location = new System.Drawing.Point(681, 710);
            this.btnSaveShx.Name = "btnSaveShx";
            this.btnSaveShx.Size = new System.Drawing.Size(91, 33);
            this.btnSaveShx.TabIndex = 24;
            this.btnSaveShx.Text = "SAVE";
            this.btnSaveShx.UseVisualStyleBackColor = true;
            this.btnSaveShx.Click += new System.EventHandler(this.btnSaveShx_Click);
            // 
            // btnSaveDbf
            // 
            this.btnSaveDbf.Location = new System.Drawing.Point(1058, 717);
            this.btnSaveDbf.Name = "btnSaveDbf";
            this.btnSaveDbf.Size = new System.Drawing.Size(91, 33);
            this.btnSaveDbf.TabIndex = 25;
            this.btnSaveDbf.Text = "SAVE";
            this.btnSaveDbf.UseVisualStyleBackColor = true;
            this.btnSaveDbf.Click += new System.EventHandler(this.btnSaveDbf_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1161, 762);
            this.Controls.Add(this.btnSaveDbf);
            this.Controls.Add(this.btnSaveShx);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSaveShp);
            this.Controls.Add(this.listDbf);
            this.Controls.Add(this.listShx);
            this.Controls.Add(this.comboShapeEncode);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textDirectoryName);
            this.Controls.Add(this.btnSelectDir);
            this.Controls.Add(this.listShp);
            this.Controls.Add(this.textFileName);
            this.Controls.Add(this.btnParse);
            this.Controls.Add(this.listBox1);
            this.Font = new System.Drawing.Font("Meiryo UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "ParseShape";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnParse;
        private System.Windows.Forms.TextBox textFileName;
        private System.Windows.Forms.ListBox listShp;
        private System.Windows.Forms.Button btnSelectDir;
        private System.Windows.Forms.TextBox textDirectoryName;
        private System.Windows.Forms.ComboBox comboShapeEncode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listShx;
        private System.Windows.Forms.ListBox listDbf;
        private System.Windows.Forms.Button btnSaveShp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnSaveShx;
        private System.Windows.Forms.Button btnSaveDbf;
    }
}


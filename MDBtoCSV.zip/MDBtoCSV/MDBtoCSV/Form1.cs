﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MDBtoCSV
{
    public partial class Form1 : Form
    {
        public delegate void UpdateMessage(string msg);
        int ZMDORGX = -18750000;//cm
        int ZMDORGY = -32500000;//cm

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExportMDB();
        }
        public void MsgOut(string msg)
        {

            DateTime dt = DateTime.Now;

            listBox1.Items.Add(dt.ToString() + "," + msg);

            int cnt = listBox1.Items.Count;
            if (cnt > 1000)
            {
                listBox1.Items.Clear();
            }
            else
            {
                listBox1.SelectedIndex = (cnt - 1);
            }
        }


        public void ExportMDB()
        {
            string db = @"C:\D_DRV\FIIM_PAGE.mdb";
            //String db = MDB_PATH;

            string msg = "Import開始";
            Invoke(new UpdateMessage(MsgOut), msg);

            try
            {
                OleDbConnection conn = new OleDbConnection();
                OleDbCommand comm = new OleDbCommand();

                conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + db; // MDB名など

                // 接続します。
                conn.Open();

                // SELECT文を設定します。
                comm.CommandText = "SELECT * FROM ページ検索テーブル";
                comm.Connection = conn;
                OleDbDataReader reader = comm.ExecuteReader();

                int reccnt = 0;

                // 結果を表示します。
                while (reader.Read())
                {

                    string book = reader["冊"].ToString();
                    string page = reader["ページ"].ToString();
                    string tree = reader["枝"].ToString();
                    string leftright = reader["左右"].ToString();
                    string zno = "0,0,0";
                    string scale = reader["スケール"].ToString();


                    //単位はcm

                    Double ld_x = Double.Parse(reader["左下正規化座標Ｘ"].ToString());
                    Double ld_y = Double.Parse(reader["左下正規化座標Ｙ"].ToString());

                    Double lu_x = Double.Parse(reader["左上正規化座標Ｘ"].ToString());
                    Double lu_y = Double.Parse(reader["左上正規化座標Ｙ"].ToString());

                    Double rd_x = Double.Parse(reader["右下正規化座標Ｘ"].ToString());
                    Double rd_y = Double.Parse(reader["右下正規化座標Ｙ"].ToString());

                    Double ru_x = Double.Parse(reader["右上正規化座標Ｘ"].ToString());
                    Double ru_y = Double.Parse(reader["右上正規化座標Ｙ"].ToString());



                    int wx=0;
                    int wy=0;
                    int w = 0;
                    int h = 0;

                    


                    int mx=(int)( (ld_x - ZMDORGX)/75000)+1;
                    int my=(int)((ld_y - ZMDORGY)/50000);

                    int pagesize;


                    if(Int32.Parse(leftright) == 0)
                    {

                        if (Int32.Parse(scale) == 1500)
                        {
                            w = 750;
                            h = 500;
                            pagesize = 1;
                            AddPage(Int32.Parse(book), Int32.Parse(page), wx, wy, w, h, mx, my, pagesize);
                        }
                        if (Int32.Parse(scale) == 3000)
                        {
                            w = 1500;
                            h = 1000;
                            pagesize = 2;
                            AddPage(Int32.Parse(book), Int32.Parse(page), wx, wy, w, h, mx, my, pagesize);
                        }

                    }



                    //1,4125,2500,1500,1000,206,410,488270092.394725,125703496.185194,-3375000,-12000000,2




                }
                conn.Close();
                msg = "Import終了";
                Invoke(new UpdateMessage(MsgOut), msg);
            }
            catch (Exception ex)
            {
                Invoke(new UpdateMessage(MsgOut), ex.ToString());
            }
        }

        private void AddPage(int book, int page, int wx, int wy, int w, int h, int mx, int my, int pagesize)
        {

            //int idx = listBook.SelectedIndex;

            //if (idx == -1) return;

            string filePath = "map" + book + ".txt";


            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {

                    int zx = (mx - 1) * 75000 + ZMDORGX;//cm
                    int zy = my * 50000 + ZMDORGY;//cm

                    double lx = (double)zx / 100.0;
                    double ly = (double)zy / 100.0;

                    double keido = 0.0;
                    double ido = 0.0;

                    MapComLib.Convert.gpconv2(lx, ly, 6, ref keido, ref ido);


                    string line = page + "," + wx + "," + wy + "," + w + "," + h + "," + mx + "," + my + "," + keido * 1000 + "," + ido * 1000 + "," + zx + "," + zy + "," + pagesize;

                    writer.WriteLine(line);
                }
            }
            catch (Exception e)
            {
            }

        }
    }
}

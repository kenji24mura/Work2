// ------------------------------------------------------------------ 
// ���h�n�}���ʉ��^�ʐM�w�߃V�X�e��
// @(h) PointCheck.cpp ver20150630 ( <2015.06.30> <FW> )
// @(s) ���h�n�}�V�X�e�����L�@�|�C���g�G���A����
//�@�@�@�@Copyright FUJITSU SYSTEMS WEST LIMITED 2014-2015
//�@�@�@�@�\�[�X����
// PointCheck.cpp : �C���v�������e�[�V���� �t�@�C��
// ------------------------------------------------------------------ 
//

#include "stdafx.h"
#include "PointCheck.h"

#include <math.h>

typedef struct
{
	short	x;
	short	y;
} POINTC_SHORT_POINT_XY;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPointCheck

IMPLEMENT_DYNCREATE(CPointCheck, CCmdTarget)

CPointCheck::CPointCheck()
{
	pArray.RemoveAll();
}

CPointCheck::~CPointCheck()
{
	pArray.RemoveAll();
}


BEGIN_MESSAGE_MAP(CPointCheck, CCmdTarget)
	//{{AFX_MSG_MAP(CPointCheck)
		// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPointCheck ���b�Z�[�W �n���h��
BOOL CPointCheck::IsPntInside(long zx, long zy, int PCnt, POINT *point)
{
	POINT		*pPos = new POINT[PCnt+1];	// 1�͗\��
	if(pPos){
		int		pidx = 0;
		for(pidx = 0; pidx < PCnt; pidx++)
		{
			pPos[pidx].x = point[pidx].x - zx;
			pPos[pidx].y = point[pidx].y - zy;
		}
		
		CRgn	rgn;
		BOOL	IsOK = rgn.CreatePolygonRgn(pPos, PCnt, ALTERNATE);
		if(IsOK){
			BOOL	isRet = rgn.PtInRegion(0, 0);
			rgn.DeleteObject();
			delete[] pPos;
			return isRet;
		}
		delete[] pPos;
		TRACE("CPointCheck::IsPntInside CreatePolygonRgn err\n");
	}else{
		TRACE("CPointCheck::IsPntInside new POINT err\n");
	}

	pArray.RemoveAll();

	pointMaxX = 20000;

	BOOL			IsPntIn;
	IsPntIn = FALSE;

	if(PCnt < 1){
		TRACE("Not Polygone\n");
		return IsPntIn;
	}
	
	// ���Ă���ꍇ PCnt--
	if(point[PCnt-1].x == point[0].x && point[PCnt-1].y == point[0].y){
		PCnt--;
	}

	int			pidx = 0;
	for(pidx = 0; pidx < PCnt; pidx++)
	{
		if(pointMaxX <= point[pidx].x ){
			pointMaxX = point[pidx].x + 5000;
		}
		pArray.Add(point[pidx]);
	}
	pArray.Add(point[0]);


	IsPntIn = Inside(CPoint(zx, zy));

	pArray.RemoveAll();

	return IsPntIn;
}

BOOL CPointCheck::IsPntInsideShort(long zx, long zy, int PCnt, void *pVspoint)
{

	POINTC_SHORT_POINT_XY	*pShortP = (POINTC_SHORT_POINT_XY *)pVspoint;
	POINT		*pPos = new POINT[PCnt+1];	// 1�͗\��
	if(pPos){
		int		pidx = 0;
		for(pidx = 0; pidx < PCnt; pidx++)
		{
			pPos[pidx].x = (long)pShortP[pidx].x - zx;
			pPos[pidx].y = (long)pShortP[pidx].y - zy;
		}
		
		CRgn	rgn;
		BOOL	IsOK = rgn.CreatePolygonRgn(pPos, PCnt, ALTERNATE);
		if(IsOK){
			BOOL	isRet = rgn.PtInRegion(0, 0);
			rgn.DeleteObject();
			delete[] pPos;
			return isRet;
		}
		delete[] pPos;
		TRACE("CPointCheck::IsPntInsideShort CreatePolygonRgn err\n");
	}else{
		TRACE("CPointCheck::IsPntInsideShort new POINT err\n");
	}

	POINT					point;
	pArray.RemoveAll();
	pointMaxX = 20000;

	BOOL			IsPntIn;
	IsPntIn = FALSE;

	if(PCnt < 1){
		TRACE("Not Polygone\n");
		return IsPntIn;
	}
	
	// ���Ă���ꍇ PCnt--
	if(pShortP[PCnt-1].x == pShortP[0].x && pShortP[PCnt-1].y == pShortP[0].y){
		PCnt--;
	}

	int			pidx = 0;
	for(pidx = 0; pidx < PCnt; pidx++)
	{
		point.x = (long)(pShortP[pidx].x);
		point.y = (long)(pShortP[pidx].y);

		if(pointMaxX <= point.x ){
			pointMaxX = point.x + 5000;
		}

		pArray.Add(point);
	}
	point.x = (long)(pShortP[0].x);
	point.y = (long)(pShortP[0].y);
	pArray.Add(point);


	IsPntIn = Inside(CPoint(zx, zy));

	pArray.RemoveAll();

	return IsPntIn;
}

BOOL CPointCheck::Inside(CPoint pnt)
{
	//pnt��pArray�̓����ɂ��邩���f����
	CPoint p1,p2,p3,q1,q2;
	double t,s;
	q1.x=pnt.x;q1.y=pnt.y;
	q2.x=pointMaxX;q2.y=pnt.y;  //�\�����������Ƃ���K�v������܂�
	int count=0,k;
	for(int i=0;i<pArray.GetSize()-1;i++){
		p1.x=pArray.GetAt(i).x;
		p1.y=pArray.GetAt(i).y;
		p2.x=pArray.GetAt(i+1).x;
		p2.y=pArray.GetAt(i+1).y;
		BOOL ret=CalcCrossPoint(p1,p2,q1,q2,&t,&s);
		if (ret  ) {
			//TRACE("Inside cross %d %f\n",i,t);
			if( fabs(t)<0.00001 ){
			  k=(i+2) % pArray.GetSize();
			  p3.y=pArray.GetAt(k).y;
			  if((pnt.y-p1.y)*(pnt.y-p3.y)>=0) count++;
			} else count++;
		}
		//TRACE("Inside %d %d \n",i,count);
	}
	if(count % 2 ==0 ) return FALSE ;
		else return TRUE;
}
BOOL CPointCheck::CalcCrossPoint(CPoint p1,CPoint p2,CPoint q1,CPoint q2,double *t,double *s)
{
   double u,v;
   *s=*t=-1.0;

   u = (double)(q1.x-q2.x)*(p1.y-p2.y) - (double)(p1.x -p2.x)*(q1.y-q2.y);
   v = (double)(p1.x-p2.x)*(q2.y-p2.y)-(double)(q2.x-p2.x)*(p1.y-p2.y);

   if(fabs(u)<0.00001) {
	   TRACE("Calc overFlow\n");
	   return FALSE;
   }

   *s = v / u;
   if(p1.x != p2.x)
	  *t = ((*s) * (q1.x-q2.x) + (double)(q2.x-p2.x))/(p1.x-p2.x);
   else
	  *t=((*s) * (q1.y-q2.y) + (double)(q2.y-p2.y))/(p1.y-p2.y);

   if(((*s)<0.0) || ((*s) >1.0)) return FALSE;
   if(((*t)<0.0) || ((*t )>1.0)) return FALSE;
   return TRUE; 
}

// ------------------------------------------------------------------ 
// ���h�n�}���ʉ��^�ʐM�w�߃V�X�e��
// @(h) LogOut.cpp ver20150630 ( <2015.06.30> <FW> )
// @(s) ���h�n�}�V�X�e�����L�@���O�o��
//�@�@�@�@Copyright FUJITSU SYSTEMS WEST LIMITED 2014-2015
//�@�@�@�@�\�[�X����
// LogOut.cpp : �C���v�������e�[�V���� �t�@�C��
// ------------------------------------------------------------------ 
//

#include "LogOut.h"
#include <io.h>
#include <time.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/timeb.h>
#include <string.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


const CString sCONFIDENTIAL = "Fujitsu CONFIDENTIAL";


/////////////////////////////////////////////////////////////////////////////
// CLogOut

IMPLEMENT_DYNCREATE(CLogOut, CCmdTarget)

CLogOut::CLogOut()
{
	LogLoopMax = 10;
}

CLogOut::CLogOut(CString MyLogPath)
{
	limit = 3000000;
	if (limit < 1000){
		limit = 1000;
	}
	strLogFilePath = MyLogPath;
	LogLoopMax = 10;
}

CLogOut::CLogOut(CString MyLogPath, int MyLogLimit)
{
	limit = MyLogLimit;
	if (limit < 1000){
		limit = 1000;
	}
	strLogFilePath = MyLogPath;
	LogLoopMax = 10;
}

CLogOut::~CLogOut()
{
}


BEGIN_MESSAGE_MAP(CLogOut, CCmdTarget)
	//{{AFX_MSG_MAP(CLogOut)
	// ���� - ClassWizard �͂��̈ʒu�Ƀ}�b�s���O�p�̃}�N����ǉ��܂��͍폜���܂��B
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogOut ���b�Z�[�W �n���h��
int CLogOut::OutPutLogln(CString str)
{
	CString	strCLSN = strClassName;
	return OutPutLogln(strCLSN, str);
}

int CLogOut::OutPutLogln(CString strCLSN, CString str)
{
	CString mstr;
	mstr.Format("%s\n", LPCSTR(str));
	return OutPutLog(strCLSN, mstr);
}

int CLogOut::OutPutLog(CString str)
{
	CString strCLSN = strClassName;
	return OutPutLog(strCLSN, str);
}

int CLogOut::OutPutLog(CString strCLSN, CString str)
{
	// �r������
	CSingleLock	lock(&m_csOutputLog, TRUE);

	CString msg;
	FILE* fp;

	long size;
	int k;

	CFileStatus status;

	SYSTEMTIME stTime;
	GetLocalTime(&stTime);

	CString		update;
	CString		milT;
	update.Format("%04d/%02d/%02d %02d:%02d:%02d.%03d"
		, stTime.wYear
		, stTime.wMonth
		, stTime.wDay
		, stTime.wHour
		, stTime.wMinute
		, stTime.wSecond
		, stTime.wMilliseconds
		);
	msg.Format("%s,%-16s, \t%s", (LPCSTR)update, (LPCSTR)strCLSN, (LPCSTR)str);

	CString BackupFilePath;
	CString BackupFilePath2;

	errno_t		errt;
	errt = fopen_s(&fp, strLogFilePath, "at+");
	if (errt == 0 && fp != NULL){
		//
		fseek(fp, 0L, SEEK_END); /* �t�@�C���I�[�Ɉړ� */
		fwrite(msg, msg.GetLength(), 1, fp);
		size = ftell(fp);
		fclose(fp);

		if (size > limit)//
		{
			BackupFilePath.Format("%s.%02d", (LPCSTR)strLogFilePath, LogLoopMax);
			if (CFile::GetStatus(BackupFilePath, status)){
				DeleteFile(BackupFilePath);
			}
			for (k = LogLoopMax - 1; k > 0; k--)
			{
				BackupFilePath.Format("%s.%02d", (LPCSTR)strLogFilePath, k);
				if (CFile::GetStatus(BackupFilePath, status)){
					//���݂�����Rename
					BackupFilePath2.Format("%s.%02d", (LPCSTR)strLogFilePath, k + 1);
					MoveFile(BackupFilePath, BackupFilePath2);
				}
				else{
					//���݂��Ȃ�
				}
			}
			BackupFilePath = strLogFilePath + ".01";
			MoveFile(strLogFilePath, BackupFilePath);
		}
	}
	return 0;
}


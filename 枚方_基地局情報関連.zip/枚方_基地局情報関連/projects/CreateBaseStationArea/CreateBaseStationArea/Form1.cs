﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CreateBaseStationArea
{
    public partial class Form1 : Form
    {
        Bitmap canvas;
        Graphics g;

        Color[] cr = new Color[10];
        Pen p;
        Brush br;
        Brush g_br;
        Font f;

        string DATA_PATH = @"F:\FJJ_WORK\基地局情報関連\data";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(canvas);
            g.Clear(Color.White);

            textOutputFile.Text = DATA_PATH+"\\dat\\example.bin";
            textCSVFile.Text = DATA_PATH + "\\csv\\基地局情報.csv";
            textViewFile.Text = DATA_PATH + "\\dat\\基地局情報.dat";

            cr[0] = Color.Yellow;
            cr[1] = Color.Blue;
            cr[2] = Color.Green;
            cr[3] = Color.Red;
            cr[4] = Color.Gray;
            cr[5] = Color.LightBlue;
            cr[6] = Color.Magenta;
            cr[7] = Color.Black;
            cr[8] = Color.Gray;

            p = new Pen(Color.Black);
            br = new SolidBrush(Color.White);
            f = new Font("ＭＳ Ｐゴシック", 10);
            g_br = new SolidBrush(Color.Black);

            textVal.Text = "3000";
        }

        private void CreateData()
        {
            string filePath = textOutputFile.Text;
            string csvPath = textCSVFile.Text;

            using (BinaryWriter writer = new BinaryWriter(File.Open(filePath, FileMode.Create)))
            {


                try
                {
                    StreamReader sr = new StreamReader(csvPath, Encoding.GetEncoding("UTF-8"));

                    string line = "";

                    while ((line = sr.ReadLine()) != null)
                    {

                        if (line.Length > 0)
                        {
                            string[] param = line.Split(',');

                            if (param.Length > 0)
                            {

                                //登録ID
                                string strID = param[0];
                                byte[] id = Encoding.UTF8.GetBytes(strID); // UTF-8でエンコード
                                writer.Write(id);

                                Int32 Points = Int32.Parse(param[25]);

                                Point[] p = new Point[Points];

                                //データ提供範囲
                                Int32 Xmin = Int32.MaxValue;  // 最小経度
                                Int32 Ymin = Int32.MaxValue;  // 最小緯度
                                Int32 Xmax = Int32.MinValue;  // 最大経度
                                Int32 Ymax = Int32.MinValue; // 最大緯度


                                for (int i = 0; i < Points; i++)
                                {
                                    p[i].X = Int32.Parse(param[26 + i * 2]);
                                    p[i].Y = Int32.Parse(param[27 + i * 2]);

                                    if (p[i].X < Xmin)
                                    {
                                        Xmin = p[i].X;
                                    }
                                    if (p[i].Y < Ymin)
                                    {
                                        Ymin = p[i].Y;
                                    }
                                    if (p[i].X > Xmax)
                                    {
                                        Xmax = p[i].X;
                                    }
                                    if (p[i].Y > Ymax)
                                    {
                                        Ymax = p[i].Y;
                                    }

                                }


                                writer.Write(Xmin);
                                writer.Write(Ymin);
                                writer.Write(Xmax);
                                writer.Write(Ymax);

                                Int32 elementId = Int32.Parse(param[1]);               // 基地局コード
                                byte elementType = Byte.Parse(param[2]);               // 要素タイプ(3固定)
                                byte deleteFlag = Byte.Parse(param[3]);                // 削除フラグ

                                writer.Write(elementId);
                                writer.Write(elementType);
                                writer.Write(deleteFlag);

                                short attributeCount = short.Parse(param[4]);                // 属性情報数
                                writer.Write(attributeCount);

                                short[] attributes = new short[20];    // 属性情報
                                for (int i = 0; i < 20; i++)
                                {
                                    attributes[i] = 0;
                                }
                                for (int i = 0; i < attributeCount; i++)
                                {
                                    attributes[i] = short.Parse(param[5+i]);
                                }
                                for (int i = 0; i < 20; i++)
                                {
                                    writer.Write(attributes[i]);
                                }


                                Int32 datasize = Points * 8 + 4;                // 形状データサイズ(座標数x8 + 4)
                                writer.Write(datasize);

                                writer.Write(Points);

                                for (int i = 0; i < Points; i++)
                                {
                                    Int32 x = p[i].X;
                                    Int32 y = p[i].Y;
                                    writer.Write(x);
                                    writer.Write(y);
                                }


                            }
                        }

                    }
                    sr.Close();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

        }

        private void drawGuide(Graphics g)
        {

            Rectangle r= new Rectangle();

            int gw = 200;
            int gh = 200;

            r.X = pictureBox1.Width-10-gw;
            r.Y = pictureBox1.Height-10-gh;
            r.Width = gw;
            r.Height = gh;

            g.FillRectangle(br, r);
            g.DrawRectangle(p, r);

            for(int i = 1; i < 9; i++)
            {

                Point start = new Point(r.X + 10, r.Y+ 15*i+20);
                Point end = new Point(r.X + 100, r.Y + 15*i+20);

                g.DrawLine(new Pen(cr[i]), start, end);
                g.DrawString("AREA:"+i.ToString("D2"), f, g_br, new Point(r.X + 110, r.Y + 15 * i-2+20));
            }


        }

        private void ParseData()
        {
            listBox1.Items.Clear();
            g.Clear(Color.White);

            string filePath = textViewFile.Text;

            using (BinaryReader reader = new BinaryReader(File.OpenRead(filePath)))
            {
                bool IsEOF = false;
                int ret = 0;

                int center_X = 0;
                int center_Y = 0;

                bool IsSetCenter = false;

                while(IsEOF == false)
                {
                    byte[] id = new byte[20];
                    ret = reader.Read(id, 0, id.Length);


                    if(ret <= 0)
                    {
                        IsEOF = true;
                        break;
                    }

                    string strId = Encoding.UTF8.GetString(id);

                    MsgOut("ID:"+strId);

                    Int32 Xmin = reader.ReadInt32();  // 最小経度
                    Int32 Ymin = reader.ReadInt32();  // 最小緯度
                    Int32 Xmax = reader.ReadInt32();  // 最大経度
                    Int32 Ymax = reader.ReadInt32(); // 最大緯度
                    if (checkBox1.Checked == true)
                    {
                        MsgOut("最小経度:" + Xmin);
                        MsgOut("最小緯度:" + Ymin);
                        MsgOut("最大経度:" + Xmax);
                        MsgOut("最大緯度:" + Ymax);
                    }
                    if (IsSetCenter == false)
                    {
                        center_X = (Xmin + Xmax) / 2;
                        center_Y = (Ymin + Ymax) / 2;

                        IsSetCenter = true;
                    }

                    Int32 elementId = reader.ReadInt32();               // 基地局コード
                    byte elementType = reader.ReadByte();               // 要素タイプ(3固定)
                    byte deleteFlag = reader.ReadByte();                // 削除フラグ
                    MsgOut("基地局コード:" + elementId);
                    MsgOut("要素タイプ(3固定):" + elementType);
                    MsgOut("削除フラグ:" + deleteFlag);

                    short attributeCount = reader.ReadInt16();                // 属性情報数
                    MsgOut("属性情報数:" + attributeCount);

                    for (int i = 0; i < 20; i++)
                    {
                        short attributes = reader.ReadInt16();                // 属性情報数
                        MsgOut("属性情報:" + attributes);
                    }

                    Int32 datasize = reader.ReadInt32();
                    //MsgOut("座標データ長:" + datasize);

                    Int32 Points = reader.ReadInt32();
                    //MsgOut("座標数:" + Points);

                    Point[] dDrawPoints = new Point[Points];

                    for (int i = 0; i < Points; i++)
                    {
                        Int32 x = reader.ReadInt32();
                        Int32 y = reader.ReadInt32();

                        if (checkBox1.Checked == true)
                        {
                            MsgOut("座標:" + x + "-" + y);
                        }

                        int val = Int32.Parse(textVal.Text);

                        dDrawPoints[i].X = pictureBox1.Width / 2 + (int)((double)(x - center_X)/val);
                        dDrawPoints[i].Y = pictureBox1.Height / 2 - (int)((double)(y - center_Y)/val);

                    }
                    g.DrawPolygon(new Pen(cr[elementId]), dDrawPoints);
                }
            }

            drawGuide(g);

            pictureBox1.Image = canvas;

        }

        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;

            textOutputFile.Text = DATA_PATH + "\\dat\\基地局情報"+dt.ToString("yyyyMMddhhmmss")+ ".dat";

            CreateData();
        }

        private void btnView_Click(object sender, EventArgs e)
        {
            ParseData();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            f.Dispose();
            p.Dispose();
            br.Dispose();
            g_br.Dispose();
            g.Dispose();
        }

        private void btnSlelect_Click(object sender, EventArgs e)
        {
            // OpenFileDialogオブジェクトの生成
            OpenFileDialog od = new OpenFileDialog();
            od.Title = "ファイルを開く";  //ダイアログ名
            od.InitialDirectory = DATA_PATH + "\\dat";  //初期フォルダ
            od.FileName = @"";  //初期選択ファイル名
            od.Filter = "すべてのファイル(*.*)|*.*";  //選択できる拡張子
            od.FilterIndex = 1;  //初期の拡張子

            // ダイアログを表示する
            DialogResult result = od.ShowDialog();


            // 選択後の判定
            if (result == DialogResult.OK)
            {
                //「開く」ボタンクリック時の処理
                textViewFile.Text = od.FileName;  //これで選択したファイルパスを取得できる
            }
            else if (result == DialogResult.Cancel)
            {
                //「キャンセル」ボタンクリック時の処理
            }
        }
    }
}

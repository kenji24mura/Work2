﻿
namespace UpdateData
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージド リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.listHosts = new System.Windows.Forms.ListBox();
            this.listUpdate1 = new System.Windows.Forms.ListBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listMessage = new System.Windows.Forms.ListBox();
            this.listUpdate2 = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCalcelAll = new System.Windows.Forms.Button();
            this.btnSelectAll = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(31, 147);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(218, 40);
            this.button1.TabIndex = 0;
            this.button1.Text = "ファイル最新化";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listHosts
            // 
            this.listHosts.FormattingEnabled = true;
            this.listHosts.ItemHeight = 15;
            this.listHosts.Location = new System.Drawing.Point(23, 21);
            this.listHosts.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listHosts.Name = "listHosts";
            this.listHosts.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listHosts.Size = new System.Drawing.Size(220, 334);
            this.listHosts.TabIndex = 1;
            // 
            // listUpdate1
            // 
            this.listUpdate1.FormattingEnabled = true;
            this.listUpdate1.ItemHeight = 15;
            this.listUpdate1.Location = new System.Drawing.Point(31, 33);
            this.listUpdate1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listUpdate1.Name = "listUpdate1";
            this.listUpdate1.Size = new System.Drawing.Size(580, 49);
            this.listUpdate1.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(31, 332);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(218, 61);
            this.button3.TabIndex = 4;
            this.button3.Text = "ファイル配信";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(278, 352);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(341, 23);
            this.textBox1.TabIndex = 5;
            // 
            // listMessage
            // 
            this.listMessage.FormattingEnabled = true;
            this.listMessage.ItemHeight = 15;
            this.listMessage.Location = new System.Drawing.Point(31, 450);
            this.listMessage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listMessage.Name = "listMessage";
            this.listMessage.Size = new System.Drawing.Size(867, 124);
            this.listMessage.TabIndex = 6;
            // 
            // listUpdate2
            // 
            this.listUpdate2.FormattingEnabled = true;
            this.listUpdate2.ItemHeight = 15;
            this.listUpdate2.Location = new System.Drawing.Point(31, 90);
            this.listUpdate2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.listUpdate2.Name = "listUpdate2";
            this.listUpdate2.Size = new System.Drawing.Size(580, 49);
            this.listUpdate2.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(275, 332);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "最終配信日時";
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(743, 598);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(155, 38);
            this.btnClose.TabIndex = 9;
            this.btnClose.Text = "閉じる";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(275, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 15);
            this.label2.TabIndex = 10;
            this.label2.Text = "端末で背景を更新した場合実行";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCalcelAll);
            this.groupBox1.Controls.Add(this.btnSelectAll);
            this.groupBox1.Controls.Add(this.listHosts);
            this.groupBox1.Location = new System.Drawing.Point(655, 17);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(255, 409);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "配信先リスト";
            // 
            // btnCalcelAll
            // 
            this.btnCalcelAll.Location = new System.Drawing.Point(157, 362);
            this.btnCalcelAll.Name = "btnCalcelAll";
            this.btnCalcelAll.Size = new System.Drawing.Size(86, 36);
            this.btnCalcelAll.TabIndex = 3;
            this.btnCalcelAll.Text = "全解除";
            this.btnCalcelAll.UseVisualStyleBackColor = true;
            this.btnCalcelAll.Click += new System.EventHandler(this.btnCalcelAll_Click);
            // 
            // btnSelectAll
            // 
            this.btnSelectAll.Location = new System.Drawing.Point(27, 362);
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.Size = new System.Drawing.Size(86, 36);
            this.btnSelectAll.TabIndex = 2;
            this.btnSelectAll.Text = "全選択";
            this.btnSelectAll.UseVisualStyleBackColor = true;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 648);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listUpdate2);
            this.Controls.Add(this.listMessage);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.listUpdate1);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Meiryo UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "地図背景データ配信";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ListBox listHosts;
        private System.Windows.Forms.ListBox listUpdate1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox listMessage;
        private System.Windows.Forms.ListBox listUpdate2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCalcelAll;
        private System.Windows.Forms.Button btnSelectAll;
    }
}


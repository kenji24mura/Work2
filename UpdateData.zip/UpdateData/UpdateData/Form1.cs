﻿/*
 * 
 * 
 * 高槻消防地図背景データ配信
 * 
 * 
 */

using com;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UpdateData
{
    public partial class Form1 : Form
    {
        static string DATA_PATH= @"D:\takatsuki\地図メンテツール\maptool\data";
        static string USER_LAY_PATH = DATA_PATH+"\\ulay";
        //20250917 start
        static string USER_LAY_PATH2 = DATA_PATH + "\\ulay2";
        //20250917 end

        List<TermInfo> ti = new List<TermInfo>();

        Log lg = new Log();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            string LOGPATH = DATA_PATH + "\\log";

            lg.LOGFNAME = LOGPATH+ "\\UpdateData.log";
            lg.loglimit = 1000000;
            lg.logmax = 10;

            if (Directory.Exists(LOGPATH) == false)
            {
                Directory.CreateDirectory(LOGPATH);
            }

            MsgOut("配信ツール起動");

            this.StartPosition = FormStartPosition.Manual; // 手動設定に切り替え
            this.Location = new Point(
                (Screen.PrimaryScreen.WorkingArea.Width - this.Width) / 2,
                (Screen.PrimaryScreen.WorkingArea.Height - this.Height) / 2
            );

            DateTime dt = DateTime.Now;

            string result = "";

            GetResult(ref result);

            if (result.Length > 0)
            {
                textBox1.Text = result;
            }
            else
            {
                textBox1.Text = DateTime.Now.ToString();
            }


            LoadTermList();
        }


        private void GetResult(ref string result)
        {
            string file = DATA_PATH + "\\result\\result.txt";

            try
            {
                using (StreamReader sr = new StreamReader(file, Encoding.GetEncoding("UTF-8")))
                {
                    if (sr != null)
                    {
                        while (sr.EndOfStream == false)
                        {
                            string line = sr.ReadLine();

                            result = line;
                        }
                        sr.Close();
                    }
                }

            }
            catch (Exception ex)
            {

            }
        }
        private void PutResult(DateTime dt)
        {
            string file = DATA_PATH + "\\result\\result.txt";

            using (StreamWriter sw = new StreamWriter(file, false,Encoding.GetEncoding("UTF-8")))
            {
                if (sw != null)
                {
                    sw.WriteLine(dt.ToString());
                    sw.Close();
                }
            }
        }

        private void MsgOut(string msg)
        {
            DateTime dt = DateTime.Now;
            listMessage.Items.Add(dt.ToString()+","+msg);

            lg.LogOut(msg);
        }

        private void FindUpdateFile(int mode,string dir)
        {
            DateTime dt = DateTime.Now;
            
            DirectoryInfo di1 = new DirectoryInfo(dir);

            FileInfo[] ofiAlls1 = di1.GetFiles();

            foreach (FileInfo f in ofiAlls1)
            {
                DateTime dt1 = DateTime.Parse(textBox1.Text);
                DateTime dt2 = File.GetLastWriteTime(f.FullName);

                if (dt2.CompareTo(dt1) >= 0)
                {
                    if (mode == 0)
                    {
                        listUpdate1.Items.Add(f.FullName);
                    }
                    else
                    {
                        listUpdate2.Items.Add(f.FullName);
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FileUpToDate();
            FileCopyToMaster();
        }

        /*
         * 端末更新ファイルを検索
         */

        private void FileUpToDate()
        {
            listUpdate1.Items.Clear();

            try
            {
                string dir = "";

                for (int i = 0; i < listHosts.Items.Count; i++)
                {
                    dir = @"\\" + listHosts.Items[i].ToString() + @"\D\takatsuki\Data\Mp\map\usrlay\011";
                    FindUpdateFile(0, dir);
                }
                for (int i = 0; i < listHosts.Items.Count; i++)
                {
                    dir = @"\\" + listHosts.Items[i].ToString() + @"\D\takatsuki\Data\Mp\map\usrlay\072";
                    FindUpdateFile(1, dir);
                }

            }
            catch (Exception ex)
            {
                MsgOut(ex.ToString());

            }

        }

        /*
         * 端末ファイルをマスターに反映
         */
        private void FileCopyToMaster()
        {
            try
            {
                if (listUpdate1.Items.Count > 0)
                {
                    string src = listUpdate1.Items[0].ToString();

                    string target = USER_LAY_PATH + @"\011\" + Path.GetFileName(src);
                    File.Copy(src, target, true);
                }
                if (listUpdate2.Items.Count > 0)
                {
                    string src = listUpdate2.Items[0].ToString();

                    string target = USER_LAY_PATH + @"\072\" + Path.GetFileName(src);
                    File.Copy(src, target, true);
                }
            }
            catch (Exception ex)
            {
                MsgOut(ex.ToString());
            }
        }


        private void LoadTermList()
        {


            string file = DATA_PATH+"\\def\\Term.csv";

            using (StreamReader sr = new StreamReader(file, Encoding.GetEncoding("UTF-8")))
            {
                if (sr != null)
                {
                    while (sr.EndOfStream == false)
                    {
                        TermInfo data = new TermInfo();
                        string line = sr.ReadLine();
                        string[] param = line.Split(',');

                        if (param.Length > 2)
                        {
                            listHosts.Items.Add(param[0]);
                            data.hostname = param[0];
                            data.address = param[1];
                            data.targetDir = param[2];
                            //20250924
                            data.TermType = Int32.Parse(param[3]);
                            ti.Add(data);
                        }
                    }
                    sr.Close();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

            //20250917 start
            //署端末用フォルダ作成

            string SRC_DIR = USER_LAY_PATH + "\\011";
            string TARGET_DIR = USER_LAY_PATH2 + "\\011";

            MsgOut("署用ディレクトリ作成");

            if (Directory.Exists(TARGET_DIR) == true)
            {
                Directory.Delete(TARGET_DIR, true);
            }
            Directory.CreateDirectory(TARGET_DIR);


            MsgOut("出入口データ削除");
            DeleteLayer(SRC_DIR,TARGET_DIR,"ENTRANCE");

            //20250917 end

            int cnt = listHosts.SelectedItems.Count;

            foreach (int idx in listHosts.SelectedIndices)
            {
                if (ti[idx].TermType == 1)
                {
                    SendProc(ti[idx].address, ti[idx].targetDir);
                }
                else
                {
                    SendProc2(ti[idx].address, ti[idx].targetDir);
                }

            }

            DateTime dt = DateTime.Now;

            PutResult(dt);
            textBox1.Text = dt.ToString();

        }
        /*
         * 20250917 作成
         */
        private void DeleteLayer(string SRC_DIR, string TARGET_DIR,string layeruser)
        {
            DirectoryInfo di = new DirectoryInfo(SRC_DIR);

            FileInfo[] fiAlls = di.GetFiles();

            foreach (FileInfo f in fiAlls)
            {
                try
                {
                    StreamReader sr = new StreamReader(f.FullName, Encoding.GetEncoding("Shift_JIS"));

                    string target_file = TARGET_DIR + "\\" + f.Name;
                    StreamWriter sw = new StreamWriter(target_file, true, Encoding.GetEncoding("Shift_JIS"));

                    string line = "";

                    while ((line = sr.ReadLine()) != null)
                    {
                        if (line.IndexOf(layeruser) < 0)
                        {
                            sw.WriteLine(line);
                        }
                    }
                    sr.Close();
                    sw.Close();

                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

            }
        }


        private void SendProc(string address, string targetDir)
        {

            string srcDir = USER_LAY_PATH + "\\011\\";
            DirectoryInfo di = new DirectoryInfo(srcDir);

            // ディレクトリ直下のすべてのファイル一覧を取得する
            FileInfo[] fiAlls = di.GetFiles();
            //int idx = 0;
            foreach (FileInfo f in fiAlls)
            {
                try
                {
                    MsgOut("送信開始:" + srcDir + " to " + address + "\\" + targetDir + "\\011\\" + f.Name);

                    File.Copy(f.FullName, address + "\\" + targetDir + "\\011\\" + f.Name, true);
                }
                catch (Exception ex)
                {
                    MsgOut(ex.Message);
                }

            }

            string srcDir2 = USER_LAY_PATH + "\\072\\";
            DirectoryInfo di2 = new DirectoryInfo(srcDir2);

            // ディレクトリ直下のすべてのファイル一覧を取得する
            FileInfo[] fiAlls2 = di2.GetFiles();
            //int idx = 0;
            foreach (FileInfo f in fiAlls2)
            {
                try
                {
                    MsgOut("送信開始:" + srcDir2 + " to " +  address + "\\" + targetDir + "\\072\\" + f.Name);

                    File.Copy(f.FullName, address + "\\" + targetDir + "\\072\\" + f.Name, true);
                }
                catch (Exception ex)
                {
                    MsgOut(ex.Message);
                }

            }
        }

        /*
         * 20250917 作成
         */
        private void SendProc2(string address, string targetDir)
        {
            string srcDir = USER_LAY_PATH2 + "\\011\\";
            DirectoryInfo di = new DirectoryInfo(srcDir);

            // ディレクトリ直下のすべてのファイル一覧を取得する
            FileInfo[] fiAlls = di.GetFiles();
            //int idx = 0;
            foreach (FileInfo f in fiAlls)
            {
                try
                {
                    MsgOut("送信開始:" + srcDir + " to " + address + "\\" + targetDir + "\\011\\" + f.Name);

                    File.Copy(f.FullName, address + "\\" + targetDir + "\\011\\" + f.Name, true);
                }
                catch (Exception ex)
                {
                    MsgOut(ex.Message);
                }

            }

            string srcDir2 = USER_LAY_PATH + "\\072\\";
            DirectoryInfo di2 = new DirectoryInfo(srcDir2);

            // ディレクトリ直下のすべてのファイル一覧を取得する
            FileInfo[] fiAlls2 = di2.GetFiles();
            //int idx = 0;
            foreach (FileInfo f in fiAlls2)
            {
                try
                {
                    MsgOut("送信開始:" + srcDir2 + " to "+address + "\\" + targetDir + "\\072\\" + f.Name);

                    File.Copy(f.FullName, address + "\\" + targetDir + "\\072\\" + f.Name, true);
                }
                catch (Exception ex)
                {
                    MsgOut(ex.Message);
                }

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("終了しますか？", "確認", MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                MsgOut("配信ツール終了");

                Close();
            }
        }

        private void btnSelectAll_Click(object sender, EventArgs e)
        {
            for(int i = 0; i < listHosts.Items.Count; i++)
            {
                listHosts.SetSelected(i, true);
            }

        }

        private void btnCalcelAll_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listHosts.Items.Count; i++)
            {
                listHosts.SetSelected(i, false);
            }
        }
    }
    public class TermInfo
    {
        public string hostname;
        public string address;
        public string targetDir;
        public int TermType;//20250917
    }
}

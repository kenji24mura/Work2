﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace RecreateLayer
{
    internal class Program
    {
		public static String GIS_SERVER_IP = System.Configuration.ConfigurationManager.AppSettings["GIS_SERVER_IP"];
		
		static async Task Main(string[] args)
        {
			Console.WriteLine("★★★ RecreateLayer start★★★");

			if(args.Length == 0)
            {
				Console.WriteLine("args error");
				return;
            }

			Console.WriteLine("レイヤタイプ=["+args[0]+"]");

            try
            {
				string layerID = args[0];

	System.Net.ServicePointManager.ServerCertificateValidationCallback =
		(sender, certificate, chain, sslPolicyErrors) => true;

				//string GIS_SERVER_IP = "127.20.10.27";

				var url = "https://" + GIS_SERVER_IP + ":1443/odgenerator/ReCreateLayer";

				var json = "{request:{'info_type': '"+layerID+"'}}";
				var content = new StringContent(json, Encoding.UTF8, "application/json");

				var client = new HttpClient();

				var response = await client.PostAsync(url, content);

			}
			catch (Exception ex)
            {
				Console.WriteLine(ex.ToString());
            }
			Console.WriteLine("★★★ RecreateLayer end★★★");
		}
	}
}

dir /b > list.csv

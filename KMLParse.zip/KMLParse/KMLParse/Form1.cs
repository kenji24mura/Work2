﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace KMLParse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }


        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string filename = @"C:\D_DRV\A-G.kml";

            listBox1.Items.Clear();
            ParseDat(filename);
        }
        private void ParseDat(string filename)
        {
            XNamespace ns = "http://www.opengis.net/kml/2.2";

            //xmlファイルを指定する
            XElement xml = XElement.Load(filename);

            /*
            IEnumerable<XElement> LineString = from item in xml.Elements(ns + "Document").Elements(ns + "Folder").Elements(ns + "Placemark").Elements(ns + "MultiGeometry").Elements(ns + "LineString") select item;


            int linecnt = 0;

            foreach (XElement line in LineString)
            {
                linecnt++;
                string data = line.Element(ns + "coordinates").Value;
                MsgOut(linecnt.ToString() + ":" + data);


            }
            */

            IEnumerable<XElement> Placemark = from item in xml.Elements(ns + "Document").Elements(ns + "Folder").Elements(ns + "Placemark") select item;


            int linecnt = 0;

            foreach (XElement line in Placemark)
            {
                linecnt++;
                string name = line.Element(ns + "name").Value;
                MsgOut(linecnt.ToString() + ":" + name);

                string styleUrl = line.Element(ns + "styleUrl").Value;


                MsgOut(linecnt.ToString() + ":" + styleUrl);

                if(line.Element(ns + "Point") != null)
                {
                    string coordinates = line.Element(ns + "Point").Element(ns + "coordinates").Value;
                    //MsgOut(linecnt.ToString() + ":" + coordinates);

                    string[] param = coordinates.Split('\n');


                    for(int i = 0; i < param.Length; i++)
                    {
                        param[i] = param[i].Trim();
                        if (param[i].Length > 0)
                        {
                            MsgOut(param[i]);
                        }
                    }


                }
                if (line.Element(ns + "LineString") != null)
                {
                    string coordinates = line.Element(ns + "LineString").Element(ns + "coordinates").Value;
                    //MsgOut(linecnt.ToString() + ":" + coordinates);


                    string[] param = coordinates.Split('\n');

                    for (int i = 0; i < param.Length; i++)
                    {
                        param[i] = param[i].Trim();
                        if (param[i].Length > 0)
                        {
                            MsgOut(param[i]);
                        }
                    }
                }


            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using COM;
using Oracle.ManagedDataAccess.Client;
using ZMDCom;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace EntryData
{
    public partial class Form1 : Form
    {
        public static String DATA_PATH = System.Configuration.ConfigurationManager.AppSettings["DATA_PATH"];
        public static String CONN_STR = System.Configuration.ConfigurationManager.AppSettings["CONN_STR"];

        int ZMDORGX = -18750000;//cm
        int ZMDORGY = -32500000;//cm


        MapComLib.Convert cv = new MapComLib.Convert();

        UInt32 mask = 0;
        int maxlay = 0;

        //リソース
        Pen[] pe = new Pen[16];
        Font[] f = new Font[16];
        SolidBrush[] b = new SolidBrush[16];

        Bitmap current_image;
        //Image[] SymbolImage = new Image[96];

        Bitmap canvas;//地図描画用canvas
        Graphics g;

        Point Offset;
        double rate = 1.0;
        int offset_w;
        int offset_h;

        //正規化係数
        int NormarizeParam = 1;


        int msize_w = 0;
        int msize_h = 0;

        int click_mode = 0;

        Boolean IsMouseDown = false;
        Point start_p;
        Point end_p;

        List<Mesh> mesh = new List<Mesh>();
        List<NumberInfo> numberinfo = new List<NumberInfo>();

        public bool[] zmd_layer_disp = new bool[128];
        public bool[] layer_disp = new bool[16];

        string[] mapinfo = new string[99];
        string[] pageinfo = new string[99];


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            /*
            String lay_no = textBox1.Text;
            String item_no = textBox2.Text;
            int info_type = Int32.Parse(textBox3.Text);
            String info_summery = textBox4.Text;
            int lay_type = Int32.Parse(textBox5.Text);
            int symbol_no = Int32.Parse(textBox6.Text);
            double zahyo_x = Double.Parse(textBox7.Text);
            double zahyo_y = Double.Parse(textBox8.Text);
            String strinfo1 = textBox9.Text;
            String strinfo2 = textBox10.Text;
            String strinfo3 = textBox11.Text;
            double str_zahyo_x = Double.Parse(textBox12.Text);
            double str_zahyo_y = Double.Parse(textBox13.Text);
            */

            label1.Text = "layno";
            label2.Text = "item_no";
            label3.Text = "info_type";
            label4.Text = "info_summery";
            label5.Text = "lay_type";
            label6.Text = "symbol_no";
            label7.Text = "zahyo_x";
            label8.Text = "zahyo_y";
            label9.Text = "strinfo1";
            label10.Text = "strinfo2";
            label11.Text = "strinfo3";
            label12.Text = "str_zahyo_x";
            label13.Text = "str_zahyo_y";
            label14.Text = "zahyo_cnt";
            label15.Text = "update_date";
            label16.Text = "item_no2";



            textBox1.Text = "n@1-1";
            textBox2.Text = "0111";
            textBox3.Text = "1";
            textBox4.Text = "summry";
            textBox5.Text = "1";
            textBox6.Text = "111";
            textBox7.Text = "130.0";
            textBox8.Text = "33.0";
            textBox9.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox12.Text = "0.0";
            textBox13.Text = "0.0";
            textBox14.Text = "0";
            textBox15.Text = "2023/05/22 23:59:13";
            textBox16.Text = "";

            Left = (Screen.GetBounds(this).Width - Width) / 2;
            Top = (Screen.GetBounds(this).Height - Height) / 2;

//            textZMDFile.Text = "";
            textRate.Text = "5.0";

            textX.Text = "0";
            textY.Text = "0";

  //          textPageSize.Text = "1";

            canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            g = Graphics.FromImage(canvas);

            pe[0] = new Pen(Color.Green, 1);
            pe[1] = new Pen(Color.Blue, 1);
            pe[2] = new Pen(Color.Yellow, 1);
            pe[3] = new Pen(Color.Red, 1);
            pe[4] = new Pen(Color.Magenta, 1);
            pe[5] = new Pen(Color.LightBlue, 1);
            b[0] = new SolidBrush(Color.Green);
            b[1] = new SolidBrush(Color.Blue);
            b[2] = new SolidBrush(Color.Yellow);
            b[3] = new SolidBrush(Color.Red);
            b[4] = new SolidBrush(Color.Magenta);

            for (int i = 0; i < zmd_layer_disp.Length; i++)
            {
                zmd_layer_disp[i] = true;
            }
            for (int i = 0; i < layer_disp.Length; i++)
            {
                layer_disp[i] = true;
            }

            /*
            checkBox1.Text = "文字";
            checkBox2.Text = "部品";
            checkBox3.Text = "折れ線";
            checkBox4.Text = "単純ポリゴン";
            checkBox5.Text = "****";
            checkBox6.Text = "****";
            checkBox7.Text = "****";

            checkBox1.Checked = layer_disp[0];
            checkBox2.Checked = layer_disp[1];
            checkBox3.Checked = layer_disp[2];
            checkBox4.Checked = layer_disp[3];
            checkBox5.Checked = layer_disp[4];
            checkBox6.Checked = layer_disp[5];
            checkBox7.Checked = layer_disp[6];
            */
            LoadList();

        }
       
        private void LoadList()
        {
            //listBook.Items.Clear();

            string filePath = DATA_PATH + "\\def\\book.def";

            try
            {
                using (StreamReader reader = new StreamReader(filePath))
                {
                    int idx = 0;
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        string[] param = line.Split(',');

                        //listBook.Items.Add(param[1]);
                        mapinfo[idx] = DATA_PATH + "\\" + param[2];
                        pageinfo[idx] = DATA_PATH + "\\txt\\" + param[1] + "_page.txt";

                        idx++;
                    }
                }
            }
            catch (Exception e)
            {
            }
        }
       
        private void LoadData()
        {

            //  int idx = listBook.SelectedIndex;
            //if (idx == -1) return;

            //textZMDFile.Text = mapinfo[idx];

            int idx = 0;

            g.Clear(Color.White);

            string zmdfile = mapinfo[idx];


            int start1 = zmdfile.IndexOf("\\BC06");
            string passfile = zmdfile.Substring(0, start1) + "\\PASSWORD.DAT";

            int start2 = zmdfile.IndexOf("\\FRM");

            string baafile = zmdfile.Replace("\\FRM\\", "\\ATR\\");
            baafile = baafile.Replace(".BCF", ".BCA");

            mask = GetMask(passfile);

            rate = Double.Parse(textRate.Text);

            offset_w = 0;
            offset_h = 0;

            //ReadBAA(baafile, passfile, 0);

//            layer_disp[0] = checkBox1.Checked;
  //          layer_disp[1] = checkBox2.Checked;
    //        layer_disp[2] = checkBox3.Checked;
      //      layer_disp[3] = checkBox4.Checked;
        //    layer_disp[4] = checkBox5.Checked;
         //   layer_disp[5] = checkBox6.Checked;
          //  layer_disp[6] = checkBox7.Checked;

            offset_w = Int32.Parse(textX.Text);
            offset_h = Int32.Parse(textY.Text);

            mesh.Clear();
            numberinfo.Clear();

            ReadFile(zmdfile, passfile);

            //DrawPage();

            pictureBox1.Image = canvas;

        }
        private void ReadFile(string zmdfile, string passfile)
        {
            string fname = Path.GetFileNameWithoutExtension(zmdfile);

            if (File.Exists(zmdfile) == false) return;

            FileStream fs = new FileStream(zmdfile, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            FRM_HEAD_NOMESH frm_head = new FRM_HEAD_NOMESH();

            //int header_length = sizeof(FRM_HEAD_NOMESH);

            frm_head.pickind = new PicKind_Code();
            frm_head.pickind.pic1 = br.ReadByte();
            frm_head.pickind.pic2 = br.ReadByte();
            frm_head.pickind.pic3 = br.ReadByte();
            frm_head.pickind.pic4 = br.ReadByte();

            frm_head.date = new Date();
            frm_head.date.y = br.ReadUInt16();
            frm_head.date.m = br.ReadByte();
            frm_head.date.d = br.ReadByte();

            frm_head.zno = new ZNO();
            frm_head.zno.x = br.ReadUInt16();
            frm_head.zno.y = br.ReadUInt16();


            frm_head.org_lon = br.ReadInt32();//座標系の原点の経度
            frm_head.org_lat = br.ReadInt32();//座標系の原点の緯度
            frm_head.offset_x1 = br.ReadInt32();//座標系の原点からZMD原点へのX方向オフセット
            frm_head.offset_y1 = br.ReadInt32();//座標系の原点からZMD原点へのY方向オフセット
            frm_head.offset_x2 = br.ReadUInt32();//ZMD原点から図の原点へのX方向の距離
            frm_head.offset_y2 = br.ReadUInt32();//ZMD原点から図の原点へのY方向の距離

            frm_head.org_x = br.ReadInt32();//図の原点の経度
            frm_head.org_y = br.ReadInt32();//図の原点の緯度
            frm_head.x_width = br.ReadUInt32();//図あたりのX方向の幅
            frm_head.y_width = br.ReadUInt32();//図あたりのY方向の幅
            frm_head.x_cnt = br.ReadInt16();//図あたりのX方向座標数
            frm_head.y_cnt = br.ReadInt16();//図あたりのY方向座標数
            frm_head.param = br.ReadUInt32();//正規化係数
            frm_head.x_prk = br.ReadUInt16();//X方向ブロック化係数
            frm_head.y_prk = br.ReadUInt16();//Y方向ブロック化係数

            frm_head.parent_zu_type = new PicKind_Code();
            frm_head.parent_zu_type.pic1 = br.ReadByte();
            frm_head.parent_zu_type.pic2 = br.ReadByte();
            frm_head.parent_zu_type.pic3 = br.ReadByte();
            frm_head.parent_zu_type.pic4 = br.ReadByte();


            frm_head.parent_zno = new ZNO();
            frm_head.parent_zno.x = br.ReadUInt16();
            frm_head.parent_zno.y = br.ReadUInt16();

            frm_head.parent_attr_num = br.ReadUInt32();

            frm_head.up_zno = new ZNO();

            frm_head.up_zno.x = br.ReadUInt16();
            frm_head.up_zno.y = br.ReadUInt16();


            frm_head.down_zno = new ZNO();
            frm_head.down_zno.x = br.ReadUInt16();
            frm_head.down_zno.y = br.ReadUInt16();


            frm_head.left_zno = new ZNO();
            frm_head.left_zno.x = br.ReadUInt16();
            frm_head.left_zno.y = br.ReadUInt16();


            frm_head.right_zno = new ZNO();
            frm_head.right_zno.x = br.ReadUInt16();
            frm_head.right_zno.y = br.ReadUInt16();

            frm_head.maxlay = br.ReadUInt16();           // 最大レイヤ番号
            frm_head.rsv = br.ReadUInt16();              // リザーブ
            frm_head.brk_ptr = br.ReadUInt32();          // ブロック管理部アドレス
            frm_head.brk_cnt = br.ReadUInt32();          // ブロック情報部レコード数
            frm_head.inf_ptr = br.ReadUInt32();          // 属性対応管理部アドレス
            frm_head.inf_cnt = br.ReadUInt32();          // 属性対応情報部レコード数
            frm_head.brk_str = br.ReadUInt32();          // ブロック部開始アドレス
            frm_head.ref_ptr = br.ReadUInt32();          // 関連図管理部アドレス
            frm_head.ref_cnt = br.ReadUInt32();          // 関連図情報部レコード数
            frm_head.rsv_ptr = br.ReadUInt32();          // 予約領域部アドレス
            frm_head.file_sz = br.ReadUInt32();          // ファイル容量

            maxlay = frm_head.maxlay;

            /*
            listInfo.Items.Clear();

            listInfo.Items.Add("座標系の原点の経度:" + frm_head.org_lon);//座標系の原点の経度
            listInfo.Items.Add("座標系の原点の緯度:" + frm_head.org_lat);//座標系の原点の緯度
            listInfo.Items.Add("座標系の原点からZMD原点へのX方向オフセット:" + frm_head.offset_x1);//座標系の原点からZMD原点へのX方向オフセット
            listInfo.Items.Add("座標系の原点からZMD原点へのY方向オフセット:" + frm_head.offset_y1);//座標系の原点からZMD原点へのY方向オフセット
            listInfo.Items.Add("ZMD原点から図の原点へのX方向の距離:" + frm_head.offset_x2);//ZMD原点から図の原点へのX方向の距離
            listInfo.Items.Add("ZMD原点から図の原点へのY方向の距離:" + frm_head.offset_y2);//ZMD原点から図の原点へのY方向の距離

            listInfo.Items.Add("図の原点の経度:" + frm_head.org_x);//図の原点の経度
            listInfo.Items.Add("図の原点の緯度:" + frm_head.org_y);//図の原点の緯度
            listInfo.Items.Add("図あたりのX方向の幅:" + frm_head.x_width);//図あたりのX方向の幅
            listInfo.Items.Add("図あたりのY方向の幅:" + frm_head.y_width);//図あたりのY方向の幅
            listInfo.Items.Add("図あたりのX方向座標数:" + frm_head.x_cnt);//図あたりのX方向座標数
            listInfo.Items.Add("図あたりのY方向座標数:" + frm_head.y_cnt);//図あたりのY方向座標数
            listInfo.Items.Add("正規化係数:" + frm_head.param);//正規化係数
            listInfo.Items.Add("X方向ブロック化係数:" + frm_head.x_prk);//X方向ブロック化係数
            listInfo.Items.Add("Y方向ブロック化係数:" + frm_head.y_prk);//Y方向ブロック化係数
            */

            NormarizeParam = (int)frm_head.param;

            int sx = 75000 / (int)frm_head.param;
            int sy = 50000 / (int)frm_head.param;

            msize_w = sx;//メッシュサイズW取得
            msize_h = sy;//メッシュサイズh取得

            Offset.X = 0; Offset.Y = frm_head.y_cnt;


            char[] s_fname = new char[256];

            s_fname = fname.ToCharArray();

            byte[] s1 = new byte[4];
            byte[] s2 = new byte[4];
            byte[] s3 = new byte[4];
            byte[] s4 = new byte[4];

            System.UInt32[] brkptr = new System.UInt32[99];
            System.UInt32[] brksize = new System.UInt32[99];


            int valx = 0;
            int valy = 0;

            for (int j = 0; j < 4; j++)
            {
                if (s_fname[j] >= 'A' && s_fname[j] <= 'P')
                {
                    valx += (int)(s_fname[j] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valx += (int)(s_fname[j] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                if (s_fname[j + 4] >= 'A' && s_fname[j + 4] <= 'P')
                {
                    valy += (int)(s_fname[j + 4] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valy += (int)(s_fname[j + 4] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
            }

            s1 = BitConverter.GetBytes(valx);
            s2 = BitConverter.GetBytes(valy);

            FRM_BRK frm_brk = new FRM_BRK();
            FRM_INF frm_inf = new FRM_INF();
            FRM_LAY frm_lay = new FRM_LAY();


            //
            //ブロック管理部
            //

            fs.Seek(frm_head.brk_ptr, SeekOrigin.Begin);

            for (int i = 0; i < frm_head.brk_cnt; i++)
            {
                frm_brk.brk_ptr = br.ReadUInt32();
                frm_brk.brk_sz = br.ReadUInt32();

                s3 = BitConverter.GetBytes(frm_brk.brk_ptr);


                s3[0] = (byte)(s3[0] ^ s1[0]);
                s3[1] = (byte)(s3[1] ^ s1[1]);
                s3[2] = (byte)(s3[2] ^ s2[0]);
                s3[3] = (byte)(s3[3] ^ s2[1]);
                //マスクとのXOR
                s3[1] = (byte)(s3[1] ^ mask);
                s3[2] = (byte)(s3[2] ^ mask);


                frm_brk.brk_ptr = BitConverter.ToUInt32(s3, 0);

                brkptr[i] = frm_brk.brk_ptr;
                brksize[i] = frm_brk.brk_sz;
            }


            string baafile = zmdfile.Replace("\\FRM\\", "\\ATR\\");
            baafile = baafile.Replace(".BCF", ".BCA");

            //
            //属性対応情報管理部
            //

            fs.Seek(frm_head.inf_ptr, SeekOrigin.Begin);


            for (int i = 0; i < frm_head.inf_cnt; i++)
            {
                frm_inf.inf_num = br.ReadUInt32();          // 図内属性番号
                frm_inf.inf_z_brk = br.ReadUInt16();        // 図形形状所属ブロック
                frm_inf.inf_m_brk = br.ReadUInt16();        // 文字形状所属ブロック
                frm_inf.inf_z_off = br.ReadUInt32();        // 図形形状ブロック内オフセット
                frm_inf.inf_m_off = br.ReadUInt32();        // 文字形状ブロック内オフセット
                frm_inf.inf_recnum = br.ReadUInt32();       // 属性情報部レコード番号
                frm_inf.rsv = br.ReadUInt32();             // リザーブ

                ReadBAA(baafile, passfile, (int)frm_inf.inf_recnum);

            }

            //
            //ブロック部
            //

            for (int i = 0; i < frm_head.brk_cnt; i++)
            {
                if (brksize[i] > 0)
                {
                    fs.Seek(brkptr[i], SeekOrigin.Begin);

                    FrmSub(g, i, fs, br, brksize[i], rate, offset_w, offset_h);

                    //f1.PaintView();
                }
            }

            //
            //関連情報管理部
            //

            //
            //予約領域部
            //

            fs.Close();
            br.Close();

        }


        public void FrmSub(Graphics g, int brkno, FileStream fs, BinaryReader br, System.UInt32 brksize, double rate, int offset_w, int offset_h)
        {

            FRM_FRMCOM frm_com = new FRM_FRMCOM();

            List<Poly> po = new List<Poly>();

            //形状情報部

            Boolean EOF = false;
            byte[] buf = new byte[2048];


            UInt32[] lay_off = new UInt32[maxlay];
            UInt32[] lay_size = new UInt32[maxlay];
            UInt32[] lay_frm_off = new UInt32[maxlay];


            int flg = 0;
            int newbufcnt = 0;

            //
            //ブロックの先頭ポインタ
            //
            int brkstart = (int)fs.Seek(0, SeekOrigin.Current);

            int size = 0;

            //レイヤ情報部
            for (int j = 0; j < maxlay; j++)
            {

                lay_off[j] = br.ReadUInt32();
                lay_size[j] = br.ReadUInt32();
                lay_frm_off[j] = br.ReadUInt32();
                size += 12;
            }

            while (EOF != true)
            {
                int cur = (int)fs.Seek(0, SeekOrigin.Current) - brkstart;

                //
                //レイヤ番号判定
                //
                int layno = -1;

                for (int k = 0; k < maxlay; k++)
                {
                    if (lay_frm_off[k] != 0xffffffff && cur >= lay_off[k] && cur < lay_off[k] + lay_size[k])
                    {
                        layno = k + 1;
                        break;
                    }
                }

                frm_com.frmcom_recnum = br.ReadUInt32();
                frm_com.frmcom_size = br.ReadUInt16();
                frm_com.frmcom_type = br.ReadByte();
                frm_com.frmcom_status = br.ReadByte();

                size += 8;

                int type = (int)frm_com.frmcom_type;
                int len = frm_com.frmcom_size - (8);

                buf = br.ReadBytes(len);

                FRM_AREAPOLY frm_areapoly = new FRM_AREAPOLY();
                frm_areapoly.ldxy = new XY();
                frm_areapoly.ruxy = new XY();
                FRM_STRINF frm_strinf = new FRM_STRINF();
                frm_strinf.ldxy = new XY();
                frm_strinf.ruxy = new XY();
                FRM_STRLINE frm_strline = new FRM_STRLINE();
                frm_strline.kxy = new XY();
                FRM_SYMBOL frm_symbol = new FRM_SYMBOL();
                frm_symbol.ldxy = new XY();
                frm_symbol.ruxy = new XY();
                frm_symbol.kxy = new XY();
                FRM_LINES frm_lines = new FRM_LINES();
                frm_lines.ldxy = new XY();
                frm_lines.ruxy = new XY();

                FRM_POLYGON frm_polygon = new FRM_POLYGON();
                frm_polygon.ldxy = new XY();
                frm_polygon.ruxy = new XY();

                FRM_OUTPOLY frm_outpoly = new FRM_OUTPOLY();
                frm_outpoly.ldxy = new XY();
                frm_outpoly.ruxy = new XY();

                FRM_INPOLY frm_inpoly = new FRM_INPOLY();
                FRM_INPOLY frm_areainpoly = new FRM_INPOLY();

                FRM_STRSYM frm_strsym = new FRM_STRSYM();
                frm_strsym.ldxy = new XY();
                frm_strsym.ruxy = new XY();
                frm_strsym.kxy = new XY();


                int offset = 0;

                int wx = 0;
                int wy = 0;

                switch (type)
                {
                    case 1://文字
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        {
                            frm_strinf.ldxy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.ldxy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.ruxy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.ruxy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            frm_strinf.height = BitConverter.ToUInt16(buf, offset);
                            offset += 2;
                            frm_strinf.angle = BitConverter.ToUInt16(buf, offset);
                            offset += 2;

                            frm_strinf.c1 = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;
                            frm_strinf.c2 = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;
                            frm_strinf.form = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;
                            frm_strinf.line = (byte)BitConverter.ToChar(buf, offset);
                            offset += 1;

                            for (int k = 0; k < frm_strinf.line; k++)
                            {
                                frm_strline.kxy.x = BitConverter.ToInt16(buf, offset);
                                offset += 2;
                                frm_strline.kxy.y = BitConverter.ToInt16(buf, offset);
                                offset += 2;
                                frm_strline.width = BitConverter.ToUInt16(buf, offset);
                                offset += 2;
                                frm_strline.height = BitConverter.ToUInt16(buf, offset);
                                offset += 2;
                                frm_strline.cnt = BitConverter.ToUInt16(buf, offset);
                                offset += 2;

                                byte[] strbuf1 = new byte[frm_strline.cnt * 2];
                                Array.Copy(buf, offset, strbuf1, 0, frm_strline.cnt * 2);

                                byte[] strbuf2 = jis2sj.Jis2Sjis(strbuf1);

                                string text = System.Text.Encoding.GetEncoding("shift_jis").GetString(strbuf2);

                                wx = frm_strline.kxy.x - Offset.X;
                                wy = frm_strline.kxy.y - Offset.Y;

                                int str_sx = (int)((double)wx / rate) + offset_w;
                                int str_sy = (int)((double)(-wy) / rate) + offset_h;


                                if (layno == 113)
                                {
                                    NumberInfo num = new NumberInfo();
                                    num.x = str_sx + 10;
                                    num.y = str_sy;
                                    num.number = text;
                                    numberinfo.Add(num);
                                }


                                int font_size = (int)((double)frm_strline.height / rate);

                                //★計算は暫定

                                Font s_font;

                                SolidBrush s_br;//文字用

                                if (layno >= 96 && layno <= 99)
                                {
                                    font_size = (int)(30 / rate);
                                    s_br = new SolidBrush(Color.Red);
                                }
                                else
                                {
                                    font_size = (int)(20 / rate);
                                    s_br = new SolidBrush(Color.Black);
                                }


                                //font_size = 24;

                                FontFamily fontFamily = new FontFamily("ＭＳ Ｐゴシック");
                                s_font = new Font(
                                fontFamily,
                                    font_size,
                                   FontStyle.Regular,
                                   GraphicsUnit.Pixel);


                                var format = new StringFormat();
                                format.Alignment = StringAlignment.Near;      // 左右方向は中心寄せ
                                format.LineAlignment = StringAlignment.Near;  // 上下方向は中心寄せ

                                g.SmoothingMode = SmoothingMode.AntiAlias;
                                if (frm_strinf.form == 2)
                                {


                                    format.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                                    StringCOM.DrawString(g, text, s_font, s_br, str_sx, str_sy - font_size, -frm_strinf.angle, format);
                                }
                                else
                                {

                                    format.FormatFlags = StringFormatFlags.DirectionVertical;
                                    StringCOM.DrawString(g, text, s_font, s_br, str_sx - font_size, str_sy, -frm_strinf.angle, format);
                                }
                                s_br.Dispose();
                                s_font.Dispose();
                                offset += frm_strline.cnt * 2;
                            }
                        }

                        break;
                    case 2://部品

                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_symbol.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.width = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_symbol.angle = BitConverter.ToUInt16(buf, offset);//角度
                        offset += 2;
                        frm_symbol.kxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.kxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_symbol.symno = BitConverter.ToUInt16(buf, offset);//部品番号
                        offset += 2;

                        wx = frm_symbol.kxy.x - Offset.X;
                        wy = frm_symbol.kxy.y - Offset.Y;

                        int symbol_sx = (int)((double)wx / rate) + offset_w;
                        int symbol_sy = (int)((double)(-wy) / rate) + offset_h;

                        //MsgOut("symno=" + frm_symbol.symno.ToString());

                        //角度を考慮するとどうなるか？
                        //Image image = SymbolImage[frm_symbol.symno];
                        //double deg = frm_symbol.angle;
                        //Point iconP = new Point(symbol_sx, symbol_sy);
                        //int iconSize = 32;

                        //DrawIcon(g, image, deg, iconP, iconSize);
                        //                        g.DrawImage(SymbolImage[frm_symbol.symno], symbol_sx - 16, symbol_sy - 16, 32, 32);

                        break;
                    case 3://折れ線

                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_lines.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_lines.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        XY lines_xy = new XY();
                        Point[] lines_pnt = new Point[frm_lines.cnt];

                        for (int k = 0; k < frm_lines.cnt; k++)
                        {
                            lines_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            lines_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = lines_xy.x - Offset.X;
                            wy = lines_xy.y - Offset.Y;

                            lines_pnt[k].X = (int)((double)wx / rate) + offset_w;
                            lines_pnt[k].Y = (int)((double)(-wy) / rate) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawLines(pe[0], lines_pnt);

                        break;
                    case 4://単純ポリゴン
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_polygon.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_polygon.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        XY polygon_xy = new XY();
                        Point[] polygon_pnt = new Point[frm_polygon.cnt];

                        for (int k = 0; k < frm_polygon.cnt; k++)
                        {
                            polygon_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;
                            polygon_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = polygon_xy.x - Offset.X;
                            wy = polygon_xy.y - Offset.Y;

                            polygon_pnt[k].X = (int)((double)wx / rate) + offset_w;
                            polygon_pnt[k].Y = (int)((double)(-wy) / rate) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        if (layno == 8 || layno == 18)
                        {
                            //g.FillPolygon(b[3], polygon_pnt);
                        }
                        else
                        {
                            //g.FillPolygon(b[1], polygon_pnt);
                        }

                        g.DrawPolygon(pe[1], polygon_pnt);

                        Mesh mdata = new Mesh();

                        int minx = int.MaxValue, miny = int.MaxValue;
                        int maxx = int.MinValue, maxy = int.MinValue;


                        for (int k = 0; k < polygon_pnt.Length; k++)
                        {
                            if (minx > polygon_pnt[k].X)
                            {
                                minx = polygon_pnt[k].X;
                            }
                            if (maxx < polygon_pnt[k].X)
                            {
                                maxx = polygon_pnt[k].X;
                            }
                            if (miny > polygon_pnt[k].Y)
                            {
                                miny = polygon_pnt[k].Y;
                            }
                            if (maxy < polygon_pnt[k].Y)
                            {
                                maxy = polygon_pnt[k].Y;
                            }
                        }

                        mdata.minx = minx;
                        mdata.maxx = maxx;
                        mdata.miny = miny;
                        mdata.maxy = maxy;

                        mesh.Add(mdata);


                        break;
                    case 5://中抜きポリゴン
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_outpoly.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.inpoly = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_outpoly.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        flg = frm_outpoly.cnt;

                        if (flg < 16)
                        {
                            flg = 16;
                        }
                        else
                        {
                            int s = flg / 16; //16の倍数
                            int a = flg % 16; //16で割ったあまり

                            if (a > 0)
                            {
                                flg = 16 * (s + 1);
                            }
                            else
                            {
                                flg = 16 * s;
                            }

                        }

                        newbufcnt = flg / 8;

                        byte[] outpolybuf = new byte[newbufcnt];
                        Array.Copy(buf, offset, outpolybuf, 0, newbufcnt);

                        offset += newbufcnt;//バイト分シフト

                        XY outpoly_xy = new XY();
                        Point[] outpoly_pnt = new Point[frm_outpoly.cnt];


                        for (int k = 0; k < frm_outpoly.cnt; k++)
                        {
                            outpoly_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;


                            outpoly_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = outpoly_xy.x - Offset.X;
                            wy = outpoly_xy.y - Offset.Y;


                            outpoly_pnt[k].X = (int)((double)wx / rate) + offset_w;
                            outpoly_pnt[k].Y = (int)((double)(-wy) / rate) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        if (layno == 8 || layno == 18)
                        {
                            g.FillPolygon(b[3], outpoly_pnt);
                        }
                        else
                        {
                            g.FillPolygon(b[1], outpoly_pnt);
                        }

                        g.DrawPolygon(pe[2], outpoly_pnt);

                        //中抜きポリゴン
                        for (int m = 0; m < frm_outpoly.inpoly; m++)
                        {
                            frm_inpoly.cnt = BitConverter.ToUInt16(buf, offset);
                            offset += 2;

                            flg = frm_inpoly.cnt;

                            if (flg < 16)
                            {
                                flg = 16;
                            }
                            else
                            {
                                int s = flg / 16; //16の倍数
                                int a = flg % 16; //16で割ったあまり

                                if (a > 0)
                                {
                                    flg = 16 * (s + 1);
                                }
                                else
                                {
                                    flg = 16 * s;
                                }

                            }

                            newbufcnt = flg / 8;

                            byte[] inpolybuf = new byte[newbufcnt];
                            Array.Copy(buf, offset, inpolybuf, 0, newbufcnt);

                            offset += newbufcnt;//バイト分シフト

                            XY inpoly_xy = new XY();
                            Point[] inpoly_pnt = new Point[frm_inpoly.cnt];


                            for (int k = 0; k < frm_inpoly.cnt; k++)
                            {
                                inpoly_xy.x = BitConverter.ToInt16(buf, offset);
                                offset += 2;


                                inpoly_xy.y = BitConverter.ToInt16(buf, offset);
                                offset += 2;

                                wx = inpoly_xy.x - Offset.X;
                                wy = inpoly_xy.y - Offset.Y;

                                inpoly_pnt[k].X = (int)((double)wx / rate) + offset_w;
                                inpoly_pnt[k].Y = (int)((double)(-wy) / rate) + offset_h;

                            }
                            g.SmoothingMode = SmoothingMode.AntiAlias;
                            if (layno == 8 || layno == 18)
                            {
                                g.FillPolygon(b[3], inpoly_pnt);
                            }
                            else
                            {
                                g.FillPolygon(b[1], inpoly_pnt);
                            }
                            g.DrawPolygon(pe[2], inpoly_pnt);


                        }



                        break;
                    case 6://行政ポリゴン
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_areapoly.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr1 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr2 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr3 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.addr4 = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.inpoly = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_areapoly.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;


                        flg = frm_areapoly.cnt;

                        if (flg < 16)
                        {
                            flg = 16;
                        }
                        else
                        {
                            int s = flg / 16; //16の倍数
                            int a = flg % 16; //16で割ったあまり

                            if (a > 0)
                            {
                                flg = 16 * (s + 1);
                            }
                            else
                            {
                                flg = 16 * s;
                            }

                        }

                        newbufcnt = flg / 8;

                        byte[] areapolybuf = new byte[newbufcnt];
                        Array.Copy(buf, offset, areapolybuf, 0, newbufcnt);

                        offset += newbufcnt;//バイト分シフト

                        XY areapoly_xy = new XY();
                        Point[] areapoly_pnt = new Point[frm_areapoly.cnt];


                        for (int k = 0; k < frm_areapoly.cnt; k++)
                        {
                            areapoly_xy.x = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            areapoly_xy.y = BitConverter.ToInt16(buf, offset);
                            offset += 2;

                            wx = areapoly_xy.x - Offset.X;
                            wy = areapoly_xy.y - Offset.Y;

                            areapoly_pnt[k].X = (int)((double)wx / rate) + offset_w;
                            areapoly_pnt[k].Y = (int)((double)(-wy) / rate) + offset_h;

                        }

                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawPolygon(pe[1], areapoly_pnt);

                        //中抜きポリゴン（行政界）
                        for (int m = 0; m < frm_areapoly.inpoly; m++)
                        {
                            frm_areainpoly.cnt = BitConverter.ToUInt16(buf, offset);
                            offset += 2;

                            flg = frm_areainpoly.cnt;

                            if (flg < 16)
                            {
                                flg = 16;
                            }
                            else
                            {
                                int s = flg / 16; //16の倍数
                                int a = flg % 16; //16で割ったあまり

                                if (a > 0)
                                {
                                    flg = 16 * (s + 1);
                                }
                                else
                                {
                                    flg = 16 * s;
                                }

                            }

                            newbufcnt = flg / 8;

                            byte[] areainpolybuf = new byte[newbufcnt];
                            Array.Copy(buf, offset, areainpolybuf, 0, newbufcnt);

                            offset += newbufcnt;//バイト分シフト

                            XY areainpoly_xy = new XY();
                            Point[] areainpoly_pnt = new Point[frm_areainpoly.cnt];


                            for (int k = 0; k < frm_areainpoly.cnt; k++)
                            {
                                areainpoly_xy.x = BitConverter.ToInt16(buf, offset);
                                offset += 2;

                                areainpoly_xy.y = BitConverter.ToInt16(buf, offset);
                                offset += 2;

                                wx = areainpoly_xy.x - Offset.X;
                                wy = areainpoly_xy.y - Offset.Y;

                                areainpoly_pnt[k].X = (int)((double)wx / rate) + offset_w;
                                areainpoly_pnt[k].Y = (int)((double)(-wy) / rate) + offset_h;

                            }

                            g.SmoothingMode = SmoothingMode.AntiAlias;
                            g.DrawPolygon(pe[2], areainpoly_pnt);
                        }

                        break;
                    case 7://文字付部品
                        if (zmd_layer_disp[layno - 1] == false) break;
                        if (layer_disp[type - 1] == false) break;

                        frm_strsym.ldxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.ldxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.ruxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.ruxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.width = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_strsym.angle = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_strsym.kxy.x = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.kxy.y = BitConverter.ToInt16(buf, offset);
                        offset += 2;
                        frm_strsym.symno = BitConverter.ToUInt16(buf, offset);
                        offset += 2;
                        frm_strsym.cnt = BitConverter.ToUInt16(buf, offset);
                        offset += 2;

                        wx = frm_strsym.kxy.x - Offset.X;
                        wy = frm_strsym.kxy.y - Offset.Y;


                        int strsymbol_sx = (int)((double)wx / rate) + offset_w;
                        int strsymbol_sy = (int)((double)(-wy) / rate) + offset_h;

                        //g.DrawString("☆", f[0], b[0], strsymbol_sx, strsymbol_sy);

                        byte[] strsymbuf1 = new byte[frm_strsym.cnt * 2];
                        Array.Copy(buf, offset, strsymbuf1, 0, frm_strsym.cnt * 2);

                        byte[] strsymbuf2 = jis2sj.Jis2Sjis(strsymbuf1);

                        string strtext = System.Text.Encoding.GetEncoding("shift_jis").GetString(strsymbuf2);


                        Point p = new Point(strsymbol_sx, strsymbol_sy);

                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        if (layno == 100)
                        {
                            ////DrawGaiku(g, p, strtext);
                        }
                        else
                        {
                            g.DrawString(strtext, f[0], b[0], strsymbol_sx - 10, strsymbol_sy - 10);
                        }

                        break;
                    default:
                        if (zmd_layer_disp[layno - 1] == false) break;
                        break;

                }

                size += len;

                if (size >= brksize)
                {
                    EOF = true;
                }
            }

        }

        public UInt32 GetMask(string PasswordFile)
        {
            int m_mask = 0;

            System.UInt32[] data = new System.UInt32[18];

            char[] passwd = new char[256];

            string str_passwd = "";


            StreamReader sr = new StreamReader(PasswordFile, Encoding.GetEncoding("Shift_JIS"));

            while (sr.Peek() != -1)
            {
                string header = "PassWord1=";

                string line = sr.ReadLine();

                if (line.IndexOf(header) == 0)
                {
                    str_passwd = line.Substring(header.Length);
                }
            }
            sr.Close();

            passwd = str_passwd.ToCharArray();

            int j = 0;
            for (int i = 0; i < 18; i++)
            {

                if (passwd[i] >= 'a' && passwd[i] <= 'z')
                {
                    data[j] = (System.UInt32)(122 - passwd[i]);
                }
                else if (passwd[i] == '#')
                {
                    data[j] = 26;
                }
                else if (passwd[i] >= '0' && passwd[i] <= '9')
                {
                    data[j] = (System.UInt32)(passwd[i] - 21);
                }
                else if (passwd[i] == '%')
                {
                    data[j] = 37;
                }
                if (passwd[i] >= 'A' && passwd[i] <= 'Z')
                {
                    data[j] = (System.UInt32)(passwd[i] - 27);
                }
                j++;
            }
            m_mask = (int)(data[7] << 6 | ((data[8] << 2) >> 2));


            string bit = "";
            for (int i = 0; i < data.Length; i++)
            {
                if (i == 4 || i == 9)//c5 c10以外
                {

                }
                else
                {
                    bit += Convert.ToString(data[i], 2).PadLeft(6, '0');
                }
            }

            int cnt = bit.Length / 8;
            string[] param = new string[cnt];
            UInt32[] t = new UInt32[cnt];

            for (int i = 0; i < cnt; i++)
            {
                param[i] = bit.Substring(i * 8, 8);
                Console.WriteLine(param[i]);


                t[i] = Convert.ToUInt32(param[i], 2);
            }

            //
            //t[8]:単独図の復号キー
            //

            return t[8];
        }
        private void ReadBAA(string BaaFile, string PasswordFile, int recnum)
        {

            mask = GetMask(PasswordFile);

            string baa_fname = BaaFile;

            FileStream fs = new FileStream(baa_fname, FileMode.Open);
            BinaryReader br = new BinaryReader(fs);

            byte[] buf = new byte[2048];
            byte[] wbuf16 = new byte[16];
            byte[] wbuf62 = new byte[62];


            buf = br.ReadBytes(4);//図種別
            UInt16 zno_x = br.ReadUInt16();//図番号X
            UInt16 zno_y = br.ReadUInt16();//図番号Y

            uint ptr1 = br.ReadUInt32();//住所索引管理部アドレス
            uint rec1 = br.ReadUInt32();//住所索引情報部レコード数
            uint ptr2 = br.ReadUInt32();//属性情報管理部アドレス
            uint rec2 = br.ReadUInt32();//属性情報部レコード数
            uint ptr3 = br.ReadUInt32();//別記属性管理部アドレス
            uint rec3 = br.ReadUInt32();//別記属性管理部容量

            fs.Seek(ptr1, SeekOrigin.Begin);

            for (int i = 0; i < rec1; i++)
            {
                UInt16 city = br.ReadUInt16();
                UInt16 town1 = br.ReadUInt16();
                UInt16 town2 = br.ReadUInt16();
                UInt16 gcode = br.ReadUInt16();
                uint z_ptr = br.ReadUInt32();
                uint z_cnt = br.ReadUInt32();
            }

            byte[] s1 = new byte[4];
            byte[] s2 = new byte[4];
            byte[] s3 = new byte[4];
            byte[] s4 = new byte[4];

            int valx = 0;
            int valy = 0;

            string fname = Path.GetFileNameWithoutExtension(baa_fname);

            char[] s_fname = new char[256];
            s_fname = fname.ToCharArray();


            for (int j = 0; j < 4; j++)
            {
                if (s_fname[j] >= 'A' && s_fname[j] <= 'P')
                {
                    valx += (int)(s_fname[j] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valx += (int)(s_fname[j] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                if (s_fname[j + 4] >= 'A' && s_fname[j + 4] <= 'P')
                {
                    valy += (int)(s_fname[j + 4] - 'A') * (int)Math.Pow((double)16, (double)(3 - j));
                }
                else
                {
                    valy += (int)(s_fname[j + 4] - 'a') * (int)Math.Pow((double)16, (double)(3 - j));
                }
            }

            s1 = BitConverter.GetBytes(valx);
            s2 = BitConverter.GetBytes(valy);

            s3 = BitConverter.GetBytes(ptr2);

            s3[0] = (byte)(s3[0] ^ s1[0]);
            s3[1] = (byte)(s3[1] ^ s1[1]);
            s3[2] = (byte)(s3[2] ^ s2[0]);
            s3[3] = (byte)(s3[3] ^ s2[1]);
            //マスクとのXOR
            s3[1] = (byte)(s3[1] ^ mask);
            s3[2] = (byte)(s3[2] ^ mask);


            ptr2 = BitConverter.ToUInt32(s3, 0);
            fs.Seek(ptr2, SeekOrigin.Begin);

            for (int i = 0; i < rec2; i++)
            {
                uint zno = br.ReadUInt32();//図番号
                UInt16 ztype = br.ReadUInt16();//属性種別
                UInt16 zcity = br.ReadUInt16();//拡張市町村
                UInt16 ztown1 = br.ReadUInt16();//大字
                UInt16 ztown2 = br.ReadUInt16();//丁目
                UInt16 zgcode = br.ReadUInt16();//街区

                buf = br.ReadBytes(2);

                wbuf16 = br.ReadBytes(16);//地番
                byte[] number_buf = jis2sj.Jis2Sjis(wbuf16);
                string number = System.Text.Encoding.GetEncoding("shift_jis").GetString(number_buf);

                byte septype = br.ReadByte();
                byte seppos = br.ReadByte();

                wbuf62 = br.ReadBytes(62);//名称
                byte[] name_buf = jis2sj.Jis2Sjis(wbuf62);
                string name = System.Text.Encoding.GetEncoding("shift_jis").GetString(name_buf);

                Int16 floor = br.ReadInt16();//建物階数

                uint frm_zno = br.ReadUInt32();//形状対応情報部のレコード番号
                uint frm_zoffset = br.ReadUInt32();//別記属性管理部からのオフセット

                if (frm_zno == recnum)
                {
                    //Console.WriteLine(name);
                    //pInfo.zcity = zcity;
                    //pInfo.ztown1 = ztown1;
                    //pInfo.ztown2 = ztown2;
                    //pInfo.zgcode = zgcode;
                    //pInfo.number = number;
                    //pInfo.name = name;

                    //maptool.Address pAddr = new maptool.Address();
                    //pAddr.f1 = f1;
                    String addrName = "";

                    //pAddr.GetAddrName(zcity / 1000, 0, 0, 0, ref addrName);
                    //pInfo.addrname = addrName.Trim();

                    //pAddr.GetAddrName(zcity / 1000, zcity % 1000, 0, 0, ref addrName);
                    //pInfo.addrname += addrName.Trim();

                    if (ztown1 > 0)
                    {
                        //pAddr.GetAddrName(zcity / 1000, zcity % 1000, ztown1, 0, ref addrName);
                        //pInfo.addrname += addrName.Trim();
                    }

                    if (ztown2 > 0)
                    {
                        //pAddr.GetAddrName(zcity / 1000, zcity % 1000, ztown1, ztown2, ref addrName);
                        //pInfo.addrname += addrName.Trim();
                    }

                    if (frm_zoffset != 0xffffffff)
                    {
                        fs.Seek(ptr3 + frm_zoffset, SeekOrigin.Begin);
                        uint ext_cnt = br.ReadUInt32();//別記属性レコード数

                        //pInfo.ext_info = new List<String>();

                        for (int m = 0; m < ext_cnt; m++)
                        {
                            uint ext_no = br.ReadUInt32();
                            uint ext_code = br.ReadUInt16();
                            char ctype = br.ReadChar();

                            byte rsv = br.ReadByte();
                            int ext_floor = br.ReadInt16();

                            byte[] wfloor_name = new byte[10];
                            wfloor_name = br.ReadBytes(10);//地番
                            byte[] floor_name_buf = jis2sj.Jis2Sjis(wfloor_name);
                            string floor_name = System.Text.Encoding.GetEncoding("shift_jis").GetString(floor_name_buf);

                            byte sep_type = br.ReadByte();
                            byte sep_pos = br.ReadByte();

                            byte[] wext_name = new byte[50];
                            wext_name = br.ReadBytes(50);//地番
                            byte[] ext_name_buf = jis2sj.Jis2Sjis(wext_name);
                            string ext_name = System.Text.Encoding.GetEncoding("shift_jis").GetString(ext_name_buf);

                            //pInfo.ext_info.Add(ctype + " " + ext_floor.ToString("D2") + " " + ext_name);
                        }
                    }

                    break;
                }
            }

            fs.Close();
            br.Close();
        }

        private void NumberToXY(string number, ref int x, ref int y)
        {
            int ret = 0;

            string result = number.Replace("０", "0");
            result = result.Replace("１", "1");
            result = result.Replace("２", "2");
            result = result.Replace("３", "3");
            result = result.Replace("４", "4");
            result = result.Replace("５", "5");
            result = result.Replace("６", "6");
            result = result.Replace("７", "7");
            result = result.Replace("８", "8");
            result = result.Replace("９", "9");

            string sx = result.Substring(0, 5);
            string sy = result.Substring(5, 5);

            x = Int32.Parse(sx);
            y = Int32.Parse(sy);

        }

        private void MsgOut(string msg)
        {
            listBox2.Items.Add(msg);
        }

        private void AddData(OracleConnection conn, String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y)
        {
            String msg;
            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                string sql = "insert into  TBWG0001(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,update_date)";
                sql += " VALUES(:lay_no,:item_no,:info_type,:info_summery,:lay_type,:symbol_no,:zahyo_x,:zahyo_y,:strinfo1,:strinfo2,:strinfo3,:str_zahyo_x,:str_zahyo_y,:update_date)";

                //using (OracleConnection conn = new OracleConnection())
                //{
                //conn.ConnectionString = CONN_STRING;
                //conn.Open();
                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        using (OracleCommand cmd = new OracleCommand(sql, conn))
                        {
                            cmd.BindByName = true;


                            cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                lay_no, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":item_no", OracleDbType.Varchar2,
                                item_no, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":info_type", OracleDbType.Int32,
                                info_type, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":info_summery", OracleDbType.Varchar2,
                                info_summery, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":lay_type", OracleDbType.Varchar2,
                                lay_type, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Varchar2,
                                symbol_no, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":zahyo_x", OracleDbType.Double,
                                zahyo_x, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":zahyo_y", OracleDbType.Double,
                                zahyo_y, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":strinfo1", OracleDbType.Varchar2,
                                strinfo1, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":strinfo2", OracleDbType.Varchar2,
                                strinfo2, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":strinfo3", OracleDbType.Varchar2,
                                strinfo3, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":str_zahyo_x", OracleDbType.Double,
                                str_zahyo_x, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":str_zahyo_y", OracleDbType.Double,
                                str_zahyo_y, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":update_date", OracleDbType.Date,
                                dt, ParameterDirection.Input));

                            cmd.ExecuteNonQuery();

                            transaction.Commit();

                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        msg = ex.ToString();
                        MsgOut(msg);
                    }
                }
                //2024.01.09 追加
                //コネクションを切断する
                //conn.Close();
                //コネクションを破棄する
                //conn.Dispose();
                //}
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }

        }
        private void AddData(OracleConnection conn, String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, DPOint[] dp)
        {
            String msg;
            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                string sql = "insert into  TBWG0002(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,update_date,zahyo_cnt,ZAHYO_ARRAY)";
                sql += " VALUES(";

                sql += "'";
                sql += lay_no;
                sql += "'";

                sql += ",";
                sql += item_no;
                sql += ",";
                sql += info_type;
                sql += ",";

                sql += "'";
                sql += info_summery;
                sql += "'";

                sql += ",";
                sql += lay_type;
                sql += ",";
                sql += symbol_no;
                sql += ",";
                sql += zahyo_x;
                sql += ",";
                sql += zahyo_y;

                sql += ",";

                sql += "'";
                sql += strinfo1;
                sql += "'";

                sql += ",";

                sql += "'";
                sql += strinfo2;
                sql += "'";

                sql += ",";

                sql += "'";
                sql += strinfo3;
                sql += "'";

                sql += ",";
                sql += str_zahyo_x;
                sql += ",";
                sql += str_zahyo_y;
                sql += ",";
                sql += "TO_DATE('" + dt + "', 'YYYY-MM-DD HH24:MI:SS') ";
                sql += ",";
                sql += zahyo_cnt;
                sql += ",";

                sql += "ARRAY_POINT(";
                for (int i = 0; i < zahyo_cnt; i++)
                {
                    if (i > 0)
                    {
                        sql += ",";
                    }
                    sql += "POINT(";
                    sql += dp[i].x;
                    sql += ",";
                    sql += dp[i].y;
                    sql += ")";
                }
                sql += ",";
                sql += "POINT(";
                sql += dp[0].x;
                sql += ",";
                sql += dp[0].y;
                sql += ")";

                sql += ")";

                sql += ")";

                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        using (OracleCommand cmd = new OracleCommand(sql, conn))
                        {
                            cmd.ExecuteNonQuery();
                            transaction.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        msg = ex.ToString();
                        MsgOut(msg);
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }
        }

        private static void AddPolygonData(OracleConnection conn, String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, ref ZPOINT[] zp, string update_date, String item_no2)
        {

            string msg;


            string arraydata = "ARRAY_POINT(";

            int maxcnt = zp.Length;

            for (int i = 0; i < maxcnt; i++)
            {
                if (i > 0)
                {
                    arraydata += ",";
                }
                arraydata += "POINT(";
                arraydata += zp[i].zahyo_x;
                arraydata += ",";
                arraydata += zp[i].zahyo_y;
                arraydata += ")";
            }

            arraydata += ")";

            try
            {


                //プレースホルダでバインドする
                string sql = "insert into  TBWG0002 ";
                sql += "(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,zahyo_cnt,zahyo_array,update_date,item_no2)";
                sql += " VALUES(:lay_no,:item_no,:info_type,:info_summery,:lay_type,:symbol_no,:zahyo_x,:zahyo_y,:strinfo1,:strinfo2,:strinfo3,:str_zahyo_x,:str_zahyo_y,:zahyo_cnt,";
                sql += arraydata;
                sql += ",:update_date,:item_no2)";

                msg = sql;
                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        using (OracleCommand cmd = new OracleCommand(sql, conn))
                        {
                            cmd.BindByName = true;


                            cmd.Parameters.Add(new OracleParameter(":lay_no", OracleDbType.Varchar2,
                                lay_no, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":item_no", OracleDbType.Varchar2,
                                item_no, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":info_type", OracleDbType.Int32,
                                info_type, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":info_summery", OracleDbType.Varchar2,
                                info_summery, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":lay_type", OracleDbType.Varchar2,
                                lay_type, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":symbol_no", OracleDbType.Varchar2,
                                symbol_no, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":zahyo_x", OracleDbType.Double,
                                zahyo_x, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":zahyo_y", OracleDbType.Double,
                                zahyo_y, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":strinfo1", OracleDbType.Varchar2,
                                strinfo1, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":strinfo2", OracleDbType.Varchar2,
                                strinfo2, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":strinfo3", OracleDbType.Varchar2,
                                strinfo3, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":str_zahyo_x", OracleDbType.Double,
                                str_zahyo_x, ParameterDirection.Input));
                            cmd.Parameters.Add(new OracleParameter(":str_zahyo_y", OracleDbType.Double,
                                str_zahyo_y, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":zahyo_cnt", OracleDbType.Int32,
                                zahyo_cnt, ParameterDirection.Input));

                            DateTime dt = DateTime.Parse(update_date);

                            cmd.Parameters.Add(new OracleParameter(":update_date", OracleDbType.Date,
                                    dt, ParameterDirection.Input));

                            cmd.Parameters.Add(new OracleParameter(":item_no2", OracleDbType.Varchar2,
                                item_no2, ParameterDirection.Input));

                            cmd.ExecuteNonQuery();

                            transaction.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }



        private void button1_Click(object sender, EventArgs e)
        {

            String lay_no = textBox1.Text;
            String item_no = textBox2.Text;
            int info_type = Int32.Parse(textBox3.Text);
            String info_summery = textBox4.Text;
            int lay_type = Int32.Parse(textBox5.Text);
            int symbol_no = Int32.Parse(textBox6.Text);
            double zahyo_x = Double.Parse(textBox7.Text);
            double zahyo_y = Double.Parse(textBox8.Text);
            String strinfo1 = textBox9.Text;
            String strinfo2 = textBox10.Text;
            String strinfo3 = textBox11.Text;
            double str_zahyo_x = Double.Parse(textBox12.Text);
            double str_zahyo_y = Double.Parse(textBox13.Text);


            using (OracleConnection conn = new OracleConnection())
            {
                conn.ConnectionString = CONN_STR;
                conn.Open();

                AddData(conn, lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y);

                conn.Close();
                conn.Dispose();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            String lay_no = textBox1.Text;
            String item_no = textBox2.Text;
            int info_type = Int32.Parse(textBox3.Text);
            String info_summery = textBox4.Text;
            int lay_type = Int32.Parse(textBox5.Text);
            int symbol_no = Int32.Parse(textBox6.Text);
            double zahyo_x = Double.Parse(textBox7.Text);
            double zahyo_y = Double.Parse(textBox8.Text);
            String strinfo1 = textBox9.Text;
            String strinfo2 = textBox10.Text;
            String strinfo3 = textBox11.Text;
            double str_zahyo_x = Double.Parse(textBox12.Text);
            double str_zahyo_y = Double.Parse(textBox13.Text);

            int zahyo_cnt = Int32.Parse(textBox14.Text);



            Double[] px = new Double[zahyo_cnt];
            Double[] py = new Double[zahyo_cnt];

            for(int i = 0; i < zahyo_cnt; i++)
            {
                string line = listBox1.Items[i].ToString();
                string[] items = line.Split(',');

                px[i] = Double.Parse(items[0]);
                py[i] = Double.Parse(items[1]);

            }

            ZPOINT[] zp = new ZPOINT[zahyo_cnt];

            for (int j = 0; j < zahyo_cnt; j++)
            {
                zp[j] = new ZPOINT();
                zp[j].zahyo_x =px[j];
                zp[j].zahyo_y =py[j];

            }

            String update_date = textBox15.Text;
            String item_no2 = textBox16.Text;

            using (OracleConnection conn = new OracleConnection())
            {
                conn.ConnectionString = CONN_STR;
                conn.Open();

                AddPolygonData(conn, lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, ref zp, update_date, item_no2);

                conn.Close();
                conn.Dispose();
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

            if(textZahyoX.Text.Length == 0 || textZahyoY.Text.Length == 0)
            {
                return;
            }

            string line = textZahyoX.Text+","+textZahyoY.Text;
            listBox1.Items.Add(line);

            textBox14.Text = listBox1.Items.Count.ToString();

            if (listBox1.Items.Count == 1)
            {
                textBox7.Text = textZahyoX.Text;
                textBox8.Text = textZahyoY.Text;
            }
            textZahyoX.Text = "";
            textZahyoY.Text = "";

        }

        private void btnCls_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            textZahyoX.Text = "";
            textZahyoY.Text = "";
            textBox14.Text = listBox1.Items.Count.ToString();
        }

        private void btnMap_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            IsMouseDown = true;
            start_p.X = e.X;
            start_p.Y = e.Y;
            current_image = new Bitmap(this.pictureBox1.Image);

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (click_mode == 0 && IsMouseDown)
            {
                end_p.X = e.X;
                end_p.Y = e.Y;

                IsMouseDown = false;

                int mx = Int32.Parse(textX.Text);
                int my = Int32.Parse(textY.Text);

                int sx = mx + end_p.X - start_p.X;
                int sy = my + end_p.Y - start_p.Y;

                textX.Text = sx.ToString();
                textY.Text = sy.ToString();

                LoadData();
            }
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (click_mode == 0 && IsMouseDown)
            {
                end_p.X = e.X;
                end_p.Y = e.Y;

                int sx = end_p.X - start_p.X;
                int sy = end_p.Y - start_p.Y;

                g.Clear(Color.White);
                g.DrawImage(current_image, sx, sy);
                pictureBox1.Image = canvas;

                //string msg = sx.ToString() + "-" + sy.ToString();
                //MsgOut(msg);
            }
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            string msg = "";

            int x = e.X;
            int y = e.Y;

            for (int i = 0; i < mesh.Count; i++)
            {
                if (x >= mesh[i].minx && x <= mesh[i].maxx && y >= mesh[i].miny && y <= mesh[i].maxy)
                {
                    for (int j = 0; j < numberinfo.Count; j++)
                    {
                        if (numberinfo[j].x > mesh[i].minx && numberinfo[j].x < mesh[i].maxx && numberinfo[j].y > mesh[i].miny && numberinfo[j].y < mesh[i].maxy)
                        {

                            msg = mesh[i].minx.ToString() + ", " + mesh[i].maxx.ToString() + ", " + mesh[i].miny.ToString() + ", " + mesh[i].maxy.ToString();

                           // MsgOut(numberinfo[j].number + " " + msg);


                            int mx = 0;
                            int my = 0;

                            NumberToXY(numberinfo[j].number, ref mx, ref my);

                            if (click_mode == 1||click_mode==2)
                            {

                                //int page = Int32.Parse(textPage.Text);

                                int px = (int)((x - offset_w) * rate);
                                int py = (int)((y - offset_h) * rate);


                                int wx = (int)((mesh[i].minx - offset_w) * rate);
                                int wy = (int)((mesh[i].miny - offset_h) * rate);

                                int sx = (mx - 1) * 75000 + +ZMDORGX + (px - wx) * NormarizeParam;//cm
                                int sy = my * 50000 + ZMDORGY + (py - wy) * NormarizeParam;//cm


                                //int PageSize = Int32.Parse(textPageSize.Text);

                                //int w = msize_w * PageSize;
                                //int h = msize_h * PageSize;

                                int zx = (mx - 1) * 75000 + ZMDORGX;//cm
                                int zy = my * 50000 + ZMDORGY;//cm

                                double lx = (double)sx / 100.0;
                                double ly = (double)sy / 100.0;

                                double keido = 0.0;
                                double ido = 0.0;

                                MapComLib.Convert.gpconv2(lx, ly, 6, ref keido, ref ido);

                             //   msg = sx + "," + sy;
                            //    MsgOut(msg);

                           //     msg = keido + "," + ido;
                           //     MsgOut(msg);

                                double keido2 = keido / 3600;
                                double ido2 = ido / 3600;

                                msg = keido2.ToString("F5") + "," + ido2.ToString("F5");
                                MsgOut(msg);

                                if (click_mode == 1)
                                {
                                    textBox7.Text = keido2.ToString("F5");
                                    textBox8.Text = ido2.ToString("F5");
                                }

                                if (click_mode == 2)
                                {
                                    //if (textZahyoX.Text.Length == 0 || textZahyoY.Text.Length == 0)
                                    //{
                                      //  return;
                                    //}

                                    string line = keido2.ToString("F5") + "," + ido2.ToString("F5");
                                    listBox1.Items.Add(line);

                                    textBox14.Text = listBox1.Items.Count.ToString();

                                    if (listBox1.Items.Count == 1)
                                    {
                                        textBox7.Text = keido2.ToString("F5");
                                        textBox8.Text = ido2.ToString("F5");
                                    }
//                                    textZahyoX.Text = "";
  //                                  textZahyoY.Text = "";
                                }


                                click_mode = 0;

                            }


                            break;
                        }
                    }
                    break;
                }
            }

            msg = e.X.ToString() + "-" + e.Y.ToString();
            //MsgOut(msg);

        }

        private void btnGetPoint_Click(object sender, EventArgs e)
        {
            click_mode = 1;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            click_mode = 2;
        }
    }
    public class DPOint
    {
        public Double x;
        public Double y;
        Double GetX()
        {
            return this.x;
        }
        Double GetY()
        {
            return this.y;
        }
        void SetX(Double x)
        {
            this.x = x;
        }
        void SetY(Double y)
        {
            this.y = y;
        }
    }
    public class ZPOINT
    {
        public double zahyo_x;
        public double zahyo_y;
    }
    public struct Poly
    {
        public Point lt;
        public Point lb;
    }

    public struct Mesh
    {
        public int minx;
        public int maxx;
        public int miny;
        public int maxy;
    }
    public struct NumberInfo
    {
        public string number;
        public int x;
        public int y;
    }

}

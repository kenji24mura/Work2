﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportTool
{
    public partial class Form1 : Form
    {
        static string CONN_STRING = "User ID=WEBGIS; Password=WEBGIS; Data Source=172.20.10.16:1521/fire.osaka";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        static private void AddDB(string filename)
        {
            string msg;

            String lay_no = "";
            String item_no = "";
            int info_type = 0;
            String info_summery = "";
            int lay_type = 0;
            int symbol_no = 0;
            double zahyo_x = 0.0;
            double zahyo_y = 0.0;
            String strinfo1 = "";
            String strinfo2 = "";
            String strinfo3 = "";
            double str_zahyo_x = 0.0;
            double str_zahyo_y = 0.0;
            int zahyo_cnt = 0;

            DateTime dt = DateTime.Now;
            TimeSpan sp1 = new TimeSpan(30, 0, 0, 0);

            DPOint[] dp = new DPOint[400];

            int cnt = 0;

            try
            {
                using (OracleConnection a_conn = new OracleConnection())
                {
                    a_conn.ConnectionString = CONN_STRING;
                    a_conn.Open();


                    try
                    {
                        StreamReader sr = new StreamReader(filename, Encoding.UTF8);

                        Boolean IsEOF = false;

                        int lcnt = 0;

                        while (IsEOF == false)
                        {
                            string line = sr.ReadLine();
                            if (line == null)
                            {
                                IsEOF = true;
                                break;
                            }

                            lcnt++;

                            if (lcnt == 1)
                            {
                                continue;
                            }

                            string[] param = line.Split(',');

                            lay_no = "n@15-1";
                            item_no = cnt.ToString();
                            info_type = 15;
                            info_summery = "";


                            info_summery += "{";
                            info_summery += "\"備考\":";
                            info_summery += "}";

                            lay_type = 3;
                            symbol_no = 3008;

                            cnt = lcnt;

                            strinfo1 = "";
                            strinfo2 = "";
                            strinfo3 = "";
                            str_zahyo_x = Double.Parse(param[6]);
                            str_zahyo_y = Double.Parse(param[7]);

                            item_no = info_type.ToString("D2");
                            item_no += symbol_no.ToString("D4");
                            item_no += cnt.ToString("D6");

                            zahyo_cnt = Int32.Parse(param[13]);
                            for (int j = 0; j < zahyo_cnt; j++)
                            {
                                dp[j] = new DPOint();

                                dp[j].x = Double.Parse(param[14+j*2]);
                                dp[j].y = Double.Parse(param[15+j*2]);

                            }
                            zahyo_x = dp[0].x;
                            zahyo_y = dp[0].y;

                            //                            dp[0].x = 1.1;
                            //                            dp[0].y = 1.1;

                            AddData(a_conn, lay_no, item_no, info_type, info_summery, lay_type, symbol_no, zahyo_x, zahyo_y, strinfo1, strinfo2, strinfo3, str_zahyo_x, str_zahyo_y, zahyo_cnt, dp);


                        }
                        sr.Close();

                    }catch(Exception ex)
                    {

                    }



                    a_conn.Close();
                    a_conn.Dispose();
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }

        }


        static private void AddData(OracleConnection conn, String lay_no, String item_no, int info_type, String info_summery, int lay_type, int symbol_no, double zahyo_x, double zahyo_y, String strinfo1, String strinfo2, String strinfo3, double str_zahyo_x, double str_zahyo_y, int zahyo_cnt, DPOint[] dp)
        {
            String msg;
            DateTime dt = DateTime.Now;
            try
            {
                //プレースホルダでバインドする
                string sql = "insert into  TBWG0002(lay_no,item_no,info_type,info_summery,lay_type,symbol_no,zahyo_x,zahyo_y,strinfo1,strinfo2,strinfo3,str_zahyo_x,str_zahyo_y,update_date,zahyo_cnt,ZAHYO_ARRAY)";
                sql += " VALUES(";

                sql += "'";
                sql += lay_no;
                sql += "'";

                sql += ",";
                sql += item_no;
                sql += ",";
                sql += info_type;
                sql += ",";

                sql += "'";
                sql += info_summery;
                sql += "'";

                sql += ",";
                sql += lay_type;
                sql += ",";
                sql += symbol_no;
                sql += ",";
                sql += zahyo_x;
                sql += ",";
                sql += zahyo_y;

                sql += ",";

                sql += "'";
                sql += strinfo1;
                sql += "'";

                sql += ",";

                sql += "'";
                sql += strinfo2;
                sql += "'";

                sql += ",";

                sql += "'";
                sql += strinfo3;
                sql += "'";

                sql += ",";
                sql += str_zahyo_x;
                sql += ",";
                sql += str_zahyo_y;
                sql += ",";
                sql += "TO_DATE('" + dt + "', 'YYYY-MM-DD HH24:MI:SS') ";
                sql += ",";
                sql += zahyo_cnt;
                sql += ",";

                sql += "ARRAY_POINT(";
                for (int i = 0; i < zahyo_cnt; i++)
                {
                    if (i > 0)
                    {
                        sql += ",";
                    }
                    sql += "POINT(";
                    sql += dp[i].x;
                    sql += ",";
                    sql += dp[i].y;
                    sql += ")";
                }
                //sql += ",";
                //sql += "POINT(";
                //sql += dp[0].x;
                //sql += ",";
                //sql += dp[0].y;
                //sql += ")";

                sql += ")";

                sql += ")";

                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        using (OracleCommand cmd = new OracleCommand(sql, conn))
                        {
                            cmd.ExecuteNonQuery();
                            transaction.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        msg = ex.ToString();
                        MsgOut(msg);
                    }
                }
            }
            catch (Exception ex)
            {
                msg = ex.ToString();
                MsgOut(msg);
            }

        }
        static public void MsgOut(string msg)
        {
            DateTime dt = DateTime.Now;

            Console.WriteLine(dt.ToString() + "," + msg);
            //lg.LogOut(dt.ToString() + "," + msg);
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string filename = @"f:\sample.csv";

            AddDB(filename);
        }
    }
    public class DPOint
    {
        public Double x;
        public Double y;
        Double GetX()
        {
            return this.x;
        }
        Double GetY()
        {
            return this.y;
        }
        void SetX(Double x)
        {
            this.x = x;
        }
        void SetY(Double y)
        {
            this.y = y;
        }
    }

}

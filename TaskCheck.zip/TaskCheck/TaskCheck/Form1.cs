﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaskCheck
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "7z";
            textBox2.Text = "10";

            timer1.Enabled = true;
            timer1.Interval = 10000;

            textBox3.Text = DateTime.Now.ToString();
            LoadList();
        }

        private void LoadList()
        {

            textBox3.Text = DateTime.Now.ToString();
            listBox1.Items.Clear();

            //ローカルコンピュータ上で実行されているすべてのプロセスを取得
            System.Diagnostics.Process[] ps =
                System.Diagnostics.Process.GetProcesses();
            //"machinename"という名前のコンピュータで実行されている
            //すべてのプロセスを取得するには次のようにする。
            //System.Diagnostics.Process[] ps =
            //    System.Diagnostics.Process.GetProcesses("machinename");

            //配列から1つずつ取り出す
            foreach (System.Diagnostics.Process p in ps)
            {
                try
                {
                    if (p.ProcessName.IndexOf(textBox1.Text) >= 0)
                    {

                        string msg ="";
                    msg += p.ProcessName;
                    msg += ",";
                    msg += p.MainModule.FileName;
                    msg += ",";
                    msg += p.Id.ToString();
                    msg += ",";
                    msg += p.StartTime.ToString();


                    DateTime startTime = p.StartTime;
                    TimeSpan runTime = DateTime.Now - startTime;

                        msg += ",";
                        msg += runTime.Minutes.ToString();

                        MsgOut(msg);
                    }

                    /*
                    //プロセス名を出力する
                    Console.WriteLine("プロセス名: {0}", p.ProcessName);
                    //ID
                    Console.WriteLine("ID: {0}", p.Id);
                    //メインモジュールのパス
                    Console.WriteLine("ファイル名: {0}", p.MainModule.FileName);
                    //合計プロセッサ時間
                    Console.WriteLine("合計プロセッサ時間: {0}", p.TotalProcessorTime);
                    //物理メモリ使用量
                    Console.WriteLine("物理メモリ使用量: {0}", p.WorkingSet64);
                    //.NET Framework 1.1以前では次のようにする
                    //Console.WriteLine("物理メモリ使用量: {0}", p.WorkingSet);

                    //Console.WriteLine();
                    */
                }
                catch (Exception ex)
                {
                    //MsgOut("エラー: {0}"+ ex.Message);
                }
            }
        }

        private void MsgOut(string msg)
        {
            listBox1.Items.Add(msg);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int cnt=listBox1.Items.Count;
            if (cnt == 0)
            {
                return;
            }
            for (int i = 0; i < cnt; i++)
            {
                string list = listBox1.Items[i].ToString();
                string[] param = list.Split(',');

                string startTime = param[3];

                DateTime stratDate=DateTime.Parse(param[3]);
                TimeSpan runTime = DateTime.Now - stratDate;

                int limit = Int32.Parse(textBox2.Text);


                if (runTime.Minutes > limit)
                {
                    Process[] processes = Process.GetProcessesByName(param[i]);

                    foreach (Process process in processes)
                    {
                        // プロセスを強制終了
                        process.Kill();
                    }
                }

            }
            LoadList();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadList();
        }
    }
}
